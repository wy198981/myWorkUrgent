package com.callNative;


import android.util.Log;

public class CallNative
{

    private static CallNative m_callNative = null;

    private void tcpsdk()
    {

    }

    public static CallNative getInstance()
    {
        if (m_callNative == null)
            m_callNative = new CallNative();
        return m_callNative;
    }


    public native void setSystemTime(String time);

    static
    {
        try
        {
            System.loadLibrary("CallNative");
        }
        catch (UnsatisfiedLinkError e)
        {
            Log.d("CallNative", "load failed");
        }
    }
}
