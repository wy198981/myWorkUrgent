package com.example.administrator.myparkingos.constant;

/**
 * Created by Administrator on 2017-03-08.
 */
public class ColumnName
{
    public static final String c1 = "c1";
    public static final String c2 = "c2";
    public static final String c3 = "c3";
    public static final String c4 = "c4";
    public static final String c5 = "c5";
    public static final String c6 = "c6";
    public static final String c7 = "c7";
    public static final String c8 = "c8";
    public static final String c9 = "c9";
    public static final String c10 = "c10";
    public static final String c11 = "c11";
    public static final String c12 = "c12";
    public static final String c13 = "c13";
    public static final String c14 = "c14";
    public static final String c15 = "c15";
    public static final String c16 = "c16";
    public static final String c17 = "c17";
    public static final String c18 = "c18";
    public static final String c19 = "c19";

    public static final String c20 = "c20";
    public static final String c21 = "c21";
    public static final String c22 = "c22";
    public static final String c23 = "c23";
    public static final String c24 = "c24";
    public static final String c25 = "c25";
    public static final String c26 = "c26";
    public static final String c27 = "c27";
    public static final String c28 = "c28";
    public static final String c29 = "c29";

    public static final String c30 = "c30";
    public static final String c31 = "c31";
    public static final String c32 = "c32";

    public static final String c33 = "c33";
    public static final String c34 = "c34";
    public static final String c35 = "c35";
    public static final String c36 = "c36";

    public static final String c37 = "c37";
}
