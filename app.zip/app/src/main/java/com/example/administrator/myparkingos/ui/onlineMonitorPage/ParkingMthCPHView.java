package com.example.administrator.myparkingos.ui.onlineMonitorPage;

import android.app.Activity;
import android.app.Dialog;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.constant.CR;
import com.example.administrator.myparkingos.constant.QueueMessageTypeEnum;
import com.example.administrator.myparkingos.model.beans.Model;
import com.example.administrator.myparkingos.util.L;
import com.example.sfmudpsdk_android.LoadLsNoX2010znyktOutGateModel;

import java.util.Map;

/**
 * Created by Administrator on 2017-04-10.
 */
public class ParkingMthCPHView implements View.OnClickListener
{
    private final Activity mActivity;
    private Dialog dialog;
    private TextView tvCarNo;
    private TextView tvExitOutName;
    private Button btnMthOk;
    private Button btnMthCancel;
    private Map<String,Object> dataMap;
    private int laneIndex;

    public ParkingMthCPHView(Activity activity, Map<String,Object> inMap)
    {
        this.mActivity = activity;
        this.dataMap = inMap;
        prepare(activity);

    }

    private void prepare(Activity activity)
    {
        dialog = new Dialog(activity); // @android:style/Theme.Dialog
        dialog.setContentView(R.layout.activity_parkingmth_cph);
        dialog.setCanceledOnTouchOutside(true);

        Window window = dialog.getWindow();
        WindowManager m = activity.getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = window.getAttributes(); // 获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 1 / 3); // 改变的是dialog框在屏幕中的位置而不是大小
        p.width = (int) (d.getWidth() * 1 / 3); // 宽度设置为屏幕的0.65
        window.setAttributes(p);

        initView();
        dialog.setTitle(activity.getResources().getString(R.string.tempPlate_title));

        loadData();
    }

    private void loadData()
    {
        laneIndex = (int) dataMap.get("laneIndex");

//        m_hLPRClient = ParkingMonitoring.m_hLPRClient[laneIndex];
//        m_nSerialHandle = ParkingMonitoring.m_nSerialHandle[laneIndex]; // 获取句柄

        tvCarNo.setText((CharSequence) dataMap.get("CPH"));
        tvExitOutName.setText((CharSequence) dataMap.get("InOutName"));

//        cmd = new ParkingCommunication.VoiceSend(ParkingMonitoring.m_hLPRClient, ParkingMonitoring.m_nSerialHandle, 1007, 1005); //发送语音的接口
    }

    private void initView()
    {
        tvCarNo = (TextView) dialog.findViewById(R.id.tvMthCarNo);
        tvExitOutName = (TextView) dialog.findViewById(R.id.tvMthExitOutName);
        btnMthOk = (Button) dialog.findViewById(R.id.btnMthOk);
        btnMthCancel = (Button) dialog.findViewById(R.id.btnMthCancel);

        btnMthOk.setOnClickListener(this);
        btnMthCancel.setOnClickListener(this);
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.btnMthOk:
            {
                CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_OPENGATE, null, laneIndex); //开闸
//                cmd.SendOpen(laneIndex); 发送语音
                if (Model.bOut485)
                {
//                    System.Threading.Thread.Sleep(50);//队列中可以加入时间的延时
                }

                LoadLsNoX2010znyktOutGateModel outGateModel = new LoadLsNoX2010znyktOutGateModel();
                outGateModel.CarTypeenum = CR.getCardTypeEnum(((String) dataMap.get("CardType")).substring(0, 3));
                outGateModel.strCPH = tvCarNo.getText().toString();
                outGateModel.CYkDay = (int) dataMap.get("RemainingDays");
                outGateModel.strCardCW = "FFFF";
                outGateModel.bCtrlShowCW = false;
                CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_LSNOX2010ZNYKTOUTGATE, outGateModel, laneIndex);

                L.e("cmd.QUEUE_LSNOX2010ZNYKTOUTGATE(laneIndex)");
                cancel();
//                cmd.VoiceDisplay(ParkingCommunication.VoiceType.OutGateVoice
// , laneIndex, dicAfferentParameter["CardType"].ToString(), lblCPH.Content.ToString(), Convert.ToInt32(dicAfferentParameter["RemainingDays"]), "FFFF", Convert.ToInt32(dicAfferentParameter["RemainingPlaceCount"]));
                break;
            }
            case R.id.btnMthCancel:
            {
                CR.sendModeToQueue(QueueMessageTypeEnum.queue_SendCombinationVioce, "D4", laneIndex); //这里接口有问题;
                onCancelChargeClick();
                cancel();
                break;
            }
            default:
                break;
        }
    }

    public void onCancelChargeClick()
    {

    }

    public void show()
    {
        if (dialog != null)
        {
            prepareLoadData();// 显示之前加载数据
            dialog.show();
        }
    }

    public void prepareLoadData()
    {

    }

    public void cancel()
    {
        if (dialog != null && dialog.isShowing())
        {
            clearDataInView();
            dialog.cancel();
        }
    }

    private void clearDataInView()
    {
        
    }
}
