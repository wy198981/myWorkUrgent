package com.example.administrator.myparkingos.model.responseInfo;

import java.util.List;

/**
 * Created by Administrator on 2017-06-27.
 */
public class SaveUserAndCardIssueExistInRecordResp
{
    private String rcode; // Y 参考错误码列表
    private String msg; // Y 错误信息
    private List<GetCarInResp.DataBean> data;

    public String getRcode()
    {
        return rcode;
    }

    public void setRcode(String rcode)
    {
        this.rcode = rcode;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg(String msg)
    {
        this.msg = msg;
    }

    public List<GetCarInResp.DataBean> getData()
    {
        return data;
    }

    public void setData(List<GetCarInResp.DataBean> data)
    {
        this.data = data;
    }

    @Override
    public String toString()
    {
        return "SaveUserAndCardIssueExistInRecordResp{" +
                "rcode='" + rcode + '\'' +
                ", msg='" + msg + '\'' +
                ", data=" + data +
                '}';
    }
}
