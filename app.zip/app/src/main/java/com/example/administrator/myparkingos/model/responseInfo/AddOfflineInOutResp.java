package com.example.administrator.myparkingos.model.responseInfo;

/**
 * Created by Administrator on 2017-06-07.
 */
public class AddOfflineInOutResp
{
    private String rcode; // Y 参考错误码列表
    private String msg; // Y 错误信息
    private long data; // N 无意义

    public String getRcode()
    {
        return rcode;
    }

    public void setRcode(String rcode)
    {
        this.rcode = rcode;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg(String msg)
    {
        this.msg = msg;
    }

    public long getData()
    {
        return data;
    }

    public void setData(long data)
    {
        this.data = data;
    }

    @Override
    public String toString()
    {
        return "AddOfflineInOutResp{" +
                "rcode='" + rcode + '\'' +
                ", msg='" + msg + '\'' +
                ", data=" + data +
                '}';
    }
}
