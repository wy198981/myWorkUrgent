package com.example.administrator.myparkingos.ui.loginHintProcess;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.BaseApplication;
import com.example.administrator.myparkingos.HttpPostRequest;
import com.example.administrator.myparkingos.common.data.cipher.Base64Cipher;
import com.example.administrator.myparkingos.constant.CR;
import com.example.administrator.myparkingos.constant.JsonSearchParam;
import com.example.administrator.myparkingos.model.GetServiceData;
import com.example.administrator.myparkingos.model.beans.Model;
import com.example.administrator.myparkingos.model.beans.ThreadMessage;
import com.example.administrator.myparkingos.model.requestInfo.GetPlateNumberDownCmdReq;
import com.example.administrator.myparkingos.model.responseInfo.GetCardIssueResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCheDaoSetResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCommonXXXResp;
import com.example.administrator.myparkingos.model.responseInfo.GetPlateNumberDownBlackListResp;
import com.example.administrator.myparkingos.model.responseInfo.GetPlateNumberDownCardIssueResp;
import com.example.administrator.myparkingos.model.responseInfo.GetPlateNumberDownTempLoadResp;
import com.example.administrator.myparkingos.myUserControlLibrary.MessageBox;
import com.example.administrator.myparkingos.myUserControlLibrary.circleProgress.CircleProgress;
import com.example.administrator.myparkingos.ui.carParkSettingPager.video.SystemState;
import com.example.administrator.myparkingos.util.HttpUtils;
import com.example.administrator.myparkingos.util.L;
import com.google.gson.Gson;

import org.greenrobot.eventbus.EventBus;

import java.net.URLEncoder;
import java.util.Arrays;
import java.util.List;

/**
 * Created by Administrator on 2017-02-16.
 * 【登录界面】 -->> 进入【现在监控界面】 提示信息，带有转动的圆动画
 */
public class ParkingDownCardActvity extends AppCompatActivity
{
    private Base64Cipher base64Cipher;
    private TextView tvValidCarCard;
    private TextView tvTotalNum;
    private GetDownLoadThread downLoadThread;

    public static final String METHOD_GETPLATENUMBERDOWNCMD = "GetPlateNumberDownCmd";
    public static final String METHOD_UPDATECARDISSUE = "UpdateCardIssue";

    private Gson mGson;

    private final int MSG_THREAD_STATE = 0x11;
    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            super.handleMessage(msg);
            if (msg.what == 0x11)
            {
                if (downLoadThread.getRunState() == 2)
                {
                    Intent intent = new Intent(ParkingDownCardActvity.this, ParkingReadRecordActivity.class);
                    startActivity(intent);
                    finish();
                }
                else
                {
                    sendEmptyMessageDelayed(MSG_THREAD_STATE, 1000);
                }
            }
        }
    };

    private CircleProgress circleProgress;
    private Dialog blackListDialog;
    private ImageView ivExit;

    /**
     * 下载类型的枚举
     */
    public enum DownTypeEnum
    {
        CardIssue(0),       // 车牌发行
        CardLoss(1),        // 车牌发行注销
        BlackListIssue(2),  // 车牌黑名单
        BlackListLoss(3),   // 车牌黑名单注销
        ErrorCPH(4);        // 错误车牌更正

        private int mTypeValue;

        DownTypeEnum(int value)
        {
            mTypeValue = value;
        }

        public int getValue()
        {
            return mTypeValue;
        }

        public static DownTypeEnum valueOf(int value)
        {
            switch (value)
            {
                case 0:
                    return CardIssue;
                case 1:
                    return CardLoss;
                case 2:
                    return BlackListIssue;
                case 3:
                    return BlackListLoss;
                case 4:
                    return ErrorCPH;
                default:
                    break;

            }
            return null;
        }
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parkdowncard);

        Window window = getWindow();
        WindowManager m = getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = window.getAttributes(); // 获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 1 / 2); // 改变的是dialog框在屏幕中的位置而不是大小
        p.width = (int) (d.getWidth() * 1 / 2); // 宽度设置为屏幕的0.65
        window.setAttributes(p);

        setTitle("车牌下载");

        base64Cipher = new Base64Cipher();
        mGson = new Gson();
        initView();

        downLoadThread = new GetDownLoadThread();
        mHandler.sendEmptyMessageDelayed(MSG_THREAD_STATE, 1000);
        downLoadThread.start();

    }

    private void initView()
    {
        tvValidCarCard = (TextView) findViewById(R.id.tvValidCarCard);
        tvTotalNum = (TextView) findViewById(R.id.tvTotalNum);
        circleProgress = (CircleProgress) findViewById(R.id.circle_progress_bar);
        circleProgress.setValue(0); // 开始的时候为0

        ivExit = (ImageView) findViewById(R.id.ivExit);
        ivExit.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                finish();
            }
        });
    }


    private int DealCarType = 0; // 0 ,车牌下载，1，车牌注销下载
    private String[] DealCarText = new String[]{"车牌下载", "车牌注销下载"};

    public class GetDownLoadThread extends Thread
    {
        private boolean isRunning = false;
        private int state; // 0 表示开启； 1，表示正在执行，2，表示已经运行完成

        public GetDownLoadThread()
        {
            isRunning = true;
            state = 0;
        }

        @Override
        public void run()
        {
            super.run(); // 还剩下的是对于进度条的更新的问题，即界面显示的问题;
//            while (isRunning)
            state = 1;
            {
                try
                {
                    if (Model.bIsKZB && Model.strKZJ.equals("1"))
                    {
                        downAndLogoutCarCard(DownTypeEnum.CardIssue, 0);

                        downAndLogoutCarCard(DownTypeEnum.CardLoss, 1);

                        correctionIncorrectCarCard(); // 车牌更正

                        downloadBlackList(); // 黑名单下载

                        logoutBlackList();// 黑名单注销

                        Model.Quit_Flag = true;
//                        Model.ReadRecord = 1;
                    }
                }
                catch (Exception ex)
                {
                    ex.printStackTrace();
                }
            }
            state = 2;
//            EventBus.getDefault().post(new ThreadMessage(1));
        }

        public int getRunState()
        {
            return state;
        }
    }

    public String getHttpUrlByDownType(DownTypeEnum typeEnum, String[] CtrlNumberList)
    {
        GetPlateNumberDownCmdReq getPlateNumberDownReq = new GetPlateNumberDownCmdReq();
        getPlateNumberDownReq.setToken(Model.token);
        getPlateNumberDownReq.setStationId(Model.stationID);
        getPlateNumberDownReq.setDownType(typeEnum.getValue());
        getPlateNumberDownReq.setIsRepeatDownload(false);

        String toJson = mGson.toJson(CtrlNumberList);
        String encode = URLEncoder.encode(toJson);

        // 注意CtrlNumberList的数据需要经过转换为Json字符串
        String resultUrl = GetServiceData.getResultUrl(METHOD_GETPLATENUMBERDOWNCMD, getPlateNumberDownReq);

        return resultUrl + "&CtrlNumberList=" + encode;
    }

    public void downAndLogoutCarCard(DownTypeEnum type, int showType)
    {
        String httpUrlByDownType = getHttpUrlByDownType(type, null);

        L.e("httpUrlByDownType:" + httpUrlByDownType);
        String doPost = HttpUtils.doPost(httpUrlByDownType, null);
        L.e("doPost 返回的数据:" + doPost);
        if (doPost != null)
        {
            GetPlateNumberDownCardIssueResp getPlateNumberDownCardIssueResp = mGson.fromJson(doPost, GetPlateNumberDownCardIssueResp.class);
            L.e("getPlateNumberDownResp:" + getPlateNumberDownCardIssueResp);
            //直接处理数据即可
            if (!getPlateNumberDownCardIssueResp.getRcode().equals("200"))
            {
                L.e("getPlateNumberDownResp.getMsg():" + getPlateNumberDownCardIssueResp.getMsg());
                return;
            }

            if (getPlateNumberDownCardIssueResp.getData() == null || getPlateNumberDownCardIssueResp.getData().size() == 0)
            {
                L.e("getPlateNumberDownResp.getData() == null || getPlateNumberDownResp.getData().size() == 0");
                return;
            }

            dealCardIssue(getPlateNumberDownCardIssueResp.getData(), showType);
        }
    }

    /**
     * 更正错误车牌 (什么时候来触发这个操作)
     */
    private void correctionIncorrectCarCard()
    {
        String httpUrlByDownType = getHttpUrlByDownType(DownTypeEnum.ErrorCPH, null);
        L.e("httpUrlByDownType:" + httpUrlByDownType);
        String doPost = HttpUtils.doPost(httpUrlByDownType, null);
        L.e("doPost 返回的数据:" + doPost);
        if (doPost != null)
        {
            GetPlateNumberDownTempLoadResp getPlateNumberDownTempLoadResp = mGson.fromJson(doPost, GetPlateNumberDownTempLoadResp.class);
            L.e("getPlateNumberDownResp:" + getPlateNumberDownTempLoadResp);
            //直接处理数据即可
            if (!getPlateNumberDownTempLoadResp.getRcode().equals("200"))
            {
                L.e("getPlateNumberDownResp.getMsg():" + getPlateNumberDownTempLoadResp.getMsg());
                return;
            }

            if (getPlateNumberDownTempLoadResp.getData() == null || getPlateNumberDownTempLoadResp.getData().size() == 0)
            {
                L.e("getPlateNumberDownResp.getData() == null || getPlateNumberDownResp.getData().size() == 0");
                return;
            }

            dealInCorrentCarCard(getPlateNumberDownTempLoadResp.getData());
        }
    }

    private void dealInCorrentCarCard(List<GetPlateNumberDownTempLoadResp.Bean> respBean)
    {
        updateProgressValue(0);

        updateUIAsync("错误车牌号码更正", String.valueOf(respBean.size()));

        for (int i = 0; i < respBean.size(); i++)
        {
            GetPlateNumberDownTempLoadResp.Bean temp = respBean.get(i);

            String oldstr = "";
            String newstr = "";

            List<GetCheDaoSetResp.DataBean> lstCDS = temp.getLstCDS();
            for (GetCheDaoSetResp.DataBean tempCheDao : lstCDS)
            {
                oldstr += "1";
                String ret = "";

                if (tempCheDao.DownCmdList.size() > 0)
                {
                    long currentTime = System.currentTimeMillis();
                    while (System.currentTimeMillis() - currentTime < Model.iDelayed * 1000)
                    {
//                        sendbll.SetUsbType(ref usbHid, lstATDL[i].lstCDS[j].XieYi); // 又对应的那个接口呢?
                        ret = SendDownCmd(tempCheDao.getIP(), base64Cipher.decrypt(tempCheDao.DownCmdList.get(0).getBytes()));
                        final String returnValue = ret;
                        if (!ret.equals("2"))
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    setValidCarCardText("错误车牌号码下载");
                                    if (returnValue.equals("5"))
                                    {
                                        setValidCarCardText("用户数据已满");
                                        return;
                                    }
                                }
                            });
                            break;
                        }
                        else
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    setValidCarCardText("连接中断..");
                                }
                            });
                        }
                    }
                    if (ret.equals("0"))
                    {
                        newstr += "1";
                    }
                    else
                    {
                        mHandler.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                if (blackListDialog == null)
                                {
                                    blackListDialog = MessageBox.create(ParkingDownCardActvity.this, "与控制机通讯不通");
                                }
                                blackListDialog.show();
                            }
                        });
                        return;
                    }
                }
            }

            if (oldstr.equals(newstr))
            {
                String sumBiao = temp.getModel().getDownloadSignal().substring(0, Model.stationID - 1) + "1" + temp.getModel().getDownloadSignal().substring(Model.stationID);
                HttpPostRequest.requestUpdateAutoCPHDownLoad((int) temp.getModel().getID(), sumBiao);
            }

            int precent = (i + 1) * 100 / respBean.size(); // 表示进度，可以用来更新进度条

            updateProgressValue(precent);
        }
    }


    /**
     * 下载黑名单
     */
    private void downloadBlackList()
    {
        String httpUrlByDownType = getHttpUrlByDownType(DownTypeEnum.BlackListIssue, null);
        L.e("httpUrlByDownType:" + httpUrlByDownType);
        String doPost = HttpUtils.doPost(httpUrlByDownType, null);
        L.e("doPost 返回的数据:" + doPost);
        if (doPost != null)
        {
            GetPlateNumberDownBlackListResp getPlateNumberDownBlackListResp = mGson.fromJson(doPost, GetPlateNumberDownBlackListResp.class);
            L.e("getPlateNumberDownResp:" + getPlateNumberDownBlackListResp);
            //直接处理数据即可
            if (!getPlateNumberDownBlackListResp.getRcode().equals("200"))
            {
                L.e("getPlateNumberDownResp.getMsg():" + getPlateNumberDownBlackListResp.getMsg());
                return;
            }

            if (getPlateNumberDownBlackListResp.getData() == null || getPlateNumberDownBlackListResp.getData().size() == 0)
            {
                L.e("getPlateNumberDownResp.getData() == null || getPlateNumberDownResp.getData().size() == 0");
                return;
            }

            dealBlackListIssue(getPlateNumberDownBlackListResp.getData());
        }
    }

    /**
     * 注销黑名单
     */
    private void logoutBlackList()
    {
        String httpUrlByDownType = getHttpUrlByDownType(DownTypeEnum.BlackListLoss, null);
        L.e("httpUrlByDownType:" + httpUrlByDownType);
        String doPost = HttpUtils.doPost(httpUrlByDownType, null);
        L.e("doPost 返回的数据:" + doPost);
        if (doPost != null)
        {
            GetPlateNumberDownBlackListResp getPlateNumberDownBlackListResp = mGson.fromJson(doPost, GetPlateNumberDownBlackListResp.class);
            L.e("getPlateNumberDownResp:" + getPlateNumberDownBlackListResp);
            //直接处理数据即可
            if (!getPlateNumberDownBlackListResp.getRcode().equals("200"))
            {
                L.e("getPlateNumberDownResp.getMsg():" + getPlateNumberDownBlackListResp.getMsg());
                return;
            }

            if (getPlateNumberDownBlackListResp.getData() == null || getPlateNumberDownBlackListResp.getData().size() == 0)
            {
                L.e("getPlateNumberDownResp.getData() == null || getPlateNumberDownResp.getData().size() == 0");
                return;
            }
            dealBlackListLoss(getPlateNumberDownBlackListResp.getData());
        }
    }

    private void updateProgressValue(final int value)
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                circleProgress.setValue(value);
            }
        });
    }

    public void updateUIAsync(final String showText, final String countText)
    {
        // 更新界面数据
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                setValidCarCardText(showText);
                setTotalNumText(countText);
            }
        });
    }

    /**
     * 处理服务器返回的车牌发行
     *
     * @param respBean
     */
    private void dealCardIssue(List<GetPlateNumberDownCardIssueResp.Bean> respBean, final int showType)
    {
        L.e("respBean.size():" + respBean.size());
        updateUIAsync(DealCarText[showType], String.valueOf(respBean.size()));

        updateProgressValue(0);

        for (int i = 0; i < respBean.size(); i++)
        {
            GetPlateNumberDownCardIssueResp.Bean temp = respBean.get(i);
            String oldstr = "";
            String newstr = "";

            List<GetCheDaoSetResp.DataBean> lstCDS = temp.getLstCDS();
            GetCardIssueResp.DataBean model = temp.getModel();
            L.e("lstCDS size:" + lstCDS.size());
            for (GetCheDaoSetResp.DataBean tempCheDao : lstCDS)
            {
                oldstr += "1";
                String ret = "";

                if (tempCheDao.DownCmdList.size() > 0)
                {
                    long currentTime = System.currentTimeMillis();
                    while (System.currentTimeMillis() - currentTime < Model.iDelayed * 1000)
                    {
                        byte[] decrypt = base64Cipher.decrypt(tempCheDao.DownCmdList.get(0).getBytes());
                        L.e("debug", Arrays.toString(decrypt) + "tempCheDao.getIP():" + tempCheDao.getIP());

                        ret = SendDownCmd(tempCheDao.getIP(), base64Cipher.decrypt(tempCheDao.DownCmdList.get(0).getBytes()));
//                        ret = BaseApplication.getUdpSend().SendDownCmd(tempCheDao.getIP(), base64Cipher.decrypt(tempCheDao.DownCmdList.get(0).getBytes()));
                        L.e("ret:" + ret);
                        final String returnValue = ret;
                        if (!ret.equals("2"))
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    setValidCarCardText(DealCarText[showType]);
                                    if (returnValue.equals("5"))
                                    {
                                        setValidCarCardText("用户数据已满");
                                        return;
                                    }
                                }
                            });
                            break;
                        }
                        else
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    setValidCarCardText("连接中断..");
                                }
                            });
                        }
                    }
                    if (ret.equals("0"))
                    {
                        newstr += "1";
                    }
                    else
                    {
                        mHandler.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                if (blackListDialog == null)
                                {
                                    blackListDialog = MessageBox.create(ParkingDownCardActvity.this, "与控制机通讯不通");
                                }
                                blackListDialog.show();
                            }
                        });
                        return;
                    }
                }
            }

            L.e("oldstr:" + oldstr + ",newstr:" + newstr);
            if (oldstr.equals(newstr))
            {
                L.e("model:", model.toString());
                String sumBiao = model.getCPHDownloadSignal().substring(0, Model.stationID - 1) + "1" + model.getCPHDownloadSignal().substring(Model.stationID);
                L.e("sumBiao:" + sumBiao);
                HttpPostRequest.requestUpdateCPHDownLoad((int) model.getID(), sumBiao);// 这里会相应的改变数据库中的数据信息
            }

            if (showType == 1)
            {
                for (int j = 0; j < temp.getLstCDS().size(); j++)
                {
                    if (temp.getLstCDS().get(j).DownCmdList.size() > 1)
                    {
                        SendDownCmd(temp.getLstCDS().get(j).getIP(), base64Cipher.decrypt(temp.getLstCDS().get(j).DownCmdList.get(1).getBytes()));
                    }
                }
            }

            final int precent = (i + 1) * 100 / respBean.size(); // 表示进度，可以用来更新进度条
            updateProgressValue(precent);
            SystemClock.sleep(50);// 延时50ms
        }
    }


    /**
     * 处理服务器返回黑名单信息
     */
    private void dealBlackListIssue(List<GetPlateNumberDownBlackListResp.Bean> respBean)
    {
        updateUIAsync("黑名单下载", String.valueOf(respBean.size()));

        updateProgressValue(0);
        for (int i = 0; i < respBean.size(); i++)
        {
            GetPlateNumberDownBlackListResp.Bean temp = respBean.get(i);

            String oldstr = "";
            String newstr = "";

            List<GetCheDaoSetResp.DataBean> lstCDS = temp.getLstCDS();
            for (GetCheDaoSetResp.DataBean tempCheDao : lstCDS)
            {
                oldstr += "1";
                String ret = "";

                if (tempCheDao.DownCmdList.size() > 0)
                {
                    long currentTime = System.currentTimeMillis();
                    while (System.currentTimeMillis() - currentTime < Model.iDelayed * 1000)
                    {
//                        sendbll.SetUsbType(ref usbHid, lstBL[i].lstCDS[j].XieYi); // ?????
                        ret = SendDownCmd(tempCheDao.getIP(), base64Cipher.decrypt(tempCheDao.DownCmdList.get(0).getBytes()));
                        final String returnValue = ret;
                        if (!ret.equals("2"))
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    setValidCarCardText("黑名单下载");
                                    if (returnValue.equals("5"))
                                    {
                                        setValidCarCardText("用户数据已满");
                                        return;
                                    }
                                }
                            });
                            break;
                        }
                        else
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    setValidCarCardText("连接中断..");
                                }
                            });
                        }
                    }
                    if (ret.equals("0"))
                    {
                        newstr += "1";
                    }
                    else
                    {
                        mHandler.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                if (blackListDialog == null)
                                {
                                    blackListDialog = MessageBox.create(ParkingDownCardActvity.this, "与控制机通讯不通");
                                }
                                blackListDialog.show();
                            }
                        });
                        return;
                    }
                }
            }
            L.e("oldstr:" + oldstr + ",newstr:" + newstr);
            if (oldstr.equals(newstr))
            {
                String sumBiao = temp.getModel().getDownloadSignal().substring(0, Model.stationID - 1) + "1" + temp.getModel().getDownloadSignal().substring(Model.stationID);
                HttpPostRequest.requestBlackListDownload((int) temp.getModel().getID(), sumBiao);
            }
            int precent = (i + 1) * 100 / respBean.size(); // 表示进度，可以用来更新进度条
            updateProgressValue(precent);
        }
    }

    /**
     * 处理服务器返回的黑名单注销信息
     */
    private void dealBlackListLoss(List<GetPlateNumberDownBlackListResp.Bean> respBean)
    {
        updateUIAsync("黑名单删除下载", String.valueOf(respBean.size()));

        updateProgressValue(0);
        for (int i = 0; i < respBean.size(); i++)
        {
            GetPlateNumberDownBlackListResp.Bean temp = respBean.get(i);

            String oldstr = "";
            String newstr = "";

            List<GetCheDaoSetResp.DataBean> lstCDS = temp.getLstCDS();
            for (GetCheDaoSetResp.DataBean tempCheDao : lstCDS)
            {
                oldstr += "1";
                String ret = "";

                if (tempCheDao.DownCmdList.size() > 0)
                {
                    long currentTime = System.currentTimeMillis();
                    while (System.currentTimeMillis() - currentTime < Model.iDelayed * 1000)
                    {
                        ret = SendDownCmd(tempCheDao.getIP(), base64Cipher.decrypt(tempCheDao.DownCmdList.get(0).getBytes()));
//                        sendbll.SetUsbType(ref usbHid, lstBL[i].lstCDS[j].XieYi);// 什么接口来替换
                        final String returnValue = ret;
                        if (!ret.equals("2"))
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    setValidCarCardText("黑名单删除下载");
                                    if (returnValue.equals("5"))
                                    {
                                        setValidCarCardText("用户数据已满");
                                        return;
                                    }
                                }
                            });
                            break;
                        }
                        else
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    setValidCarCardText("连接中断..");
                                }
                            });
                        }
                    }
                    if (ret.equals("0"))
                    {
                        newstr += "1";
                    }
                    else
                    {
                        mHandler.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                if (blackListDialog == null)
                                {
                                    blackListDialog = MessageBox.create(ParkingDownCardActvity.this, "与控制机通讯不通");
                                }
                                blackListDialog.show();
                            }
                        });
                        return;
                    }
                }
            }

            if (oldstr.equals(newstr))
            {
                String sumBiao = temp.getModel().getDownloadSignal().substring(0, Model.stationID - 1) + "0" + temp.getModel().getDownloadSignal().substring(Model.stationID);
                if (sumBiao.equals(CR.stringPadLeft("", sumBiao.length(), '0')))
//                if (sumBiao == ("").PadLeft(sumTBiao.Length, '0'))
                {
//                    gsd.DeleteMYBlacklist(lstBL[i].model.ID);
                    HttpPostRequest.requestDeleteMyBlacklist((int) temp.getModel().getID());
                }
                else
                {
                    HttpPostRequest.requestBlackListDownload((int) temp.getModel().getID(), sumBiao);
                }
            }
            int precent = (i + 1) * 100 / respBean.size(); // 表示进度，可以用来更新进度条
            updateProgressValue(precent);
        }
    }


    private void setValidCarCardText(String text)
    {
        tvValidCarCard.setText(text);
    }

    public void setTotalNumText(String countContent)
    {
        tvTotalNum.setText(countContent);
    }

    public String SendDownCmd(String strIP, byte[] bData)
    {
        synchronized (ParkingDownCardActvity.class)
        {
            return BaseApplication.getUdpSend().SendDownCmd(strIP, bData);
        }
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        if (blackListDialog != null)
        {
            blackListDialog.dismiss();
        }

        if (circleProgress != null)
        {
            circleProgress.stopNestedScroll();
        }
        mHandler.removeCallbacksAndMessages(null);
    }
}
