package com.example.administrator.myparkingos.ui.carParkSettingPager.video;

/**
 * Created by Administrator on 2017-02-16.
 *
 * 【车场设置】 -->> 【设备管理】 -->>【摄像机管理】 -->> 【线圈配置】 -->> 【规则配置】
 */
public class RuleCfg_Form
{
}
