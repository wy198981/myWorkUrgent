package com.example.administrator.myparkingos.ui.carParkSettingPager.video;

/**
 * Created by Administrator on 2017-02-16.
 * 【车场设置】 -->> 【设备管理】 -->>【摄像机管理】 -->> 【视频配置】
 */
public class VideoCfg_Form
{
}
