package com.example.administrator.myparkingos.ui.loginHintProcess;

import android.app.Activity;
import android.app.Dialog;
import android.os.Handler;
import android.view.Display;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.BaseApplication;
import com.example.administrator.myparkingos.constant.JsonSearchParam;
import com.example.administrator.myparkingos.model.GetServiceData;
import com.example.administrator.myparkingos.model.RequestByURL;
import com.example.administrator.myparkingos.model.beans.Model;
import com.example.administrator.myparkingos.model.beans.ThreadMessage;
import com.example.administrator.myparkingos.model.requestInfo.AddOfflineInOutReq;
import com.example.administrator.myparkingos.model.responseInfo.AddOfflineInOutResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCheDaoSetResp;
import com.example.administrator.myparkingos.myUserControlLibrary.MessageBox;
import com.example.administrator.myparkingos.util.HttpUtils;
import com.example.administrator.myparkingos.util.L;
import com.google.gson.Gson;

import org.greenrobot.eventbus.EventBus;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017-02-16.
 * 【登录界面】 -->> 【在线监控】 车场进入监控的提示信息
 */
public class ParkingReadRecordView
{
    private final Activity mActivity;
    private final Dialog dialog;
    private final ReadCardThread readCardThread;
    private final Gson mGson;
    private TextView tvLaneName;
    private TextView tvChannelIP;
    private TextView tvChannelNo;
    private TextView tvRecordNum;
    private int SumCount = 0;
    private TextView tvLoadingText;

    private final static String METHOD_ADDOFFLINEINOUT = "AddOfflineInOut";

    public ParkingReadRecordView(Activity activity)
    {
        this.mActivity = activity;

        dialog = new Dialog(activity); // @android:style/Theme.Dialog
        dialog.setContentView(R.layout.activity_readrecord);
        dialog.setCanceledOnTouchOutside(true);

        Window window = dialog.getWindow();
        WindowManager m = activity.getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = window.getAttributes(); // 获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 2 / 3); // 改变的是dialog框在屏幕中的位置而不是大小
        p.width = (int) (d.getWidth() * 2 / 3); // 宽度设置为屏幕的0.65
        window.setAttributes(p);

        initView();
        dialog.setTitle("");
        mGson = new Gson();
        // 开启一个读的线程来获取相应的信息；
        readCardThread = new ReadCardThread();
        readCardThread.start();
    }

    private void initView()
    {
        tvLoadingText = (TextView) dialog.findViewById(R.id.tvLoadingText);
        tvLaneName = (TextView) dialog.findViewById(R.id.tvLaneName);
        tvChannelIP = (TextView) dialog.findViewById(R.id.tvChannelIP);
        tvChannelNo = (TextView) dialog.findViewById(R.id.tvChannelNo);
        tvRecordNum = (TextView) dialog.findViewById(R.id.tvRecordNum);
    }

    public class ReadCardThread extends Thread
    {
        @Override
        public void run()
        {
            super.run();
            try
            {
                String getCheDaoSet = JsonSearchParam.getCtrlNameFields("GetCheDaoSet", Model.token, Model.stationID);
                String resultUrl = GetServiceData.generateResultUrl(getCheDaoSet, null);

                L.e("resultUrl:" + resultUrl);
                String doPost = HttpUtils.doPost(resultUrl, null);
                L.e("doPost:" + doPost);
                if (doPost == null)
                {
                    return;
                }

                GetCheDaoSetResp getCheDaoSetResp = mGson.fromJson(doPost, GetCheDaoSetResp.class);
                if (!getCheDaoSetResp.getRcode().equals("200"))
                {
                    L.e("getCheDaoSetResp.getMsg():" + getCheDaoSetResp.getMsg());
                    return;
                }

                if (getCheDaoSetResp.getData() == null || getCheDaoSetResp.getData().size() == 0)
                {
                    L.e("getCheDaoSetResp.getData() == null || getCheDaoSetResp.getData().size() == 0");
                    return;
                }
                dealCheDaoSet(getCheDaoSetResp.getData());
            }
            catch (Exception ex)
            {
                ex.printStackTrace();
            }
            EventBus.getDefault().post(new ThreadMessage(2));
        }
    }

    private void dealCheDaoSet(List<GetCheDaoSetResp.DataBean> data)
    {
        L.e("data:" + data.toString());
        int read = 0;
        for (GetCheDaoSetResp.DataBean cheDaoItem : data)
        {
            read++;
            updateUIAsync(cheDaoItem.getInOutName(), cheDaoItem.getIP()
                    , String.valueOf(cheDaoItem.getCtrlNumber()), String.valueOf(SumCount));

            int XieYi = cheDaoItem.getXieYi();
            String Count = "0";

            if (XieYi == 1 || XieYi == 3)
            {
                long currentTime = System.currentTimeMillis();
                while (System.currentTimeMillis() - currentTime <= Model.iDelayed * 1000)
                {
                    //                sendbll.SetUsbType(ref usbHid, XieYi);  //2015-09-18
                    Count = BaseApplication.getUdpSend().ReadRecordCount(cheDaoItem.getIP(), cheDaoItem.getCtrlNumber());// 读取记录数
                    L.e("cheDaoItem.getIP():" + cheDaoItem.getIP() + ":Count:" + Count);
                    if (!Count.equals("-2"))
                    {
                        mHandler.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                tvLoadingText.setText("正在加载...");
                            }
                        });
                        break;
                    }
                    else
                    {
                        mHandler.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                tvLoadingText.setText("链接中断...");
                            }
                        });
                    }
                }
            }

            if (Count.equals("-2"))
            {
                MessageBox.show(mActivity, "与控制机通讯不通!\\n请检查通讯链接后重新提取脱机记录！", "通讯不通");
            }

            SumCount = Integer.parseInt(Count);
            List<String> offlineCmdList = new ArrayList<String>();
            for (int i = 0; i < SumCount; i++)
            {
                String Data = "";
                if (XieYi == 1 || XieYi == 3)
                {
                    long currentTime = System.currentTimeMillis();
                    while (System.currentTimeMillis() - currentTime <= Model.iDelayed * 1000)
                    {
//                        sendbll.SetUsbType(ref usbHid, XieYi);
                        Data = BaseApplication.getUdpSend().ReadRecordEx(cheDaoItem.getIP(), cheDaoItem.getCtrlNumber());//提取脱机记录
                        L.e("cheDaoItem.getIP():" + cheDaoItem.getIP() + "Data:" + Data);
                        if (!Data.equals("2"))
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    tvLoadingText.setText("正在加载...");
                                }
                            });
                            break;
                        }
                        else
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    tvLoadingText.setText("链接中断...");
                                }
                            });
                        }
                    }
                }

                if (!Data.equals("2"))
                {
                    offlineCmdList.add(Data);
                }
            }

            List<String> OfflineCmdTmp = new ArrayList<String>();
            int m = offlineCmdList.size();

            for (int j = 0; j < offlineCmdList.size(); j++)
            {
                m--;
                OfflineCmdTmp.add(offlineCmdList.get(j));
                if (OfflineCmdTmp.size() >= 10)
                {
                    long ret = requestAddOfflineInOut(cheDaoItem.getCtrlNumber(), OfflineCmdTmp);
//                    long ret = req.AddOfflineInOut<long>(Model.token, Model.stationID, dr.CtrlNumber, OfflineCmdTmp);// 服务器请求
                    if (ret > 0)
                    {
                        int precent = (j + 1) * 100 / Integer.parseInt(Count);
                        OfflineCmdTmp.clear();
                    }
                    else
                    {
                        break;
                    }
                }
                else
                {
                    if (m == 0)
                    {
                        long ret = requestAddOfflineInOut(cheDaoItem.getCtrlNumber(), OfflineCmdTmp);
//                        long ret = req.AddOfflineInOut<long>(Model.token, Model.stationID, dr.CtrlNumber, OfflineCmdTmp);
                        if (ret > 0)
                        {
                            int precent = (j + 1) * 100 / Integer.parseInt(Count);
                        }
                        else
                        {
                            break;
                        }
                    }
                }
            }

        }
    }

    private Handler mHandler = new Handler();

    public void updateUIAsync(final String InOutName, final String IP, final String CtrlNumber, final String SumCount)
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                tvLaneName.setText(InOutName);
                tvChannelIP.setText(IP);
                tvChannelNo.setText(CtrlNumber);
                tvRecordNum.setText(SumCount);
            }
        });
    }

    /**
     * 向服务器请求添加离线记录接口
     */
    public long requestAddOfflineInOut(int CtrlNumber, List<String> DataList)
    {
        AddOfflineInOutReq addOfflineInOutReq = new AddOfflineInOutReq();
        addOfflineInOutReq.setToken(Model.token);
        addOfflineInOutReq.setCtrlNumber(CtrlNumber);
        addOfflineInOutReq.setStationId(Model.stationID);

        //对于dataList来说需要先转换为gson字符串
        String toJson = mGson.toJson(DataList);
        String encode = URLEncoder.encode(toJson);

        // 注意CtrlNumberList的数据需要经过转换为Json字符串
        String tempUrl = GetServiceData.getResultUrl(METHOD_ADDOFFLINEINOUT, addOfflineInOutReq);
        String resultURL = tempUrl + "&DataList=" + encode;

        L.e("resultURL:" + resultURL);
        String doPost = HttpUtils.doPost(resultURL, null);
        if (doPost == null)
        {
            return -1;
        }

        L.e("doPost:" + doPost);
        AddOfflineInOutResp addOfflineInOutResp = mGson.fromJson(doPost, AddOfflineInOutResp.class);
        return addOfflineInOutResp.getData();
    }

    public void show()
    {
        if (dialog != null && !dialog.isShowing())
        {
            dialog.show();
        }
    }

    public void dismiss()
    {
        if (dialog != null && dialog.isShowing())
        {
            dialog.dismiss();
        }
    }
}
