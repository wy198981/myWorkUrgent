package com.example.administrator.myparkingos.model.responseInfo;

/**
 * Created by Administrator on 2017-07-05.
 */
public class GetWorkHandoverPrintResp
{
    private String rcode;//		Y	参考错误码列表
    private String msg;//   	Y	错误信息
    private SetWorkHandoverResp.Handover data;// N	换班记录Model结构

    @Override
    public String toString()
    {
        return "GetWorkHandoverPrintResp{" +
                "rcod='" + rcode + '\'' +
                ", msg='" + msg + '\'' +
                ", data=" + data +
                '}';
    }

    public String getRcode()
    {
        return rcode;
    }

    public void setRcod(String rcode)
    {
        this.rcode = rcode;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg(String msg)
    {
        this.msg = msg;
    }

    public SetWorkHandoverResp.Handover getData()
    {
        return data;
    }

    public void setData(SetWorkHandoverResp.Handover data)
    {
        this.data = data;
    }
}
