package com.example.administrator.myparkingos.model.requestInfo;

/**
 * Created by Administrator on 2017-05-08.
 */
public class KeepAliveReq
{
    private String token; // Y 用户登录时候获取的token值
    private String CallBack; // N 是否使用JSONP方式。关于JSONP方式请参考Javascript跨域访问一节。

    public KeepAliveReq(String token)
    {
        this.token = token;
    }

    public KeepAliveReq()
    {
    }

    public String getToken()
    {
        return token;
    }

    public void setToken(String token)
    {
        this.token = token;
    }

    public String getCallBack()
    {
        return CallBack;
    }

    @Override
    public String toString()
    {
        return "KeepAliveReq{" +
                "token='" + token + '\'' +
                ", CallBack='" + CallBack + '\'' +
                '}';
    }
}
