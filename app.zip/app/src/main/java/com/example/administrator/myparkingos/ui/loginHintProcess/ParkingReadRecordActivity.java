package com.example.administrator.myparkingos.ui.loginHintProcess;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.BaseApplication;
import com.example.administrator.myparkingos.HttpPostRequest;
import com.example.administrator.myparkingos.constant.JsonSearchParam;
import com.example.administrator.myparkingos.model.GetServiceData;
import com.example.administrator.myparkingos.model.beans.Model;
import com.example.administrator.myparkingos.model.beans.ThreadMessage;
import com.example.administrator.myparkingos.model.requestInfo.AddOfflineInOutReq;
import com.example.administrator.myparkingos.model.responseInfo.AddOfflineInOutResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCheDaoSetResp;
import com.example.administrator.myparkingos.myUserControlLibrary.MessageBox;
import com.example.administrator.myparkingos.myUserControlLibrary.circleProgress.CircleProgress;
import com.example.administrator.myparkingos.ui.onlineMonitorPage.ParkingMonitoringActivity;
import com.example.administrator.myparkingos.util.HttpUtils;
import com.example.administrator.myparkingos.util.L;
import com.example.sfmudpsdk_android.RecordModel;
import com.example.sfmudpsdk_android.UDPSendbll;
import com.google.gson.Gson;

import org.greenrobot.eventbus.EventBus;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017-06-05.
 */
public class ParkingReadRecordActivity extends AppCompatActivity
{
    private TextView tvLaneName;
    private TextView tvChannelIP;
    private TextView tvChannelNo;
    private TextView tvRecordNum;
    private Gson mGson;
    private ReadCardThread readCardThread;
    private TextView tvLoadingText;


    private final static String METHOD_ADDOFFLINEINOUT = "AddOfflineInOut";

    private final int MSG_THREAD_STATE = 0x11;
    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            super.handleMessage(msg);
            if (msg.what == 0x11)
            {
                if (readCardThread.getRunState() == 2)
                {
                    Intent intent = new Intent(ParkingReadRecordActivity.this, ParkingMonitoringActivity.class);
                    startActivity(intent);
                    finish();
                }
                else
                {
                    sendEmptyMessageDelayed(MSG_THREAD_STATE, 1000);
                }
            }
        }
    };
    private CircleProgress circleProgress;
    private Dialog dialog;
    private ImageView ivExit;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_readrecord);


        Window window = getWindow();
        WindowManager m = getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = window.getAttributes(); // 获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 2 / 3); // 改变的是dialog框在屏幕中的位置而不是大小
        p.width = (int) (d.getWidth() * 2 / 3); // 宽度设置为屏幕的0.65
        window.setAttributes(p);
        initView();

        mGson = new Gson();
        // 开启一个读的线程来获取相应的信息；
        readCardThread = new ReadCardThread();
        mHandler.sendEmptyMessageDelayed(MSG_THREAD_STATE, 1000);
        readCardThread.start();

    }

    private void initView()
    {
        tvLoadingText = (TextView) findViewById(R.id.tvLoadingText);
        tvLaneName = (TextView) findViewById(R.id.tvLaneName);
        tvChannelIP = (TextView) findViewById(R.id.tvChannelIP);
        tvChannelNo = (TextView) findViewById(R.id.tvChannelNo);
        tvRecordNum = (TextView) findViewById(R.id.tvRecordNum);
        circleProgress = (CircleProgress) findViewById(R.id.circleProgress);
        circleProgress.setValue(0);

        ivExit = (ImageView) findViewById(R.id.ivExit);
        ivExit.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                finish();
            }
        });
    }

    public class ReadCardThread extends Thread
    {
        private int state; // 0 表示开启； 1，表示正在执行，2，表示已经运行完成

        public ReadCardThread()
        {
            state = 0;
        }

        @Override
        public void run()
        {
            super.run();
            state = 1;
            try
            {
                String getCheDaoSet = JsonSearchParam.getCtrlNameFields("GetCheDaoSet", Model.token, Model.stationID);
                String resultUrl = GetServiceData.generateResultUrl(getCheDaoSet, null);

                L.e("resultUrl:" + resultUrl);
                String doPost = HttpUtils.doPost(resultUrl, null);
                L.e("doPost:" + doPost);
                if (doPost == null)
                {
                    state = 2;
                    return;
                }

                GetCheDaoSetResp getCheDaoSetResp = mGson.fromJson(doPost, GetCheDaoSetResp.class);
                if (!getCheDaoSetResp.getRcode().equals("200"))
                {
                    L.e("getCheDaoSetResp.getMsg():" + getCheDaoSetResp.getMsg());
                    state = 2;
                    return;
                }

                if (getCheDaoSetResp.getData() == null || getCheDaoSetResp.getData().size() == 0)
                {
                    L.e("getCheDaoSetResp.getData() == null || getCheDaoSetResp.getData().size() == 0");
                    state = 2;
                    return;
                }
                dealCheDaoSet(getCheDaoSetResp.getData());
            }
            catch (Exception ex)
            {
                ex.printStackTrace();
            }
//            EventBus.getDefault().post(new ThreadMessage(2));
            state = 2;
        }

        public int getRunState()
        {
            return state;
        }
    }

    private int SumCount = 0;

    private void dealCheDaoSet(List<GetCheDaoSetResp.DataBean> data)
    {
        L.e("data:" + data.toString());
        int read = 0;
        for (GetCheDaoSetResp.DataBean cheDaoItem : data)
        {
            read++;
            updateUIAsync(cheDaoItem.getInOutName(), cheDaoItem.getIP()
                    , String.valueOf(cheDaoItem.getCtrlNumber()), String.valueOf(SumCount));

            int XieYi = cheDaoItem.getXieYi();
            String Count = "0";

            if (XieYi == 1 || XieYi == 3)
            {
                long currentTime = System.currentTimeMillis();
                while (System.currentTimeMillis() - currentTime <= Model.iDelayed * 1000)
                {
                    //                sendbll.SetUsbType(ref usbHid, XieYi);  //2015-09-18
                    Count = readRecordCount(cheDaoItem.getIP(), cheDaoItem.getCtrlNumber()); // 读记录数
                    L.e("cheDaoItem.getIP():" + cheDaoItem.getIP() + ", Count:" + Count);
                    if (!Count.equals("-3"))
                    {
                        mHandler.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                tvLoadingText.setText("正在加载...");
                            }
                        });
                        break;
                    }
                    else
                    {
                        mHandler.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                tvLoadingText.setText("链接中断...");
                            }
                        });
                    }
                }
            }

            if (Count.equals("-3"))
            {
//                MessageBox.show(ParkingReadRecordActivity.this, "与控制机通讯不通!\\n请检查通讯链接后重新提取脱机记录！", "通讯不通");
                if (dialog == null)
                {
                    dialog = MessageBox.create(ParkingReadRecordActivity.this, "与控制机通讯不通!\\n请检查通讯链接后重新提取脱机记录！", "通讯不通");
                }
                dialog.show(); // 退出时，需要dialog.dimiss
            }


            SumCount = Integer.parseInt(Count);
            L.e("SumCount:" + SumCount);
            List<String> offlineCmdList = new ArrayList<String>();
            for (int i = 0; i < SumCount; i++)
            {
                String Data = "";
                if (XieYi == 1 || XieYi == 3)
                {
                    long currentTime = System.currentTimeMillis();
                    while (currentTime + Model.iDelayed * 1000 >= System.currentTimeMillis())
                    {
//                        sendbll.SetUsbType(ref usbHid, XieYi);
                        Data = readRecord(cheDaoItem.getIP(), cheDaoItem.getCtrlNumber());
                        L.e("cheDaoItem.getIP():" + cheDaoItem.getIP() + ", Data:" + Data);
                        if (!Data.equals("-3"))
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    tvLoadingText.setText("正在加载...");
                                }
                            });
                            break;
                        }
                        else
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    tvLoadingText.setText("链接中断...");
                                }
                            });
                        }
                    }
                }

                if (!Data.equals("-3"))
                {
                    offlineCmdList.add(Data);
                }

                List<String> OfflineCmdTmp = new ArrayList<String>();
                int m = offlineCmdList.size();

                for (int j = 0; j < offlineCmdList.size(); j++)
                {
                    m--;
                    OfflineCmdTmp.add(offlineCmdList.get(j));
                    if (OfflineCmdTmp.size() >= 10)
                    {
                        long ret = HttpPostRequest.requestAddOfflineInOut(METHOD_ADDOFFLINEINOUT, cheDaoItem.getCtrlNumber(), OfflineCmdTmp);
//                    long ret = req.AddOfflineInOut<long>(Model.token, Model.stationID, dr.CtrlNumber, OfflineCmdTmp);// 服务器请求
                        if (ret > 0)
                        {
                            int precent = (j + 1) * 100 / Integer.parseInt(Count);
                            OfflineCmdTmp.clear();
                            updateCircleProgressValue(precent);
                        }
                        else
                        {
                            break;
                        }
                    }
                    else
                    {
                        if (m == 0)
                        {
                            L.e("OfflineCmdTmp:" + OfflineCmdTmp);
                            long ret = HttpPostRequest.requestAddOfflineInOut(METHOD_ADDOFFLINEINOUT, cheDaoItem.getCtrlNumber(), OfflineCmdTmp);
//                        long ret = req.AddOfflineInOut<long>(Model.token, Model.stationID, dr.CtrlNumber, OfflineCmdTmp);
                            if (ret > 0)
                            {
                                int precent = (j + 1) * 100 / Integer.parseInt(Count);
                                updateCircleProgressValue(precent);
                            }
                            else
                            {
                                break;
                            }
                        }
                    }
                }
            }
        }
    }

    private void updateCircleProgressValue(final int value)
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                circleProgress.setValue(value);
            }
        });
    }

    private void updateUIAsync(final String InOutName, final String IP, final String CtrlNumber, final String SumCount)
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                tvLaneName.setText(InOutName);
                tvChannelIP.setText(IP);
                tvChannelNo.setText(CtrlNumber);
                tvRecordNum.setText(SumCount);
            }
        });
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        if (dialog != null)
            dialog.dismiss();
        mHandler.removeCallbacksAndMessages(null);
    }

    private String readRecordCount(String IP, int ctrlNumber)
    {
        synchronized (ParkingReadRecordActivity.class)
        {
            return BaseApplication.getUdpSend().ReadRecordCount(IP, ctrlNumber);
        }
    }

    private String readRecord(String IP, int ctrlNumber)
    {
        synchronized (ParkingReadRecordActivity.class)
        {
            return BaseApplication.getUdpSend().ReadRecordEx(IP, ctrlNumber);
        }
    }
}
