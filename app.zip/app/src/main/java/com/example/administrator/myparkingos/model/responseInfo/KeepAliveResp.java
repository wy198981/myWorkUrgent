package com.example.administrator.myparkingos.model.responseInfo;

/**
 * Created by Administrator on 2017-05-08.
 */
public class KeepAliveResp
{
    private String rcode; // Y 参考错误码列表
    private String msg; // Y 错误信息
    private int data; // Y 当前Toke从当前时间开始算的有效时间(毫秒)。

    @Override
    public String toString()
    {
        return "KeepAliveResp{" +
                "rcode='" + rcode + '\'' +
                ", msg='" + msg + '\'' +
                ", data=" + data +
                '}';
    }

    public String getRcode()
    {
        return rcode;
    }

    public void setRcode(String rcode)
    {
        this.rcode = rcode;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg(String msg)
    {
        this.msg = msg;
    }

    public int getData()
    {
        return data;
    }

    public void setData(int data)
    {
        this.data = data;
    }
}
