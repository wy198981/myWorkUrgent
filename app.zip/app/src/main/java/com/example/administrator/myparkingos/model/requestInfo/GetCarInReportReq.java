package com.example.administrator.myparkingos.model.requestInfo;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017-07-07.
 */
public class GetCarInReportReq
{
    private String token; // Y	用户登录时候获取的token值
    private String jsonModel; // Y	查询Model。数据结构参考下面的说明。
    private String CallBack; // N	是否使用JSONP方式。关于JSONP方式请参考Javascript跨域访问一节。

    @Override
    public String toString()
    {
        return "GetCarInReportReq{" +
                "token='" + token + '\'' +
                ", jsonModel='" + jsonModel + '\'' +
                ", CallBack='" + CallBack + '\'' +
                '}';
    }

    public static class ReportModel
    {
        private String StartTime;// Y	开始时间。
        private String EndTime;// Y	结束时间。
        private Integer PageSize;// N	每页最大记录数。必须和Page参数一起使用。
        private Integer Page;// N	表示选取分页后的第几页的数据。从1开始编号。必须和PageSize参数一起使用。
        private List<ConditionsModel> Conditions = new ArrayList<>();// N	其它字段条件列表。数据结构参考下面的说明。

        @Override
        public String toString()
        {
            return "ReportModel{" +
                    "StartTime='" + StartTime + '\'' +
                    ", EndTime='" + EndTime + '\'' +
                    ", PageSize=" + PageSize +
                    ", Page=" + Page +
                    ", Conditions=" + Conditions +
                    '}';
        }

        public String getStartTime()
        {
            return StartTime;
        }

        public void setStartTime(String startTime)
        {
            StartTime = startTime;
        }

        public String getEndTime()
        {
            return EndTime;
        }

        public void setEndTime(String endTime)
        {
            EndTime = endTime;
        }

        public int getPageSize()
        {
            return PageSize;
        }

        public void setPageSize(int pageSize)
        {
            PageSize = pageSize;
        }

        public int getPage()
        {
            return Page;
        }

        public void setPage(int page)
        {
            Page = page;
        }

        public List<ConditionsModel> getConditions()
        {
            return Conditions;
        }

        public void setConditions(List<ConditionsModel> conditions)
        {
            Conditions = conditions;
        }
    }

    public static class ConditionsModel
    {
        private Integer Selected; // Y	是否已选中(选中才有效)
        private String RealField; // Y	真实字段名。
        private Integer OP; // Y	对比类型。0 等于，1 包含，2 小于，3 大于，4 小于或等于，5 大于或等于，6 不等于。
        private String SearchValue; // N	查询值

        @Override
        public String toString()
        {
            return "ConditionsModel{" +
                    "Selected=" + Selected +
                    ", RealField='" + RealField + '\'' +
                    ", OP=" + OP +
                    ", SearchValue='" + SearchValue + '\'' +
                    '}';
        }

        public int getSelected()
        {
            return Selected;
        }

        public void setSelected(int selected)
        {
            Selected = selected;
        }

        public String getRealField()
        {
            return RealField;
        }

        public void setRealField(String realField)
        {
            RealField = realField;
        }

        public int getOP()
        {
            return OP;
        }

        public void setOP(int OP)
        {
            this.OP = OP;
        }

        public String getSearchValue()
        {
            return SearchValue;
        }

        public void setSearchValue(String searchValue)
        {
            SearchValue = searchValue;
        }
    }

    public String getToken()
    {
        return token;
    }

    public void setToken(String token)
    {
        this.token = token;
    }

    public String getJsonModel()
    {
        return jsonModel;
    }

    public void setJsonModel(String jsonModel)
    {
        this.jsonModel = jsonModel;
    }

    public String getCallBack()
    {
        return CallBack;
    }

    public void setCallBack(String callBack)
    {
        CallBack = callBack;
    }
}
