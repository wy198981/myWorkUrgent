package com.example.administrator.myparkingos.ui;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.text.format.Time;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.TextView;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.constant.CR;
import com.example.administrator.myparkingos.constant.JsonSearchParam;
import com.example.administrator.myparkingos.constant.OrderField;
import com.example.administrator.myparkingos.constant.RCodeEnum;
import com.example.administrator.myparkingos.model.GetServiceData;
import com.example.administrator.myparkingos.model.beans.Model;
import com.example.administrator.myparkingos.model.requestInfo.GetCarInReportReq;
import com.example.administrator.myparkingos.model.requestInfo.GetCommXXConditionReq;
import com.example.administrator.myparkingos.model.requestInfo.GetDeleteListReq;
import com.example.administrator.myparkingos.model.requestInfo.GetModelListReq;
import com.example.administrator.myparkingos.model.requestInfo.GetXXXCommonReq;
import com.example.administrator.myparkingos.model.requestInfo.GetXXXDistinctReq;
import com.example.administrator.myparkingos.model.responseInfo.GetCarInReportFormDataResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCarInReportResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCommonXXXResp;
import com.example.administrator.myparkingos.model.responseInfo.GetQueryResp;
import com.example.administrator.myparkingos.model.responseInfo.GetQuerySchemeResp;
import com.example.administrator.myparkingos.model.responseInfo.GetQueryValueResp;
import com.example.administrator.myparkingos.myUserControlLibrary.DateTimePicker;
import com.example.administrator.myparkingos.myUserControlLibrary.MessageBox;
import com.example.administrator.myparkingos.myUserControlLibrary.niceSpinner.NiceSpinner;
import com.example.administrator.myparkingos.ui.adapter.CommonAdapter;
import com.example.administrator.myparkingos.ui.adapter.ViewHolder;
import com.example.administrator.myparkingos.ui.onlineMonitorPage.report.ReportInParkActivity;
import com.example.administrator.myparkingos.util.L;
import com.example.administrator.myparkingos.util.T;
import com.example.administrator.myparkingos.util.TimeConvertUtils;
import com.example.administrator.myparkingos.volleyUtil.callback.GsonCallback;
import com.google.gson.Gson;
import com.jude.http.LoadController;
import com.jude.http.RequestListener;
import com.jude.http.RequestManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by Administrator on 2017-07-06.
 */
public class CarInParkingSelectFragment extends Fragment implements GsonCallback.Listener
{
    private ReportInParkActivity mActivity;
    private DateTimePicker dtStartTime;
    private DateTimePicker dtEndTime;
    private ListView dgvQuery;
    private NiceSpinner cmbQuery;
    private Button btnSave;
    private Button btnDelete;
    private Button btnSelect;
    private Button btnExit;
    private ArrayList<GetQueryResp.DataBean> dataBeanArrayList;
    private OperatorListAdapter operatorListAdapter;

    public CarInParkingSelectFragment()
    {

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        mActivity = (ReportInParkActivity) getActivity();
        View root = inflater.inflate(R.layout.carinpark_select_fg, container, false);
        initView(root);
        return root;
    }

    private void initView(View root)
    {
        dtStartTime = (DateTimePicker) root.findViewById(R.id.dtStartTime);
        dtEndTime = (DateTimePicker) root.findViewById(R.id.dtEndTime);
        dgvQuery = (ListView) root.findViewById(R.id.dgvQuery);
        cmbQuery = (NiceSpinner) root.findViewById(R.id.cmbQuery);
        btnSave = (Button) root.findViewById(R.id.btnSave);
        btnSave.setOnClickListener(myClickListener);
        btnDelete = (Button) root.findViewById(R.id.btnDelete);
        btnDelete.setOnClickListener(myClickListener);
        btnSelect = (Button) root.findViewById(R.id.btnSelect);
        btnSelect.setOnClickListener(myClickListener);
        btnExit = (Button) root.findViewById(R.id.btnExit);
        btnExit.setOnClickListener(myClickListener);

        initListView();
        initSpinnerView();
    }

    private List<String> mSelectPlanList;

    private void initSpinnerView()
    {
        mSelectPlanList = new ArrayList<>();
        cmbQuery.setSpinnerListener(new NiceSpinner.SpinnerListener()
        {
            @Override
            public void OnSpinnerItemClick(int pos)
            {
                onClickSpinner(mSelectPlanList.get(pos));
            }
        });
        cmbQuery.refreshData(mSelectPlanList, 0, true);
    }

    /**
     * 点击某个条目触发的行为
     *
     * @param selectKey
     */
    private void onClickSpinner(String selectKey)
    {
        if (mSelectPlanList == null || mSelectPlanList.size() == 0)
        {
            return;
        }

        for (GetQueryResp.DataBean item : dataBeanArrayList) // 直接将dataBeanArrayList的字符串变成""
        {
            item.setOP(0);
            item.setSearchValue("");
            item.setSelected(0);
        }

        List<GetQuerySchemeResp.DataBean> planValue = getPlanValue(selectKey);
        for (GetQueryResp.DataBean item : dataBeanArrayList) // 直接将dataBeanArrayList的字符串变成""
        {
            if (planValue == null)
            {
                break;
            }

            for (GetQuerySchemeResp.DataBean queryItem : planValue)
            {
                if (item.getRealField().equals(queryItem.getFieldName()))
                {
                    item.setOP(queryItem.getOperators());
                    item.setSearchValue(queryItem.getSelectvalues());
                    item.setSelected(1);
                }
            }
        }
        operatorListAdapter.notifyDataSetChanged();
    }

    public List<GetQuerySchemeResp.DataBean> getPlanValue(String selectKey)
    {
        if (mPlan == null || mPlan.size() == 0)
        {
            return null;
        }

        for (String item : mPlan.keySet())
        {
            if (item.equals(selectKey))
            {
                L.e("find selectKey.............");
                return mPlan.get(selectKey);
            }
        }

        return null;
    }

    private void initListView()
    {
        dataBeanArrayList = new ArrayList<GetQueryResp.DataBean>();
        operatorListAdapter = new OperatorListAdapter(mActivity, dataBeanArrayList, R.layout.operator_item);
        dgvQuery.setAdapter(operatorListAdapter);

    }

    public void setGridData(List<GetQueryResp.DataBean> inData)
    {
        dataBeanArrayList.clear();
        if (inData != null)
        {
            dataBeanArrayList.addAll(inData);
        }
        operatorListAdapter.notifyDataSetChanged();
    }

    private Map<String, List<GetQuerySchemeResp.DataBean>> mPlan;

    public void setPlan(Map<String, List<GetQuerySchemeResp.DataBean>> selectPlan)
    {
        mSelectPlanList.clear(); // 先清除
        mPlan = selectPlan;

        if (selectPlan != null && selectPlan.size() != 0)
        {
            Set<String> strings = selectPlan.keySet();
            mSelectPlanList.addAll(strings);//后添加
        }
        cmbQuery.refreshData(mSelectPlanList, 0, true);
    }

    private List<GetQuerySchemeResp.DataBean> querySchemeList;

    private void setPlan(List<GetQuerySchemeResp.DataBean> inData) // 这里没有进来啊
    {
//        mSelectPlanList.clear(); // 先清除
////        querySchemeList = inData;
//        mPlan.clear();
//
//        for (GetQuerySchemeResp.DataBean item : inData)
//        {
//            mSelectPlanList.add(item.getSchName());
////            mPlan.put(item.getSchName(), item);
//        }
//        cmbQuery.refreshData(mSelectPlanList, 0);
    }

    private View.OnClickListener myClickListener = new View.OnClickListener()
    {
        @Override
        public void onClick(View v)
        {
            switch (v.getId())
            {
                case R.id.btnSelect:
                    onSelect();
                    break;
                case R.id.btnExit:
                    onExit();
                    break;
                case R.id.btnSave:
                    onSavePlan();
                    break;
                case R.id.btnDelete:
                    onDeletePlan();
                    break;

            }
        }


    };

    /**
     * 删除某查询方案
     */
    private void onDeletePlan()
    {
        if (TextUtils.isEmpty(cmbQuery.getCurrentText()))
        {
            T.showShort(mActivity, "方案为空");
            return;
        }

        MessageBox.showCanSetCallback(mActivity, "确定删除此方案吗?", new MessageBox.IMessageBoxListener()
        {
            @Override
            public void onClickPositive(DialogInterface dialog)
            {
                requestInParkDeleteSchemeInfo(cmbQuery.getCurrentText());
                dialog.dismiss();
            }

            @Override
            public void onClickNegative(DialogInterface dialog)
            {
                dialog.dismiss();
            }
        });
    }

    private void requestInParkDeleteSchemeInfo(String scheName)
    {
        GetCommXXConditionReq getCommXXConditionReq = new GetCommXXConditionReq();
        getCommXXConditionReq.setToken(Model.token);
        getCommXXConditionReq.setJsonConditions(JsonSearchParam.getInParkSelectSchemeInfo(scheName));

        String resultUrl = GetServiceData.getResultUrl("DeleteQuerySchemeBy", getCommXXConditionReq);

        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetCommonXXXResp.class, this, getCommXXConditionReq, resultUrl, -1));
    }

    /**
     * 保存某查询方案
     */
    private void onSavePlan()
    {
        if (TextUtils.isEmpty(cmbQuery.getCurrentText()))
        {
            T.showShort(mActivity, "方案为空");
            return;
        }

        requestInParkSelectSchemeInfo(cmbQuery.getCurrentText());
    }

    public void requestInParkSelectSchemeInfo(String schName)
    {
        GetXXXCommonReq getXXXCommonReq = new GetXXXCommonReq();
        getXXXCommonReq.setToken(Model.token);
        getXXXCommonReq.setJsonSearchParam(JsonSearchParam.getInParkSelectSchemeInfo(schName));

        String resultUrl = GetServiceData.getResultUrl("GetQueryScheme", getXXXCommonReq);

        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetQuerySchemeResp.class, this, getXXXCommonReq, resultUrl, -1));
    }

    protected void onExit()
    {
        mActivity.finish();
    }

    /**
     * 点击查询按钮
     */
    protected void onSelect()
    {
        try
        {
            GetCarInReportReq.ReportModel reportModel = new GetCarInReportReq.ReportModel();
            reportModel.setStartTime(TimeConvertUtils.toLongDateString(dtStartTime.getDateTime()));//疑问 TODO
            reportModel.setEndTime(TimeConvertUtils.toLongDateString(dtEndTime.getDateTime()));

            for (GetQueryResp.DataBean item : dataBeanArrayList)
            {
                if (item.getSelected() == 0)
                {
                    continue;
                }

                GetCarInReportReq.ConditionsModel conditionsModel = new GetCarInReportReq.ConditionsModel();
                conditionsModel.setOP(item.getOP());
                conditionsModel.setSelected(1);
                conditionsModel.setRealField(item.getRealField());

                if (item.getRealField().equals("CardType"))
                {
                    conditionsModel.setSearchValue(CR.GetCardType(item.getSearchValue(), 0));
                }
                else
                {
                    conditionsModel.setSearchValue(item.getSearchValue());
                }

                reportModel.getConditions().add(conditionsModel);
            }

            L.e(reportModel.toString());
            requestGetCarInReport(reportModel);
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }


    private void requestGetCarInReport(GetCarInReportReq.ReportModel model)
    {
        GetCarInReportReq getCarInReportReq = new GetCarInReportReq();
        getCarInReportReq.setToken(Model.token);
        getCarInReportReq.setJsonModel(JsonSearchParam.getInfoModel(model));

        String resultUrl = GetServiceData.getResultUrl("GetCarInReport", getCarInReportReq);

        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetCarInReportResp.class, this, getCarInReportReq, resultUrl, -1));
    }

    public void setStartTime(String dateTime)
    {
        dtStartTime.setDateTime(dateTime);
    }

    public void setEndTime(String dateTime)
    {
        dtEndTime.setDateTime(dateTime);
    }

    @Override
    public void success(Object reqData, Object respData, String url, int paramInt)
    {
        CR.printGsonResp(reqData, respData, url, paramInt);
        if (respData instanceof GetCarInReportResp)
        {
            GetCarInReportResp getCarInReportResp = (GetCarInReportResp) respData;
            L.e(getCarInReportResp.toString());
            if (Integer.parseInt(getCarInReportResp.getRcode()) != RCodeEnum.OK.getValue())
            {
                L.e(getCarInReportResp.getMsg());
            }
            else
            {
                if (getCarInReportResp.getData() == null)
                {
                    L.e("getCardIssueResp.getData() == null");
                }
                else
                {
                    updateGetCarInReport(getCarInReportResp.getData());
                }
            }
        }
        else if (respData instanceof GetQuerySchemeResp)
        {
            GetQuerySchemeResp getQuerySchemeResp = (GetQuerySchemeResp) respData;
            L.e(getQuerySchemeResp.toString());
            if (Integer.parseInt(getQuerySchemeResp.getRcode()) != RCodeEnum.OK.getValue())
            {
                L.e(getQuerySchemeResp.getMsg());
            }
            else
            {
                updateGetQureyScheme(getQuerySchemeResp.getData());
            }
        }
        else if (respData instanceof GetCommonXXXResp)
        {
            boolean isAdd = true; // 0 add ;1 delete
            if (reqData instanceof GetCommXXConditionReq) // 删除
            {
                isAdd = false;
            }

            GetCommonXXXResp commonXXXResp = (GetCommonXXXResp) respData;
            L.e(commonXXXResp.toString());
            if (Integer.parseInt(commonXXXResp.getRcode()) != RCodeEnum.OK.getValue())
            {
                L.e(commonXXXResp.getMsg());
            }
            else
            {
                int ret = commonXXXResp.getData();
                if (ret > 0)
                {
                    requestInParkSelectSchemeName("GetCarIn");
                    if (isAdd)
                    {
                        MessageBox.show(mActivity, "保存成功");
                    }
                }
                else
                {
                    if (isAdd)
                    {
                        MessageBox.show(mActivity, "保存失败");
                    }
                    else
                    {
                        MessageBox.show(mActivity, "删除失败");
                    }
                }
            }
        }
    }

    private void requestInParkSelectSchemeName(String queryTable)
    {
        GetXXXDistinctReq getXXXDistinctReq = new GetXXXDistinctReq();
        getXXXDistinctReq.setToken(Model.token);
        getXXXDistinctReq.setFieldNames("SchName");
        getXXXDistinctReq.setJsonSearchParam(JsonSearchParam.getInParkSelectSchemeName(queryTable));
        String resultUrl = GetServiceData.getResultUrl("GetQuerySchemeDistinct", getXXXDistinctReq); // 没有回应啊!

        L.e("getXXXDistinctReq:" + getXXXDistinctReq + "," + resultUrl);
        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new RequestListener()
                {
                    @Override
                    public void onRequest()
                    {
                    }

                    @Override
                    public void onSuccess(String s)
                    {
                        Gson gson = new Gson();
                        GetQuerySchemeResp getQuerySchemeResp = gson.fromJson(s, GetQuerySchemeResp.class);
                        if (Integer.parseInt(getQuerySchemeResp.getRcode()) != RCodeEnum.OK.getValue())
                        {
                            L.e(getQuerySchemeResp.getMsg());
                        }
                        else
                        {
                            if (getQuerySchemeResp.getData() == null)
                            {
                            }
                            else
                            {
                                setPlan(getQuerySchemeResp.getData());//这里
                            }
                        }
                    }

                    @Override
                    public void onError(String s)
                    {

                    }
                });
    }


    private void updateGetQureyScheme(final List<GetQuerySchemeResp.DataBean> data)
    {
        final List<GetQuerySchemeResp.DataBean> queryList = new ArrayList<GetQuerySchemeResp.DataBean>();
        for (GetQueryResp.DataBean item : dataBeanArrayList)
        {
            if (item.getSelected() == 1)
            {
                GetQuerySchemeResp.DataBean queryScheme = new GetQuerySchemeResp.DataBean();
                queryScheme.setStartime(dtStartTime.getDateTime());
                queryScheme.setEndtime(dtEndTime.getDateTime());
                queryScheme.setFieldName(item.getRealField());
                queryScheme.setOperators(item.getOP());
                queryScheme.setSelectvalues(item.getSearchValue());

                queryScheme.setQueryTable("GetCarIn");
                queryScheme.setSchName(cmbQuery.getCurrentText());

                queryList.add(queryScheme);

                L.e(queryScheme.toString());
            }
        }

        if (queryList == null || queryList.size() == 0)// 没有找到，不用覆盖
        {
            requestInParkSelectSchemeName(queryList);
        }
        else
        {
            MessageBox.showCanSetCallback(mActivity, "是否覆盖此方案", new MessageBox.IMessageBoxListener()
            {
                @Override
                public void onClickPositive(DialogInterface dialog)
                {
                    dialog.dismiss();
                    if (queryList.size() == 0)
                    {
                        MessageBox.show(mActivity, "保存失败");
                    }
                    else
                    {
                        requestInParkSelectSchemeName(queryList);
                    }
                }

                @Override
                public void onClickNegative(DialogInterface dialog)
                {
                    dialog.dismiss();
                }
            });
        }
    }

    private void requestInParkSelectSchemeName(List<GetQuerySchemeResp.DataBean> queryList)
    {
        GetModelListReq getModelListReq = new GetModelListReq();
        getModelListReq.setToken(Model.token);
        getModelListReq.setJsonModelList(JsonSearchParam.getInfoModel(queryList));

        String resultUrl = GetServiceData.getResultUrl("AddQuerySchemeList", getModelListReq);

        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetCommonXXXResp.class, this, getModelListReq, resultUrl, -1));
    }

    private boolean bSearch = false;

    private void updateGetCarInReport(GetCarInReportResp.DataBean data)
    {
        bSearch = true;
        // 查询出来结果之后，需要将结果进行更新即可
        mActivity.show(data);
    }

    @Override
    public void error(Object data, String url, String errorString)
    {
        L.e("连接服务器失败");
    }

    public class OperatorListAdapter extends CommonAdapter<GetQueryResp.DataBean>
    {

        private List<String> operatorList;

        public OperatorListAdapter(Context context, List<GetQueryResp.DataBean> datas, int layoutId)
        {
            super(context, datas, layoutId);
            initData();
        }

        @Override
        public void convert(ViewHolder viewHolder, final GetQueryResp.DataBean dataBean, int position)
        {
            CheckBox rbCheckB = (CheckBox) viewHolder.getView(R.id.rbCheckB);
            rbCheckB.setChecked(dataBean.getSelected() == 0 ? false : true);
            rbCheckB.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
            {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
                {
                    if (isChecked)//选中为0
                    {
                        dataBean.setSelected(1);
                    }
                    else
                    {
                        dataBean.setSelected(0);
                    }
                }
            });

            TextView tvColumnName = (TextView) viewHolder.getView(R.id.tvColumnName);
            tvColumnName.setText(dataBean.getShowField_CN());

            // 操作符的下拉列表
            NiceSpinner niceSpinnerOp = (NiceSpinner) viewHolder.getView(R.id.niceSpinnerOp);
            niceSpinnerOp.setSpinnerListener(new NiceSpinner.SpinnerListener()
            {
                @Override
                public void OnSpinnerItemClick(int pos)
                {
                    dataBean.setOP(pos);
                }
            });
            niceSpinnerOp.refreshData(operatorList, dataBean.getOP());

            // 获取相应的列表的值
            final NiceSpinner niceSpinnerValue = (NiceSpinner) viewHolder.getView(R.id.niceSpinnerValue); // 它的值来至哪里??
            niceSpinnerValue.setSpinnerListener(new NiceSpinner.SpinnerListener()
            {
                @Override
                public void OnSpinnerItemClick(int pos)
                {
                    dataBean.setSearchValue(niceSpinnerValue.getCurrentText());
                }
            });

            String realField = dataBean.getRealField();
            String searchValue = dataBean.getSearchValue();
            L.e("searchValue........." + searchValue);
            if (niceSpinnerValue.getTotolListNum() == 0) // no data 请求数据
            {
                requestSpinnerValue(viewHolder, realField);
            }
            else
            {
                if (!TextUtils.isEmpty(searchValue))
                {
                    niceSpinnerValue.setTextContent(searchValue);
                }
                else
                {
                    niceSpinnerValue.setTextContent("");
                }
            }
        }

        private void initData()
        {// 0 等于，1 包含，2 小于，3 大于，4 小于或等于，5 大于或等于，6 不等于。
            operatorList = new ArrayList<>();
            operatorList.add("等于");
            operatorList.add("包含");
            operatorList.add("小于");
            operatorList.add("大于");
            operatorList.add("小于或等于");
            operatorList.add("大于或等于");
            operatorList.add("不等于");
        }

        private void requestSpinnerValue(final ViewHolder viewHolder, final String realField)
        {
            String date = TimeConvertUtils.getAddMonth(System.currentTimeMillis(), -1);

            GetXXXDistinctReq getXXXDistinctReq = new GetXXXDistinctReq();
            getXXXDistinctReq.setToken(Model.token);
            getXXXDistinctReq.setFieldNames(realField);
            getXXXDistinctReq.setJsonSearchParam(JsonSearchParam.getQueryValue(date));
            getXXXDistinctReq.setOrderField(OrderField.getQueryValueOrder(realField, "asc"));

            String resultUrl = GetServiceData.getResultUrl("GetCarInDistinct", getXXXDistinctReq);

            LoadController loadController = RequestManager
                    .getInstance()
                    .get(resultUrl, new RequestListener()
                    {
                        @Override
                        public void onRequest()
                        {
                        }

                        @Override
                        public void onSuccess(String s) // 获取的数据
                        {
                            Gson gson = new Gson();
                            GetQueryValueResp getQueryValueResp = gson.fromJson(s, GetQueryValueResp.class);
                            L.e(getQueryValueResp.toString());
                            if (Integer.parseInt(getQueryValueResp.getRcode()) != RCodeEnum.OK.getValue())
                            {
                                L.e(getQueryValueResp.getMsg());
                            }
                            else // 获取到返回的数据
                            {
                                if (getQueryValueResp.getData() == null)
                                {
                                    return;
                                }
                                ArrayList<String> strings = new ArrayList<>();
                                List<Map<String, Object>> data = getQueryValueResp.getData();
                                for (Map<String, Object> temMap : data)
                                {
                                    for (String item : temMap.keySet())
                                    {
                                        if (item.equals(realField))
                                        {
                                            if (realField.equals("CardType"))
                                            {
                                                strings.add(CR.GetCardType((String) temMap.get(realField), 0));
                                            }
                                            else
                                            {
                                                String tempValue = "" + temMap.get(realField);
                                                if (!TextUtils.isEmpty(tempValue))
                                                {
                                                    strings.add(tempValue);
                                                }
                                            }
                                        }
                                    }
                                }
                                NiceSpinner niceSpinnerValue = (NiceSpinner) viewHolder.getView(R.id.niceSpinnerValue);

                                niceSpinnerValue.refreshData(strings, 0, true);
                            }

                        }

                        @Override
                        public void onError(String s)
                        {

                        }
                    });


        }
    }

}
