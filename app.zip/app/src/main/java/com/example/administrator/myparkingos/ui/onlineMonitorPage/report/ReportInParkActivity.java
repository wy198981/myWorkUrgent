package com.example.administrator.myparkingos.ui.onlineMonitorPage.report;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.constant.CR;
import com.example.administrator.myparkingos.constant.RCodeEnum;
import com.example.administrator.myparkingos.model.GetServiceData;
import com.example.administrator.myparkingos.model.beans.Model;
import com.example.administrator.myparkingos.model.requestInfo.GetCarInReportReq;
import com.example.administrator.myparkingos.model.requestInfo.GetXXXCommonReq;
import com.example.administrator.myparkingos.model.responseInfo.GetCarInReportFormDataResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCarInReportResp;
import com.example.administrator.myparkingos.ui.FragmentParkRecordManager;
import com.example.administrator.myparkingos.util.L;
import com.example.administrator.myparkingos.volleyUtil.callback.GsonCallback;
import com.jude.http.LoadController;
import com.jude.http.RequestManager;

/**
 * Created by Administrator on 2017-02-16.
 * 【期限查询】 -->> 【场内车辆】
 */
public class ReportInParkActivity extends AppCompatActivity implements View.OnClickListener, GsonCallback.Listener
{
    private FragmentParkRecordManager fragmentParkRecordManager;
    private TextView tvInParkResult;
    private TextView tvInParkSelect;
    private ImageView ivExit;
    private TextView tvTitle;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reportinpark_activity);

        Window window = getWindow();
        WindowManager m = getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = window.getAttributes(); // 获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 2 / 3); // 改变的是dialog框在屏幕中的位置而不是大小
        p.width = (int) (d.getWidth() * 1 / 2); // 宽度设置为屏幕的0.65
        window.setAttributes(p);

        initView();
        initFragment(savedInstanceState);

        requestGetCarInReportFormData();
    }

    private void requestGetCarInReportFormData()
    {
        GetXXXCommonReq getXXXCommonReq = new GetXXXCommonReq();
        getXXXCommonReq.setToken(Model.token);

        String resultUrl = GetServiceData.getResultUrl("GetCarInReportFormData", getXXXCommonReq);

        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetCarInReportFormDataResp.class, this, getXXXCommonReq, resultUrl, -1));
    }

    private void initView()
    {
        tvInParkSelect = (TextView) findViewById(R.id.tvInParkSelect);
        tvInParkResult = (TextView) findViewById(R.id.tvInParkResult);

        tvInParkSelect.setOnClickListener(this);
        tvInParkResult.setOnClickListener(this);
        ivExit = (ImageView) findViewById(R.id.ivExit);
        ivExit.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                finish();
            }
        });
        tvTitle = (TextView) findViewById(R.id.tvTitle);
        tvTitle.setOnClickListener(this);
    }

    private void initFragment(Bundle savedInstanceState)
    {
        FragmentManager supportFragmentManager = getSupportFragmentManager();

        fragmentParkRecordManager = new FragmentParkRecordManager(supportFragmentManager);
        fragmentParkRecordManager.init(savedInstanceState);

        tvInParkSelect.setBackgroundColor(Color.TRANSPARENT);
        tvInParkResult.setBackgroundResource(R.color.colorNoClick);
    }

    @Override
    public void onClick(View v)
    {
        if (v.getId() == R.id.tvInParkSelect)
        {
            fragmentParkRecordManager.showFragment(0);
            tvInParkSelect.setBackgroundColor(Color.TRANSPARENT);
            tvInParkResult.setBackgroundResource(R.color.colorNoClick);
        }
        else if (v.getId() == R.id.tvInParkResult)
        {
            fragmentParkRecordManager.showFragment(1);
            tvInParkSelect.setBackgroundResource(R.color.colorNoClick);
            tvInParkResult.setBackgroundColor(Color.TRANSPARENT);
        }
    }

    @Override
    public void success(Object reqData, Object respData, String url, int paramInt)
    {
        CR.printGsonResp(reqData, respData, url, paramInt);
        if (respData instanceof GetCarInReportFormDataResp)
        {
            GetCarInReportFormDataResp carInReportFormDataResp = (GetCarInReportFormDataResp) respData;
            L.e(carInReportFormDataResp.toString());
            if (Integer.parseInt(carInReportFormDataResp.getRcode()) != RCodeEnum.OK.getValue())
            {
                L.e(carInReportFormDataResp.getMsg());
            }
            else
            {
                if (carInReportFormDataResp.getData() == null)
                {
                    L.e("getCardIssueResp.getData() == null");
                }
                else
                {
                    updateGetCarInReportFormDataToView(carInReportFormDataResp.getData());
                }
            }
        }
    }

    private void updateGetCarInReportFormDataToView(GetCarInReportFormDataResp.BeanData data)
    {
        fragmentParkRecordManager.setStartTime(data.getStartTime());
        fragmentParkRecordManager.setEndTime(data.getEndTime());

        fragmentParkRecordManager.setSelectGridData(data.getFields());
        fragmentParkRecordManager.setSelectPlan(data.getSavedPlans());
    }

    @Override
    public void error(Object data, String url, String errorString)
    {
        L.e("连接服务器失败");
    }

    public void show(GetCarInReportResp.DataBean carInReportResp)
    {
        fragmentParkRecordManager.showFragment(1);//显示第二页数据
        fragmentParkRecordManager.setResultCountInfo(carInReportResp);
    }
}
