package com.example.administrator.myparkingos.model.requestInfo;

/**
 * Created by Administrator on 2017-05-12.
 */
public class CardIssueCancellationReq
{
    private String token; // Y 用户登录时候获取的token值
    private String IDList; // N 卡片发行Model的ID字段的值组成的数组。IDList、CardNo和CPH参数不能同时为空；如果同时指定了三个参数的值，服务器优先按IDList参数注销车辆，找不到再按CardNo注销，仍然找不到再按CPH注销。
    private String CardNo; // N 卡片发行Model的CardNO字段的值。CardNo和CPH参数不能同时为空；如果同时指定了两个参数的值，服务器优先按CardNo参数注销车辆，找不到再按CPH注销。
    private String CPH; // N 卡片发行Model的CPH字段的值。CardNo和CPH参数不能同时为空；如果同时指定了两个参数的值，服务器优先按CardNo参数注销车辆，找不到再按CPH注销。
    private Boolean ForceCancel; // N 如果将要注销的车辆已经入场，是否强制注销并更改场内记录的计费类型为临时车A。默认否。
    private String CallBack; // N 是否使用JSONP方式。关于JSONP方式请参考Javascript跨域访问一节。

    @Override
    public String toString()
    {
        return "CardIssueCancellationReq{" +
                "token='" + token + '\'' +
                ", IDList='" + IDList + '\'' +
                ", CardNo='" + CardNo + '\'' +
                ", CPH='" + CPH + '\'' +
                ", ForceCancel=" + ForceCancel +
                ", CallBack='" + CallBack + '\'' +
                '}';
    }

    public String getIDList()
    {
        return IDList;
    }

    public void setIDList(String IDList)
    {
        this.IDList = IDList;
    }

    public Boolean getForceCancel()
    {
        return ForceCancel;
    }

    public void setForceCancel(Boolean forceCancel)
    {
        ForceCancel = forceCancel;
    }

    public String getToken()
    {
        return token;
    }

    public void setToken(String token)
    {
        this.token = token;
    }

    public String getCardNo()
    {
        return CardNo;
    }

    public void setCardNo(String cardNo)
    {
        CardNo = cardNo;
    }

    public String getCPH()
    {
        return CPH;
    }

    public void setCPH(String CPH)
    {
        this.CPH = CPH;
    }

    public String getCallBack()
    {
        return CallBack;
    }

    public void setCallBack(String callBack)
    {
        CallBack = callBack;
    }
}
