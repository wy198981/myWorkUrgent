package com.example.administrator.myparkingos.model.responseInfo;

import java.util.List;

/**
 * Created by Administrator on 2017-05-11.
 */
public class GetParkJHSetResp
{
    private String rcode;  // 参考错误码列表
    private String msg;  //错误信息
    private int PageIndex;  //当前页码。仅当查询时指定了分页参数才有此值。
    private int PageSize;  // 分页大小。仅当查询时指定了分页参数才有此值。
    private int TotalRows;  //总行数。仅当查询时指定了分页参数才有此值。
    //Data  参考说明中的描述    如果没有指定ExportFields参数则为数据Model数组，否则为下载导出文件的完整URL

    private List<DataBean> data;


    public static class DataBean
    {
        private long ID; //Y	自增长唯一标识
        private int CtrlNumber; //  Y	机号
        private String Location; //Y	名称

        @Override
        public String toString()
        {
            return "DataBean{" +
                    "ID=" + ID +
                    ", CtrlNumber=" + CtrlNumber +
                    ", Location='" + Location + '\'' +
                    '}';
        }

        public long getID()
        {
            return ID;
        }

        public void setID(long ID)
        {
            this.ID = ID;
        }

        public int getCtrlNumber()
        {
            return CtrlNumber;
        }

        public void setCtrlNumber(int ctrlNumber)
        {
            CtrlNumber = ctrlNumber;
        }

        public String getLocation()
        {
            return Location;
        }

        public void setLocation(String location)
        {
            Location = location;
        }
    }
}
