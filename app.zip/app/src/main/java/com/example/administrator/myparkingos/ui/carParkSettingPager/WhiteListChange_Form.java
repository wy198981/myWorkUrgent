package com.example.administrator.myparkingos.ui.carParkSettingPager;

/**
 * Created by Administrator on 2017-02-16.
 * 【车场设置】 -->> 【下载管理】 -->> 【摄像机下载和设置】 -->> 【白名单】 按钮【修改】
 */
public class WhiteListChange_Form
{
}
