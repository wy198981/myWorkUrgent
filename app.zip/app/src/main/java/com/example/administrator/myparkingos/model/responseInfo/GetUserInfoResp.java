package com.example.administrator.myparkingos.model.responseInfo;

import java.util.List;

/**
 * Created by Administrator on 2017-05-11.
 */
public class GetUserInfoResp
{
    private String rcode;  // 参考错误码列表
    private String msg;  //错误信息
    private int PageIndex;  //当前页码。仅当查询时指定了分页参数才有此值。
    private int PageSize;  // 分页大小。仅当查询时指定了分页参数才有此值。
    private int TotalRows;  //总行数。仅当查询时指定了分页参数才有此值。
    //Data  参考说明中的描述    如果没有指定ExportFields参数则为数据Model数组，否则为下载导出文件的完整URL


    public String getRcode()
    {
        return rcode;
    }

    public void setRcode(String rcode)
    {
        this.rcode = rcode;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg(String msg)
    {
        this.msg = msg;
    }

    public int getPageIndex()
    {
        return PageIndex;
    }

    public void setPageIndex(int pageIndex)
    {
        PageIndex = pageIndex;
    }

    public int getPageSize()
    {
        return PageSize;
    }

    public void setPageSize(int pageSize)
    {
        PageSize = pageSize;
    }

    public int getTotalRows()
    {
        return TotalRows;
    }

    public void setTotalRows(int totalRows)
    {
        TotalRows = totalRows;
    }

    public List<DataBean> getData()
    {
        return data;
    }

    public void setData(List<DataBean> data)
    {
        this.data = data;
    }

    @Override
    public String toString()
    {
        return "GetUserInfoResp{" +
                "rcode='" + rcode + '\'' +
                ", msg='" + msg + '\'' +
                ", PageIndex=" + PageIndex +
                ", PageSize=" + PageSize +
                ", TotalRows=" + TotalRows +
                ", data=" + data +
                '}';
    }

    private List<DataBean> data;

    public static class DataBean
    {
        private long ID; // Y 自增长唯一标识
        private String UserNO; // Y 自定义人员编号
        private String UserName; // Y 人员名称
        private String Sex; // N 性别：男，女，null
        //        private int HomeAddress; // N 家庭住址
        private String HomeAddress; // N 家庭住址

        private long DeptId; // Y 部门Id
        private String DeptName; // N 参考部门数据结构同名字段
        private String Job; // N 职业
        private String WorkTime; // N 工作时间
        private String BirthDate; // N 出生日期
        private String IDCard; // N 身份证号
        private String MaritalStatus; // N 已婚：是，否，null
        private String HighestDegree; // N 最高学历
        private String PoliticalStatus; // N 政治身份
        private String School; // N 学校
        private String Speciality; // N 专长
        private String ForeignLanguage; // N 外语
        private String Skill; // N 技能
        private String TelNumber; // N 联系电话
        private String MobNumber; // N 移动电话
        private String ZipCode; // N 邮编
        private String NativePlace; // N 籍贯
        private int CarPlaceNo; // N 车位数量

        @Override
        public String toString()
        {
            return "DataBean{" +
                    "ID=" + ID +
                    ", UserNO='" + UserNO + '\'' +
                    ", UserName='" + UserName + '\'' +
                    ", Sex='" + Sex + '\'' +
                    ", HomeAddress=" + HomeAddress +
                    ", DeptId=" + DeptId +
                    ", DeptName='" + DeptName + '\'' +
                    ", Job='" + Job + '\'' +
                    ", WorkTime='" + WorkTime + '\'' +
                    ", BirthDate='" + BirthDate + '\'' +
                    ", IDCard='" + IDCard + '\'' +
                    ", MaritalStatus='" + MaritalStatus + '\'' +
                    ", HighestDegree='" + HighestDegree + '\'' +
                    ", PoliticalStatus='" + PoliticalStatus + '\'' +
                    ", School='" + School + '\'' +
                    ", Speciality='" + Speciality + '\'' +
                    ", ForeignLanguage='" + ForeignLanguage + '\'' +
                    ", Skill='" + Skill + '\'' +
                    ", TelNumber='" + TelNumber + '\'' +
                    ", MobNumber='" + MobNumber + '\'' +
                    ", ZipCode='" + ZipCode + '\'' +
                    ", NativePlace='" + NativePlace + '\'' +
                    ", CarPlaceNo=" + CarPlaceNo +
                    '}';
        }

        public long getID()
        {
            return ID;
        }

        public void setID(long ID)
        {
            this.ID = ID;
        }

        public String getUserNO()
        {
            return UserNO;
        }

        public void setUserNO(String userNO)
        {
            UserNO = userNO;
        }

        public String getUserName()
        {
            return UserName;
        }

        public void setUserName(String userName)
        {
            UserName = userName;
        }

        public String getSex()
        {
            return Sex;
        }

        public void setSex(String sex)
        {
            Sex = sex;
        }

        public String getHomeAddress()
        {
            return HomeAddress;
        }

        public void setHomeAddress(String homeAddress)
        {
            HomeAddress = homeAddress;
        }

        public long getDeptId()
        {
            return DeptId;
        }

        public void setDeptId(long deptId)
        {
            DeptId = deptId;
        }

        public String getDeptName()
        {
            return DeptName;
        }

        public void setDeptName(String deptName)
        {
            DeptName = deptName;
        }

        public String getJob()
        {
            return Job;
        }

        public void setJob(String job)
        {
            Job = job;
        }

        public String getWorkTime()
        {
            return WorkTime;
        }

        public void setWorkTime(String workTime)
        {
            WorkTime = workTime;
        }

        public String getBirthDate()
        {
            return BirthDate;
        }

        public void setBirthDate(String birthDate)
        {
            BirthDate = birthDate;
        }

        public String getIDCard()
        {
            return IDCard;
        }

        public void setIDCard(String IDCard)
        {
            this.IDCard = IDCard;
        }

        public String getMaritalStatus()
        {
            return MaritalStatus;
        }

        public void setMaritalStatus(String maritalStatus)
        {
            MaritalStatus = maritalStatus;
        }

        public String getHighestDegree()
        {
            return HighestDegree;
        }

        public void setHighestDegree(String highestDegree)
        {
            HighestDegree = highestDegree;
        }

        public String getPoliticalStatus()
        {
            return PoliticalStatus;
        }

        public void setPoliticalStatus(String politicalStatus)
        {
            PoliticalStatus = politicalStatus;
        }

        public String getSchool()
        {
            return School;
        }

        public void setSchool(String school)
        {
            School = school;
        }

        public String getSpeciality()
        {
            return Speciality;
        }

        public void setSpeciality(String speciality)
        {
            Speciality = speciality;
        }

        public String getForeignLanguage()
        {
            return ForeignLanguage;
        }

        public void setForeignLanguage(String foreignLanguage)
        {
            ForeignLanguage = foreignLanguage;
        }

        public String getSkill()
        {
            return Skill;
        }

        public void setSkill(String skill)
        {
            Skill = skill;
        }

        public String getTelNumber()
        {
            return TelNumber;
        }

        public void setTelNumber(String telNumber)
        {
            TelNumber = telNumber;
        }

        public String getMobNumber()
        {
            return MobNumber;
        }

        public void setMobNumber(String mobNumber)
        {
            MobNumber = mobNumber;
        }

        public String getZipCode()
        {
            return ZipCode;
        }

        public void setZipCode(String zipCode)
        {
            ZipCode = zipCode;
        }

        public String getNativePlace()
        {
            return NativePlace;
        }

        public void setNativePlace(String nativePlace)
        {
            NativePlace = nativePlace;
        }

        public int getCarPlaceNo()
        {
            return CarPlaceNo;
        }

        public void setCarPlaceNo(int carPlaceNo)
        {
            CarPlaceNo = carPlaceNo;
        }
    }
}
