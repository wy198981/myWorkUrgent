package com.example.administrator.myparkingos.ui.onlineMonitorPage;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.myUserControlLibrary.DateTimePicker;
import com.example.administrator.myparkingos.myUserControlLibrary.niceSpinner.NiceSpinner;

/**
 * Created by Administrator on 2017-02-16.
 * 【在线监控】 -->> 【车牌登记】 -->>【双击车牌延期】
 */
public class FormPostponeActivity extends AppCompatActivity implements View.OnClickListener
{
    private TextView tvCarNo;
    private TextView tvUserName;
    private TextView tvCPH;
    private TextView tvUserNo;
    private TextView tvCarType;
    private TextView tvBalance;
    private NiceSpinner spinnerRule;
    private EditText etCollectMoney;
    private DateTimePicker validStartTime;
    private DateTimePicker validEndTime;
    private EditText etRemarks;
    private Button btnPrint;
    private Button btnPostpone;
    private Button btnExit;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.formpostpone_activity);
        initView();
    }

    private void initView()
    {
        tvCarNo = (TextView) findViewById(R.id.tvCarNo);
        tvUserName = (TextView) findViewById(R.id.tvUserName);
        tvCPH = (TextView) findViewById(R.id.tvCPH);
        tvUserNo = (TextView) findViewById(R.id.tvUserNo);
        tvCarType = (TextView) findViewById(R.id.tvCarType);
        tvBalance = (TextView) findViewById(R.id.tvBalance);
        spinnerRule = (NiceSpinner) findViewById(R.id.spinnerRule);
        etCollectMoney = (EditText) findViewById(R.id.etCollectMoney);
        validStartTime = (DateTimePicker) findViewById(R.id.validStartTime);
        validEndTime = (DateTimePicker) findViewById(R.id.validEndTime);
        etRemarks = (EditText) findViewById(R.id.etRemarks);
        btnPrint = (Button) findViewById(R.id.btnPrint);
        btnPostpone = (Button) findViewById(R.id.btnPostpone);
        btnExit = (Button) findViewById(R.id.btnExit);

        btnPrint.setOnClickListener(this);
        btnPostpone.setOnClickListener(this);
        btnExit.setOnClickListener(this);
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.btnPrint:

                break;
            case R.id.btnPostpone:

                break;
            case R.id.btnExit:

                break;
        }
    }


}
