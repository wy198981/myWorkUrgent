package com.example.administrator.myparkingos.ui.loginHintProcess;

import android.app.Activity;
import android.app.Dialog;
import android.app.usage.UsageEvents;
import android.os.Handler;
import android.os.SystemClock;
import android.view.Display;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.BaseApplication;
import com.example.administrator.myparkingos.common.data.cipher.Base64Cipher;
import com.example.administrator.myparkingos.constant.CR;
import com.example.administrator.myparkingos.constant.JsonSearchParam;
import com.example.administrator.myparkingos.model.GetServiceData;
import com.example.administrator.myparkingos.model.beans.Model;
import com.example.administrator.myparkingos.model.beans.ThreadMessage;
import com.example.administrator.myparkingos.model.requestInfo.GetPlateNumberDownCmdReq;
import com.example.administrator.myparkingos.model.responseInfo.GetCarOutResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCardIssueResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCheDaoSetResp;
import com.example.administrator.myparkingos.model.responseInfo.GetPlateNumberDownBlackListResp;
import com.example.administrator.myparkingos.model.responseInfo.GetPlateNumberDownCardIssueResp;
import com.example.administrator.myparkingos.model.responseInfo.GetPlateNumberDownTempLoadResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCommonXXXResp;
import com.example.administrator.myparkingos.myUserControlLibrary.MessageBox;
import com.example.administrator.myparkingos.util.HttpUtils;
import com.example.administrator.myparkingos.util.L;
import com.example.administrator.myparkingos.volleyUtil.callback.GsonCallback;
import com.google.gson.Gson;
import com.jude.http.LoadController;
import com.jude.http.RequestManager;

import org.greenrobot.eventbus.EventBus;

import java.net.URLEncoder;
import java.util.Arrays;
import java.util.List;

/**
 * Created by Administrator on 2017-06-05.
 */
public class ParkingDownCardView
{
    private final Base64Cipher base64Cipher;
    private Activity mActivity;
    private final Dialog dialog;
    private final GetDownLoadThread getDownLoadThread;
    private TextView tvValidCarCard;
    private TextView tvTotalNum;

    public static final String METHOD_GETPLATENUMBERDOWNCMD = "GetPlateNumberDownCmd";
    public static final String METHOD_UPDATECARDISSUE = "UpdateCardIssue";

    private Gson mGson;

    private Handler mHandler = new Handler();

    /**
     * 下载类型的枚举
     */
    public enum DownTypeEnum
    {
        CardIssue(0),       // 车牌发行
        CardLoss(1),        // 车牌发行注销
        BlackListIssue(2),  // 车牌黑名单
        BlackListLoss(3),   // 车牌黑名单注销
        ErrorCPH(4);        // 错误车牌更正

        private int mTypeValue;

        DownTypeEnum(int value)
        {
            mTypeValue = value;
        }

        public int getValue()
        {
            return mTypeValue;
        }

        public static DownTypeEnum valueOf(int value)
        {
            switch (value)
            {
                case 0:
                    return CardIssue;
                case 1:
                    return CardLoss;
                case 2:
                    return BlackListIssue;
                case 3:
                    return BlackListLoss;
                case 4:
                    return ErrorCPH;
                default:
                    break;

            }
            return null;
        }
    }

    public ParkingDownCardView(Activity activity)
    {
        this.mActivity = activity;

        dialog = new Dialog(activity); // @android:style/Theme.Dialog
        dialog.setContentView(R.layout.activity_parkdowncard);
        dialog.setCanceledOnTouchOutside(true);

        Window window = dialog.getWindow();
        WindowManager m = activity.getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = window.getAttributes(); // 获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 2 / 3); // 改变的是dialog框在屏幕中的位置而不是大小
        p.width = (int) (d.getWidth() * 2 / 3); // 宽度设置为屏幕的0.65
        window.setAttributes(p);

        initView();
        dialog.setTitle("");

        base64Cipher = new Base64Cipher();

        mGson = new Gson();

        getDownLoadThread = new GetDownLoadThread();//开启新的线程
        getDownLoadThread.start();
    }

    private void initView()
    {
        tvValidCarCard = (TextView) dialog.findViewById(R.id.tvValidCarCard);
        tvTotalNum = (TextView) dialog.findViewById(R.id.tvTotalNum);
    }

    public void show()
    {
        if (dialog != null)
        {
            dialog.show();
        }
    }

    public void dismiss()
    {
        if (dialog != null && dialog.isShowing())
        {
            dialog.dismiss();
        }
    }

    public class GetDownLoadThread extends Thread
    {
        private boolean isRunning = false;

        public GetDownLoadThread()
        {
            isRunning = true;
        }

        @Override
        public void run()
        {
            super.run(); // 还剩下的是对于进度条的更新的问题，即界面显示的问题;
//            while (isRunning)
            {
                try
                {
                    if (Model.bIsKZB && Model.strKZJ.equals("1"))
                    {
                        downAndLogoutCarCard(DownTypeEnum.CardIssue, "车牌下载");

                        downAndLogoutCarCard(DownTypeEnum.CardIssue, "车牌注销下载");

                        correctionIncorrectCarCard(); // 车牌更正

                        downloadBlackList(); // 黑名单下载

                        logoutBlackList();// 黑名单注销
                    }
                }
                catch (Exception ex)
                {
                    ex.printStackTrace();
                }
            }

            EventBus.getDefault().post(new ThreadMessage(1));
        }
    }


    public String getHttpUrlByDownType(DownTypeEnum typeEnum, String[] CtrlNumberList)
    {
        GetPlateNumberDownCmdReq getPlateNumberDownReq = new GetPlateNumberDownCmdReq();
        getPlateNumberDownReq.setToken(Model.token);
        getPlateNumberDownReq.setStationId(Model.stationID);
        getPlateNumberDownReq.setDownType(typeEnum.getValue());
        getPlateNumberDownReq.setIsRepeatDownload(false);

        String toJson = mGson.toJson(CtrlNumberList);
        String encode = URLEncoder.encode(toJson);

        // 注意CtrlNumberList的数据需要经过转换为Json字符串
        String resultUrl = GetServiceData.getResultUrl(METHOD_GETPLATENUMBERDOWNCMD, getPlateNumberDownReq);

        return resultUrl + "&CtrlNumberList=" + encode;
    }

    public void downAndLogoutCarCard(DownTypeEnum type, String showText)
    {
        String httpUrlByDownType = getHttpUrlByDownType(type, null);

        L.e("httpUrlByDownType:" + httpUrlByDownType);
        String doPost = HttpUtils.doPost(httpUrlByDownType, null);
        L.e("doPost 返回的数据:" + doPost);
        if (doPost != null)
        {
            GetPlateNumberDownCardIssueResp getPlateNumberDownCardIssueResp = mGson.fromJson(doPost, GetPlateNumberDownCardIssueResp.class);
            L.e("getPlateNumberDownResp:" + getPlateNumberDownCardIssueResp);
            //直接处理数据即可
            if (!getPlateNumberDownCardIssueResp.getRcode().equals("200"))
            {
                L.e("getPlateNumberDownResp.getMsg():" + getPlateNumberDownCardIssueResp.getMsg());
                return;
            }

            if (getPlateNumberDownCardIssueResp.getData() == null || getPlateNumberDownCardIssueResp.getData().size() == 0)
            {
                L.e("getPlateNumberDownResp.getData() == null || getPlateNumberDownResp.getData().size() == 0");
                return;
            }

            dealCardIssue(getPlateNumberDownCardIssueResp.getData(), showText);
        }
    }

    /**
     * 更正错误车牌 (什么时候来触发这个操作)
     */
    private void correctionIncorrectCarCard()
    {
        String httpUrlByDownType = getHttpUrlByDownType(DownTypeEnum.ErrorCPH, null);
        L.e("httpUrlByDownType:" + httpUrlByDownType);
        String doPost = HttpUtils.doPost(httpUrlByDownType, null);
        L.e("doPost 返回的数据:" + doPost);
        if (doPost != null)
        {
            GetPlateNumberDownTempLoadResp getPlateNumberDownTempLoadResp = mGson.fromJson(doPost, GetPlateNumberDownTempLoadResp.class);
            L.e("getPlateNumberDownResp:" + getPlateNumberDownTempLoadResp);
            //直接处理数据即可
            if (!getPlateNumberDownTempLoadResp.getRcode().equals("200"))
            {
                L.e("getPlateNumberDownResp.getMsg():" + getPlateNumberDownTempLoadResp.getMsg());
                return;
            }

            if (getPlateNumberDownTempLoadResp.getData() == null || getPlateNumberDownTempLoadResp.getData().size() == 0)
            {
                L.e("getPlateNumberDownResp.getData() == null || getPlateNumberDownResp.getData().size() == 0");
                return;
            }

            dealInCorrentCarCard(getPlateNumberDownTempLoadResp.getData());
        }
    }

    private void dealInCorrentCarCard(List<GetPlateNumberDownTempLoadResp.Bean> respBean)
    {
        updateUIAsync("错误车牌号码更正", String.valueOf(respBean.size()));

        for (int i = 0; i < respBean.size(); i++)
        {
            GetPlateNumberDownTempLoadResp.Bean temp = respBean.get(i);

            String oldstr = "";
            String newstr = "";

            List<GetCheDaoSetResp.DataBean> lstCDS = temp.getLstCDS();
            for (GetCheDaoSetResp.DataBean tempCheDao : lstCDS)
            {
                oldstr += "1";
                String ret = "";

                if (tempCheDao.DownCmdList.size() > 0)
                {
                    long currentTime = System.currentTimeMillis();
                    while (System.currentTimeMillis() - currentTime < Model.iDelayed * 1000)
                    {
//                        sendbll.SetUsbType(ref usbHid, lstATDL[i].lstCDS[j].XieYi); // 又对应的那个接口呢?
                        ret = BaseApplication.getUdpSend().SendDownCmd(tempCheDao.getIP(), base64Cipher.decrypt(tempCheDao.DownCmdList.get(0).getBytes()));
                        final String returnValue = ret;
                        if (!ret.equals("2"))
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    setValidCarCardText("错误车牌号码下载");
                                    if (returnValue.equals("5"))
                                    {
                                        setValidCarCardText("用户数据已满");
                                        return;
                                    }
                                }
                            });
                            break;
                        }
                        else
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    setValidCarCardText("连接中断..");
                                }
                            });
                        }
                    }
                    if (ret.equals("0"))
                    {
                        newstr += "1";
                    }
                    else
                    {
                        mHandler.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                MessageBox.show(mActivity, "与控制机通讯不通");
                            }
                        });
                        return;
                    }
                }
            }

            if (oldstr.equals(newstr))
            {
                String sumBiao = temp.getModel().getDownloadSignal().substring(0, Model.stationID - 1) + "1" + temp.getModel().getDownloadSignal().substring(Model.stationID);
                requestUpdateCPHDownLoad((int) temp.getModel().getID(), sumBiao);
            }

            int precent = (i + 1) * 100 / respBean.size(); // 表示进度，可以用来更新进度条
            SystemClock.sleep(50);// 延时50ms
        }
    }


    /**
     * 下载黑名单
     */
    private void downloadBlackList()
    {
        String httpUrlByDownType = getHttpUrlByDownType(DownTypeEnum.BlackListIssue, null);
        L.e("httpUrlByDownType:" + httpUrlByDownType);
        String doPost = HttpUtils.doPost(httpUrlByDownType, null);
        L.e("doPost 返回的数据:" + doPost);
        if (doPost != null)
        {
            GetPlateNumberDownBlackListResp getPlateNumberDownBlackListResp = mGson.fromJson(doPost, GetPlateNumberDownBlackListResp.class);
            L.e("getPlateNumberDownResp:" + getPlateNumberDownBlackListResp);
            //直接处理数据即可
            if (!getPlateNumberDownBlackListResp.getRcode().equals("200"))
            {
                L.e("getPlateNumberDownResp.getMsg():" + getPlateNumberDownBlackListResp.getMsg());
                return;
            }

            if (getPlateNumberDownBlackListResp.getData() == null || getPlateNumberDownBlackListResp.getData().size() == 0)
            {
                L.e("getPlateNumberDownResp.getData() == null || getPlateNumberDownResp.getData().size() == 0");
                return;
            }

            dealBlackListIssue(getPlateNumberDownBlackListResp.getData());
        }
    }

    /**
     * 注销黑名单
     */
    private void logoutBlackList()
    {
        String httpUrlByDownType = getHttpUrlByDownType(DownTypeEnum.BlackListLoss, null);
        L.e("httpUrlByDownType:" + httpUrlByDownType);
        String doPost = HttpUtils.doPost(httpUrlByDownType, null);
        L.e("doPost 返回的数据:" + doPost);
        if (doPost != null)
        {
            GetPlateNumberDownBlackListResp getPlateNumberDownBlackListResp = mGson.fromJson(doPost, GetPlateNumberDownBlackListResp.class);
            L.e("getPlateNumberDownResp:" + getPlateNumberDownBlackListResp);
            //直接处理数据即可
            if (!getPlateNumberDownBlackListResp.getRcode().equals("200"))
            {
                L.e("getPlateNumberDownResp.getMsg():" + getPlateNumberDownBlackListResp.getMsg());
                return;
            }

            if (getPlateNumberDownBlackListResp.getData() == null || getPlateNumberDownBlackListResp.getData().size() == 0)
            {
                L.e("getPlateNumberDownResp.getData() == null || getPlateNumberDownResp.getData().size() == 0");
                return;
            }
            dealBlackListLoss(getPlateNumberDownBlackListResp.getData());
        }
    }

    public void updateUIAsync(final String showText, final String countText)
    {
        // 更新界面数据
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                setValidCarCardText(showText);
                setTotalNumText(countText);
            }
        });
    }

    /**
     * 处理服务器返回的车牌发行
     *
     * @param respBean
     */
    private void dealCardIssue(List<GetPlateNumberDownCardIssueResp.Bean> respBean, final String showText)
    {
        updateUIAsync(showText, String.valueOf(respBean.size()));

        for (int i = 0; i < respBean.size(); i++)
        {
            GetPlateNumberDownCardIssueResp.Bean temp = respBean.get(i);

            String oldstr = "";
            String newstr = "";

            List<GetCheDaoSetResp.DataBean> lstCDS = temp.getLstCDS();
            GetCardIssueResp.DataBean model = temp.getModel();
            L.e("lstCDS size:" + lstCDS.size());
            for (GetCheDaoSetResp.DataBean tempCheDao : lstCDS)
            {
                oldstr += "1";
                String ret = "";

                if (tempCheDao.DownCmdList.size() > 0)
                {
                    long currentTime = System.currentTimeMillis();
                    while (System.currentTimeMillis() - currentTime < Model.iDelayed * 1000)
                    {
                        ret = BaseApplication.getUdpSend().SendDownCmd(tempCheDao.getIP(), base64Cipher.decrypt(tempCheDao.DownCmdList.get(0).getBytes()));
                        L.e("ret:" + ret);
                        final String returnValue = ret;
                        if (!ret.equals("2"))
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    setValidCarCardText(showText);
                                    if (returnValue.equals("5"))
                                    {
                                        setValidCarCardText("用户数据已满");
                                        return;
                                    }
                                }
                            });
                            break;
                        }
                        else
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    setValidCarCardText("连接中断..");
                                }
                            });
                        }
                    }
                    if (ret.equals("0"))
                    {
                        newstr += "1";
                    }
                    else
                    {
                        mHandler.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                MessageBox.show(mActivity, "与控制机通讯不通");
                            }
                        });
                        return;
                    }
                }
            }

            L.e("oldstr:" + oldstr + ",newstr:" + newstr);
            if (oldstr.equals(newstr))
            {
                L.e("model:", model.toString());
                String sumBiao = model.getCPHDownloadSignal().substring(0, Model.stationID - 1) + "1" + model.getCPHDownloadSignal().substring(Model.stationID);
                L.e("sumBiao:" + sumBiao);
                requestUpdateCPHDownLoad((int) model.getID(), sumBiao);// 这里会相应的改变数据库中的数据信息
            }

            int precent = (i + 1) * 100 / respBean.size(); // 表示进度，可以用来更新进度条

            SystemClock.sleep(50);// 延时50ms
        }
    }


    private int requestUpdateCPHDownLoad(int ID, String Down)
    {
        String cardIssue = JsonSearchParam.getJsonModelWhenUpdateCPHDownLoad("CardIssue", Model.token, ID, Down);
        String resultUrl = GetServiceData.getInstance().generateResultUrl(cardIssue, null);
        L.e("resultUrl:" + resultUrl);

        String doPost = HttpUtils.doPost(resultUrl, null);
        L.e("doPost:" + doPost);
        if (doPost == null)
        {
            return -1;
        }
        else
        {
            GetCommonXXXResp getCommonXXXResp = mGson.fromJson(doPost, GetCommonXXXResp.class);
            return getCommonXXXResp.getData();
        }
    }

    private int requestBlackListDownload(int ID, String Down)
    {
        String cardIssue = JsonSearchParam.getJsonModelWhenBlackListUpdateCPHDownLoad("Blacklist", Model.token, ID, Down);
        String resultUrl = GetServiceData.getInstance().generateResultUrl(cardIssue, null);
        L.e("resultUrl:" + resultUrl);
        String doPost = HttpUtils.doPost(resultUrl, null);
        L.e("doPost:" + doPost);
        if (doPost == null)
        {
            return -1;
        }
        else
        {
            GetCommonXXXResp getCommonXXXResp = mGson.fromJson(doPost, GetCommonXXXResp.class);
            return getCommonXXXResp.getData();
        }
    }


    /**
     * 处理服务器返回黑名单信息
     */
    private void dealBlackListIssue(List<GetPlateNumberDownBlackListResp.Bean> respBean)
    {
        updateUIAsync("黑名单下载", String.valueOf(respBean.size()));
        for (int i = 0; i < respBean.size(); i++)
        {
            GetPlateNumberDownBlackListResp.Bean temp = respBean.get(i);

            String oldstr = "";
            String newstr = "";

            List<GetCheDaoSetResp.DataBean> lstCDS = temp.getLstCDS();
            for (GetCheDaoSetResp.DataBean tempCheDao : lstCDS)
            {
                oldstr += "1";
                String ret = "";

                if (tempCheDao.DownCmdList.size() > 0)
                {
                    long currentTime = System.currentTimeMillis();
                    while (System.currentTimeMillis() - currentTime < Model.iDelayed * 1000)
                    {
//                        sendbll.SetUsbType(ref usbHid, lstBL[i].lstCDS[j].XieYi); // ?????
                        ret = BaseApplication.getUdpSend().SendDownCmd(tempCheDao.getIP(), base64Cipher.decrypt(tempCheDao.DownCmdList.get(0).getBytes()));
                        final String returnValue = ret;
                        if (!ret.equals("2"))
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    setValidCarCardText("黑名单下载");
                                    if (returnValue.equals("5"))
                                    {
                                        setValidCarCardText("用户数据已满");
                                        return;
                                    }
                                }
                            });
                            break;
                        }
                        else
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    setValidCarCardText("连接中断..");
                                }
                            });
                        }
                    }
                    if (ret.equals("0"))
                    {
                        newstr += "1";
                    }
                    else
                    {
                        mHandler.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                MessageBox.show(mActivity, "与控制机通讯不通");
                            }
                        });
                        return;
                    }
                }
            }

            if (oldstr.equals(newstr))
            {
                String sumBiao = temp.getModel().getDownloadSignal().substring(0, Model.stationID - 1) + "1" + temp.getModel().getDownloadSignal().substring(Model.stationID);
                requestBlackListDownload((int) temp.getModel().getID(), sumBiao);
            }
            int precent = (i + 1) * 100 / respBean.size(); // 表示进度，可以用来更新进度条
            SystemClock.sleep(50);// 延时50ms
        }
    }

    /**
     * 处理服务器返回的黑名单注销信息
     */
    private void dealBlackListLoss(List<GetPlateNumberDownBlackListResp.Bean> respBean)
    {
        updateUIAsync("黑名单删除下载", String.valueOf(respBean.size()));
        for (int i = 0; i < respBean.size(); i++)
        {
            GetPlateNumberDownBlackListResp.Bean temp = respBean.get(i);

            String oldstr = "";
            String newstr = "";

            List<GetCheDaoSetResp.DataBean> lstCDS = temp.getLstCDS();
            for (GetCheDaoSetResp.DataBean tempCheDao : lstCDS)
            {
                oldstr += "1";
                String ret = "";

                if (tempCheDao.DownCmdList.size() > 0)
                {
                    long currentTime = System.currentTimeMillis();
                    while (System.currentTimeMillis() - currentTime < Model.iDelayed * 1000)
                    {
//                        sendbll.SetUsbType(ref usbHid, lstBL[i].lstCDS[j].XieYi);// 什么接口来替换
                        ret = BaseApplication.getUdpSend().SendDownCmd(tempCheDao.getIP(), base64Cipher.decrypt(tempCheDao.DownCmdList.get(0).getBytes()));
                        final String returnValue = ret;
                        if (!ret.equals("2"))
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    setValidCarCardText("黑名单删除下载");
                                    if (returnValue.equals("5"))
                                    {
                                        setValidCarCardText("用户数据已满");
                                        return;
                                    }
                                }
                            });
                            break;
                        }
                        else
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    setValidCarCardText("连接中断..");
                                }
                            });
                        }
                    }
                    if (ret.equals("0"))
                    {
                        newstr += "1";
                    }
                    else
                    {
                        mHandler.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                MessageBox.show(mActivity, "与控制机通讯不通");
                            }
                        });
                        return;
                    }
                }
            }

            if (oldstr.equals(newstr))
            {
                String sumBiao = temp.getModel().getDownloadSignal().substring(0, Model.stationID - 1) + "0" + temp.getModel().getDownloadSignal().substring(Model.stationID);
                if (sumBiao.equals(CR.stringPadLeft("", sumBiao.length(), '0')))
//                if (sumBiao == ("").PadLeft(sumTBiao.Length, '0'))
                {
//                    gsd.DeleteMYBlacklist(lstBL[i].model.ID);
                    requestDeleteMyBlacklist((int) temp.getModel().getID());
                }
                else
                {
                    requestBlackListDownload((int) temp.getModel().getID(), sumBiao);
                }
            }
            int precent = (i + 1) * 100 / respBean.size(); // 表示进度，可以用来更新进度条
            SystemClock.sleep(50);// 延时50ms
        }
    }

    private int requestDeleteMyBlacklist(int id)
    {
        String deleteBlacklistBy = JsonSearchParam.getJsonConditionWhenDeleteDataBy("DeleteBlacklistBy", Model.token, id);
        String resultUrl = GetServiceData.getInstance().generateResultUrl(deleteBlacklistBy, null);
        String doPost = HttpUtils.doPost(resultUrl, null);
        L.e("doPost:" + doPost);
        if (doPost == null)
        {
            return -1;
        }
        else
        {
            GetCommonXXXResp getCommonXXXResp = mGson.fromJson(doPost, GetCommonXXXResp.class);
            return getCommonXXXResp.getData();
        }
    }


    private void setValidCarCardText(String text)
    {
        tvValidCarCard.setText(text);
    }

    public void setTotalNumText(String countContent)
    {
        tvTotalNum.setText(countContent);
    }
}
