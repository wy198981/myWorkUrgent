package com.example.administrator.myparkingos.model.responseInfo;

/**
 * Created by Administrator on 2017-07-08.
 */
public class GetCarOutReportFormDataResp
{
}
