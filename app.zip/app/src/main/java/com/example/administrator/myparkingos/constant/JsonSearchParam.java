package com.example.administrator.myparkingos.constant;

import android.text.TextUtils;

import com.example.administrator.myparkingos.model.GetServiceData;
import com.example.administrator.myparkingos.model.RequestByURL;
import com.example.administrator.myparkingos.model.beans.gson.EntityCardIssue;
import com.example.administrator.myparkingos.ui.carParkSettingPager.video.SystemState;
import com.example.administrator.myparkingos.util.L;
import com.example.administrator.myparkingos.util.TimeConvertUtils;
import com.google.gson.Gson;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.Time;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by Administrator on 2017-03-29.
 */
public class JsonSearchParam
{
    private static final String ENCODE_FORMAT = "UTF-8";
    private static Gson gson = new Gson();


    private static String getSearchParam(Map<String, Object> dic, boolean isExclude, boolean isLike)
    {
        if (dic == null)
        {
            return null;
        }

        SelectModel selectModel = new SelectModel();
        Set<String> set = dic.keySet();
        for (String tempStr : set)
        {
            SelectModel.conditions conditions = selectModel.new conditions();
            conditions.setFieldName(tempStr);
            conditions.setOperator(isLike ? (isExclude ? "not like" : "like") : (isExclude ? "<>" : "="));
            conditions.setFieldValue(dic.get(tempStr));
            conditions.setCombinator("and");
            selectModel.getConditions().add(conditions);
        }
        selectModel.setCombinator("and");
        ArrayList<SelectModel> selectList = new ArrayList<>();
        selectList.add(selectModel);

        String s = gson.toJson(selectList); // 转换成String
        return s;
    }

    /**
     * 输入车牌，构建 JsonSearchParam 字符串
     * CPH lick %cph% and cardState=0 or CardState=2
     *
     * @param cph
     * @return
     */
    public static String getWhenGetCardIssue(String cph)
    {
        List<SelectModel> lstSM = new ArrayList<SelectModel>();
        SelectModel sm = new SelectModel();

        sm.getConditions().add(sm.new conditions("CPH", "like", "%" + cph + "%", "and"));
        lstSM.add(sm);

        sm = new SelectModel();
        sm.getConditions().add(sm.new conditions("CardState", "=", 0, "or"));
        sm.getConditions().add(sm.new conditions("CardState", "=", 2, "or"));
        lstSM.add(sm);

        String where = gson.toJson(lstSM);
        return URLEncoder.encode(where);
    }


    public static String getWhenGetOperators(String userNo)
    {
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("UserNO", userNo);

        String toJson = getSearchParam(map, false, false);
        return URLEncoder.encode(toJson);
    }

    public static String getWhenGetCheDaoSet(String stationID)
    {
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("StationID", stationID);
        String toJson = getSearchParam(map, false, false);
        return URLEncoder.encode(toJson);
    }

    public static String getWhenGetCameraSet(String cameraIp)
    {
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("VideoIP", cameraIp);
        String toJson = getSearchParam(map, false, false);
        return URLEncoder.encode(toJson);
    }

    public static String getWhenGetCarOutAndIn(String carParkNo)
    {
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("CarparkNO", carParkNo);
        String toJson = getSearchParam(map, false, true);
        return URLEncoder.encode(toJson);
    }

    public static String getWhenGetCarOutAndIn(Map<String, Object> map)
    {
        String toJson = getSearchParam(map, false, true);
        return URLEncoder.encode(toJson);
    }

    public static String getWhenSelectComeCPH_Like(String cph, String parkingNO)
    {
        L.i("getWhenSelectComeCPH_Like: cph," + cph + "parkingNO," + parkingNO);
        List<SelectModel> lstSM = new ArrayList<SelectModel>();
        SelectModel sm = new SelectModel();

        sm.getConditions().add(sm.new conditions("CPH", "like", "%" + cph + "%", "and"));
        sm.getConditions().add(sm.new conditions("bigsmall", "=", 0, "and"));
        sm.getConditions().add(sm.new conditions("CarParkNo", "=", parkingNO, "and"));
        lstSM.add(sm);

        String where = gson.toJson(lstSM);
        return URLEncoder.encode(where);// 编码方式，会出现乱码?
    }

    public static String getWhenGetCarTypeDef(String cardType)
    {
        List<SelectModel> lstSM = new ArrayList<SelectModel>();
        SelectModel sm = new SelectModel();

        String expectedCardType = "";
        if (cardType == null || cardType.trim().length() <= 0)
        {
        }
        else
        {
            if (cardType.trim().length() > 3)
            {
                expectedCardType = cardType.trim().substring(0, 3);
            }
            else
            {
                expectedCardType = cardType.trim();
            }
        }
        sm.getConditions().add(sm.new conditions("Enabled", "=", 1, "and"));
        sm.getConditions().add(sm.new conditions("Identifying", "like", expectedCardType + "%", "and"));
        lstSM.add(sm);

        String where = gson.toJson(lstSM);
        return URLEncoder.encode(where);// 编码方式，会出现乱码?
    }

    public static String getTempWhenGetCarTypeDef()
    {
        //查询是否使能，且字段为Identifying的临时车
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("Enabled", "%1%");
        map.put("Identifying", "Tmp%");
        String toJson = getSearchParam(map, false, true);

        String encode;
        try
        {
            encode = URLEncoder.encode(toJson, ENCODE_FORMAT);
            return encode;
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
            return null;
        }
    }

    public static String getMonthWhenGetCarTypeDef()
    {
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("Enabled", "1%");
        map.put("Identifying", "Mth%");
        String toJson = getSearchParam(map, false, true);

        String encode;
        try
        {
            encode = URLEncoder.encode(toJson, ENCODE_FORMAT);
            return encode;
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 无牌车查询字段
     *
     * @param dtStart
     * @param dtEnd
     * @return
     */
    public static String getWhenGetInNoCPH(Map<String, String> map, String dtStart, String dtEnd, String fieldName)
    {
        List<SelectModel> lstSM = new ArrayList<SelectModel>();
        SelectModel sm = new SelectModel();

        // 且 0为大车场，1为小车场。

        // 查询无牌车 且是大车场 且满足一定的匹配规则 且在一定的时间范围内;
        sm.getConditions().add(sm.new conditions("IsUnlicensed", "=", 1, "and"));
        sm.getConditions().add(sm.new conditions("BigSmall", "=", 0, "and"));

        for (Map.Entry<String, String> temp : map.entrySet())
        {
            sm.getConditions().add(sm.new conditions(temp.getKey(), "like", "%" + temp.getValue() + "%", "and"));
        }

        sm.getConditions().add(sm.new conditions(fieldName, ">=", dtStart, "and"));
        sm.getConditions().add(sm.new conditions(fieldName, "<=", dtEnd, "and"));

        lstSM.add(sm);

        String where = gson.toJson(lstSM);
        return URLEncoder.encode(where);
    }

    /**
     * 根据条件查询剩余车位屏信息
     *
     * @return
     */
    public static String getWhenGetLedSetting(int JiHao, String stationId)
    {
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("CtrID", String.valueOf(JiHao));
        map.put("StationID", stationId);
        String toJson = getSearchParam(map, false, false);
        String encode;
        try
        {
            encode = URLEncoder.encode(toJson, ENCODE_FORMAT);
            return encode;
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
            return null;
        }
    }


    public static String getWhenAutoCardNo()
    {
        List<SelectModel> lstSM = new ArrayList<SelectModel>();
        SelectModel sm = new SelectModel();

        sm.getConditions().add(sm.new conditions("CardNO", "like", "88______%", "or"));
        lstSM.add(sm);
        String where = gson.toJson(lstSM);
        return URLEncoder.encode(where);
    }

    public static String getWhenAutoUserNo()
    {
        List<SelectModel> lstSM = new ArrayList<SelectModel>();
        SelectModel sm = new SelectModel();

        sm.getConditions().add(sm.new conditions("UserNO", "like", "A_____%", "or"));
        lstSM.add(sm);
        String where = gson.toJson(lstSM);
        return URLEncoder.encode(where);
    }

    public static String getWhenJsonModel(Object object)
    {
        String toJson = gson.toJson(object);

        try
        {
            return URLEncoder.encode(toJson, ENCODE_FORMAT);
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
            return null;
        }
    }

    public static String getWhenGetCarChePIss(Map<String, Object> map)
    {
        List<SelectModel> lstSM = new ArrayList<SelectModel>();
        SelectModel sm = new SelectModel();

        sm.getConditions().add(sm.new conditions("SubSystem", "like", "1%", "and"));
        sm.getConditions().add(sm.new conditions("CardState", "=", "0", "and"));
        lstSM.add(sm);

        if (map != null && map.size() > 0)
        {
            for (String key : map.keySet())
            {
                sm.getConditions().add(sm.new conditions(key, "like", map.get(key), "and"));
            }
            lstSM.add(sm);
        }

        String where = gson.toJson(lstSM);
        return URLEncoder.encode(where);
    }


    public static String getJsonModelWhenUpdateAutoCPHDownLoad(String method, String token, int ID, String Down)
    {
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("ID", ID);
        String where = getSearchParam(map, false, false);

        map.clear();
        map.put("DownloadSignal", Down);
        String updstr = gson.toJson(map);
        String encode = URLEncoder.encode(updstr);

        return getUpdateFileds(method, token, URLEncoder.encode(where), encode);
    }

    public static String getJsonModelWhenUpdateCPHDownLoad(String method, String token, int ID, String Down)
    {
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("ID", ID);
        String where = getSearchParam(map, false, false);

        map.clear();
        map.put("CPHDownloadSignal", Down);
        String updstr = gson.toJson(map);
        String encode = URLEncoder.encode(updstr);

        return getUpdateFileds(method, token, URLEncoder.encode(where), encode);
    }

    public static String getJsonModelWhenBlackListUpdateCPHDownLoad(String method, String token, int ID, String Down)
    {
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("ID", ID);
        String where = getSearchParam(map, false, false);

        map.clear();
        map.put("DownloadSignal", Down);
        String updstr = gson.toJson(map);
        String encode = URLEncoder.encode(updstr);

        return getUpdateFileds(method, token, URLEncoder.encode(where), encode);
    }

    public static String getJsonConditionWhenDeleteDataBy(String method, String token, int ID)
    {
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("ID", ID);
        String where = getSearchParam(map, false, false);

        return String.format("%1$s?token=%2$s&jsonConditions=%3$s", method, token, URLEncoder.encode(where));
    }

    public static String getUpdateFileds(String method, String token, String where, String condition)
    {
        String result = "";
        String tableName = "";
        if (where == null)
        {
            tableName = "Update" + method;
            result = String.format("%1$s?token=%2$s&jsonModel=%3$s", tableName, token, condition);
        }
        else
        {
            tableName = "Update" + method + "Fields";
            result = String.format("%1$s?token=%2$s&jsonFieldValues=%3$s&jsonConditions=%4$s"
                    , tableName, token, condition, where);
        }
        return result;
    }

    public static String getCtrlNameFields(String method, String token, int stationID)
    {
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("StationID", stationID);
        String where = getSearchParam(map, false, false);

        Map<String, String> map1 = new LinkedHashMap<String, String>();
        map1.put("InOut", "asc");

        String orderField = OrderField.getOrderField(map1);
        return String.format("%1$s?token=%2$s&jsonSearchParam=%3$s&OrderField=%4$s"
                , method, token, URLEncoder.encode(where), orderField);
    }

    public static String getFindField(String method, String token, String where)
    {
        return String.format("%1$s?token=%2$s&jsonSearchParam=%3$s"
                , method, token, where);
    }

    public static String getFindFieldHavePage(String method, String token, String where, int pageSize, int page, String orderField)
    {
        return String.format("%1$s?token=%2$s&jsonSearchParam=%3$s&PageSize=%4$s&Page=%5$s&OrderField=%6$s"
                , method, token, where, pageSize, page, orderField);
    }

    public static String getDeleteTempOnGetCardIssue(String method, String token)
    {
        List<SelectModel> lstSM = new ArrayList<SelectModel>();
        SelectModel sm = new SelectModel();

        sm.setCombinator("and");
        sm.getConditions().add(sm.new conditions("CarCardType", "like", "Mth%", "and"));
        sm.getConditions().add(sm.new conditions("CardState", "=", 0, "and"));
        lstSM.add(sm);
        String encode = URLEncoder.encode(gson.toJson(lstSM));
        return getFindField(method, token, encode);

    }

    public static String getUpdateDataList(String method, String token, String where)
    {
        return String.format("%1$s?token=%2$s&jsonModelList=%3$s"
                , method, token, where);
    }

    public static String getDeleteField(String method, String token, String condition)
    {
        return String.format("%1$s?token=%2$s&jsonConditions=%3$s"
                , method, token, condition);
    }

    public static String getAutoTempDownLoad(String method, String token, int workStationNo, int inout, int flag)
    {
        String tmpstr = "";
        for (int i = 1; i < workStationNo; i++)
        {
            tmpstr += "_";
        }

        List<SelectModel> lstSM = new ArrayList<SelectModel>();
        SelectModel sm = new SelectModel();

        sm.setCombinator("and");
        sm.getConditions().add(sm.new conditions("DownloadSignal", "like", tmpstr + "1%", "and"));
        sm.getConditions().add(sm.new conditions("InOut", "=", inout, "and"));
        lstSM.add(sm);
        String encode = URLEncoder.encode(gson.toJson(lstSM));
        return getFindField(method, token, encode);
    }

    public static String getDeleteTemp(String method, String token, String strCPH)
    {
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("CPH", strCPH);
        String where = getSearchParam(map, false, false);
        return getDeleteField(method, token, where);
    }

    public static String getUpdateTempDownLoad(String method, String token, String strCPH, String Down)
    {
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("CPH", strCPH);
        String where = getSearchParam(map, false, false);

        map.clear();
        map.put("DownloadSignal", Down);
        String encode = URLEncoder.encode(gson.toJson(map));
        return getUpdateField(method, token, encode, where);
    }

    public static String getUpdateField(String method, String token, String condition, String where)
    {
        String tableName = "";
        String result = "";
        if (null == where)
        {
            tableName = "Update" + method;
            return String.format("%1$s?token=%2$s&jsonModel=%3$s"
                    , tableName, token, condition);
        }
        else
        {
            tableName = "Update" + method + "Fields";
            return String.format("%1$s?token=%2$s&jsonFieldValues=%3$s&jsonConditions=%4$s"
                    , tableName, token, condition, where);
        }
    }

    public static String getInfoModel(Object object)
    {
        String toJson = gson.toJson(object);
        try
        {
            return URLEncoder.encode(toJson, ENCODE_FORMAT);
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
            return null;
        }
    }

    public static String getChargeRuleString(String cardType)
    {

        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("CardType", cardType);
        String toJson = getSearchParam(map, false, false);
        String encode;
        try
        {
            encode = URLEncoder.encode(toJson, ENCODE_FORMAT);
            return encode;
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
            return null;
        }
    }

    public static String getMyCarComeRecord(String cardNo, String cph, String cardType)
    {
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("CardNo", cardNo);
        map.put("CPH", cph);
        map.put("CardType", cardType);
        String toJson = getSearchParam(map, false, false);
        String encode;
        try
        {
            encode = URLEncoder.encode(toJson, ENCODE_FORMAT);
            return encode;
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
            return null;
        }
    }

    public static String getMyfaxingssue(String cardNo)
    {
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("CardNo", cardNo);
        map.put("CardState", 0);
        String toJson = getSearchParam(map, false, false);
        String encode;
        try
        {
            encode = URLEncoder.encode(toJson, ENCODE_FORMAT);
            return encode;
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
            return null;
        }
    }

    public static String getCPHDJfxPersonnelData(String userNO, String userName, String department, String homeAddress, String idCard, String mobNumber)
    {
        List<SelectModel> lstSM = new ArrayList<SelectModel>();
        SelectModel sm = new SelectModel();

        if (!TextUtils.isEmpty(userNO))
        {
            sm.getConditions().add(sm.new conditions("UserNO", "like", "%" + userNO + "%", "and"));
        }
        if (!TextUtils.isEmpty(userName))
        {
            sm.getConditions().add(sm.new conditions("UserName", "like", "%" + userName + "%", "and"));
        }
        if (!TextUtils.isEmpty(department))
        {
            sm.getConditions().add(sm.new conditions("DeptName", "like", "%" + department + "%", "and"));
        }
        if (!TextUtils.isEmpty(homeAddress))
        {
            sm.getConditions().add(sm.new conditions("HomeAddress", "like", "%" + homeAddress + "%", "and"));
        }
        if (!TextUtils.isEmpty(idCard))
        {
            sm.getConditions().add(sm.new conditions("IDCard", "like", "%" + idCard + "%", "and"));
        }
        if (!TextUtils.isEmpty(mobNumber))
        {
            sm.getConditions().add(sm.new conditions("MobNumber", "like", "%" + mobNumber + "%", "and"));
        }

        if (sm.getConditions().size() == 0)// 个数为0
        {
            L.e("sm.getConditions().size() == 0");
            return null;
        }

        lstSM.add(sm);
        String encode = URLEncoder.encode(gson.toJson(lstSM));
        return encode;
    }

    public static String getByUserNo(String userNo)
    {
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("UserNO", userNo);
        String where = getSearchParam(map, false, false);
        return URLEncoder.encode(where);
    }

    public static String getRightGroup(String groupName)
    {
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("GroupName", groupName);
        String where = getSearchParam(map, false, false);
        return URLEncoder.encode(where);
    }

    public static String getDeletBlackBy(String cph)
    {
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("CPH", cph);
        String where = getSearchParam(map, false, false);
        return URLEncoder.encode(where);
    }

    public static String getSelectBlackList(String cph, String startTime, String endTime)
    {
        List<SelectModel> lstSM = new ArrayList<SelectModel>();
        SelectModel sm = new SelectModel();

        sm.getConditions().add(sm.new conditions("CPH", "=", cph, "and"));
        sm.getConditions().add(sm.new conditions("StartTime", "<", startTime, "and"));
        sm.getConditions().add(sm.new conditions("EndTime", ">", endTime, "and"));
        sm.getConditions().add(sm.new conditions("AddDelete", "=", 0, "and"));
        lstSM.add(sm);
        String encode = URLEncoder.encode(gson.toJson(lstSM));
        return encode;
    }

    public static String getByUserNo(String userNo, boolean isExclude)
    {
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("UserNO", userNo);
        String where = getSearchParam(map, isExclude, false);
        return URLEncoder.encode(where);
    }

    public static String getSelectDuringTime(int days)
    {
        List<SelectModel> lstSM = new ArrayList<SelectModel>();
        SelectModel sm = new SelectModel();

        sm.getConditions().add(sm.new conditions("CarValidEndDate", ">=", TimeConvertUtils.getCurrentYMD(), "and"));
        sm.getConditions().add(sm.new conditions("CarValidEndDate", "<=", TimeConvertUtils.getAddDays(System.currentTimeMillis(), days), "and"));
        lstSM.add(sm);
        String encode = URLEncoder.encode(gson.toJson(lstSM));
        return encode;
    }

    public static String getSelectDuringTime(String startTime, String endTime)
    {
        List<SelectModel> lstSM = new ArrayList<SelectModel>();
        SelectModel sm = new SelectModel();

        sm.getConditions().add(sm.new conditions("CarValidEndDate", ">=", startTime, "and"));
        sm.getConditions().add(sm.new conditions("CarValidEndDate", "<=", endTime, "and"));
        lstSM.add(sm);
        String encode = URLEncoder.encode(gson.toJson(lstSM));
        return encode;
    }

    public static String getDealLineByCarNo(String carNo)
    {
        List<SelectModel> lstSM = new ArrayList<SelectModel>();
        SelectModel sm = new SelectModel();
        sm.getConditions().add(sm.new conditions("CPH", "like", "%" + carNo + "%", "and"));
        lstSM.add(sm);

        sm.getConditions().add(sm.new conditions("CarCardType", "like", "Mth%", "or"));
        sm.getConditions().add(sm.new conditions("CarCardType", "like", "Fre%", "or"));
        lstSM.add(sm);

        sm = new SelectModel();
        sm.getConditions().add(sm.new conditions("CardState", "<>", "5", "and"));
        lstSM.add(sm);
        String encode = URLEncoder.encode(gson.toJson(lstSM));
        return encode;
    }

    public static String getDealLineByUserNo(String userNo)
    {
        List<SelectModel> lstSM = new ArrayList<SelectModel>();
        SelectModel sm = new SelectModel();
        sm.getConditions().add(sm.new conditions("UserNO", "like", "%" + userNo + "%", "and"));
        lstSM.add(sm);

        sm.getConditions().add(sm.new conditions("CarCardType", "like", "Mth%", "or"));
        sm.getConditions().add(sm.new conditions("CarCardType", "like", "Fre%", "or"));
        lstSM.add(sm);

        sm = new SelectModel();
        sm.getConditions().add(sm.new conditions("CardState", "<>", "5", "and"));
        lstSM.add(sm);
        String encode = URLEncoder.encode(gson.toJson(lstSM));
        return encode;
    }

    public static String getInParkSelectSchemeInfo(String schName)
    {
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("SchName", schName);
        String where = getSearchParam(map, false, false);
        return URLEncoder.encode(where);
    }

    public static String getInParkSelectSchemeName(String queryTable)
    {
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("QueryTable", queryTable);
        String where = getSearchParam(map, false, false);
        return URLEncoder.encode(where);
    }

    public static String getQueryValue(String date)
    {
        List<SelectModel> lstSM = new ArrayList<SelectModel>();
        SelectModel sm = new SelectModel();
        sm.getConditions().add(sm.new conditions("InTime", ">=", date, "and"));
        lstSM.add(sm);
        String encode = URLEncoder.encode(gson.toJson(lstSM));
        return encode;
    }
}
