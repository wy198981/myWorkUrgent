package com.example.administrator.myparkingos.util;

/**
 * Created by Administrator on 2017-05-04.
 */
public interface OpenGateCallBack
{
    void success(String strRst);
    void failed();
}
