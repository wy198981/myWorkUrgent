package com.example.administrator.myparkingos.model.requestInfo;

import java.util.Arrays;

/**
 * Created by Administrator on 2017-06-07.
 */
public class AddOfflineInOutReq
{
    private String token; // Y 用户登录时候获取的token值
    private Integer StationId; // Y 工作站编号
    private Integer CtrlNumber; // Y 车道机号
    private String[] DataList; // Y 离线记录数据组成的字符串数组。
    private String OnlineState; // N 在线状态。1为在线获取到的离线记录；2为通过U盘读取到的离线记录。
    private String Reserved; // N 备用字段
    private String CallBack; // N 是否使用JSONP方式。关于JSONP方式请参考Javascript跨域访问一节。

    public String getToken()
    {
        return token;
    }

    public void setToken(String token)
    {
        this.token = token;
    }

    public Integer getStationId()
    {
        return StationId;
    }

    public void setStationId(Integer stationId)
    {
        StationId = stationId;
    }

    public Integer getCtrlNumber()
    {
        return CtrlNumber;
    }

    public void setCtrlNumber(Integer ctrlNumber)
    {
        CtrlNumber = ctrlNumber;
    }

    public String[] getDataList()
    {
        return DataList;
    }

    public void setDataList(String[] dataList)
    {
        DataList = dataList;
    }

    public String getOnlineState()
    {
        return OnlineState;
    }

    public void setOnlineState(String onlineState)
    {
        OnlineState = onlineState;
    }

    public String getReserved()
    {
        return Reserved;
    }

    public void setReserved(String reserved)
    {
        Reserved = reserved;
    }

    public String getCallBack()
    {
        return CallBack;
    }

    public void setCallBack(String callBack)
    {
        CallBack = callBack;
    }

    @Override
    public String toString()
    {
        return "AddOfflineInOutReq{" +
                "token='" + token + '\'' +
                ", StationId=" + StationId +
                ", CtrlNumber=" + CtrlNumber +
                ", DataList=" + Arrays.toString(DataList) +
                ", OnlineState='" + OnlineState + '\'' +
                ", Reserved='" + Reserved + '\'' +
                ", CallBack='" + CallBack + '\'' +
                '}';
    }
}
