package com.example.administrator.myparkingos.ui;

/**
 * Created by Administrator on 2017-04-13.
 */
public class Summary
{
    /// <summary>
    /// txbSurplusCarCount (剩余车位)
    /// </summary>
    public int SurplusCarCount ;

    /// <summary>
    /// lblMthCount  (记录场内固定车总数)
    /// </summary>
    public int MthCount ;

    /// <summary>
    /// lblTmpCount (记录场内临时车总数)
    /// </summary>
    public int TmpCount ;

    /// <summary>
    ///lblFreCount (记录场内免费车总数)
    /// </summary>
    public int FreCount ;

    /// <summary>
    /// lblStrCount（记录场内储值车总数）
    /// </summary>
    public int StrCount ;

    /// <summary>
    /// lblOutCount (记录场内派出车数)
    /// </summary>
    public int OutCount ;

    /// <summary>
    /// lblOpenCount  (手动开闸数)
    /// </summary>
    public int OpenCount ;

    /// <summary>
    /// lblFreMoney  (免费金额)
    /// </summary>
    public double FreMoney ;

    /// <summary>
    /// lblMoneyCount  (总收费金额)
    /// </summary>
    public double MoneyCount ;

}
