package com.example.administrator.myparkingos.constant;

import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/**
 * Created by Administrator on 2017-03-29.
 */
public class OrderField
{
    /**
     * 获取查询的升序降序字段
     * @param cphOrder
     * @return
     */
    public static String getWhenGetCardIssue(String cphOrder)
    {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("CPH", cphOrder);

        String orderField = getOrderField(hashMap);
        return orderField;
    }

    public static String getWhenGetCheDaoSet(String onlineOrder, String ctrlNumberOrder, String inOutOrder)
    {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("OnLine", onlineOrder);
        hashMap.put("CtrlNumber", ctrlNumberOrder);
        hashMap.put("InOut", inOutOrder);

        String orderField = getOrderField(hashMap);
        return orderField;
    }

    public static String getWhenGetCarOut(String order)
    {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("OutTime", order);

        String orderField = getOrderField(hashMap);
        return orderField;
    }

    public static String getWhenGetCarIn(String order)
    {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("ID", order);

        String orderField = getOrderField(hashMap);
        return orderField;
    }

    public static String getSelectComeCPH_Like(String order)
    {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("InTime", order);

        String orderField = getOrderField(hashMap);
        return orderField;
    }

    public static String getOrderFieldObject(Map<String, Object> inMap)
    {
        if (inMap == null)
        {
            return null;
        }

        String order = "";
        int count = 0;
        Set<String> keySet = inMap.keySet();
        for (String tempStr : keySet)
        {
            count++;
            if (count == 1)
            {
                order = tempStr + " " + inMap.get(tempStr);
            }
            else
            {
                order += "," + tempStr + " " + inMap.get(tempStr);
            }
        }
//        return order;
        return URLEncoder.encode(order); //where条件都没有经过编码转换
    }

    public static String getOrderField(Map<String, String> inMap)
    {
        if (inMap == null)
        {
            return null;
        }

        String order = "";
        int count = 0;
        Set<String> keySet = inMap.keySet();
        for (String tempStr : keySet)
        {
            count++;
            if (count == 1)
            {
                order = tempStr + " " + inMap.get(tempStr);
            }
            else
            {
                order += "," + tempStr + " " + inMap.get(tempStr);
            }
        }
//        return order;
        return URLEncoder.encode(order); //where条件都没有经过编码转换
    }


    public static String getWhenGetReasonNOPlate(String order)
    {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("ItemID", order);

        String orderField = getOrderField(hashMap);
        return orderField;
    }

    public static String getWhenAutoCardNo(String order)
    {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("CardNO", order);

        String orderField = getOrderField(hashMap);
        return orderField;
    }

    public static String getWhenAutoUserNo(String order)
    {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("UserNo", order);

        String orderField = getOrderField(hashMap);
        return orderField;
    }

    public static String getWhenGetCarChePIss(String order)
    {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("CarissueDate", order);

        String orderField = getOrderField(hashMap);
        return orderField;
    }

    public static String getAutoTempDownload(int order)
    {
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("InOut", order);
        String orderField = getOrderFieldObject(hashMap);
        return orderField;
    }

    public static String getAutoTempDownLoad(String order)
    {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("InTime", order);
        String orderField = getOrderField(hashMap);
        return orderField;
    }

    public static String getUserInfo(String order)
    {
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("UserNo", order);
        String orderField = getOrderFieldObject(hashMap);
        return orderField;
    }

    public static String getPersonnel(String order)
    {
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("UserNo", order);
        String orderField = getOrderFieldObject(hashMap);
        return orderField;
    }

    public static String getSelectCardIssue(String order)
    {
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("CarissueDate", order);
        String orderField = getOrderFieldObject(hashMap);
        return orderField;
    }

    public static String getOperators(String id)
    {
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("ID", id);
        String orderField = getOrderFieldObject(hashMap);
        return orderField;
    }

    public static String getQueryValueOrder(String field, String asc)
    {
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put(field, asc);
        String orderField = getOrderFieldObject(hashMap);
        return orderField;
    }
}
