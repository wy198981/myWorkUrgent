package com.example.administrator.myparkingos.model.responseInfo;

import java.util.List;

/**
 * Created by Administrator on 2017-07-06.
 */
public class GetQuerySchemeResp
{
    private String rcode;  // 参考错误码列表
    private String msg;  //错误信息
    private int PageIndex;  //当前页码。仅当查询时指定了分页参数才有此值。
    private int PageSize;  // 分页大小。仅当查询时指定了分页参数才有此值。
    private int TotalRows;  //总行数。仅当查询时指定了分页参数才有此值。
    //Data  参考说明中的描述    如果没有指定ExportFields参数则为数据Model数组，否则为下载导出文件的完整URL


    @Override
    public String toString()
    {
        return "GetQuerySchemeResp{" +
                "rcode='" + rcode + '\'' +
                ", msg='" + msg + '\'' +
                ", PageIndex=" + PageIndex +
                ", PageSize=" + PageSize +
                ", TotalRows=" + TotalRows +
                ", data=" + data +
                '}';
    }

    private List<DataBean> data;

    public String getRcode()
    {
        return rcode;
    }

    public void setRcode(String rcode)
    {
        this.rcode = rcode;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg(String msg)
    {
        this.msg = msg;
    }

    public int getPageIndex()
    {
        return PageIndex;
    }

    public void setPageIndex(int pageIndex)
    {
        PageIndex = pageIndex;
    }

    public int getPageSize()
    {
        return PageSize;
    }

    public void setPageSize(int pageSize)
    {
        PageSize = pageSize;
    }

    public int getTotalRows()
    {
        return TotalRows;
    }

    public void setTotalRows(int totalRows)
    {
        TotalRows = totalRows;
    }

    public List<DataBean> getData()
    {
        return data;
    }

    public void setData(List<DataBean> data)
    {
        this.data = data;
    }

    public static class DataBean
    {
        private long ID; // Y 自增长唯一标识
        private String QueryTable; // Y 表名
        private int SchId; // Y
        private String SchName; // Y 方案名称
        private String FieldName; // Y 匹配字段
        private int Operators; // Y 匹配操作符。0 等于，1 包含，2 小于，3 大于，4 小于或等于，5 大于或等于，6 不等于。
        private String Selectvalues; // N 匹配值
        private String startime; // Y 开始时间
        private String endtime; // Y 结束时间

        @Override
        public String toString()
        {
            return "DataBean{" +
                    "ID=" + ID +
                    ", QueryTable='" + QueryTable + '\'' +
                    ", SchId=" + SchId +
                    ", SchName='" + SchName + '\'' +
                    ", FieldName='" + FieldName + '\'' +
                    ", Operators=" + Operators +
                    ", Selectvalues='" + Selectvalues + '\'' +
                    ", startime='" + startime + '\'' +
                    ", endtime='" + endtime + '\'' +
                    '}';
        }

        public long getID()
        {
            return ID;
        }

        public void setID(long ID)
        {
            this.ID = ID;
        }

        public String getQueryTable()
        {
            return QueryTable;
        }

        public void setQueryTable(String queryTable)
        {
            QueryTable = queryTable;
        }

        public int getSchId()
        {
            return SchId;
        }

        public void setSchId(int schId)
        {
            SchId = schId;
        }

        public String getSchName()
        {
            return SchName;
        }

        public void setSchName(String schName)
        {
            SchName = schName;
        }

        public String getFieldName()
        {
            return FieldName;
        }

        public void setFieldName(String fieldName)
        {
            FieldName = fieldName;
        }

        public int getOperators()
        {
            return Operators;
        }

        public void setOperators(int operators)
        {
            Operators = operators;
        }

        public String getSelectvalues()
        {
            return Selectvalues;
        }

        public void setSelectvalues(String selectvalues)
        {
            Selectvalues = selectvalues;
        }

        public String getStartime()
        {
            return startime;
        }

        public void setStartime(String startime)
        {
            this.startime = startime;
        }

        public String getEndtime()
        {
            return endtime;
        }

        public void setEndtime(String endtime)
        {
            this.endtime = endtime;
        }
    }
}
