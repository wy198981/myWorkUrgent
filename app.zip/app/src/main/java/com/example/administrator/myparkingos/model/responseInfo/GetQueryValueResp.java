package com.example.administrator.myparkingos.model.responseInfo;

import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2017-07-08.
 */
public class GetQueryValueResp
{

    /**
     * rcode : 200
     * msg : OK
     * data : [{"DeptId":0,"CarparkNOInStation":0,"InGateName":"入口车道9","IsFreeOut":false,"IsCentralCharge":false,"IsAsMtp":false,"IsUnlicensed":false,"IsOvertimeCharge":false,"AsMtpType":0,"ID":0}]
     */

    private String rcode;
    private String msg;
//    private List<DataBean> data;

    private List<Map<String, Object>> data;

    @Override
    public String toString()
    {
        return "GetQueryValueResp{" +
                "rcode='" + rcode + '\'' +
                ", msg='" + msg + '\'' +
                ", data=" + data +
                '}';
    }

    public String getRcode()
    {
        return rcode;
    }

    public void setRcode(String rcode)
    {
        this.rcode = rcode;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg(String msg)
    {
        this.msg = msg;
    }

    public List<Map<String, Object>> getData()
    {
        return data;
    }

    public void setData(List<Map<String, Object>> data)
    {
        this.data = data;
    }
}
