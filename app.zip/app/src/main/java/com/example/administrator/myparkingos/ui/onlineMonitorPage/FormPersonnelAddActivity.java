package com.example.administrator.myparkingos.ui.onlineMonitorPage;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.myUserControlLibrary.DateTimePicker;
import com.example.administrator.myparkingos.myUserControlLibrary.niceSpinner.NiceSpinner;

/**
 * Created by Administrator on 2017-02-16.
 * 【在线监控】 -->> 【车牌登记】 -->> 【添加人事信息】
 */
public class FormPersonnelAddActivity extends AppCompatActivity implements View.OnClickListener
{
    private EditText txtUserNO;
    private EditText txtUserName;
    private DateTimePicker dpBirthDate;
    private DateTimePicker dpWorkDate;
    private RadioButton rbtMan;
    private RadioButton rbtWoman;
    private RadioButton rbtMarried;
    private RadioButton personnelAddUnMarried;
    private NiceSpinner cmbDeptName;
    private NiceSpinner cmbJob;
    private EditText txtIDCard;
    private EditText txtCarPosCount;
    private EditText txtTelephone;
    private EditText txtPhone;
    private EditText txtCredentials;
    private EditText txtNativePlace;
    private EditText txtHomeAddress;
    private Button btnSave;
    private Button btnUpdate;
    private Button btnCarPic;
    private Button btnPeoplePic;
    private Button btVedio;
    private Button btnColose;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.personneladd_activity);
        initView();

        Window window = getWindow();
        WindowManager m = getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = window.getAttributes(); // 获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 1 / 2); // 改变的是dialog框在屏幕中的位置而不是大小
        p.width = (int) (d.getWidth() * 1 / 2); // 宽度设置为屏幕的0.65
        window.setAttributes(p);
    }

    private void initView()
    {
        txtUserNO = (EditText) findViewById(R.id.txtUserNO);
        txtUserName = (EditText) findViewById(R.id.txtUserName);
        dpBirthDate = (DateTimePicker) findViewById(R.id.dpBirthDate);
        dpWorkDate = (DateTimePicker) findViewById(R.id.dpWorkDate);
        rbtMan = (RadioButton) findViewById(R.id.rbtMan);
        rbtWoman = (RadioButton) findViewById(R.id.rbtWoman);
        rbtMarried = (RadioButton) findViewById(R.id.rbtMarried);
        personnelAddUnMarried = (RadioButton) findViewById(R.id.personnelAddUnMarried);
        cmbDeptName = (NiceSpinner) findViewById(R.id.cmbDeptName);
        cmbJob = (NiceSpinner) findViewById(R.id.cmbJob);
        txtIDCard = (EditText) findViewById(R.id.txtIDCard);
        txtCarPosCount = (EditText) findViewById(R.id.txtCarPosCount);
        txtTelephone = (EditText) findViewById(R.id.txtTelephone);
        txtPhone = (EditText) findViewById(R.id.txtPhone);
        txtCredentials = (EditText) findViewById(R.id.txtCredentials);
        txtNativePlace = (EditText) findViewById(R.id.txtNativePlace);
        txtHomeAddress = (EditText) findViewById(R.id.txtHomeAddress);
        btnSave = (Button) findViewById(R.id.btnSave);
        btnUpdate = (Button) findViewById(R.id.btnUpdate);
        btnCarPic = (Button) findViewById(R.id.btnCarPic);
        btnPeoplePic = (Button) findViewById(R.id.btnPeoplePic);
        btVedio = (Button) findViewById(R.id.btVedio);
        btnColose = (Button) findViewById(R.id.btnColose);

        btnSave.setOnClickListener(this);
        btnUpdate.setOnClickListener(this);
        btnCarPic.setOnClickListener(this);
        btnPeoplePic.setOnClickListener(this);
        btVedio.setOnClickListener(this);
        btnColose.setOnClickListener(this);
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.btnSave:

                break;
            case R.id.btnUpdate:

                break;
            case R.id.btnCarPic:

                break;
            case R.id.btnPeoplePic:

                break;
            case R.id.btVedio:

                break;
            case R.id.btnColose:

                break;
        }
    }

}
