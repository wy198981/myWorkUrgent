package com.example.administrator.myparkingos.model.requestInfo;

/**
 * Created by Administrator on 2017-06-30.
 */
public class ChangeCarValidDateReq
{
    private String token; // Y 用户登录时候获取的token值
    private String CardNO; // Y 发行记录的车辆编号
    private String ChargeAmount; // Y 收费金额
    private String EndDate; // Y 新的有效期结束日期。如20170301
    private String memo; // Y 备注
    private String StartDate; // N 新的有效期开始日期。默认为当天日期。如20170201
    private String CallBack; // N 是否使用JSONP方式。关于JSONP方式请参考Javascript跨域访问一节。

    public String getToken()
    {
        return token;
    }

    public void setToken(String token)
    {
        this.token = token;
    }

    public String getCardNO()
    {
        return CardNO;
    }

    public void setCardNO(String cardNO)
    {
        CardNO = cardNO;
    }

    public String getChargeAmount()
    {
        return ChargeAmount;
    }

    public void setChargeAmount(String chargeAmount)
    {
        ChargeAmount = chargeAmount;
    }

    public String getEndDate()
    {
        return EndDate;
    }

    public void setEndDate(String endDate)
    {
        EndDate = endDate;
    }

    public String getMemo()
    {
        return memo;
    }

    public void setMemo(String memo)
    {
        this.memo = memo;
    }

    public String getStartDate()
    {
        return StartDate;
    }

    public void setStartDate(String startDate)
    {
        StartDate = startDate;
    }

    public String getCallBack()
    {
        return CallBack;
    }

    public void setCallBack(String callBack)
    {
        CallBack = callBack;
    }

    @Override
    public String toString()
    {
        return "ChangeCarValidDateReq{" +
                "token='" + token + '\'' +
                ", CardNO='" + CardNO + '\'' +
                ", ChargeAmount='" + ChargeAmount + '\'' +
                ", EndDate='" + EndDate + '\'' +
                ", memo='" + memo + '\'' +
                ", StartDate='" + StartDate + '\'' +
                ", CallBack='" + CallBack + '\'' +
                '}';
    }
}
