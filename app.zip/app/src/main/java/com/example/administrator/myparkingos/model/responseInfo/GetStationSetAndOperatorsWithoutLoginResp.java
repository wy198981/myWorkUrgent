package com.example.administrator.myparkingos.model.responseInfo;

import java.util.List;

/**
 * Created by Administrator on 2017-05-02.
 */
public class GetStationSetAndOperatorsWithoutLoginResp
{
    private String   rcode; // 参考错误码列表
    private String   msg; // 错误信息
    private DataBean   data; //

    public String getRcode()
    {
        return rcode;
    }

    public void setRcode(String rcode)
    {
        this.rcode = rcode;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg(String msg)
    {
        this.msg = msg;
    }

    public DataBean getData()
    {
        return data;
    }

    public void setData(DataBean data)
    {
        this.data = data;
    }

    @Override
    public String toString()
    {
        return "GetStationSetAndOperatorsWithoutLoginResp{" +
                "rcode='" + rcode + '\'' +
                ", msg='" + msg + '\'' +
                ", data=" + data +
                '}';
    }

    public static class DataBean
    {
        List<GetOperatorsResp.DataBean> Operators;
        List<GetStationSetWithoutLoginResp.DataBean> Stations;

        public List<GetOperatorsResp.DataBean> getOperators()
        {
            return Operators;
        }

        public void setOperators(List<GetOperatorsResp.DataBean> operators)
        {
            Operators = operators;
        }

        public List<GetStationSetWithoutLoginResp.DataBean> getStations()
        {
            return Stations;
        }

        public void setStations(List<GetStationSetWithoutLoginResp.DataBean> stations)
        {
            Stations = stations;
        }

        @Override
        public String toString()
        {
            return "DataBean{" +
                    "Operators=" + Operators +
                    ", Stations=" + Stations +
                    '}';
        }
    }
}
