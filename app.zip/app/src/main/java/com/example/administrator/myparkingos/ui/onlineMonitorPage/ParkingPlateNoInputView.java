package com.example.administrator.myparkingos.ui.onlineMonitorPage;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.constant.CR;
import com.example.administrator.myparkingos.constant.ColumnName;
import com.example.administrator.myparkingos.myUserControlLibrary.radioBtn.FlowRadioGroup;
import com.example.administrator.myparkingos.myUserControlLibrary.radioBtn.MyRadioGroup;
import com.example.administrator.myparkingos.myUserControlLibrary.spinnerList.AbstractSpinerAdapter;
import com.example.administrator.myparkingos.myUserControlLibrary.spinnerList.SpinerPopWindow;
import com.example.administrator.myparkingos.util.AppOperation;
import com.example.administrator.myparkingos.util.L;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017-03-10.
 */
public class ParkingPlateNoInputView implements AbstractSpinerAdapter.IOnItemSelectListener
{
    private final Window window;
    private Dialog dialog;
    private MyRadioGroup rgSelectProvince;
    private Button btnCarInputOk;
    private Button btnCarIntCancel;
    private Activity mActivity;
    private EditText etCPH;
    private String province = null;
    private int mInOut = 0;// 0,in;1,out
    private TextView tvProvinceText;
    private SpinerPopWindow mPopWindow;
    private AbstractSpinerAdapter popAdapter;
    private ArrayList<String> carPopData;
    private RadioGroup rgCarPlateClass;

    private int charMaxNum = 7;// 个数；
    private TextView tvJCNumber;

    private final int isPTIndex = 0;
    private final int isJinCIndex = 1;
    private final int isJCIndex = 2;
    private final int isWJIndex = 3;

    public ParkingPlateNoInputView(Activity activity, int inOut)
    {
        this.mInOut = inOut;
        this.mActivity = activity;
        dialog = new Dialog(activity); // @android:style/Theme.Dialog
        dialog.setContentView(R.layout.dialog_carin);
        dialog.setCanceledOnTouchOutside(true);

        window = dialog.getWindow();
        WindowManager m = activity.getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = window.getAttributes(); // 获取对话框当前的参数值
//        p.height = (int) (d.getHeight() * 1 / 2); // 改变的是dialog框在屏幕中的位置而不是大小 1/ 2
//        p.width = (int) (d.getWidth() * 1 / 4.5); // 宽度设置为屏幕的0.65 (这个高度正好 1/1.7 1/4.5)

        p.height = (int) (d.getHeight() * 1 / 1.2); // 改变的是dialog框在屏幕中的位置而不是大小 1/ 2
        p.width = (int) (d.getWidth() * 1 / 3); // 宽度设置为屏幕的0.65 (这个高度正好 1/1.7 1/4.5)
        window.setAttributes(p);

        dialog.setTitle(activity.getResources().getString(R.string.parkMontior_carInTitle));
        initView();
    }

    // 选择武警时，需要特殊处理;
    private boolean isWJChecked = false;

    private void initView()
    {
        rgSelectProvince = (MyRadioGroup) dialog.findViewById(R.id.rgSelectProvince);

        btnCarInputOk = (Button) dialog.findViewById(R.id.btnCarInputOk);
        btnCarIntCancel = (Button) dialog.findViewById(R.id.btnCarIntCancel);

        etCPH = (EditText) dialog.findViewById(R.id.etCPH);
        tvProvinceText = (TextView) dialog.findViewById(R.id.tvProvinceText);

        rgCarPlateClass = (RadioGroup) dialog.findViewById(R.id.rgCarPlateClass);

        btnCarInputOk.setOnClickListener(dialogListern);
        btnCarIntCancel.setOnClickListener(dialogListern);

        RadioButton childAt = (RadioButton) rgCarPlateClass.getChildAt(0);
        childAt.setChecked(true);//开始默认是普通车辆的选择

        // 选择车辆类型触发的动作
        tvJCNumber = (TextView) dialog.findViewById(R.id.tvJCNumber);
        rgCarPlateClass.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                for (int i = 0; i < group.getChildCount(); i++)
                {
                    if (group.getChildAt(i).getId() == checkedId)
                    {
                        switch (i)
                        {
                            case isPTIndex:
                                rbtPT_Click();//普通车辆
                                isWJChecked = false;
                                break;
                            case isJinCIndex:
                                rbtJinC_Click();//警车
                                isWJChecked = false;
                                break;
                            case isJCIndex:
                                rbtJC_Click();//军车
                                isWJChecked = false;
                                break;
                            case isWJIndex:
                                rbtWJ_Click();//武警
                                isWJChecked = true;
                                break;
                            default:
                                break;
                        }
                        break;
                    }
                }
            }
        });

        /**
         * 主要是对于武警处理时，需要将车牌放到编辑框中
         */
        rgSelectProvince.setOnCheckedChangeListener(new MyRadioGroup.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(MyRadioGroup group, int checkedId)
            {
                String currentProvince = getCurrentProvince();
                tvProvinceText.setText(currentProvince);

                if (isWJChecked == true)// 在点击的时候
                {
                    String txtContent = etCPH.getText().toString();
                    String modifyCPH = "";
                    if (txtContent.length() > 0)
                    {
                        String strCPH = "京津冀晋蒙辽吉黑沪苏浙皖闽赣鲁豫鄂湘粤桂琼渝川贵云藏陕甘青宁新港澳台警使武领学民航";
                        if (strCPH.contains(txtContent.substring(0, 1)))
                        {
                            modifyCPH = currentProvince + txtContent.substring(1);
                        }
                        else
                        {
                            modifyCPH = currentProvince + txtContent;
                        }
                    }
                    else
                    {
                        modifyCPH = currentProvince + etCPH.getText().toString();
                    }

                    etCPH.setText(modifyCPH);
                    if (modifyCPH.length() > 0)
                    {
                        etCPH.setSelection(modifyCPH.length());
                    }
                    tvProvinceText.setText("WJ");
                }
            }
        });

//        rgSelectProvince.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
//        {
//            @Override
//            public void onCheckedChanged(RadioGroup group, int checkedId)
//            {
//                String currentProvince = getCurrentProvince();
//                tvProvinceText.setText(currentProvince);
//
//                if (isWJChecked == true)// 在点击的时候
//                {
//                    String txtContent = etCPH.getText().toString();
//                    String modifyCPH = "";
//                    if (txtContent.length() > 0)
//                    {
//                        String strCPH = "京津冀晋蒙辽吉黑沪苏浙皖闽赣鲁豫鄂湘粤桂琼渝川贵云藏陕甘青宁新港澳台警使武领学民航";
//                        if (strCPH.contains(txtContent.substring(0, 1)))
//                        {
//                            modifyCPH = currentProvince + txtContent.substring(1);
//                        }
//                        else
//                        {
//                            modifyCPH = currentProvince + txtContent;
//                        }
//                    }
//                    else
//                    {
//                        modifyCPH = currentProvince + etCPH.getText().toString();
//                    }
//
//                    etCPH.setText(modifyCPH);
//                    if (modifyCPH.length() > 0)
//                    {
//                        etCPH.setSelection(modifyCPH.length());
//                    }
//                    tvProvinceText.setText("WJ");
//                }
//            }
//        });

        /**
         * 监听当车牌的类型变化时，触发的判断和操作
         */
//        AppOperation.hiddenSoftInput(window, etCPH);
        etCPH.addTextChangedListener(new TextWatcher()
        {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after)
            {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count)
            {

            }

            @Override
            public void afterTextChanged(Editable s)
            {
                String s1 = s.toString().toString().toUpperCase();
                int length = s1.length();
                etCPH.removeTextChangedListener(this);

                if (s1.contains("O") || s1.contains("I"))
                {
                    if (length == 0)
                    {
                        etCPH.setText("");
                    }
                    else
                    {
                        etCPH.setText(s1.substring(0, s1.length() - 1));
                        etCPH.setSelection(s1.length() - 1);
                    }
                    Toast.makeText(mActivity, "你输入的字数为o或是为i", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    etCPH.setText(s1);
                    etCPH.setSelection(s1.length());
                }

                if (s1.length() > charMaxNum)
                {
                    Toast.makeText(mActivity, "你输入的字数已经超过了限制！" + charMaxNum, Toast.LENGTH_SHORT).show();
                    etCPH.setText(s1.substring(0, charMaxNum));
                    etCPH.setSelection(charMaxNum);
                    etCPH.addTextChangedListener(this);
                    return;
                }
                etCPH.addTextChangedListener(this);
                String haveJCNumber = "";
                if (tvJCNumber.getVisibility() == View.VISIBLE)
                {
                    haveJCNumber = tvJCNumber.getText().toString();
                }

                String CPH = etCPH.getText().toString();
                if (CPH.length() >= 3 && CPH.length() < 6) // 长度大于3之后，就可以提供相应的提示
                {

                    String resultCPH = province + CPH + haveJCNumber;
                    if (mInOut == 0)
                    {
                        L.e("mInOut == 0..... ");
                        onClickInTextInput(resultCPH, CPH.length()); // 在入场时，也是模糊对比进场获取车牌
                    }
                    else if (mInOut == 1)
                    {
                        L.i("mInOut == 1" + resultCPH + ",resultCPH:" + resultCPH);
                        onClickOutTextInput(resultCPH, CPH.length()); // 在出场时，也是模糊对比进场获取车牌
                    }
                }
            }
        });

        // 显示PopWindow弹出框
        mPopWindow = new SpinerPopWindow(mActivity);
        popAdapter = new AbstractSpinerAdapter(mActivity);
        carPopData = new ArrayList<>();

        popAdapter.refreshData(carPopData, 0);
        mPopWindow.setAdatper(popAdapter);
        mPopWindow.setItemListener(this);
    }


    private void rbtWJ_Click()
    {
        charMaxNum = 6;
        etCPH.setText("");
        tvProvinceText.setText("WJ");
        if (tvJCNumber.getVisibility() == View.VISIBLE)
        {
            tvJCNumber.setVisibility(View.INVISIBLE);
        }

        if (tvProvinceText.getVisibility() != View.VISIBLE)
        {
            tvProvinceText.setVisibility(View.VISIBLE);
        }
    }

    private void rbtJC_Click()
    {
        charMaxNum = 7;
        etCPH.setText("");
        if (tvJCNumber.getVisibility() == View.VISIBLE)
        {
            tvJCNumber.setVisibility(View.INVISIBLE);
        }
        if (tvProvinceText.getVisibility() == View.VISIBLE)
        {
            tvProvinceText.setVisibility(View.INVISIBLE);
        }
    }

    private void rbtJinC_Click()
    {
        charMaxNum = 5;
        etCPH.setText("");
        if (tvJCNumber.getVisibility() == View.INVISIBLE)
        {
            tvJCNumber.setVisibility(View.VISIBLE);
        }
        if (tvProvinceText.getVisibility() != View.VISIBLE)
        {
            tvProvinceText.setVisibility(View.VISIBLE);
        }
        tvProvinceText.setText(getCurrentProvince());
    }

    private void rbtPT_Click()
    {
        charMaxNum = 7;
        etCPH.setText("");
        if (tvJCNumber.getVisibility() == View.VISIBLE)
        {
            tvJCNumber.setVisibility(View.INVISIBLE);
        }
        if (tvProvinceText.getVisibility() != View.VISIBLE)
        {
            tvProvinceText.setVisibility(View.VISIBLE);
        }
        tvProvinceText.setText(getCurrentProvince());
    }

    public String getCurrentProvince()
    {
        String tmpProvince = "";
        int checkedRadioButtonId = rgSelectProvince.getCheckedRadioButtonId();
        RadioButton radioButton = (RadioButton) dialog.findViewById(checkedRadioButtonId);
        return radioButton.getText().toString();
//
//        for (int i = 0; i < rgSelectProvince.getChildCount(); i++)
//        {
//            RadioButton childAt = (RadioButton) rgSelectProvince.getChildAt(i);
//            if (childAt.isChecked() == true)
//            {
//                tmpProvince = mActivity.getResources().getStringArray(R.array.provinceArray)[i];
//            }
//        }
//        return tmpProvince;
    }

    public void onClickOutTextInput(String resultCPH, int length)
    {

    }

    public void onClickInTextInput(final String s, final int Precision)
    {

    }

    private View.OnClickListener dialogListern = new View.OnClickListener()
    {
        @Override
        public void onClick(View v)
        {
            switch (v.getId())
            {
                case R.id.btnCarInputOk:
                {
                    String allCPH = "";
                    boolean isCheckJC = false;
                    for (int i = 0; i < rgCarPlateClass.getChildCount(); i++)
                    {
                        RadioButton tempRadio = (RadioButton) rgCarPlateClass.getChildAt(i);
                        if (tempRadio.isChecked() && (i == isPTIndex || i == isWJIndex))
                        {
                            allCPH = tvProvinceText.getText().toString() + etCPH.getText().toString();
                        }
                        else if (tempRadio.isChecked() && i == isJinCIndex)
                        {
                            allCPH = tvProvinceText.getText().toString() + etCPH.getText().toString() + tvJCNumber.getText().toString();
                        }
                        else if (tempRadio.isChecked() && i == isJCIndex)
                        {
                            allCPH = etCPH.getText().toString();
                            isCheckJC = true;
                        }
                    }
                    allCPH = allCPH.toUpperCase();
                    L.i("显示的车牌:" + allCPH);
                    if (CR.CheckUpCPH(allCPH, isCheckJC))
                    {
                        if (mInOut == 0) //入场
                        {
                            onCarInBtnOk(allCPH);
                        }
                        else//出场
                        {
                            onCarOutBtnOk(allCPH);
                        }
                        cancel();
                    }
                    else
                    {
                        Toast.makeText(mActivity, "输入的车牌" + allCPH + "格式不符合", Toast.LENGTH_LONG).show();
                    }
                    break;
                }
                case R.id.btnCarIntCancel:
                {
                    cancel();
                    break;
                }
                default:
                {
                    break;
                }
            }
        }
    };

    public void onCarOutBtnOk(String s)
    {

    }

    protected void onCarInBtnOk(final String getCPH)
    {

    }

    public void show()
    {
        if (dialog != null)
        {
            prepareLoadData();
            dialog.show();
        }
    }

    public void cancel()
    {
        if (dialog != null && dialog.isShowing())
        {
            dialog.cancel();
        }

    }

    /**
     * 设置默认的省份
     *
     * @param str
     */
    public void setProvince(String str)
    {
        String[] stringArray = mActivity.getResources().getStringArray(R.array.provinceArray);
        province = str;


        for (int i = 0; i < stringArray.length; i++)
        {
            if (str.equals(stringArray[i]))
            {
//                RadioButton tempRadio = (RadioButton) rgSelectProvince.getChildAt(i);

                getAllRadioButton(rgSelectProvince).get(i).setChecked(true);
//                tempRadio.setChecked(true);
                province = str;
                break;
            }
        }
        tvProvinceText.setText(province);
    }

    /**
     * 获取所有的RadioButton
     *
     * @param child
     * @return
     */
    private List<RadioButton> getAllRadioButton(View child)
    {
        List<RadioButton> btns = new ArrayList<RadioButton>();
        if (child instanceof RadioButton)
        {
            btns.add((RadioButton) child);
        }
        else if (child instanceof ViewGroup)
        {
            int counts = ((ViewGroup) child).getChildCount();
            for (int i = 0; i < counts; i++)
            {
                btns.addAll(getAllRadioButton(((ViewGroup) child).getChildAt(i)));
            }
        }
        return btns;
    }


    public void prepareLoadData()
    {
        etCPH.setText("");
    }

    public void setCompleteCPHText(List<String> cphList)
    {
        carPopData.clear();
        carPopData.addAll(cphList);
        popAdapter.notifyDataSetChanged();
    }


    @Override
    public void onItemClick(int pos)
    {
        if (pos >= 0 && pos < carPopData.size())
        {
//            String substring = carPopData.get(pos).substring(0, 1);// 截取省份简称，设置到界面
//            setProvince(substring);
            String selectCPH = carPopData.get(pos);
            if (selectCPH.substring(0, 2).equals("WJ"))
            {
                setSelectRadioButton(isWJIndex);
                tvProvinceText.setText("WJ");
//                cmbCarNumber.Text = "WJ"; cmbCarNumber gone
                etCPH.setText(selectCPH.substring(2));
                etCPH.setSelection(selectCPH.substring(2) == null ? 0 : selectCPH.substring(2).length());
                return;
            }

            if (selectCPH.substring(selectCPH.length() - 1).equals("警"))
            {
                setSelectRadioButton(isJinCIndex);
                tvProvinceText.setText(selectCPH.substring(0, 1));
//                cmbCarNumber.Text = obj.ToString().Substring(0, 1);
                String substring = selectCPH.substring(1, selectCPH.length() - 1);
                etCPH.setText(substring);
                etCPH.setSelection(substring == null ? 0 : substring.length());
                return;
            }

            if (!CR.IsChineseCharacters(selectCPH.substring(0, 1))
                    && !CR.IsChineseCharacters(selectCPH.substring(selectCPH.length() - 1)))
            {
                setSelectRadioButton(isJCIndex);
                tvProvinceText.setText("");
                etCPH.setText(selectCPH);
                etCPH.setSelection(selectCPH == null ? 0 : selectCPH.length());
                return;
            }

            setSelectRadioButton(isPTIndex);
//            cmbCarNumber.Text = obj.ToString().Substring(0, 1);
            String carDigit = carPopData.get(pos).substring(1);
            etCPH.setText(carDigit);
            etCPH.setSelection(carDigit == null ? 0 : carDigit.length());
        }
    }

    public void showPopWindow()
    {
        mPopWindow.setWidth(etCPH.getWidth());
        mPopWindow.showAsDropDown(etCPH);
    }


    public void setSelectRadioButton(int selectIndex)
    {
        int childCount = rgCarPlateClass.getChildCount();
        if (selectIndex >= childCount || selectIndex < 0)
        {
            return;
        }

        RadioButton childAt = (RadioButton) rgCarPlateClass.getChildAt(selectIndex);
        childAt.setChecked(true);
    }

}



