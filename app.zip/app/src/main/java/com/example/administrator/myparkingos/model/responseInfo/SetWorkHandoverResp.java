package com.example.administrator.myparkingos.model.responseInfo;

/**
 * Created by Administrator on 2017-07-05.
 */
public class SetWorkHandoverResp
{
    private String rcode;
    private String msg;
    private DataBean data;

    @Override
    public String toString()
    {
        return "SetWorkHandoverResp{" +
                "rcode='" + rcode + '\'' +
                ", msg='" + msg + '\'' +
                ", data=" + data +
                '}';
    }

    public String getRcode()
    {
        return rcode;
    }

    public void setRcode(String rcode)
    {
        this.rcode = rcode;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg(String msg)
    {
        this.msg = msg;
    }

    public DataBean getData()
    {
        return data;
    }

    public void setData(DataBean data)
    {
        this.data = data;
    }

    public static class DataBean
    {
        private String token;
        private Handover model;

        @Override
        public String toString()
        {
            return "DataBean{" +
                    "token='" + token + '\'' +
                    ", model=" + model +
                    '}';
        }

        public String getToken()
        {
            return token;
        }

        public void setToken(String token)
        {
            this.token = token;
        }

        public Handover getModel()
        {
            return model;
        }

        public void setModel(Handover model)
        {
            this.model = model;
        }
    }

    public static class Handover // 换班记录表
    {
        private long ID; // 自增长主键
        private int CarparkNO; // 车场编号
        private String OffDutyOperatorNO; // 交班操作员编号
//        private String OffDutyOperatorName; // 交班操作员名称
        private String TakeOverOperatorNO; // 接班操作员编号
//        private String TakeOverOperatorName; // 接班操作员名称
        private String LastTakeOverTime; // 交班操作员上一次接班时间
        private String ThisTakeOverTime; // 本次换班时间
        private double TotalCharge; // 两次换班期间出场的总应收金额
        private double TotalPaid; // 两次换班期间出场的总收费金额
        private double StrPaid; // 两次换班期间出场的储值卡收费金额
        private double TmpPaid; // 两次换班期间出场的临时车收费金额
        private double MtpPaid; // 两次换班期间出场的月临车收费金额
        private double ATypePaid; // 两次换班期间出场的A类车收费金额
        private double BTypePaid; // 两次换班期间出场的B类车收费金额
        private double CTypePaid; // 两次换班期间出场的C类车收费金额
        private double DTypePaid; // 两次换班期间出场的D类车收费金额
        private double ETypePaid; // 两次换班期间出场的E类车收费金额
        private double FTypePaid; // 两次换班期间出场的F类车收费金额
        private double GTypePaid; // 两次换班期间出场的G类车收费金额
        private double HTypePaid; // 两次换班期间出场的H类车收费金额
        private int InTmpNum; // 当前场内临时车数量
        private int InMthNum; // 当前场内月租车数量
        private int OutTmpNum; // 两次换班期间出场的临时车车次
        private int OutTfrNum; // 两次换班期间出场的临免车车次
        private int OutMthNum; // 两次换班期间出场的月租车车次
        private int OutMtpNum; // 两次换班期间出场的月临车车次
        private int OutFreNum; // 两次换班期间出场的免费车车次
        private int OutPerOpen; // 两次换班期间出场的人工开闸车次
        private int TotalInTmpNum; // 两次换班期间进入过车场的临时车总车次
        private int TotalInNumber; // 两次换班期间进入过车场的总车次
        private int TotalOutNumber; // 两次换班期间已出场的总车次
        private int ATypeCarNum; // 两次换班期间出场的A类车总车次
        private int BTypeCarNum; // 两次换班期间出场的B类车总车次
        private int CTypeCarNum; // 两次换班期间出场的C类车总车次
        private int DTypeCarNum; // 两次换班期间出场的D类车总车次
        private int ETypeCarNum; // 两次换班期间出场的E类车总车次
        private int FTypeCarNum; // 两次换班期间出场的F类车总车次
        private int GTypeCarNum; // 两次换班期间出场的G类车总车次
        private int HTypeCarNum; // 两次换班期间出场的H类车总车次
        private int PaidCarNum; // 两次换班期间出场的收费车车次
        private int FreCarNum; // 两次换班期间出场的免费车车次
        private int NotPaidCarNum; // 两次换班期间出场的未交费车车次
        private String Remarks; // 备注
        private String OffDutyOperatorCard; // 参考系统用户数据Model的CardNO字段
        private String OffDutyOperatorName; // 参考系统用户数据Model的UserName字段
        private String TakeOverOperatorCard; // 参考系统用户数据Model的CardNO字段
        private String TakeOverOperatorName; // 参考系统用户数据Model的UserName字段

        @Override
        public String toString()
        {
            return "Handover{" +
                    "ID=" + ID +
                    ", CarparkNO=" + CarparkNO +
                    ", OffDutyOperatorNO='" + OffDutyOperatorNO + '\'' +
                    ", TakeOverOperatorNO='" + TakeOverOperatorNO + '\'' +
                    ", LastTakeOverTime='" + LastTakeOverTime + '\'' +
                    ", ThisTakeOverTime='" + ThisTakeOverTime + '\'' +
                    ", TotalCharge=" + TotalCharge +
                    ", TotalPaid=" + TotalPaid +
                    ", StrPaid=" + StrPaid +
                    ", TmpPaid=" + TmpPaid +
                    ", MtpPaid=" + MtpPaid +
                    ", ATypePaid=" + ATypePaid +
                    ", BTypePaid=" + BTypePaid +
                    ", CTypePaid=" + CTypePaid +
                    ", DTypePaid=" + DTypePaid +
                    ", ETypePaid=" + ETypePaid +
                    ", FTypePaid=" + FTypePaid +
                    ", GTypePaid=" + GTypePaid +
                    ", HTypePaid=" + HTypePaid +
                    ", InTmpNum=" + InTmpNum +
                    ", InMthNum=" + InMthNum +
                    ", OutTmpNum=" + OutTmpNum +
                    ", OutTfrNum=" + OutTfrNum +
                    ", OutMthNum=" + OutMthNum +
                    ", OutMtpNum=" + OutMtpNum +
                    ", OutFreNum=" + OutFreNum +
                    ", OutPerOpen=" + OutPerOpen +
                    ", TotalInTmpNum=" + TotalInTmpNum +
                    ", TotalInNumber=" + TotalInNumber +
                    ", TotalOutNumber=" + TotalOutNumber +
                    ", ATypeCarNum=" + ATypeCarNum +
                    ", BTypeCarNum=" + BTypeCarNum +
                    ", CTypeCarNum=" + CTypeCarNum +
                    ", DTypeCarNum=" + DTypeCarNum +
                    ", ETypeCarNum=" + ETypeCarNum +
                    ", FTypeCarNum=" + FTypeCarNum +
                    ", GTypeCarNum=" + GTypeCarNum +
                    ", HTypeCarNum=" + HTypeCarNum +
                    ", PaidCarNum=" + PaidCarNum +
                    ", FreCarNum=" + FreCarNum +
                    ", NotPaidCarNum=" + NotPaidCarNum +
                    ", Remarks='" + Remarks + '\'' +
                    ", OffDutyOperatorCard='" + OffDutyOperatorCard + '\'' +
                    ", OffDutyOperatorName='" + OffDutyOperatorName + '\'' +
                    ", TakeOverOperatorCard='" + TakeOverOperatorCard + '\'' +
                    ", TakeOverOperatorName='" + TakeOverOperatorName + '\'' +
                    '}';
        }

        public long getID()
        {
            return ID;
        }

        public void setID(long ID)
        {
            this.ID = ID;
        }

        public int getCarparkNO()
        {
            return CarparkNO;
        }

        public void setCarparkNO(int carparkNO)
        {
            CarparkNO = carparkNO;
        }

        public String getOffDutyOperatorNO()
        {
            return OffDutyOperatorNO;
        }

        public void setOffDutyOperatorNO(String offDutyOperatorNO)
        {
            OffDutyOperatorNO = offDutyOperatorNO;
        }

        public String getTakeOverOperatorNO()
        {
            return TakeOverOperatorNO;
        }

        public void setTakeOverOperatorNO(String takeOverOperatorNO)
        {
            TakeOverOperatorNO = takeOverOperatorNO;
        }

        public String getLastTakeOverTime()
        {
            return LastTakeOverTime;
        }

        public void setLastTakeOverTime(String lastTakeOverTime)
        {
            LastTakeOverTime = lastTakeOverTime;
        }

        public String getThisTakeOverTime()
        {
            return ThisTakeOverTime;
        }

        public void setThisTakeOverTime(String thisTakeOverTime)
        {
            ThisTakeOverTime = thisTakeOverTime;
        }

        public double getTotalCharge()
        {
            return TotalCharge;
        }

        public void setTotalCharge(double totalCharge)
        {
            TotalCharge = totalCharge;
        }

        public double getTotalPaid()
        {
            return TotalPaid;
        }

        public void setTotalPaid(double totalPaid)
        {
            TotalPaid = totalPaid;
        }

        public double getStrPaid()
        {
            return StrPaid;
        }

        public void setStrPaid(double strPaid)
        {
            StrPaid = strPaid;
        }

        public double getTmpPaid()
        {
            return TmpPaid;
        }

        public void setTmpPaid(double tmpPaid)
        {
            TmpPaid = tmpPaid;
        }

        public double getMtpPaid()
        {
            return MtpPaid;
        }

        public void setMtpPaid(double mtpPaid)
        {
            MtpPaid = mtpPaid;
        }

        public double getATypePaid()
        {
            return ATypePaid;
        }

        public void setATypePaid(double ATypePaid)
        {
            this.ATypePaid = ATypePaid;
        }

        public double getBTypePaid()
        {
            return BTypePaid;
        }

        public void setBTypePaid(double BTypePaid)
        {
            this.BTypePaid = BTypePaid;
        }

        public double getCTypePaid()
        {
            return CTypePaid;
        }

        public void setCTypePaid(double CTypePaid)
        {
            this.CTypePaid = CTypePaid;
        }

        public double getDTypePaid()
        {
            return DTypePaid;
        }

        public void setDTypePaid(double DTypePaid)
        {
            this.DTypePaid = DTypePaid;
        }

        public double getETypePaid()
        {
            return ETypePaid;
        }

        public void setETypePaid(double ETypePaid)
        {
            this.ETypePaid = ETypePaid;
        }

        public double getFTypePaid()
        {
            return FTypePaid;
        }

        public void setFTypePaid(double FTypePaid)
        {
            this.FTypePaid = FTypePaid;
        }

        public double getGTypePaid()
        {
            return GTypePaid;
        }

        public void setGTypePaid(double GTypePaid)
        {
            this.GTypePaid = GTypePaid;
        }

        public double getHTypePaid()
        {
            return HTypePaid;
        }

        public void setHTypePaid(double HTypePaid)
        {
            this.HTypePaid = HTypePaid;
        }

        public int getInTmpNum()
        {
            return InTmpNum;
        }

        public void setInTmpNum(int inTmpNum)
        {
            InTmpNum = inTmpNum;
        }

        public int getInMthNum()
        {
            return InMthNum;
        }

        public void setInMthNum(int inMthNum)
        {
            InMthNum = inMthNum;
        }

        public int getOutTmpNum()
        {
            return OutTmpNum;
        }

        public void setOutTmpNum(int outTmpNum)
        {
            OutTmpNum = outTmpNum;
        }

        public int getOutTfrNum()
        {
            return OutTfrNum;
        }

        public void setOutTfrNum(int outTfrNum)
        {
            OutTfrNum = outTfrNum;
        }

        public int getOutMthNum()
        {
            return OutMthNum;
        }

        public void setOutMthNum(int outMthNum)
        {
            OutMthNum = outMthNum;
        }

        public int getOutMtpNum()
        {
            return OutMtpNum;
        }

        public void setOutMtpNum(int outMtpNum)
        {
            OutMtpNum = outMtpNum;
        }

        public int getOutFreNum()
        {
            return OutFreNum;
        }

        public void setOutFreNum(int outFreNum)
        {
            OutFreNum = outFreNum;
        }

        public int getOutPerOpen()
        {
            return OutPerOpen;
        }

        public void setOutPerOpen(int outPerOpen)
        {
            OutPerOpen = outPerOpen;
        }

        public int getTotalInTmpNum()
        {
            return TotalInTmpNum;
        }

        public void setTotalInTmpNum(int totalInTmpNum)
        {
            TotalInTmpNum = totalInTmpNum;
        }

        public int getTotalInNumber()
        {
            return TotalInNumber;
        }

        public void setTotalInNumber(int totalInNumber)
        {
            TotalInNumber = totalInNumber;
        }

        public int getTotalOutNumber()
        {
            return TotalOutNumber;
        }

        public void setTotalOutNumber(int totalOutNumber)
        {
            TotalOutNumber = totalOutNumber;
        }

        public int getATypeCarNum()
        {
            return ATypeCarNum;
        }

        public void setATypeCarNum(int ATypeCarNum)
        {
            this.ATypeCarNum = ATypeCarNum;
        }

        public int getBTypeCarNum()
        {
            return BTypeCarNum;
        }

        public void setBTypeCarNum(int BTypeCarNum)
        {
            this.BTypeCarNum = BTypeCarNum;
        }

        public int getCTypeCarNum()
        {
            return CTypeCarNum;
        }

        public void setCTypeCarNum(int CTypeCarNum)
        {
            this.CTypeCarNum = CTypeCarNum;
        }

        public int getDTypeCarNum()
        {
            return DTypeCarNum;
        }

        public void setDTypeCarNum(int DTypeCarNum)
        {
            this.DTypeCarNum = DTypeCarNum;
        }

        public int getETypeCarNum()
        {
            return ETypeCarNum;
        }

        public void setETypeCarNum(int ETypeCarNum)
        {
            this.ETypeCarNum = ETypeCarNum;
        }

        public int getFTypeCarNum()
        {
            return FTypeCarNum;
        }

        public void setFTypeCarNum(int FTypeCarNum)
        {
            this.FTypeCarNum = FTypeCarNum;
        }

        public int getGTypeCarNum()
        {
            return GTypeCarNum;
        }

        public void setGTypeCarNum(int GTypeCarNum)
        {
            this.GTypeCarNum = GTypeCarNum;
        }

        public int getHTypeCarNum()
        {
            return HTypeCarNum;
        }

        public void setHTypeCarNum(int HTypeCarNum)
        {
            this.HTypeCarNum = HTypeCarNum;
        }

        public int getPaidCarNum()
        {
            return PaidCarNum;
        }

        public void setPaidCarNum(int paidCarNum)
        {
            PaidCarNum = paidCarNum;
        }

        public int getFreCarNum()
        {
            return FreCarNum;
        }

        public void setFreCarNum(int freCarNum)
        {
            FreCarNum = freCarNum;
        }

        public int getNotPaidCarNum()
        {
            return NotPaidCarNum;
        }

        public void setNotPaidCarNum(int notPaidCarNum)
        {
            NotPaidCarNum = notPaidCarNum;
        }

        public String getRemarks()
        {
            return Remarks;
        }

        public void setRemarks(String remarks)
        {
            Remarks = remarks;
        }

        public String getOffDutyOperatorCard()
        {
            return OffDutyOperatorCard;
        }

        public void setOffDutyOperatorCard(String offDutyOperatorCard)
        {
            OffDutyOperatorCard = offDutyOperatorCard;
        }

        public String getOffDutyOperatorName()
        {
            return OffDutyOperatorName;
        }

        public void setOffDutyOperatorName(String offDutyOperatorName)
        {
            OffDutyOperatorName = offDutyOperatorName;
        }

        public String getTakeOverOperatorCard()
        {
            return TakeOverOperatorCard;
        }

        public void setTakeOverOperatorCard(String takeOverOperatorCard)
        {
            TakeOverOperatorCard = takeOverOperatorCard;
        }

        public String getTakeOverOperatorName()
        {
            return TakeOverOperatorName;
        }

        public void setTakeOverOperatorName(String takeOverOperatorName)
        {
            TakeOverOperatorName = takeOverOperatorName;
        }
    }
}
