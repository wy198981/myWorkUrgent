package com.example.administrator.myparkingos.model.responseInfo;

/**
 * Created by Administrator on 2017-04-21.
 */
public class GetCaptureImageResp
{

}
