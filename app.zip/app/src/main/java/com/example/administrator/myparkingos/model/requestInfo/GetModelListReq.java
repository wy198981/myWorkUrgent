package com.example.administrator.myparkingos.model.requestInfo;

/**
 * Created by Administrator on 2017-07-07.
 */
public class GetModelListReq
{
    private String token; // Y 用户登录时候获取的token值
    private String jsonModelList; //查考c#代码的字段
    private String CallBack; // N 是否使用JSONP方式。关于JSONP方式请参考Javascript跨域访问一节。

    @Override
    public String toString()
    {
        return "GetModelListReq{" +
                "token='" + token + '\'' +
                ", jsonModelList='" + jsonModelList + '\'' +
                ", CallBack='" + CallBack + '\'' +
                '}';
    }

    public String getToken()
    {
        return token;
    }

    public void setToken(String token)
    {
        this.token = token;
    }

    public String getJsonModelList()
    {
        return jsonModelList;
    }

    public void setJsonModelList(String jsonModelList)
    {
        this.jsonModelList = jsonModelList;
    }

    public String getCallBack()
    {
        return CallBack;
    }

    public void setCallBack(String callBack)
    {
        CallBack = callBack;
    }
}
