package com.example.administrator.myparkingos.ui;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.util.L;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Administrator on 2017-03-07.
 */
public class FragmentDetailManager
{
    private FragmentManager mFragmentManager;

    private Fragment currentChargeFragment = new Fragment();
    private List<Fragment> fragmentsList = new ArrayList<>();
    public static final String CURRENT_FRAGMENT = "STATE_FRAGMENT_SHOW_DETAIL";
    private int currentIndex = 0;

    public static final String DETAILMANAGER = "DetailManager";
    public FragmentDetailManager(FragmentManager fragmentManager)
    {
        mFragmentManager = fragmentManager;
    }

    public String createTagName(int index)
    {
        return new StringBuffer(DETAILMANAGER).append(index).toString();
    }

    public void init(@Nullable Bundle savedInstanceState)
    {
        if (savedInstanceState != null)
        { // “内存重启”时调用
            //获取“内存重启”时保存的索引下标
            currentIndex = savedInstanceState.getInt(CURRENT_FRAGMENT, 0);

            fragmentsList.removeAll(fragmentsList);
            Fragment fragmentByTag0 = mFragmentManager.findFragmentByTag(createTagName(0));
            if (fragmentByTag0 == null)
            {
                fragmentByTag0 = new CarInParkingDetailFragment();
            }
            Fragment fragmentByTag1 = mFragmentManager.findFragmentByTag(createTagName(1));
            if (fragmentByTag1 == null)
            {
                fragmentByTag1 = new CarChargeDetailFragment();
            }

            fragmentsList.add(fragmentByTag0);
            fragmentsList.add(fragmentByTag1);
            //恢复fragment页面
            loadFragment();
        }
        else
        {      //正常启动时调用
            fragmentsList.add(new CarInParkingDetailFragment());
            fragmentsList.add(new CarChargeDetailFragment());
            loadFragment();
        }
    }


    private void loadFragment()
    {
        FragmentTransaction transaction = mFragmentManager.beginTransaction();
        for (int i = 0; i < fragmentsList.size(); i++)
        {
            if (fragmentsList.get(i).isAdded())
            {

            }
            else
            {
                transaction.add(R.id.flDetailList, fragmentsList.get(i), createTagName(i));
            }
            transaction.hide(fragmentsList.get(i));
        }

        if (currentIndex >=0 && currentIndex < fragmentsList.size())
        {
            transaction.show(fragmentsList.get(currentIndex));
        }

        currentChargeFragment = fragmentsList.get(currentIndex);
        transaction.commit();
    }
    /**
     * 使用show() hide()切换页面
     * 显示fragment
     */
    public void showFragment(int index)
    {
        FragmentTransaction transaction = mFragmentManager.beginTransaction();
        currentIndex = index;

        transaction
                .hide(currentChargeFragment)
                .show(fragmentsList.get(currentIndex));

        currentChargeFragment = fragmentsList.get(currentIndex);
        transaction.commit();

    }
    /**
     * 获取当前fragment的名
     *
     * @return
     */
    public String getCurrentFragmentName()
    {
        if (currentChargeFragment != null)
        {
            return currentChargeFragment.getClass().getName();
        }
        return null;
    }

    public void cleanCarInPakingDetailData()
    {
        L.e("fragmentsList.size:" + fragmentsList.size());
        CarInParkingDetailFragment fragment = (CarInParkingDetailFragment) fragmentsList.get(0);
        fragment.cleanData();
    }

    public void cleanCargeDetailData()
    {
        L.e("fragmentsList.size:" + fragmentsList.size());
        CarInParkingDetailFragment fragment1 = (CarInParkingDetailFragment) fragmentsList.get(0);

        CarChargeDetailFragment fragment = (CarChargeDetailFragment) fragmentsList.get(1);
        fragment.cleanData();
    }

    public void setData(
            ArrayList<HashMap<String, String>> carInParkingDetail, int carInDetailWidth[]
            , ArrayList<HashMap<String, String>> chargeDetail, int cargeDetailWidth[]
    )
    {
        if (carInParkingDetail != null && carInParkingDetail.size() > 0)
        {
            CarInParkingDetailFragment fragment = (CarInParkingDetailFragment) fragmentsList.get(0);
            fragment.setData(carInParkingDetail);

            for (int i = 0; carInDetailWidth != null && i < carInDetailWidth.length; i++)
            {
                if (carInDetailWidth[i] != -1)
                {
                    L.i("index:" + i + ",carInDetailWidth:" + carInDetailWidth[i]);
                    fragment.setColumnsWidth(i, 120); // 这里直接写死了120的宽度的情况，也不行，还是需要找合适的控件；
                }
            }
        }

        if (chargeDetail != null && chargeDetail.size() > 0)
        {
            CarChargeDetailFragment fragment = (CarChargeDetailFragment) fragmentsList.get(1);
            fragment.setData(chargeDetail);

            for (int i = 0; cargeDetailWidth != null && i < cargeDetailWidth.length; i++)
            {
                if (cargeDetailWidth[i] != -1)
                {
                    fragment.setColumnsWidth(i, cargeDetailWidth[i]);
                }
            }
        }
    }

    public int getCurrentIndex()
    {
        return currentIndex;
    }
}
