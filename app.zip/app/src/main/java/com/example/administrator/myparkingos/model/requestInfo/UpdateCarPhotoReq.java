package com.example.administrator.myparkingos.model.requestInfo;

/**
 * Created by Administrator on 2017-07-04.
 */
public class UpdateCarPhotoReq
{
    private String token; // Y 用户登录时候获取的token值
    private String CardNo; // N 卡片发行Model的CardNO字段的值。CardNo和CPH参数不能同时为空；如果同时指定了两个参数的值，服务器优先以CardNo参数查找照片，找不到再用CPH参数查找。
    private String CPH; // N 卡片发行Model的CPH字段的值。CardNo和CPH参数不能同时为空；如果同时指定了两个参数的值，服务器优先以CardNo参数查找照片，找不到再用CPH参数查找。
    private String Photo; // Y 人员照片数据(Base64编码)
    private String CallBack; // N 是否使用JSONP方式。关于JSONP方式请参考Javascript跨域访问一节。

    @Override
    public String toString()
    {
        return "UpdateCarPhotoReq{" +
                "token='" + token + '\'' +
                ", CardNo='" + CardNo + '\'' +
                ", CPH='" + CPH + '\'' +
                ", Photo='" + Photo + '\'' +
                ", CallBack='" + CallBack + '\'' +
                '}';
    }

    public String getToken()
    {
        return token;
    }

    public void setToken(String token)
    {
        this.token = token;
    }

    public String getCardNo()
    {
        return CardNo;
    }

    public void setCardNo(String cardNo)
    {
        CardNo = cardNo;
    }

    public String getCPH()
    {
        return CPH;
    }

    public void setCPH(String CPH)
    {
        this.CPH = CPH;
    }

    public String getPhoto()
    {
        return Photo;
    }

    public void setPhoto(String photo)
    {
        Photo = photo;
    }

    public String getCallBack()
    {
        return CallBack;
    }

    public void setCallBack(String callBack)
    {
        CallBack = callBack;
    }
}
