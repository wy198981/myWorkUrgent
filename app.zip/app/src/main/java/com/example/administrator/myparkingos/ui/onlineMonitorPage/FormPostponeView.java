package com.example.administrator.myparkingos.ui.onlineMonitorPage;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.TimeUtils;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.constant.CR;
import com.example.administrator.myparkingos.constant.JsonSearchParam;
import com.example.administrator.myparkingos.constant.RCodeEnum;
import com.example.administrator.myparkingos.model.GetServiceData;
import com.example.administrator.myparkingos.model.beans.Model;
import com.example.administrator.myparkingos.model.requestInfo.ChangeCarValidDateReq;
import com.example.administrator.myparkingos.model.requestInfo.GetCardTypeDefReq;
import com.example.administrator.myparkingos.model.requestInfo.GetXXXCommonReq;
import com.example.administrator.myparkingos.model.responseInfo.GetCarInResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCardIssueResp2;
import com.example.administrator.myparkingos.model.responseInfo.GetCardTypeDefResp;
import com.example.administrator.myparkingos.model.responseInfo.GetChargeRulesResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCommonXXXResp;
import com.example.administrator.myparkingos.myUserControlLibrary.DateTimePicker;
import com.example.administrator.myparkingos.myUserControlLibrary.MessageBox;
import com.example.administrator.myparkingos.myUserControlLibrary.niceSpinner.NiceSpinner;
import com.example.administrator.myparkingos.util.L;
import com.example.administrator.myparkingos.util.T;
import com.example.administrator.myparkingos.util.TimeConvertUtils;
import com.example.administrator.myparkingos.volleyUtil.callback.GsonCallback;
import com.jude.http.LoadController;
import com.jude.http.RequestManager;

import org.w3c.dom.Text;

import java.sql.Time;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Created by Administrator on 2017-02-16.
 * 【在线监控】 -->> 【车牌登记】 -->>【双击车牌延期】 长按-车牌延期
 */
public class FormPostponeView implements View.OnClickListener, GsonCallback.Listener
{
    private Dialog dialog;
    private Activity mActivity;

    private TextView tvCarNo;
    private TextView tvUserName;
    private TextView tvCPH;
    private TextView tvUserNo;
    private TextView tvCarType;
    private TextView tvBalance;
    private NiceSpinner spinnerRule;
    private EditText etCollectMoney;
    private DateTimePicker validStartTime;
    private DateTimePicker validEndTime;
    private EditText etRemarks;
    private Button btnPrint;
    private Button btnPostpone;
    private Button btnExit;

    GetCardIssueResp2.DataBean mDataBean;
    private TextView tvBalanceLabel;
    private TextView tvChargeRuleLabel;
    private ArrayList<String> chargeRuleList;
    private List<GetChargeRulesResp.DataBean> storeChargeList;
    private String url;
    private TextView lblInfo;

    public FormPostponeView(Activity activity)
    {
        mActivity = activity;
        dialog = new Dialog(activity); // @android:style/Theme.Dialog
        dialog.setContentView(R.layout.formpostpone_activity);
        dialog.setCanceledOnTouchOutside(true);

        Window window = dialog.getWindow();
        WindowManager m = activity.getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = window.getAttributes(); // 获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 1 / 2.5); // 改变的是dialog框在屏幕中的位置而不是大小
        p.width = (int) (d.getWidth() * 1 / 3); // 宽度设置为屏幕的0.65
        window.setAttributes(p);
        dialog.getWindow().setBackgroundDrawableResource(R.drawable.parkdowncard_background);
        dialog.setTitle(activity.getResources().getString(R.string.parkNoRegister_dalayTitle));

        initView();
        initViewContent();
    }

    public void setDataBean(GetCardIssueResp2.DataBean inData)
    {
        mDataBean = inData;
    }

    private void initData()
    {
        requestGetCardTypeDef();
        if (mDataBean == null)
        {
            return;
        }
        tvCarNo.setText(mDataBean.getCardNO());
        tvUserName.setText(mDataBean.getUserName());
        tvCPH.setText(mDataBean.getCPH());
        tvUserNo.setText(mDataBean.getUserNO());
        tvCarType.setText(mDataBean.getCardType());
        validStartTime.setDateTime(TimeConvertUtils.toShortDateString(mDataBean.getCarValidStartDate()));
        validEndTime.setDateTime(TimeConvertUtils.toShortDateString(mDataBean.getCarValidEndDate()));

        String getCardType = CR.GetCardType(mDataBean.getCardType(), 0);
        if (getCardType.contains("Str"))
        {
            tvBalance.setVisibility(View.VISIBLE);
            tvBalanceLabel.setVisibility(View.VISIBLE);
            dialog.setTitle("车牌充值");
            btnPostpone.setText("充   值");
        }
        else
        {
            tvBalance.setVisibility(View.INVISIBLE);
            dialog.setTitle("车牌延期");
            btnPostpone.setText("延   期");
            tvBalanceLabel.setVisibility(View.INVISIBLE);
        }

        if (getCardType.contains("Mth") || getCardType.contains("Fre"))
        {
            if (Model.iMonthRule == 1)
            {
                validStartTime.setDateTime(TimeConvertUtils.toShortDateString(TimeConvertUtils.longToString(System.currentTimeMillis())));
                requestGetChargeRules(getCardType);
            }
            else
            {
                setNoHaveChargeRules();
            }
        }
        else
        {
            setNoHaveChargeRules();
        }

        if (getCardType.startsWith("Mth"))
        {
            requestGetMyCarComeRecord(tvCarNo.getText().toString(), tvCPH.getText().toString(), tvCarType.getText().toString());
        }
    }

    public void setNoHaveChargeRules()
    {
        spinnerRule.setVisibility(View.INVISIBLE);
        tvChargeRuleLabel.setVisibility(View.INVISIBLE);

        validStartTime.setEnabled(true);
        validEndTime.setEnabled(true);
    }

    public void setHaveChargeRules()
    {
        spinnerRule.setVisibility(View.VISIBLE);
        tvChargeRuleLabel.setVisibility(View.VISIBLE);

        validStartTime.setEnabled(false);
        validEndTime.setEnabled(false);
    }

    private void initViewContent()
    {
        validStartTime.setDateTime("选择日期");
        validEndTime.setDateTime("选择日期");

        chargeRuleList = new ArrayList<>();
        spinnerRule.setSpinnerListener(new NiceSpinner.SpinnerListener()
        {
            @Override
            public void OnSpinnerItemClick(int pos)
            {
                cmbRule_SelectionChanged();
            }
        });
        spinnerRule.refreshData(chargeRuleList, 0);
    }

    private void initView()
    {
        tvCarNo = (TextView) dialog.findViewById(R.id.tvCarNo);
        tvUserName = (TextView) dialog.findViewById(R.id.tvUserName);
        tvCPH = (TextView) dialog.findViewById(R.id.tvCPH);
        tvUserNo = (TextView) dialog.findViewById(R.id.tvUserNo);
        tvCarType = (TextView) dialog.findViewById(R.id.tvCarType);
        tvBalance = (TextView) dialog.findViewById(R.id.tvBalance);
        tvBalanceLabel = (TextView) dialog.findViewById(R.id.tvBalanceLabel);
        spinnerRule = (NiceSpinner) dialog.findViewById(R.id.spinnerRule);
        etCollectMoney = (EditText) dialog.findViewById(R.id.etCollectMoney);
        validStartTime = (DateTimePicker) dialog.findViewById(R.id.validStartTime);
        validEndTime = (DateTimePicker) dialog.findViewById(R.id.validEndTime);
        etRemarks = (EditText) dialog.findViewById(R.id.etRemarks);
        btnPrint = (Button) dialog.findViewById(R.id.btnPrint);
        btnPostpone = (Button) dialog.findViewById(R.id.btnPostpone);
        btnExit = (Button) dialog.findViewById(R.id.btnExit);

        lblInfo = (TextView) dialog.findViewById(R.id.lblInfo);

        tvChargeRuleLabel = (TextView) dialog.findViewById(R.id.tvChargeRuleLabel);

        btnPrint.setOnClickListener(this);
        btnPostpone.setOnClickListener(this);
        btnExit.setOnClickListener(this);

        etCollectMoney.setOnFocusChangeListener(new View.OnFocusChangeListener()
        {
            @Override
            public void onFocusChange(View v, boolean hasFocus)
            {
                if (!hasFocus)
                {
                    L.e("光标发生了变化。。。。。。。。。。。。");
                    txtMoney_MouseLeave();
                }
            }
        });

        etCollectMoney.addTextChangedListener(textWatcher);
    }

    /**
     * 显示数据
     */
    public void show()
    {
        if (dialog != null && dialog.isShowing() == false)
        {
            initData();
            dialog.show();
        }
    }

    /**
     * 当隐藏时，将view的数据清除掉
     */
    public void cleanDataWhenDismiss()
    {
        tvUserName.setText("");
        tvUserNo.setText("");
        tvCPH.setText("");
        tvCarNo.setText("");
        etCollectMoney.setText("");
        etRemarks.setText("");
    }

    /**
     * 隐藏
     */
    public void dismiss()
    {
        if (dialog != null && dialog.isShowing())
        {
            cleanDataWhenDismiss();
            dialog.dismiss();
            validStartTime.setDateTime("选择日期");
            validEndTime.setDateTime("选择日期");
        }
    }


    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.btnPrint:
                break;
            case R.id.btnPostpone://车辆延期处理
                requestChangeCarValidDate();
                break;
            case R.id.btnExit:
                dismiss();
                break;
        }
    }

    /**
     * 请求服务器更新延时时间
     */
    private void requestChangeCarValidDate()
    {
        ChangeCarValidDateReq changeCarValidDateReq = new ChangeCarValidDateReq();
        changeCarValidDateReq.setToken(Model.token);
        changeCarValidDateReq.setCardNO(tvCarNo.getText().toString().trim());
        changeCarValidDateReq.setChargeAmount(etCollectMoney.getText().toString().trim());
        changeCarValidDateReq.setStartDate(TimeConvertUtils.formatConvert(validStartTime.getDateTime()));//YYYYMMdd 格式转换
        changeCarValidDateReq.setEndDate(TimeConvertUtils.formatConvert(validEndTime.getDateTime()));//YYYMMdd
        changeCarValidDateReq.setMemo(etRemarks.getText().toString().trim());

        // 6:9000/ParkAPI/ChangeCarValidDate?CardNO=212&EndDate=2017-08-04&Memo=&StartDate=2017-07-04
        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_CHANGECARVALIDDATE, changeCarValidDateReq);
        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetCommonXXXResp.class, this, changeCarValidDateReq, resultUrl, -1));
    }

    /**
     * 请求车牌类型
     */
    public static final String METHOD_GETCARDTYPEDEF = "GetCardTypeDef";
    public static final String METHOD_GETCHARGERULES = "GetChargeRules";
    public static final String METHOD_GetCarIn = "GetCarIn";
    public static final String METHOD_GETCARDISSUE = "GetCardIssue";
    public static final String METHOD_CHANGECARVALIDDATE = "ChangeCarValidDate";


    private void requestGetCardTypeDef()
    {
        GetCardTypeDefReq cardTypeDefReq = new GetCardTypeDefReq();
        cardTypeDefReq.setToken(Model.token);

        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_GETCARDTYPEDEF, cardTypeDefReq);
        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetCardTypeDefResp.class, this, cardTypeDefReq, resultUrl, -1));
    }

    private void requestGetChargeRules(String cardType)
    {
        GetXXXCommonReq getXXXCommonReq = new GetXXXCommonReq();
        getXXXCommonReq.setToken(Model.token);
        getXXXCommonReq.setJsonSearchParam(JsonSearchParam.getChargeRuleString(cardType));

        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_GETCHARGERULES, getXXXCommonReq);

        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetChargeRulesResp.class, this, getXXXCommonReq, resultUrl, -1));
    }

    private void requestGetMyCarComeRecord(String cardNo, String cph, String cardType)
    {
        GetXXXCommonReq getXXXCommonReq = new GetXXXCommonReq();
        getXXXCommonReq.setToken(Model.token);
        getXXXCommonReq.setJsonSearchParam(JsonSearchParam.getMyCarComeRecord(cardNo, cph, cardType));

        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_GetCarIn, getXXXCommonReq);
        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetCarInResp.class, this, getXXXCommonReq, resultUrl, -1));
    }

    private void requestGetMyfaxingssue(String cardNo, String inTime)
    {
        GetXXXCommonReq getXXXCommonReq = new GetXXXCommonReq();
        getXXXCommonReq.setToken(Model.token);
        getXXXCommonReq.setJsonSearchParam(JsonSearchParam.getMyfaxingssue(cardNo));

        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_GetCarIn, getXXXCommonReq);
        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetCardIssueResp2.class, this, getXXXCommonReq, inTime, -1));
    }

    @Override
    public void success(Object reqData, Object respData, String url, int paramInt)
    {
        try
        {
            if (respData instanceof GetCardTypeDefResp)// 处理车辆类型
            {
                GetCardTypeDefResp resp = (GetCardTypeDefResp) respData;
                if (Integer.parseInt(resp.getRcode()) != RCodeEnum.OK.getValue())
                {
                    L.e(resp.getMsg());
                }
                else
                {
                    CR.BinDic(resp.getData());
                }
            }
            else if (respData instanceof GetChargeRulesResp)// 对于车辆规则返回处理
            {
                GetChargeRulesResp resp = (GetChargeRulesResp) respData;
                if (Integer.parseInt(resp.getRcode()) != RCodeEnum.OK.getValue())
                {
                    L.e(resp.getMsg());
                }
                else
                {
                    if (resp.getData() == null || resp.getData().size() == 0)
                    {
                        setNoHaveChargeRules();
                    }
                    else
                    {
                        storeChargeList = resp.getData();
                        for (GetChargeRulesResp.DataBean item : storeChargeList)
                        {
                            chargeRuleList.add(String.valueOf(item.getFreeMinute()));
                        }
                        spinnerRule.refreshData(chargeRuleList, 0);
                        setHaveChargeRules();
                    }
                }
            }
            else if (respData instanceof GetCarInResp)// 获取场内车辆
            {
                GetCarInResp resp = (GetCarInResp) respData;
                if (Integer.parseInt(resp.getRcode()) != RCodeEnum.OK.getValue())
                {
                    L.e(resp.getMsg());
                }
                else
                {
                    if (resp.getData() == null || resp.getData().size() == 0)
                    {
                    }
                    else
                    {
                        String inTime = ((GetCarInResp) respData).getData().get(0).getInTime();
                        if (TextUtils.isEmpty(inTime))
                        {
                            requestGetMyfaxingssue(tvCarNo.getText().toString(), inTime);
                        }
                    }
                }
            }
            else if (respData instanceof GetCardIssueResp2)// 获取车辆发行处理信息
            {
                GetCardIssueResp2 resp = (GetCardIssueResp2) respData;
                if (Integer.parseInt(resp.getRcode()) != RCodeEnum.OK.getValue())
                {
                    L.e(resp.getMsg());
                }
                else
                {
                    if (resp.getData() == null || resp.getData().size() == 0)
                    {
                    }
                    else
                    {
                        String inTime = url; // 表示输入的时间
                        String carValidStartDate = resp.getData().get(0).getCarValidStartDate();
                        String carValidEndDate = resp.getData().get(0).getCarValidEndDate();

                        long startTime = TimeConvertUtils.stringToLong(carValidStartDate);
                        long endTime = TimeConvertUtils.stringToLong(carValidEndDate);
                        // 获取当前的 2017-07-01 00:00:00 所表示的秒数
                        long nowTime = TimeConvertUtils.stringToLong("yyyy-MM-dd 00:00:00", TimeConvertUtils.longToString(System.currentTimeMillis()));
                        // c # 表示有最大、最小时间的判断
                        long inTime_long = TimeConvertUtils.stringToLong(inTime);

                        if (inTime_long > endTime)
                        {
                            validStartTime.setDateTime(inTime);
                            validEndTime.setDateTime(TimeConvertUtils.getNextYMD(inTime));
                            validStartTime.setEnabled(false);
                        }
                        else if (inTime_long <= endTime && endTime < nowTime)
                        {
                            validStartTime.setDateTime(carValidEndDate);
                            validEndTime.setDateTime(TimeConvertUtils.getNextYMD(carValidEndDate));
                            validStartTime.setEnabled(false);
                        }

                    }
                }
            }
            else if (respData instanceof GetCommonXXXResp)
            {
                GetCommonXXXResp commonXXXResp = (GetCommonXXXResp) respData;
                if (Integer.parseInt(commonXXXResp.getRcode()) != RCodeEnum.OK.getValue())
                {
                    L.e(commonXXXResp.getMsg());
                }
                else//成功
                {
                    String CarType = CR.GetCardType(getCardType(), 0);
                    if (CarType.contains("Str"))
                    {
                        MessageBox.show(mActivity, "充值成功");
                    }
                    else
                    {
                        MessageBox.show(mActivity, "延期成功");
                    }

                    updateGridViewData();
//                    cpponeHandler(); 回调
                    btnPostpone.setEnabled(false);
                    if (Model.iBillPrint == 1)
                    {
                        btnPrint.setEnabled(true);
                    }
                    else
                    {
                        dismiss();
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    /**
     * 提供对外的回调
     */
    protected void updateGridViewData()
    {
    }

    @Override
    public void error(Object data, String url, String errorString)
    {
        T.showShort(mActivity, "连接服务器失败");
    }

    /**
     * 当进行延期之前的判断处理，即EditText 没有焦点的判断
     */
    private void txtMoney_MouseLeave()
    {
        try
        {
            if (Model.iMonthRule == 1)
            {
                if (spinnerRule.getVisibility() == View.VISIBLE)
                {
                    double M1 = Double.parseDouble(etCollectMoney.getText().toString().trim());
                    double M2 = Double.parseDouble(spinnerRule.getCurrentText()); // FreeMinute

                    int t = (int) Math.floor(M1 / M2); //?

                    String endTime = "";
                    if (t > 0)
                    {
                        String dateTime = validStartTime.getDateTime();
                        String carValidEndDate = getCarValidEndDate();

                        // 计算 carValidEndDate 和 当前的now相差的天数
                        int[] distanceNowDate = TimeConvertUtils.distanceNowDate(carValidEndDate);
                        int parseInt = Integer.parseInt(spinnerRule.getCurrentText());

                        // 开始时间相隔加入相应的 月 和 日
                        endTime = TimeConvertUtils.getAddMonthAndDays(dateTime, t * parseInt, distanceNowDate[0]);
                    }
                    else
                    {
                        endTime = TimeConvertUtils.toShortDateString(getCarValidEndDate());
                    }
                    validEndTime.setDateTime(endTime);

                }
            }
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    /**
     * 当txtMoney的内容发生变化时
     */
    private void txtMoney_TextChanged(String text)
    {
        try
        {
            if (TextUtils.isEmpty(text))
            {
                etCollectMoney.setText("0");
            }

            if (Model.iMonthRule == 1)
            {
                if (spinnerRule.getVisibility() == View.VISIBLE)
                {
                    if (TextUtils.isEmpty(spinnerRule.getCurrentText()))
                    {
                        double M1 = Double.parseDouble(etCollectMoney.getText().toString().trim());
                        double M2 = Double.parseDouble(spinnerRule.getCurrentText()); // FreeMinute

                        int t = (int) Math.floor(M1 / M2); //?

                        if (t > 0)
                        {
                            String carValidEndDate = getCarValidEndDate(); // 注意相应的格式
                            long endMis = TimeConvertUtils.stringToLong("yyyy-MM-dd", carValidEndDate);
                            long currentMis = TimeConvertUtils.getCurrentMis();

                            String resultField = "";
                            if (endMis > currentMis)
                            {
                                resultField = carValidEndDate;
                            }
                            else
                            {
                                resultField = TimeConvertUtils.longToString("yyyy-MM-dd", System.currentTimeMillis());
                            }
                            int parseInt = Integer.parseInt(spinnerRule.getCurrentText());
//                            // 开始时间相隔加入相应的 月 和 日
                            String endTime = TimeConvertUtils.getAddMonthAndDays(resultField, t * parseInt, 0);

                            validEndTime.setDateTime(endTime);
                            double iYu = M1 % M2;
                            if (iYu > 0)
                            {
                                lblInfo.setText("交纳金额不是收费规则的整数倍");
                                btnPostpone.setEnabled(false);
                            }
                            else
                            {
                                lblInfo.setText("");
                                btnPostpone.setEnabled(true);
                            }
                        }
                        else
                        {
                            validEndTime.setDateTime(TimeConvertUtils.toShortDateString(getCarValidEndDate()));
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    private double getRuleMoney()
    {
        if (storeChargeList == null || storeChargeList.size() == 0)
        {
            L.e("storeChargeList == null || storeChargeList.size() == 0");
            return 0;
        }

        String currentText = spinnerRule.getCurrentText();
        for (GetChargeRulesResp.DataBean item : storeChargeList)
        {
            if (item.getFreeMinute() == Integer.parseInt(currentText))
            {
                return item.getJE();
            }
        }
        L.e(" no find currentText" + currentText + " in storeChargeList");
        return 0;
    }

    private TextWatcher textWatcher = new TextWatcher()
    {

        @Override
        public void afterTextChanged(Editable s)
        {
            L.e("afterTextChanged--------------->");
        }

        @Override
        public void beforeTextChanged(
                CharSequence s, int start, int count,
                int after
        )
        {
            L.e("beforeTextChanged--------------->");
        }

        @Override
        public void onTextChanged(
                CharSequence s, int start, int before,
                int count
        )
        {
            L.e("onTextChanged--------------->");
            String str = etCollectMoney.getText().toString();
            txtMoney_TextChanged(str);
        }
    };

    private void cmbRule_SelectionChanged()
    {
        if (chargeRuleList == null || chargeRuleList.size() == 0)
        {
            L.e("chargeRuleList == null || chargeRuleList.size() == 0");
            return;
        }

        if (storeChargeList == null || storeChargeList.size() == 0)
        {
            L.e("chargeRuleList == null || chargeRuleList.size() == 0");
            return;
        }

        double ruleMoney = getRuleMoney();// 获取JE
        etCollectMoney.setText(String.valueOf(getRuleMoney()));

//        DateTime dt = DateTime.Now;
//        if (Convert.ToDateTime(endTime) >= Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd")))
//        {
//            dt = Convert.ToDateTime(endTime);
//        }
//        else
//        {
//            dt = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd"));
//        }
//
//        dtpEndTime.Text = dt.AddMonths(Convert.ToInt32(cr.FreeMinute)).ToString();

        String carValidEndDate = getCarValidEndDate(); // 注意相应的格式
        long endMis = TimeConvertUtils.stringToLong("yyyy-MM-dd", carValidEndDate);
        long currentMis = TimeConvertUtils.getCurrentMis();

        String resultField = "";
        if (endMis > currentMis)
        {
            resultField = carValidEndDate;
        }
        else
        {
            resultField = TimeConvertUtils.longToString("yyyy-MM-dd", System.currentTimeMillis());
        }
        int parseInt = Integer.parseInt(spinnerRule.getCurrentText());
//                            // 开始时间相隔加入相应的 月 和 日
        String endTime = TimeConvertUtils.getAddMonthAndDays(resultField, parseInt, 0);

        validEndTime.setDateTime(endTime);
    }

    public String getCardType()
    {
        if (mDataBean == null)
            return "";
        else
            return mDataBean.getCardType();
    }

    public String getCarValidEndDate()
    {
        if (mDataBean == null)
            return "";
        else
            return mDataBean.getCarValidEndDate();
    }
}
