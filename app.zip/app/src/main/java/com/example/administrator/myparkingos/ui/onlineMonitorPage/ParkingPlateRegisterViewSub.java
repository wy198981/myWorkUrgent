package com.example.administrator.myparkingos.ui.onlineMonitorPage;

import android.content.DialogInterface;
import android.text.TextUtils;

import com.example.administrator.myparkingos.constant.CR;
import com.example.administrator.myparkingos.constant.ColumnName;
import com.example.administrator.myparkingos.constant.JsonSearchParam;
import com.example.administrator.myparkingos.constant.OrderField;
import com.example.administrator.myparkingos.constant.RCodeEnum;
import com.example.administrator.myparkingos.model.GetServiceData;
import com.example.administrator.myparkingos.model.beans.Model;
import com.example.administrator.myparkingos.model.requestInfo.CardIssueCancellationReq;
import com.example.administrator.myparkingos.model.requestInfo.GetCardIssueReq;
import com.example.administrator.myparkingos.model.requestInfo.GetIssueFormDataReq;
import com.example.administrator.myparkingos.model.requestInfo.GetXXXCommonReq;
import com.example.administrator.myparkingos.model.requestInfo.SaveUserAndCardIssueReq;
import com.example.administrator.myparkingos.model.responseInfo.CardIssueCancellationCardIssueResp;
import com.example.administrator.myparkingos.model.responseInfo.CardIssueCancellationPartResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCarInResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCardIssueResp2;
import com.example.administrator.myparkingos.model.responseInfo.GetIssueFormDataResp;
import com.example.administrator.myparkingos.model.responseInfo.GetUserInfoResp;
import com.example.administrator.myparkingos.model.responseInfo.SaveUserAndCardIssueExistCardNoResp;
import com.example.administrator.myparkingos.model.responseInfo.SaveUserAndCardIssueExistInRecordResp;
import com.example.administrator.myparkingos.model.responseInfo.SaveUserAndCardIssueObjResp;
import com.example.administrator.myparkingos.model.responseInfo.SaveUserAndCardIssueOkResp;
import com.example.administrator.myparkingos.myUserControlLibrary.MessageBox;
import com.example.administrator.myparkingos.util.L;
import com.example.administrator.myparkingos.util.T;
import com.example.administrator.myparkingos.volleyUtil.callback.GsonCallback;
import com.google.gson.Gson;
import com.jude.http.RequestListener;
import com.jude.http.RequestManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Administrator on 2017-05-11.
 */
public class ParkingPlateRegisterViewSub extends ParkingPlateRegisterView implements GsonCallback.Listener
{
    public static final String METHOD_GETISSUEFORMDATA = "GetIssueFormData";
    public static final String METHOD_GETCARDISSUE = "GetCardIssue";
    public static final String METHOD_GETUSERINFO = "GetUserInfo";
    public static final String METHOD_CARDISSUECANCELLATION = "CardIssueCancellation";
    public static final String METHOD_SAVEUSERANDCARDISSUE = "SaveUserAndCardIssue";
    public static final String METHOD_UPDATECARDISSUE = "UpdateCardIssue";
    private Gson mGson = new Gson();
    private FormPostponeView formPostponeView;
    private FormPersonnelSelectView formPersonnelSelectView;
    private FormPersonnelAddView formPersonnelAddView;

    public ParkingPlateRegisterViewSub(ParkingMonitoringActivity activity)
    {
        super(activity);
    }

    @Override
    public void startLoadData()
    {
        super.startLoadData();
        requestGetIssueFormData();
        autoAddNo();
    }

    private void autoAddNo()
    {
        if (getAutoCardNoIsChecked())//车辆自动编号
        {
            setCarNoEnable(false);
            requestGeAutoCardNo();
        }
        if (getAutoUserNoIsChecked())
        {
            setUserNoEnable(false);
            requestGetAutoUserNo();
        }
    }

    private void requestGeAutoCardNo()
    {
        GetCardIssueReq req = new GetCardIssueReq();
        req.setToken(Model.token);
        req.setJsonSearchParam(JsonSearchParam.getWhenAutoCardNo());
        req.setPage(1);
        req.setPageSize(1);
        req.setOrderField(OrderField.getWhenAutoCardNo("desc"));

        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_GETCARDISSUE, req);
        RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetCardIssueResp2.class, this, req, resultUrl, -1));
    }

    private void requestGetAutoUserNo()
    {
        GetXXXCommonReq req = new GetXXXCommonReq();
        req.setToken(Model.token);
        req.setJsonSearchParam(JsonSearchParam.getWhenAutoUserNo());
        req.setOrderField(OrderField.getWhenAutoUserNo("desc"));
        req.setPage(1);
        req.setPageSize(1);

        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_GETUSERINFO, req);
        RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetUserInfoResp.class, this, req, resultUrl, -1));
    }

    public void requestGetIssueFormData()
    {
        GetIssueFormDataReq issueFormDataReq = new GetIssueFormDataReq();
        issueFormDataReq.setToken(Model.token);

        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_GETISSUEFORMDATA, issueFormDataReq);
        RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetIssueFormDataResp.class, this, issueFormDataReq, resultUrl, -1));
    }


    @Override
    public void success(Object reqData, Object respData, String url, int paramInt)
    {
        CR.printGsonResp(reqData, respData, url, paramInt);
        if (respData instanceof GetIssueFormDataResp)
        {
            GetIssueFormDataResp resp = (GetIssueFormDataResp) respData;
            if (Integer.parseInt(resp.getRcode()) == RCodeEnum.OK.getValue())
            {
                updateGetIssueFormData(resp.getData());
            }
        }
        else if (respData instanceof GetCardIssueResp2)
        {
            GetCardIssueResp2 resp = (GetCardIssueResp2) respData;
            updateGetAutoCardNo(resp.getData());
        }
        else if (respData instanceof GetUserInfoResp)
        {
            GetUserInfoResp resp = (GetUserInfoResp) respData;
            udpateGetAutoUserNo(resp.getData());
        }
    }

    private void udpateGetAutoUserNo(List<GetUserInfoResp.DataBean> data)
    {
        if (data == null)
        {
            return;
        }

        if (data.size() > 0)
        {
            String substring = data.get(0).getUserNO().substring(1, 6);
            setUserNoText("A" + CR.stringPadLeft(String.valueOf(Integer.parseInt(substring) + 1), 5, '0'));
        }
        else
        {
            setUserNoText("A00001");
        }
    }

    private void updateGetAutoCardNo(List<GetCardIssueResp2.DataBean> data)
    {
        if (data == null)
        {
            return;
        }

        if (data.size() > 0)
        {
            String substring = data.get(0).getCardNO().substring(2, 8);
            setCarNoText("88" + CR.stringPadLeft(String.valueOf(Integer.parseInt(substring) + 1), 6, '0'));
        }
        else
        {
            setCarNoText("88000001");
        }
    }

    private void updateGetIssueFormData(GetIssueFormDataResp.DataBean respData)
    {
        if (respData == null)
        {
            L.e("updateGetIssueFormData: respData == null");
            return;
        }


        CR.BinDic(respData.getCardTypeDef());
        setCardType(respData.getCardTypeDef());//设置车辆类型 月租车
        setUserNo(respData.getUserInfo());//人员表数据
        setJiHaoData(respData.getDevice()); // 更新机号

        saveGridViewData(respData.getCardIssue());
        setGridViewData(dealDataGridView(respData.getCardIssue()));//更新列表数据

    }

    @Override
    public void error(Object data, String url, String errorString)
    {

    }

    private ArrayList<HashMap<String, String>> dealDataGridView(List<GetCardIssueResp2.DataBean> cardIssueList)
    {
        if (cardIssueList == null)
        {
            return null;
        }

        ArrayList<HashMap<String, String>> items = null;
        for (GetCardIssueResp2.DataBean carIssue : cardIssueList)
        {
            if (items == null)
                items = new ArrayList<HashMap<String, String>>();
            HashMap<String, String> item = new HashMap<String, String>();

            item.put(ColumnName.c1, CR.prepareDetectString(carIssue.getCPH(), ""));
            item.put(ColumnName.c2, CR.prepareDetectString(carIssue.getCardNO(), ""));
            item.put(ColumnName.c3, CR.prepareDetectString(carIssue.getCardType(), ""));
            item.put(ColumnName.c4, CR.prepareDetectString(carIssue.getCardState(), ""));
            item.put(ColumnName.c5, CR.prepareDetectString(carIssue.getUserNO(), ""));
            item.put(ColumnName.c6, CR.prepareDetectString(carIssue.getUserName(), ""));
            item.put(ColumnName.c7, CR.prepareDetectString(carIssue.getCarValidStartDate(), ""));
            item.put(ColumnName.c8, CR.prepareDetectString(carIssue.getCarValidEndDate(), ""));
            item.put(ColumnName.c9, CR.prepareDetectString(carIssue.getMobNumber(), ""));
            item.put(ColumnName.c10, String.valueOf(carIssue.getHomeAddress()));
            item.put(ColumnName.c11, String.valueOf(carIssue.getBalance())); // 充值余额
            item.put(ColumnName.c12, String.valueOf(carIssue.getCardYJ())); // 车辆押金
            item.put(ColumnName.c13, CR.prepareDetectString(carIssue.getCarType(), ""));
            item.put(ColumnName.c14, CR.prepareDetectString(carIssue.getCarPlace(), "")); //车位
            item.put(ColumnName.c15, CR.prepareDetectString(carIssue.getCarIssueDate(), ""));
            item.put(ColumnName.c16, CR.prepareDetectString(carIssue.getCarIssueUserCard(), ""));
            item.put(ColumnName.c17, CR.prepareDetectString(carIssue.getCarValidZone(), ""));//下载标识
            item.put(ColumnName.c18, CR.prepareDetectString(carIssue.getCarMemo(), ""));// 车场备注
            item.put(ColumnName.c19, String.valueOf(carIssue.getCarPlaceNo()));
            items.add(item);
        }
        return items;
    }

    private List<String> dealUserNo(List<GetUserInfoResp.DataBean> userInfoList)
    {
        if (userInfoList == null)
        {
            return null;
        }


        List<String> list = null;

        for (GetUserInfoResp.DataBean userInfo : userInfoList)
        {
            if (list == null)
            {
                list = new ArrayList<String>();
            }
            list.add(userInfo.getUserNO());
        }
        return list;
    }

    @Override
    public void btnAdd_Click()
    {
        super.btnAdd_Click();
        autoAddNo();
    }


    public void btnCancel_Click()
    {
        String cph = getCPH();
        String carNo = getCarNo();

        MessageBox.showCanSetCallback(mActivity, "确定注销车牌:" + cph + "  车辆编号:" + carNo, new MessageBox.IMessageBoxListener()
        {
            @Override
            public void onClickPositive(DialogInterface dialog)
            {
                requestCancelCardIssue(false);
                dialog.dismiss();
            }


            @Override
            public void onClickNegative(DialogInterface dialog)
            {
                dialog.dismiss();
            }
        });
    }

    private void dealCancelCardIssueAgain(String respString)
    {
        CardIssueCancellationReq cardIssueCancellationReq = initCardIssueCancel(true);
        CardIssueCancellationCardIssueResp cardIssueCancellationCardIssueResp = mGson.fromJson(respString, CardIssueCancellationCardIssueResp.class);
        List<GetCardIssueResp2.DataBean> beanList = cardIssueCancellationCardIssueResp.getData();
        if (beanList == null)
        {
            L.e("cardIssueCancellationCardIssueResp.getData() == null");
            return;
        }

        String retCPH = (beanList == null || beanList.size() == 0) ? getCPH() : (TextUtils.isEmpty(beanList.get(0).getCPH()) ? beanList.get(0).getCPH() : getCPH());

        MessageBox.showCanSetCallback(mActivity, "确定注销【场内】车牌:" + retCPH + "\r\n 系统自动会把此车牌转换为临时车\r\n 并且按照当前时间开始计费", new MessageBox.IMessageBoxListener()
        {
            @Override
            public void onClickPositive(DialogInterface dialog)
            {
                requestCancelCardIssue(true);
                dialog.dismiss();
            }

            @Override
            public void onClickNegative(DialogInterface dialog)
            {
                dialog.dismiss();
            }
        });
    }

    private CardIssueCancellationReq initCardIssueCancel(boolean forceCancel)
    {
        CardIssueCancellationReq req = new CardIssueCancellationReq();
        req.setToken(Model.token);
        req.setCardNo(getUserNo());
        req.setCPH(getCPH());
        req.setForceCancel(forceCancel);
        return req;
    }

    private void requestCancelCardIssue(boolean forceCancel)
    {
        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_CARDISSUECANCELLATION, initCardIssueCancel(forceCancel));
        RequestManager
                .getInstance()
                .get(resultUrl, new RequestListener()
                {
                    @Override
                    public void onRequest()
                    {
                    }

                    @Override
                    public void onSuccess(String s)
                    {
                        CardIssueCancellationPartResp cardIssueCancellationPartResp = mGson.fromJson(s, CardIssueCancellationPartResp.class);
                        L.e("cardIssueCancellationPartResp respData:" + cardIssueCancellationPartResp.toString());
                        int parseInt = Integer.parseInt(cardIssueCancellationPartResp.getRcode());
                        RCodeEnum rCodeEnum = RCodeEnum.valueOf(parseInt);
                        switch (rCodeEnum)
                        {
                            case ExistApproachRecord:
                                dealCancelCardIssueAgain(s);
                                break;
                            case OK:
                                setViewWhenCanceCardIssue();
                                MessageBox.show(mActivity, "车牌注销成功!");
                                requestGetCardIssueList();
                                break;
                            default:
                                MessageBox.show(mActivity, "车牌注销失败:" + cardIssueCancellationPartResp.getMsg());
                                break;
                        }
                    }

                    @Override
                    public void onError(String s)
                    {
                        MessageBox.show(mActivity, "车牌注销失败，网络请求失败");
                    }
                });
    }


    @Override
    public void btnSave_ClickWhenChkDCWDC(
            final GetCardIssueResp2.DataBean cardIssue
            , String[] dcwdClistData
            , boolean autoCarNo
            , boolean autoUserNo
            , boolean Overwrite
            , boolean ChangeBillingType
    )
    {
        SaveUserAndCardIssueReq req = new SaveUserAndCardIssueReq();
        req.setToken(Model.token);
        req.setAutoCardNo(autoCarNo);
        req.setAutoUserNo(autoUserNo);
        req.setChangeBillingType(ChangeBillingType);
        req.setOverwrite(Overwrite);
        req.setJsonIssueModel(JsonSearchParam.getWhenJsonModel(cardIssue));
        req.setCPList(JsonSearchParam.getWhenJsonModel(dcwdClistData));

        final SaveUserAndCardIssueReq useReq = req;
        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_SAVEUSERANDCARDISSUE, req);
        RequestManager
                .getInstance()
                .get(resultUrl, new RequestListener()
                {
                    @Override
                    public void onRequest()
                    {
                    }

                    @Override
                    public void onSuccess(String s)
                    {
                        dealSaveUserAndCardIssueWhenStart(s, useReq, cardIssue.getID());
                    }

                    @Override
                    public void onError(String s)
                    {
                        L.e("onError ," + s);
                    }
                });
    }

    private void requestSaveUserAndCardIssueWhenExistInRecord(
            SaveUserAndCardIssueReq req
            , boolean autoCarNo
            , boolean autoUserNo
            , boolean Overwrite
            , boolean ChangeBillingType
    )
    {
        SaveUserAndCardIssueReq copySelf = SaveUserAndCardIssueReq.copySelf(req);
        copySelf.setAutoCardNo(autoCarNo);
        copySelf.setAutoUserNo(autoUserNo);
        copySelf.setChangeBillingType(ChangeBillingType);
        copySelf.setOverwrite(Overwrite);
        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_SAVEUSERANDCARDISSUE, copySelf);
        RequestManager
                .getInstance()
                .get(resultUrl, new RequestListener()
                {
                    @Override
                    public void onRequest()
                    {
                    }

                    @Override
                    public void onSuccess(String s)
                    {
                        SaveUserAndCardIssueObjResp respData = mGson.fromJson(s, SaveUserAndCardIssueObjResp.class);
                        L.e("respData:" + respData.toString());
                        int parseInt = Integer.parseInt(respData.getRcode());
                        RCodeEnum rCodeEnum = RCodeEnum.valueOf(parseInt);
                        switch (rCodeEnum)
                        {
                            case OK:
                                dealRcodeOk(s);
                                requestGetCardIssueList();
                                break;
                            default:
                                MessageBox.show(mActivity, respData.getMsg());
                                break;
                        }
                    }

                    @Override
                    public void onError(String s)
                    {
                        L.e("onError ," + s);
                    }
                });

    }

    /**
     * 存在相同的cardNo,即再次请求
     *
     * @param req
     * @param autoCarNo
     * @param autoUserNo
     * @param Overwrite
     * @param ChangeBillingType
     */
    private void requestSaveUserAndCardIssueWhenExistIssueCardNO(
            SaveUserAndCardIssueReq req
            , boolean autoCarNo
            , boolean autoUserNo
            , boolean Overwrite
            , boolean ChangeBillingType
            , final int ID
    )
    {
        SaveUserAndCardIssueReq copy = SaveUserAndCardIssueReq.copySelf(req);
        copy.setAutoCardNo(autoCarNo);
        copy.setAutoUserNo(autoUserNo);
        copy.setChangeBillingType(ChangeBillingType);
        copy.setOverwrite(Overwrite);
        L.e("copy:" + copy);
        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_SAVEUSERANDCARDISSUE, copy);

        final SaveUserAndCardIssueReq finalReq = copy;
        RequestManager
                .getInstance()
                .get(resultUrl, new RequestListener()
                {
                    @Override
                    public void onRequest()
                    {
                    }

                    @Override
                    public void onSuccess(String s)
                    {
                        SaveUserAndCardIssueObjResp respData = mGson.fromJson(s, SaveUserAndCardIssueObjResp.class);
                        L.e("requestSaveUserAndCardIssueWhenExistIssueCardNO respData:" + respData.toString());
                        int parseInt = Integer.parseInt(respData.getRcode());
                        RCodeEnum rCodeEnum = RCodeEnum.valueOf(parseInt);
                        switch (rCodeEnum)
                        {
                            case OK:
                                dealRcodeOk(s);
                                requestGetCardIssueList();
                                break;
                            case ExistApproachRecord:
                                dealSaveUserAndCardIssueWhenExistApproachRecord(s, ID, finalReq);
                                break;
                            default:
                                MessageBox.show(mActivity, respData.getMsg());
                                break;
                        }
                    }

                    @Override
                    public void onError(String s)
                    {
                        L.e("onError ," + s);
                    }
                });
    }

    private void requestGetCardIssueList()
    {
        final GetCardIssueReq getCardIssueReq = new GetCardIssueReq();
        getCardIssueReq.setToken(Model.token);
        getCardIssueReq.setJsonSearchParam(JsonSearchParam.getWhenGetCarChePIss(null));
        getCardIssueReq.setOrderField(OrderField.getWhenGetCarChePIss("desc"));

        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_GETCARDISSUE, getCardIssueReq);
        RequestManager.getInstance()
                .get(resultUrl, new RequestListener()
                {
                    @Override
                    public void onRequest()
                    {
                    }

                    @Override
                    public void onSuccess(String s)
                    {
                        GetCardIssueResp2 getCardIssueResp2 = mGson.fromJson(s, GetCardIssueResp2.class);
                        L.e("getCardIssueResp2:" + getCardIssueResp2.toString());
                        if (!getCardIssueResp2.getRcode().equals("200"))
                        {
                            L.e("!getCardIssueResp2.getRcode().equals(\"200\")");
                            return;
                        }
                        if (getCardIssueResp2.getData() == null)
                        {
                            L.e("getCardIssueResp2.getData() == null");
                        }
                        saveGridViewData(getCardIssueResp2.getData());
                        setGridViewData(dealDataGridView(getCardIssueResp2.getData()));
                    }

                    @Override
                    public void onError(String s)
                    {

                    }
                });
    }

    private void requestGetCardIssueList(String jsonParam, String orderParam)
    {
        final GetCardIssueReq getCardIssueReq = new GetCardIssueReq();
        getCardIssueReq.setToken(Model.token);
        getCardIssueReq.setJsonSearchParam(jsonParam);
        getCardIssueReq.setOrderField(orderParam);

        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_GETCARDISSUE, getCardIssueReq);
        RequestManager.getInstance()
                .get(resultUrl, new RequestListener()
                {
                    @Override
                    public void onRequest()
                    {
                    }

                    @Override
                    public void onSuccess(String s)
                    {
                        GetCardIssueResp2 getCardIssueResp2 = mGson.fromJson(s, GetCardIssueResp2.class);
                        L.e("getCardIssueResp2:" + getCardIssueResp2.toString());
                        if (!getCardIssueResp2.getRcode().equals("200"))
                        {
                            L.e("!getCardIssueResp2.getRcode().equals(\"200\")");
                            return;
                        }
                        if (getCardIssueResp2.getData() == null)
                        {
                            L.e("getCardIssueResp2.getData() == null");
                        }
                        saveGridViewData(getCardIssueResp2.getData());
                        setGridViewData(dealDataGridView(getCardIssueResp2.getData()));
                    }

                    @Override
                    public void onError(String s)
                    {

                    }
                });
    }

    private void dealSaveUserAndCardIssueWhenExistApproachRecord(String respString, final int ID, final SaveUserAndCardIssueReq req)
    {
        SaveUserAndCardIssueExistInRecordResp saveUserAndCardIssueExistInRecordResp = mGson.fromJson(respString, SaveUserAndCardIssueExistInRecordResp.class);
        if (saveUserAndCardIssueExistInRecordResp == null)
        {
            return;
        }
        List<GetCarInResp.DataBean> beanList = saveUserAndCardIssueExistInRecordResp.getData();
        if (beanList == null
                || beanList.size() == 0
                || TextUtils.isEmpty(beanList.get(0).getCPH())
                || beanList.get(0).getCPH().length() == 0)
        {
            return;
        }

        String tempCardType = beanList.get(0).getCardType();
        if (TextUtils.isEmpty(tempCardType))//默认的空判断
        {
            tempCardType = "TmpA";
        }

        if (tempCardType.length() <= 3)//默认的长度的判断
        {
            tempCardType = "TmpA";
        }
        String resultCardType = CR.GetCardType(tempCardType, 1).substring(0, tempCardType.length() - 1);

        final String finalCph = beanList.get(0).getCPH();
        final String finalCardType = resultCardType;
        MessageBox.showCanSetCallback(mActivity, finalCph + "是【已入场的" + finalCardType + "】，若继续操作，则此车出场时将不按临时车收费！\n请确认是否继续？", new MessageBox.IMessageBoxListener()
        {
            @Override
            public void onClickPositive(DialogInterface dialog)
            {
                MessageBox.showCanSetCallback(mActivity, finalCph + "是【已入场的" + finalCardType + "】，若继续操作，则此车出场时将不按临时车收费！\n请确认是否继续？", new MessageBox.IMessageBoxListener()
                {
                    @Override
                    public void onClickPositive(DialogInterface dialog)
                    {
                        MessageBox.showCanSetCallback(mActivity, finalCph + "是【已入场的" + finalCardType + "】，若继续操作，则此车出场时将不按临时车收费！\n请确认是否继续？", new MessageBox.IMessageBoxListener()
                        {
                            @Override
                            public void onClickPositive(DialogInterface dialog)
                            {
                                if (ID > 0)
                                {
                                    requestSaveUserAndCardIssueWhenExistInRecord(req, false, false, true, true);
                                }
                                else
                                {
                                    requestSaveUserAndCardIssueWhenExistInRecord(req, getAutoUserNoIsChecked(), getAutoCardNoIsChecked(), true, false);
                                }
                            }

                            @Override
                            public void onClickNegative(DialogInterface dialog)
                            {
                                dismiss();
                            }
                        });
                    }

                    @Override
                    public void onClickNegative(DialogInterface dialog)
                    {
                        dismiss();
                    }
                });
            }

            @Override
            public void onClickNegative(DialogInterface dialog)
            {
                dismiss();
            }
        });
    }


    private void dealSaveUserAndCardIssueWhenStart(String respString, SaveUserAndCardIssueReq req, final int ID)
    {
        SaveUserAndCardIssueObjResp respData = mGson.fromJson(respString, SaveUserAndCardIssueObjResp.class);
        L.e("dealSaveUserAndCardIssueWhenStart respData:" + respData.toString());
        int parseInt = Integer.parseInt(respData.getRcode());
        RCodeEnum rCodeEnum = RCodeEnum.valueOf(parseInt);

        switch (rCodeEnum)
        {
            case ExistIssueCardNO: // 同车辆编号的发行记录已存在,可通过接口的Overwrite参数传入true强制覆盖现有记录。
                dealRespExitCardUserNo(respString, req, ID);
                break;
            case ExistIssuePlate://同车牌的发行记录已存在, 可通过接口的Overwrite参数传入true强制覆盖现有记录。
                dealRespExitCardUserNo(respString, req, ID);
                break;
            case ExistApproachRecord://同车牌或同车辆编号的场内记录已存在。可通过接口的ChangeBillingType参数传入true强制修改场内记录的车辆类型。
                dealSaveUserAndCardIssueWhenExistApproachRecord(respString, ID, req);
                break;
            case OK:
                dealRcodeOk(respString);
                requestGetCardIssueList();
                break;
            default:
                MessageBox.show(mActivity, respData.getMsg());
                break;
        }

    }

    private void dealRespExitCardUserNo(String respString, final SaveUserAndCardIssueReq req, final int ID)
    {
        SaveUserAndCardIssueExistCardNoResp saveUserAndCardIssueExistCardNoResp = mGson.fromJson(respString, SaveUserAndCardIssueExistCardNoResp.class);
        if (saveUserAndCardIssueExistCardNoResp.getData() == null || saveUserAndCardIssueExistCardNoResp.getData().getCardNO().length() == 0)
        {
            L.e("saveUserAndCardIssueExistCardNoResp.getData() == null || saveUserAndCardIssueExistCardNoResp.getData().getCardNO().length() ==0");
            return;
        }

        GetCardIssueResp2.DataBean getCardIssue = saveUserAndCardIssueExistCardNoResp.getData();
        MessageBox.showCanSetCallback(mActivity, "车辆编号已重复是否覆盖添加！\n\n【" + getCardIssue.getCPH() + "】", new MessageBox.IMessageBoxListener()
        {
            @Override
            public void onClickPositive(DialogInterface dialog)
            {
                L.e("dealRespExitCardUserNo ID:" + ID);
                if (ID > 0)
                {
                    requestSaveUserAndCardIssueWhenExistIssueCardNO(req, false, false, true, true, ID);
                }
                else
                {
                    requestSaveUserAndCardIssueWhenExistIssueCardNO(req, getAutoUserNoIsChecked(), getAutoCardNoIsChecked(), true, false, ID);
                }
            }

            @Override
            public void onClickNegative(DialogInterface dialog)
            {
                dismiss();
            }
        });
    }

    private void requestGetPersonal(final String userNo)
    {
        GetXXXCommonReq getXXXCommonReq = new GetXXXCommonReq();
        getXXXCommonReq.setToken(Model.token);
        getXXXCommonReq.setOrderField(OrderField.getPersonnel("asc"));

        final String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_GETUSERINFO, getXXXCommonReq);
        RequestManager
                .getInstance()
                .get(resultUrl, new RequestListener()
                {
                    @Override
                    public void onRequest()
                    {
                    }

                    @Override
                    public void onSuccess(String s)
                    {
                        GetUserInfoResp userInfoResp = mGson.fromJson(s, GetUserInfoResp.class);
                        L.e("onSuccess:" + userInfoResp);
                        if (Integer.parseInt(userInfoResp.getRcode()) != RCodeEnum.OK.getValue())
                        {
                            L.e("onSuccess:" + resultUrl + "," + userInfoResp.getMsg());
                        }
                        else
                        {
                            if (userInfoResp.getData() != null && userInfoResp.getData().size() != 0)
                            {
                                setUserNo(userInfoResp.getData());
                                setUserNo(userNo);
                            }
                        }
                    }

                    @Override
                    public void onError(String s)
                    {

                    }
                });
    }

    public void dealRcodeOk(String inStr)
    {
        String strCPHList = "";
        SaveUserAndCardIssueOkResp saveUserAndCardIssueOkResp = mGson.fromJson(inStr, SaveUserAndCardIssueOkResp.class);
        List<GetCardIssueResp2.DataBean> data = saveUserAndCardIssueOkResp.getData();
        if (data == null)
        {
            return;
        }

        for (int i = 0; i < data.size(); i++)
        {
            strCPHList += "【" + data.get(i).getCPH() + "】";
        }

        MessageBox.show(mActivity, "添加车牌：" + strCPHList + "成功!");
        setViewWhenAddSuccess();
    }

    @Override
    protected void btnAdd_OnAutoNO()
    {
        super.btnAdd_OnAutoNO();
        autoAddNo();
    }

    /**
     * 长按某一行数据
     *
     * @param line
     */
    @Override
    protected void onListViewLongItemClick(int line)
    {
        super.onListViewLongItemClick(line);
        T.showShort(mActivity, "长按点击了第" + line + "数据");

        if (getGridViewData() == null || getGridViewData().size() == 0)
        {
        }
        else
        {
            if (formPostponeView == null)
            {
                formPostponeView = new FormPostponeView(mActivity)
                {
                    @Override
                    protected void updateGridViewData()
                    {
                        requestGetCardIssueList();
                    }
                };
            }
            formPostponeView.setDataBean(getGridViewData().get(line));
            formPostponeView.show();
        }
    }

    /**
     * 点击按钮 【添加人事信息】
     */
    @Override
    protected void btnAddPersonInfo_Click()
    {
        super.btnAddPersonInfo_Click();
//
//        Intent intent = new Intent(mActivity, FormPersonnelAddActivity.class);
//        mActivity.startActivity(intent);

        if (formPersonnelAddView == null)
        {
            formPersonnelAddView = new FormPersonnelAddView(mActivity)
            {
                @Override
                protected void CPHDJfxPersonnelDataHandler(String strUserNO, String strUserName, String strDept)//对于userNo和StrUserName来进行处理
                {
                    requestGetPersonal(strUserNO);
                    setUserName(strUserName);
                }
            };
        }
        formPersonnelAddView.show();
    }

    /**
     * 点击按钮 【查询】
     */
    @Override
    protected void btnSelectCondition_Click()
    {
        if (formPostponeView == null)
        {
            formPersonnelSelectView = new FormPersonnelSelectView(mActivity)
            {
                @Override
                protected void requestGetCPHDJfxPersonnel(String cphdJfxPersonnelData)
                {
                    selectData(cphdJfxPersonnelData);
                }
            };
        }
        formPersonnelSelectView.show();
    }

    /**
     * 请求服务器并选择数据
     *
     * @param cphdJfxPersonnelData
     */
    private void selectData(String cphdJfxPersonnelData)
    {
        GetXXXCommonReq getXXXCommonReq = new GetXXXCommonReq();
        getXXXCommonReq.setToken(Model.token);
        getXXXCommonReq.setJsonSearchParam(cphdJfxPersonnelData);

        final String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_GETUSERINFO, getXXXCommonReq);
        RequestManager
                .getInstance()
                .get(resultUrl, new RequestListener()
                {
                    @Override
                    public void onRequest()
                    {
                    }

                    @Override
                    public void onSuccess(String s)
                    {
                        GetUserInfoResp getUserInfoResp = mGson.fromJson(s, GetUserInfoResp.class);
                        L.e("onSuccess:" + getUserInfoResp);
                        if (Integer.parseInt(getUserInfoResp.getRcode()) != RCodeEnum.OK.getValue())
                        {
                            L.e("onSuccess:" + resultUrl + "," + getUserInfoResp.getMsg());
                        }
                        else
                        {
                            if (getUserInfoResp.getData() != null && getUserInfoResp.getData().size() != 0)
                            {
                                updateUserNoOnSelect(getUserInfoResp.getData());
                            }
                        }
                    }

                    @Override
                    public void onError(String s)
                    {
                        L.e("链接服务器失败");
                    }
                });
    }

    /**
     * 选择之后选择界面的数据
     *
     * @param data
     */
    private void updateUserNoOnSelect(List<GetUserInfoResp.DataBean> data)
    {
        String userNo;
        if (getAutoUserNoIsChecked())
        {
            userNo = data.get(0).getUserNO();
            setUserNoText(userNo);
        }
        else
        {
            setUserNo(data); // 设置UserNo数据
            userNo = getUserNo();
        }

        if (TextUtils.isEmpty(userNo))
        {
            return;
        }

        requestGetCardIssueByUserNo(userNo);
    }

    private void requestGetCardIssueByUserNo(String userNo)
    {
        final GetCardIssueReq getCardIssueReq = new GetCardIssueReq();
        getCardIssueReq.setToken(Model.token);
        getCardIssueReq.setJsonSearchParam(JsonSearchParam.getByUserNo(userNo));

        final String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_GETCARDISSUE, getCardIssueReq);
        RequestManager.getInstance()
                .get(resultUrl, new RequestListener()
                {
                    @Override
                    public void onRequest()
                    {
                    }

                    @Override
                    public void onSuccess(String s)
                    {
                        GetCardIssueResp2 getCardIssueResp2 = mGson.fromJson(s, GetCardIssueResp2.class);
                        L.e("onSuccess:" + getCardIssueResp2);
                        if (Integer.parseInt(getCardIssueResp2.getRcode()) != RCodeEnum.OK.getValue())
                        {
                            L.e("onSuccess:" + resultUrl + "," + getCardIssueResp2.getMsg());
                        }
                        else
                        {
                            if (getCardIssueResp2.getData() != null && getCardIssueResp2.getData().size() != 0)
                            {
                                setViewTextOnUserNo(getCardIssueResp2.getData().get(0));
                            }
                        }
                    }

                    @Override
                    public void onError(String s)
                    {
                        L.e("链接服务器失败");
                    }
                });
    }

    @Override
    protected void updateCardIssueWhenSelectCondition(String jsonParam, String orderParam)
    {
        requestGetCardIssueList(jsonParam, orderParam);
    }
}





















