package com.example.administrator.myparkingos.model.beans;

/**
 * Created by Administrator on 2017-06-08.
 */
public class ThreadMessage
{
    private int what; // 1, 表示下载车牌的结束的消息; 2, 表示读取记录的结束的消息

    public ThreadMessage(int what)
    {
        this.what = what;
    }

    public int getWhat()
    {
        return what;
    }

    public void setWhat(int what)
    {
        this.what = what;
    }
}
