package com.example.administrator.myparkingos.util;

import android.app.Activity;
import android.content.Context;
import android.util.DisplayMetrics;

/**
 * Created by Administrator on 2017-06-16.
 */
public class DensityUtil
{
    private static final String TAG = "DensityUtil";

    /**
     * 5      * 根据手机的分辨率从 dip 的单位 转成为 px(像素)
     * 6
     */

    public static int dip2px(Context context, float dpValue)
    {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }


    /**
     * 13      * 根据手机的分辨率从 px(像素) 的单位 转成为 dp
     * 14
     */

    public static int px2dip(Context context, float pxValue)
    {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (pxValue / scale + 0.5f);

    }


    /**
     * 获取手机的分辨率px，返回一个数组，为宽度和长度。
     */


    public static int[] getDevicePx(Activity activity)
    {
        DisplayMetrics metrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(metrics);
        int width = metrics.widthPixels;
        int heigth = metrics.heightPixels;
        return new int[]{width, heigth};
    }
    /**
     * 获取屏幕密度 屏幕密度（0.75 / 1.0 / 1.5）
     * @param activity
     * @return
     */
    public static float getDensity(Activity activity)
    {
        DisplayMetrics metrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(metrics);
        return metrics.density;
    }

    /**
     * 获取屏幕密度 屏幕密度DPI（120 / 160 / 240）
     * @param activity
     * @return
     */
    public static float getDensityDpi(Activity activity)
    {
        DisplayMetrics metrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(metrics);
        return metrics.densityDpi;
    }
}
