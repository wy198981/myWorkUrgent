package com.example.administrator.myparkingos;


import com.example.administrator.myparkingos.constant.JsonSearchParam;
import com.example.administrator.myparkingos.constant.OrderField;
import com.example.administrator.myparkingos.model.GetServiceData;
import com.example.administrator.myparkingos.model.beans.Model;
import com.example.administrator.myparkingos.model.requestInfo.AddOfflineInOutReq;
import com.example.administrator.myparkingos.model.requestInfo.GetPlateNumberDownCmdReq;
import com.example.administrator.myparkingos.model.requestInfo.GetServerTimeReq;
import com.example.administrator.myparkingos.model.responseInfo.AddOfflineInOutResp;
import com.example.administrator.myparkingos.model.responseInfo.GetAutoTempDownLoadResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCardIssueResp2;
import com.example.administrator.myparkingos.model.responseInfo.GetCommonXXXResp;
import com.example.administrator.myparkingos.model.responseInfo.GetIssueFormDataResp;
import com.example.administrator.myparkingos.model.responseInfo.GetPlateNumberDownBlackListResp;
import com.example.administrator.myparkingos.model.responseInfo.GetPlateNumberDownCardIssueResp;
import com.example.administrator.myparkingos.model.responseInfo.GetPlateNumberDownTempLoadResp;
import com.example.administrator.myparkingos.model.responseInfo.GetServerTimeResp;
import com.example.administrator.myparkingos.ui.loginHintProcess.ParkingDownCardActvity;
import com.example.administrator.myparkingos.util.HttpUtils;
import com.example.administrator.myparkingos.util.L;
import com.google.gson.Gson;

import java.net.URLEncoder;
import java.util.List;

/**
 * Created by Administrator on 2017-06-13.
 */
public class HttpPostRequest
{
    public static final String METHOD_GETSERVERTIME = "getServerTime";
    public static Gson httpGson = new Gson();

    public static String getServerTime()
    {
        GetServerTimeReq getServerTimeReq = new GetServerTimeReq();
        getServerTimeReq.setToken(Model.token);
        String resultUrl = GetServiceData.getResultUrl(METHOD_GETSERVERTIME, getServerTimeReq);

        L.e("resultUrl" + resultUrl);
        String doPost = HttpUtils.doPost(resultUrl, null);
        L.e("doPost 返回的数据:" + doPost);
        if (doPost != null)
        {
            GetServerTimeResp getServerTimeResp = httpGson.fromJson(doPost, GetServerTimeResp.class);
            if (getServerTimeResp.getRcode().equals("200"))
            {
                return getServerTimeResp.getData().getServerTime();
            }
            else
            {
                L.e("debug", getServerTimeResp.getMsg());
                return null;
            }
        }
        else
        {
            return null;
        }
    }

    private static List<GetCardIssueResp2.DataBean> getCardIssue()
    {
        String getCardIssueUrl = JsonSearchParam.getDeleteTempOnGetCardIssue("GetCardIssue", Model.token);
        String resultUrl = GetServiceData.getInstance().generateResultUrl(getCardIssueUrl, null);
        L.e("resultUrl" + resultUrl);
        String doPost = HttpUtils.doPost(resultUrl, null);
        L.e("doPost 返回的数据:" + doPost);
        if (doPost != null)
        {
            GetCardIssueResp2 cardIssueResp2 = httpGson.fromJson(doPost, GetCardIssueResp2.class);
            if (cardIssueResp2.getRcode().equals("200"))
            {
                if (cardIssueResp2.getData() != null && cardIssueResp2.getData().size() != 0)
                {
                    return cardIssueResp2.getData();
                }
                else
                {
                    L.e("!if (cardIssueResp2.getData() != null && cardIssueResp2.getData().size() != 0)");
                    return null;
                }
            }
            else
            {
                L.e("debug", cardIssueResp2.getMsg());
                return null;
            }
        }
        else
        {
            return null;
        }
    }

    private static List<GetAutoTempDownLoadResp.DataBean> getAutoTempDownLoad()
    {
        String autoTempDownload = OrderField.getAutoTempDownload(1);
        String getAutoTempDownLoad = JsonSearchParam.getFindField("GetAutoTempDownLoad", Model.token, autoTempDownload);
        String resultUrl = GetServiceData.getInstance().generateResultUrl(getAutoTempDownLoad, null);
        L.e("resultUrl" + resultUrl);
        String doPost = HttpUtils.doPost(resultUrl, null);
        L.e("doPost 返回的数据:" + doPost);
        if (doPost != null)
        {
            GetAutoTempDownLoadResp getAutoTempDownLoadResp = httpGson.fromJson(doPost, GetAutoTempDownLoadResp.class);
            if (getAutoTempDownLoadResp.getRcode().equals("200"))
            {
                if (getAutoTempDownLoadResp.getData() != null && getAutoTempDownLoadResp.getData().size() != 0)
                {
                    return getAutoTempDownLoadResp.getData();
                }
                else
                {
                    L.e("!getAutoTempDownLoadResp.getData() != null && getAutoTempDownLoadResp.getData().size() != 0");
                    return null;
                }
            }
            else
            {
                L.e("debug", getAutoTempDownLoadResp.getMsg());
                return null;
            }
        }
        else
        {
            return null;
        }
    }

    public static List<GetAutoTempDownLoadResp.DataBean> getAutoTempDownLoadIncludePage(int iSum)
    {
        String condition = OrderField.getAutoTempDownload(0);
        String orderField = OrderField.getAutoTempDownLoad("asc");

        String getAutoTempDownLoad = JsonSearchParam.getFindFieldHavePage("GetAutoTempDownLoad", Model.token, condition, iSum, 1, orderField);
        L.e("url" + getAutoTempDownLoad);
        String resultUrl = GetServiceData.getInstance().generateResultUrl(getAutoTempDownLoad, null);
        L.e("resultUrl" + resultUrl);
        String doPost = HttpUtils.doPost(resultUrl, null);
        L.e("doPost 返回的数据:" + doPost);
        if (doPost != null)
        {
            GetAutoTempDownLoadResp getAutoTempDownLoadResp = httpGson.fromJson(doPost, GetAutoTempDownLoadResp.class);
            if (getAutoTempDownLoadResp.getRcode().equals("200"))
            {
                if (getAutoTempDownLoadResp.getData() != null && getAutoTempDownLoadResp.getData().size() != 0)
                {
                    return getAutoTempDownLoadResp.getData();
                }
                else
                {
                    L.e("!getAutoTempDownLoadResp.getData() != null && getAutoTempDownLoadResp.getData().size() != 0");
                    return null;
                }
            }
            else
            {
                L.e("debug", getAutoTempDownLoadResp.getMsg());
                return null;
            }
        }
        else
        {
            return null;
        }
    }

    public static void GetDeleteTemp()
    {
        int iFXCount = 0;
        List<GetCardIssueResp2.DataBean> cardIssue = getCardIssue();
        if (cardIssue == null)
        {
            iFXCount = 0;
        }
        iFXCount = cardIssue.size();

        int iAutoCount = 0;
        List<GetAutoTempDownLoadResp.DataBean> autoTempDownLoad = getAutoTempDownLoad();
        if (autoTempDownLoad != null)
        {
            iAutoCount = 0;
        }
        iAutoCount = autoTempDownLoad.size();

        int tempCount = 0;
        int iSum = iAutoCount - (10000 - iFXCount);
        if (iSum > 0)
        {
            List<GetAutoTempDownLoadResp.DataBean> autoTempDownLoadIncludePage = getAutoTempDownLoadIncludePage(iSum);
            if (autoTempDownLoadIncludePage != null && autoTempDownLoadIncludePage.size() > 0)
            {
                for (int i = 0; i < tempCount; i++)
                {
                    autoTempDownLoadIncludePage.get(0).setInOut(1);
                }
                updateAutoTempList(autoTempDownLoadIncludePage);
            }
        }
    }

    private static long updateAutoTempList(List<GetAutoTempDownLoadResp.DataBean> autoTempDownLoadIncludePage)
    {
        String toJson = httpGson.toJson(autoTempDownLoadIncludePage);
        String updateAutoTempDownLoadList = JsonSearchParam.getUpdateDataList("UpdateAutoTempDownLoadList", Model.token, toJson);
        String resultUrl = GetServiceData.getInstance().generateResultUrl(updateAutoTempDownLoadList, null);
        L.e("resultUrl" + resultUrl);
        String doPost = HttpUtils.doPost(resultUrl, null);
        L.e("doPost 返回的数据:" + doPost);
        if (doPost != null)
        {
            GetCommonXXXResp getCommonXXXResp = httpGson.fromJson(doPost, GetCommonXXXResp.class);
            if (getCommonXXXResp.getRcode().equals("200"))
            {
                return getCommonXXXResp.getData();
            }
            else
            {
                L.e("debug", getCommonXXXResp.getMsg());
                return -1;
            }
        }
        return -1;
    }

    public static List<GetAutoTempDownLoadResp.DataBean> getAutoTempDownLoad(int workStationNo, int inout, int flag)
    {
        String getCardIssueUrl = JsonSearchParam.getAutoTempDownLoad("GetAutoTempDownLoad", Model.token, workStationNo, 1, 1);
        String resultUrl = GetServiceData.getInstance().generateResultUrl(getCardIssueUrl, null);
        L.e("resultUrl" + resultUrl);
        String doPost = HttpUtils.doPost(resultUrl, null);
        L.e("doPost 返回的数据:" + doPost);
        if (doPost != null)
        {
            GetAutoTempDownLoadResp getAutoTempDownLoadResp = httpGson.fromJson(doPost, GetAutoTempDownLoadResp.class);
            if (getAutoTempDownLoadResp.getRcode().equals("200"))
            {
                if (getAutoTempDownLoadResp.getData() != null && getAutoTempDownLoadResp.getData().size() != 0)
                {
                    return getAutoTempDownLoadResp.getData();
                }
                else
                {
                    L.e("!getAutoTempDownLoadResp.getData() != null && getAutoTempDownLoadResp.getData().size() != 0");
                    return null;
                }
            }
            else
            {
                L.e("debug", getAutoTempDownLoadResp.getMsg());
                return null;
            }
        }
        else
        {
            return null;
        }
    }


    public static int DeleteTemp(String strCPH)
    {
        String deleteAutoTempDownLoadBy = JsonSearchParam.getDeleteTemp("DeleteAutoTempDownLoadBy", Model.token, strCPH);
        String resultUrl = GetServiceData.getInstance().generateResultUrl(deleteAutoTempDownLoadBy, null);
        L.e("resultUrl" + resultUrl);
        String doPost = HttpUtils.doPost(resultUrl, null);
        L.e("doPost 返回的数据:" + doPost);

        GetCommonXXXResp getCommonXXXResp = httpGson.fromJson(doPost, GetCommonXXXResp.class);
        if (getCommonXXXResp != null)
        {
            if (getCommonXXXResp.getRcode().equals("200"))
            {
                return getCommonXXXResp.getData();
            }
            else
            {
                L.e("debug", getCommonXXXResp.getMsg());
                return -1;
            }
        }
        else
        {
            return -1;
        }
    }

    public static int UpdateTempDownLoad(String strCPH, String sumBiao)
    {
        String autoTempDownLoad = JsonSearchParam.getUpdateTempDownLoad("AutoTempDownLoad", Model.token, strCPH, sumBiao);
        String resultUrl = GetServiceData.getInstance().generateResultUrl(autoTempDownLoad, null);
        L.e("resultUrl" + resultUrl);
        String doPost = HttpUtils.doPost(resultUrl, null);
        L.e("doPost 返回的数据:" + doPost);
        GetCommonXXXResp getCommonXXXResp = httpGson.fromJson(doPost, GetCommonXXXResp.class);
        if (getCommonXXXResp != null)
        {
            if (getCommonXXXResp.getRcode().equals("200"))
            {
                return getCommonXXXResp.getData();
            }
            else
            {
                L.e("debug", getCommonXXXResp.getMsg());
                return -1;
            }
        }
        else
        {
            return -1;
        }
    }

    public static final String METHOD_GETPLATENUMBERDOWNCMD = "GetPlateNumberDownCmd";

    private static String getHttpUrlByDownType(ParkingDownCardActvity.DownTypeEnum typeEnum, String[] CtrlNumberList)
    {
        GetPlateNumberDownCmdReq getPlateNumberDownReq = new GetPlateNumberDownCmdReq();
        getPlateNumberDownReq.setToken(Model.token);
        getPlateNumberDownReq.setStationId(Model.stationID);
        getPlateNumberDownReq.setDownType(typeEnum.getValue());
        getPlateNumberDownReq.setIsRepeatDownload(false);

        String toJson = httpGson.toJson(CtrlNumberList);
        String encode = URLEncoder.encode(toJson);

        // 注意CtrlNumberList的数据需要经过转换为Json字符串
        String resultUrl = GetServiceData.getResultUrl(METHOD_GETPLATENUMBERDOWNCMD, getPlateNumberDownReq);
        return resultUrl + "&CtrlNumberList=" + encode;
    }

    public static int requestUpdateCPHDownLoad(int ID, String Down)
    {
        String cardIssue = JsonSearchParam.getJsonModelWhenUpdateCPHDownLoad("CardIssue", Model.token, ID, Down);
        String resultUrl = GetServiceData.getInstance().generateResultUrl(cardIssue, null);
        L.e("resultUrl:" + resultUrl);

        String doPost = HttpUtils.doPost(resultUrl, null);
        L.e("doPost:" + doPost);
        if (doPost == null)
        {
            return -1;
        }
        else
        {
            GetCommonXXXResp getCommonXXXResp = httpGson.fromJson(doPost, GetCommonXXXResp.class);
            return getCommonXXXResp.getData();
        }
    }

    public static int requestUpdateAutoCPHDownLoad(int ID, String Down)
    {
        String cardIssue = JsonSearchParam.getJsonModelWhenUpdateAutoCPHDownLoad("AutoTempDownLoad", Model.token, ID, Down);
        String resultUrl = GetServiceData.getInstance().generateResultUrl(cardIssue, null);
        L.e("resultUrl:" + resultUrl);

        String doPost = HttpUtils.doPost(resultUrl, null);
        L.e("doPost:" + doPost);
        if (doPost == null)
        {
            return -1;
        }
        else
        {
            GetCommonXXXResp getCommonXXXResp = httpGson.fromJson(doPost, GetCommonXXXResp.class);
            return getCommonXXXResp.getData();
        }
    }

    public static int requestBlackListDownload(int ID, String Down)
    {
        String cardIssue = JsonSearchParam.getJsonModelWhenBlackListUpdateCPHDownLoad("Blacklist", Model.token, ID, Down);
        String resultUrl = GetServiceData.getInstance().generateResultUrl(cardIssue, null);
        L.e("resultUrl:" + resultUrl);
        String doPost = HttpUtils.doPost(resultUrl, null);
        L.e("doPost:" + doPost);
        if (doPost == null)
        {
            return -1;
        }
        else
        {
            GetCommonXXXResp getCommonXXXResp = httpGson.fromJson(doPost, GetCommonXXXResp.class);
            return getCommonXXXResp.getData();
        }
    }

    public static int requestDeleteMyBlacklist(int id)
    {
        String deleteBlacklistBy = JsonSearchParam.getJsonConditionWhenDeleteDataBy("DeleteBlacklistBy", Model.token, id);
        String resultUrl = GetServiceData.getInstance().generateResultUrl(deleteBlacklistBy, null);
        String doPost = HttpUtils.doPost(resultUrl, null);
        L.e("doPost:" + doPost);
        if (doPost == null)
        {
            return -1;
        }
        else
        {
            GetCommonXXXResp getCommonXXXResp = httpGson.fromJson(doPost, GetCommonXXXResp.class);
            return getCommonXXXResp.getData();
        }
    }


    public static List<GetPlateNumberDownCardIssueResp.Bean> getPlateNumberDownCmdByCardIssue()
    {
        String httpUrlByDownType = getHttpUrlByDownType(ParkingDownCardActvity.DownTypeEnum.CardIssue, null);
        L.e("httpUrlByDownType:" + httpUrlByDownType);
        String doPost = HttpUtils.doPost(httpUrlByDownType, null);
        L.e("doPost 返回的数据:" + doPost);
        if (doPost != null)
        {
            GetPlateNumberDownCardIssueResp getPlateNumberDownCardIssueResp = httpGson.fromJson(doPost, GetPlateNumberDownCardIssueResp.class);
            L.e("getPlateNumberDownResp:" + getPlateNumberDownCardIssueResp);
            //直接处理数据即可
            if (!getPlateNumberDownCardIssueResp.getRcode().equals("200"))
            {
                L.e("getPlateNumberDownResp.getMsg():" + getPlateNumberDownCardIssueResp.getMsg());
                return null;
            }

            if (getPlateNumberDownCardIssueResp.getData() == null || getPlateNumberDownCardIssueResp.getData().size() == 0)
            {
                L.e("getPlateNumberDownResp.getData() == null || getPlateNumberDownResp.getData().size() == 0");
                return null;
            }

            return getPlateNumberDownCardIssueResp.getData();
        }
        else
        {
            return null;
        }
    }

    public static List<GetPlateNumberDownCardIssueResp.Bean> getPlateNumberDownCmdByCardLoss()
    {
        String httpUrlByDownType = getHttpUrlByDownType(ParkingDownCardActvity.DownTypeEnum.CardLoss, null);
        String doPost = HttpUtils.doPost(httpUrlByDownType, null);
        L.e("doPost 返回的数据:" + doPost);
        if (doPost != null)
        {
            GetPlateNumberDownCardIssueResp getPlateNumberDownCardIssueResp = httpGson.fromJson(doPost, GetPlateNumberDownCardIssueResp.class);
            L.e("getPlateNumberDownResp:" + getPlateNumberDownCardIssueResp);
            //直接处理数据即可
            if (!getPlateNumberDownCardIssueResp.getRcode().equals("200"))
            {
                L.e("getPlateNumberDownResp.getMsg():" + getPlateNumberDownCardIssueResp.getMsg());
                return null;
            }

            if (getPlateNumberDownCardIssueResp.getData() == null || getPlateNumberDownCardIssueResp.getData().size() == 0)
            {
                L.e("getPlateNumberDownResp.getData() == null || getPlateNumberDownResp.getData().size() == 0");
                return null;
            }

            return getPlateNumberDownCardIssueResp.getData();
        }
        else
        {
            return null;
        }
    }

    public static List<GetPlateNumberDownBlackListResp.Bean> getPlateNumberDownCmdByBlacklistIssue()
    {
        String httpUrlByDownType = getHttpUrlByDownType(ParkingDownCardActvity.DownTypeEnum.BlackListIssue, null);
        String doPost = HttpUtils.doPost(httpUrlByDownType, null);
        L.e("doPost 返回的数据:" + doPost);
        if (doPost != null)
        {
            GetPlateNumberDownBlackListResp getPlateNumberDownBlackListResp = httpGson.fromJson(doPost, GetPlateNumberDownBlackListResp.class);
            L.e("getPlateNumberDownBlackListResp:" + getPlateNumberDownBlackListResp);
            //直接处理数据即可
            if (!getPlateNumberDownBlackListResp.getRcode().equals("200"))
            {
                L.e("getPlateNumberDownResp.getMsg():" + getPlateNumberDownBlackListResp.getMsg());
                return null;
            }

            if (getPlateNumberDownBlackListResp.getData() == null || getPlateNumberDownBlackListResp.getData().size() == 0)
            {
                L.e("getPlateNumberDownResp.getData() == null || getPlateNumberDownResp.getData().size() == 0");
                return null;
            }

            return getPlateNumberDownBlackListResp.getData();
        }
        else
        {
            return null;
        }
    }

    public static List<GetPlateNumberDownBlackListResp.Bean> getPlateNumberDownCmdByBlacklistLoss()
    {
        String httpUrlByDownType = getHttpUrlByDownType(ParkingDownCardActvity.DownTypeEnum.BlackListLoss, null);
        String doPost = HttpUtils.doPost(httpUrlByDownType, null);
        L.e("doPost 返回的数据:" + doPost);
        if (doPost != null)
        {
            GetPlateNumberDownBlackListResp getPlateNumberDownBlackListResp = httpGson.fromJson(doPost, GetPlateNumberDownBlackListResp.class);
            L.e("getPlateNumberDownBlackListResp:" + getPlateNumberDownBlackListResp);
            //直接处理数据即可
            if (!getPlateNumberDownBlackListResp.getRcode().equals("200"))
            {
                L.e("getPlateNumberDownResp.getMsg():" + getPlateNumberDownBlackListResp.getMsg());
                return null;
            }

            if (getPlateNumberDownBlackListResp.getData() == null || getPlateNumberDownBlackListResp.getData().size() == 0)
            {
                L.e("getPlateNumberDownResp.getData() == null || getPlateNumberDownResp.getData().size() == 0");
                return null;
            }

            return getPlateNumberDownBlackListResp.getData();
        }
        else
        {
            return null;
        }
    }

    public static List<GetPlateNumberDownTempLoadResp.Bean> getPlateNumberDownCmdByErrorCPH()
    {
        String httpUrlByDownType = getHttpUrlByDownType(ParkingDownCardActvity.DownTypeEnum.ErrorCPH, null);
        String doPost = HttpUtils.doPost(httpUrlByDownType, null);
        L.e("doPost 返回的数据:" + doPost);
        if (doPost != null)
        {
            GetPlateNumberDownTempLoadResp getPlateNumberDownTempLoadResp = httpGson.fromJson(doPost, GetPlateNumberDownTempLoadResp.class);
            L.e("getPlateNumberDownBlackListResp:" + getPlateNumberDownTempLoadResp);
            //直接处理数据即可
            if (!getPlateNumberDownTempLoadResp.getRcode().equals("200"))
            {
                L.e("getPlateNumberDownResp.getMsg():" + getPlateNumberDownTempLoadResp.getMsg());
                return null;
            }

            if (getPlateNumberDownTempLoadResp.getData() == null || getPlateNumberDownTempLoadResp.getData().size() == 0)
            {
                L.e("getPlateNumberDownResp.getData() == null || getPlateNumberDownResp.getData().size() == 0");
                return null;
            }

            return getPlateNumberDownTempLoadResp.getData();
        }
        else
        {
            return null;
        }
    }

    public static long requestAddOfflineInOut(String method, int CtrlNumber, List<String> DataList)
    {
        AddOfflineInOutReq addOfflineInOutReq = new AddOfflineInOutReq();
        addOfflineInOutReq.setToken(Model.token);
        addOfflineInOutReq.setCtrlNumber(CtrlNumber);
        addOfflineInOutReq.setOnlineState("1");
        addOfflineInOutReq.setStationId(Model.stationID);

        //对于dataList来说需要先转换为gson字符串
        String toJson = httpGson.toJson(DataList);
        L.e("toJson:" + toJson);
        String encode = URLEncoder.encode(toJson);

        // 注意CtrlNumberList的数据需要经过转换为Json字符串
        String tempUrl = GetServiceData.getResultUrl(method, addOfflineInOutReq);
        String resultURL = tempUrl + "&DataList=" + encode;

        L.e("resultURL:" + resultURL);
        String doPost = HttpUtils.doPost(resultURL, null);
        if (doPost == null)
        {
            return -1;
        }

        L.e("doPost:" + doPost);
        AddOfflineInOutResp addOfflineInOutResp = httpGson.fromJson(doPost, AddOfflineInOutResp.class);
        return addOfflineInOutResp.getData();
    }
}
