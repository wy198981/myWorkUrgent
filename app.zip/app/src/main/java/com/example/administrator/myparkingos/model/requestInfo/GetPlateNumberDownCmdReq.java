package com.example.administrator.myparkingos.model.requestInfo;

import java.util.Arrays;

/**
 * Created by Administrator on 2017-06-05.
 */
public class GetPlateNumberDownCmdReq
{
    private String token; // Y 用户登录时候获取的token值
    private Integer StationId; // Y 工作站编号
    private Integer DownType; // Y 下载类型,0表示下载发行车牌,1表示删除发行车牌,2表示下载黑名单车牌,3表示删除黑名单车牌,4表示更正错误车牌,其他表示下载发行车牌
    private Boolean IsRepeatDownload; // N True表示可以重复下载,false表示未下载的车牌才能下载
    private String[] CtrlNumberList; // N 当该车道信息未保存数据的情况下(只显示在界面)使用，控制板机号的数组
    private String Reserved; // N 备用字段
    private String CallBack; // N 是否使用JSONP方式。关于JSONP方式请参考Javascript跨域访问一节。

    public String getToken()
    {
        return token;
    }

    public void setToken(String token)
    {
        this.token = token;
    }

    public Integer getStationId()
    {
        return StationId;
    }

    public void setStationId(Integer stationId)
    {
        StationId = stationId;
    }

    public Integer getDownType()
    {
        return DownType;
    }

    public void setDownType(Integer downType)
    {
        DownType = downType;
    }

    public Boolean getIsRepeatDownload()
    {
        return IsRepeatDownload;
    }

    public void setIsRepeatDownload(Boolean repeatDownload)
    {
        IsRepeatDownload = repeatDownload;
    }

    public String[] getCtrlNumberList()
    {
        return CtrlNumberList;
    }

    public void setCtrlNumberList(String[] ctrlNumberList)
    {
        CtrlNumberList = ctrlNumberList;
    }

    public String getReserved()
    {
        return Reserved;
    }

    public void setReserved(String reserved)
    {
        Reserved = reserved;
    }

    public String getCallBack()
    {
        return CallBack;
    }

    public void setCallBack(String callBack)
    {
        CallBack = callBack;
    }

    @Override
    public String toString()
    {
        return "GetPlateNumberDownCmdReq{" +
                "token='" + token + '\'' +
                ", StationId=" + StationId +
                ", DownType=" + DownType +
                ", IsRepeatDownload=" + IsRepeatDownload +
                ", CtrlNumberList=" + Arrays.toString(CtrlNumberList) +
                ", Reserved='" + Reserved + '\'' +
                ", CallBack='" + CallBack + '\'' +
                '}';
    }
}
