package com.example.administrator.myparkingos.constant;

import com.example.administrator.myparkingos.util.L;

/**
 * Created by Administrator on 2017-04-24.
 */
public enum QueueMessageTypeEnum
{
    QUEUE_CAR_IN_TYPE_AUTO(0),           // 手动入场
    QUEUE_CAR_IN_TYPE_AUTO_NOPLATE(1),   // 无牌车手动入场
    QUEUE_CAR_IN_TYPE_RECOGNITION(2),     // 车牌识别入场
    QUEUE_CAR_OUT_TYPE_AUTO(3),          // 手动出场
    QUEUE_CAR_OUT_TYPE_AUTO_NOPLATE(4),   // 无牌车手动出场
    QUEUE_CAR_OUT_TYPE_RECOGNITION(5),     // 车牌识别出场
    QUEUE_CAR_INOUT_TYPE_RECOGNITION(6),   // 相机自动识别 -- 在(0~100中来处理进场出厂的处理)
    QUEUE_CAR_OUT_MANUAL_OPEN(7),

    QUEUE_BLACKLIST(100),
    QUEUE_NOTHISLANEPERMISSION(101),
    QUEUE_BEOVERDUE(102),

    QUEUE_OPENGATE(103),
    QUEUE_VOICEINYW(104),
    QUEUE_CONFIRMCUTOFF(105),
    QUEUE_PERSONALFULL(106),
    QUEUE_PROHIBITCURRENT(107),
    QUEUE_PROHIBITCUTOFF(108),
    QUEUE_CARFULL(109),
    QUEUE_BALANCENOTENOUGH(110),
    QUEUE_TEMPORARYCARNOTINSMALL(111),

    QUEUE_CARFULLCONFIRMCUTOFF(112),
    queue_MthBeOverdueToTmpCharge(113),

    QUEUE_CAROUT_SENDVOICE(114), // 出场发送语音
    QUEUE_TEMPOUTOPEN(115),

    QUEUE_TEMP_NOCUTOFF(116),

    QUEUE_CENTERCHARGEBUTNOTEXIT(117),
    QUEU_CENTERCHARGEOUTFREETIMEBUTNOTEXIT(118),

    QUEUE_REPEATADMISSION(119),

    QUEUE_CACLCHARGEAMOUNT(120),

    QUEUE_LOADLSNOX2010ZNYKTINGATE(121),

    QUEUE_LSNOX2010ZNYKTOUTGATE(122),

    queue_SendCombinationVioce(123),

    queue_ShowLed(124),

    queue_openGate_callback(125),

    queue_DownLoadToTempCPH(126),// 下载临时车牌

    QUEUE_RELIEVEPARKINGLOTFULL(127), // 解除满位

    QUEUE_CtrlLedShowLoad(128), // 控制屏的显示内容

    QUEUE_SurplusCtrlLedShow(129), // 控制屏的显示设置
    ;

    private int value;

    private QueueMessageTypeEnum(int inValue)
    {
        value = inValue;
    }

    private QueueMessageTypeEnum()
    {

    }

    public int getValue()
    {
        return value;
    }

    public void setValue(int value)
    {
        this.value = value;
    }
}
