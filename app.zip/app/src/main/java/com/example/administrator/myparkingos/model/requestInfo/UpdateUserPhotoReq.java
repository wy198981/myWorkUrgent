package com.example.administrator.myparkingos.model.requestInfo;

/**
 * Created by Administrator on 2017-07-04.
 */
public class UpdateUserPhotoReq
{
    private String token; // Y 用户登录时候获取的token值
    private String UserNo; // Y 人员Model的UserNO字段的值
    private String photo; // Y 人员照片数据(Base64编码)
    private String CallBack; // N 是否使用JSONP方式。关于JSONP方式请参考Javascript跨域访问一节。

    @Override
    public String toString()
    {
        return "UpdateUserPhotoReq{" +
                "token='" + token + '\'' +
                ", UserNo='" + UserNo + '\'' +
                ", photo='" + photo + '\'' +
                ", CallBack='" + CallBack + '\'' +
                '}';
    }

    public String getToken()
    {
        return token;
    }

    public void setToken(String token)
    {
        this.token = token;
    }

    public String getUserNo()
    {
        return UserNo;
    }

    public void setUserNo(String userNo)
    {
        UserNo = userNo;
    }

    public String getPhoto()
    {
        return photo;
    }

    public void setPhoto(String photo)
    {
        this.photo = photo;
    }

    public String getCallBack()
    {
        return CallBack;
    }

    public void setCallBack(String callBack)
    {
        CallBack = callBack;
    }
}
