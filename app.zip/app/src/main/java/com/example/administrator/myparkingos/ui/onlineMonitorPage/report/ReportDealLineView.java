package com.example.administrator.myparkingos.ui.onlineMonitorPage.report;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.constant.CR;
import com.example.administrator.myparkingos.constant.JsonSearchParam;
import com.example.administrator.myparkingos.constant.OrderField;
import com.example.administrator.myparkingos.constant.RCodeEnum;
import com.example.administrator.myparkingos.constant.SelectModel;
import com.example.administrator.myparkingos.model.GetServiceData;
import com.example.administrator.myparkingos.model.beans.Model;
import com.example.administrator.myparkingos.model.requestInfo.GetXXXCommonReq;
import com.example.administrator.myparkingos.model.responseInfo.GetBlacklistResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCardIssueResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCardIssueResp2;
import com.example.administrator.myparkingos.model.responseInfo.GetCommonXXXResp;
import com.example.administrator.myparkingos.myUserControlLibrary.DateTimePicker;
import com.example.administrator.myparkingos.myUserControlLibrary.MessageBox;
import com.example.administrator.myparkingos.myUserControlLibrary.radioBtn.FlowRadioGroup;
import com.example.administrator.myparkingos.ui.adapter.CommonAdapter;
import com.example.administrator.myparkingos.ui.adapter.ViewHolder;
import com.example.administrator.myparkingos.util.L;
import com.example.administrator.myparkingos.util.TimeConvertUtils;
import com.example.administrator.myparkingos.volleyUtil.callback.GsonCallback;
import com.jude.http.LoadController;
import com.jude.http.RequestManager;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2017-03-13.
 */
public class ReportDealLineView implements GsonCallback.Listener
{
    private Dialog dialog;
    private FlowRadioGroup rgSelectProvince;
    private Button btnCarInputOk;
    private Button btnCarIntCancel;
    private Button btnNoPlateCancel;
    private ListView dgvDeadline;
    private RadioButton rbtSurplusDays;
    private EditText txtSurplusDays;
    private RadioButton rbtCarNo;
    private EditText txtCarNo;
    private RadioButton rbtTime;
    private DateTimePicker dtStartTime;
    private DateTimePicker dtEndTime;
    private RadioButton rbtUserNo;
    private EditText txtUserNo;
    private Button btnSelect;
    private Button btnExport;
    private Button btnExit;
    private TextView lblCount;
    private Activity mActivity;
    private ArrayList<RadioButton> buttonArrayList;
    private SelectListViewAdapter selectListViewAdapter;


    public ReportDealLineView(Activity activity)
    {
        this.mActivity = activity;
        dialog = new Dialog(activity); // @android:style/Theme.Dialog
        dialog.setContentView(R.layout.form_dealline_query);
        dialog.setCanceledOnTouchOutside(true);

        Window window = dialog.getWindow();
        WindowManager m = activity.getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = window.getAttributes(); // 获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 2 / 3); // 改变的是dialog框在屏幕中的位置而不是大小
        p.width = (int) (d.getWidth() * 1 / 2); // 宽度设置为屏幕的0.65
        window.setAttributes(p);

        dialog.getWindow().setBackgroundDrawableResource(R.drawable.parkdowncard_background);
        dialog.setTitle(activity.getResources().getString(R.string.carDeadlineSelectTitle));
        initView();
    }

    private void initView()
    {
        btnExport = (Button) dialog.findViewById(R.id.btnExport);
        btnExport.setOnClickListener(dialogListener);
        btnSelect = (Button) dialog.findViewById(R.id.btnSelect);
        btnSelect.setOnClickListener(dialogListener);
        btnExit = (Button) dialog.findViewById(R.id.btnExit);
        btnExit.setOnClickListener(dialogListener);

        dtStartTime = (DateTimePicker) dialog.findViewById(R.id.dtStartTime);
        dtEndTime = (DateTimePicker) dialog.findViewById(R.id.dtEndTime);

        txtSurplusDays = (EditText) dialog.findViewById(R.id.txtSurplusDays);
        txtCarNo = (EditText) dialog.findViewById(R.id.txtCarNo);
        txtCarNo.addTextChangedListener(new MyTextWatcher(txtCarNo));

        txtUserNo = (EditText) dialog.findViewById(R.id.txtUserNo);
        txtUserNo.addTextChangedListener(new MyTextWatcher(txtUserNo));

        rbtSurplusDays = (RadioButton) dialog.findViewById(R.id.rbtSurplusDays);
        rbtSurplusDays.setOnCheckedChangeListener(new MyRadioCheckChangeListener(rbtSurplusDays));

        rbtCarNo = (RadioButton) dialog.findViewById(R.id.rbtCarNo);
        rbtCarNo.setOnCheckedChangeListener(new MyRadioCheckChangeListener(rbtCarNo));

        rbtTime = (RadioButton) dialog.findViewById(R.id.rbtTime);
        rbtTime.setOnCheckedChangeListener(new MyRadioCheckChangeListener(rbtTime));

        rbtUserNo = (RadioButton) dialog.findViewById(R.id.rbtUserNo);
        rbtUserNo.setOnCheckedChangeListener(new MyRadioCheckChangeListener(rbtUserNo));

        buttonArrayList = new ArrayList<RadioButton>();
        buttonArrayList.add(rbtSurplusDays);
        buttonArrayList.add(rbtCarNo);
        buttonArrayList.add(rbtTime);
        buttonArrayList.add(rbtUserNo);

        initListView();
    }

    private List<GetCardIssueResp2.DataBean> mlistViewData;

    private void initListView()
    {
        dgvDeadline = (ListView) dialog.findViewById(R.id.dgvDeadline);
        mlistViewData = new ArrayList();

        selectListViewAdapter = new SelectListViewAdapter(mActivity, mlistViewData, R.layout.selectdealline_activity);
        dgvDeadline.setAdapter(selectListViewAdapter);
    }

    @Override
    public void success(Object reqData, Object respData, String url, int paramInt)
    {
        CR.printGsonResp(reqData, respData, url, paramInt);
        if (respData instanceof GetCardIssueResp2)
        {
            GetCardIssueResp2 getCardIssueResp = (GetCardIssueResp2) respData;
            L.e(getCardIssueResp.toString());
            if (Integer.parseInt(getCardIssueResp.getRcode()) != RCodeEnum.OK.getValue())
            {
                L.e(getCardIssueResp.getMsg());
            }
            else
            {
                if (getCardIssueResp.getData() == null)
                {
                    L.e("getCardIssueResp.getData() == null");
                }
                else
                {
                    updateSelectCardIssue(getCardIssueResp.getData());
                }
            }
        }
    }

    private void updateSelectCardIssue(List<GetCardIssueResp2.DataBean> data)
    {
        String currentStr = TimeConvertUtils.longToString(System.currentTimeMillis());
        String shortDateString = TimeConvertUtils.toShortDateString(currentStr);
        for (GetCardIssueResp2.DataBean item : data)
        {
            int dateDiff = TimeConvertUtils.DateDiff(shortDateString, item.getCarValidEndDate());
            L.e("dateDiff:" + dateDiff);
            item.setSurplusDays(dateDiff); // 连个时间间隔的天数
        }
        setListViewData(data);
    }

    private void setListViewData(List<GetCardIssueResp2.DataBean> data)
    {
        mlistViewData.clear();
        if (data != null)
        {
            mlistViewData.addAll(data);
        }
        selectListViewAdapter.notifyDataSetChanged();
    }

    @Override
    public void error(Object data, String url, String errorString)
    {
        L.e("url" + url + "连接服务器失败");
    }

    public class MyRadioCheckChangeListener implements CompoundButton.OnCheckedChangeListener
    {
        private RadioButton mRbtn;

        public MyRadioCheckChangeListener(RadioButton radioButton)
        {
            this.mRbtn = radioButton;
        }

        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
        {
            if (isChecked)//某一个选中，其它的就取消选中
            {
                setRadioButtonCheck(buttonView.getId());
            }
        }
    }

    public void setRadioButtonCheck(int viewID)
    {
        for (RadioButton item : buttonArrayList)
        {
            if (item.getId() != viewID)
            {
                item.setChecked(false);
            }
        }
    }


    private ExportExcelView exportExcelView;
    private View.OnClickListener dialogListener = new View.OnClickListener()
    {
        @Override
        public void onClick(View v)
        {
            switch (v.getId())
            {
                case R.id.btnExport:
                {
                    if (exportExcelView == null)
                    {
                        exportExcelView = new ExportExcelView(mActivity);
                    }
                    exportExcelView.show();
                    break;
                }
                case R.id.btnSelect:
                {
                    onBtnSelect();
                    break;
                }
                case R.id.btnExit:
                {
                    dismiss();
                    break;
                }
                default:
                {
                    break;
                }
            }
        }
    };


    private void onBtnSelect()
    {
        List<SelectModel> lstSM = new ArrayList<SelectModel>();
        SelectModel sm = new SelectModel();
        if (rbtSurplusDays.isChecked())
        {
            String trim = txtSurplusDays.getText().toString().trim();
            if (!TextUtils.isDigitsOnly(trim))
            {
                MessageBox.show(mActivity, "请输入正确的数字", "提示");
                txtSurplusDays.setFocusable(true);
                return;
            }
            else
            {
                sm.getConditions().add(sm.new conditions("CarValidEndDate", ">=", TimeConvertUtils.getCurrentYMD(), "and"));
                sm.getConditions().add(sm.new conditions("CarValidEndDate", "<=", TimeConvertUtils.getAddDays(System.currentTimeMillis(), Integer.parseInt(trim)), "and"));
            }
        }
        else if (rbtTime.isChecked())
        {
            sm.getConditions().add(sm.new conditions("CarValidEndDate", ">=", dtStartTime.getDateTime(), "and"));
            sm.getConditions().add(sm.new conditions("CarValidEndDate", "<=", dtEndTime.getDateTime(), "and"));
        }

        lstSM.add(sm);
        requestDealLineCardIssue(lstSM);
    }

    private void displaySelectModel(List<SelectModel> lstSM)
    {
        for (SelectModel item : lstSM)
        {
            L.e(item.toString());
        }
    }

    private void requestDealLineCardIssue(List<SelectModel> lstSM)
    {
        SelectModel sm = new SelectModel();
        sm.getConditions().add(sm.new conditions("CarCardType", "like", "Mth%", "or"));
        sm.getConditions().add(sm.new conditions("CarCardType", "like", "Fre%", "or"));
        lstSM.add(sm);

        sm = new SelectModel();
        sm.getConditions().add(sm.new conditions("CardState", "<>", "5", "and"));
        lstSM.add(sm);
        displaySelectModel(lstSM);

        GetXXXCommonReq getXXXCommonReq = new GetXXXCommonReq();
        getXXXCommonReq.setToken(Model.token);
        getXXXCommonReq.setJsonSearchParam(JsonSearchParam.getInfoModel(lstSM));

        String resultUrl = GetServiceData.getResultUrl("GetCardIssue", getXXXCommonReq);

        L.e("getXXXCommonReq:" + getXXXCommonReq);
        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetCardIssueResp2.class, this, getXXXCommonReq, resultUrl, -1));
    }


    public void show()
    {
        if (dialog != null)
        {
            resumeStartStatus();
            dialog.show();
        }
    }

    private void resumeStartStatus()
    {
        setListViewData(null);
        txtCarNo.setText("");
        txtUserNo.setText("");
        txtSurplusDays.setText("");
        buttonArrayList.get(0).setChecked(true);
    }

    public void dismiss()
    {
        if (dialog != null && dialog.isShowing())
        {
            dialog.dismiss();
        }
    }

    public class SelectListViewAdapter extends CommonAdapter<GetCardIssueResp2.DataBean>
    {

        public SelectListViewAdapter(Context context, List<GetCardIssueResp2.DataBean> datas, int layoutId)
        {
            super(context, datas, layoutId);
        }

        @Override
        public void convert(ViewHolder viewHolder, GetCardIssueResp2.DataBean dataBean, int position)
        {
            TextView tvCPH = (TextView) viewHolder.getView(R.id.tvCPH);
            tvCPH.setText(dataBean.getCPH());

            TextView tvCardNO = (TextView) viewHolder.getView(R.id.tvCardNO);
            tvCardNO.setText(dataBean.getCardNO());

            TextView tvCardType = (TextView) viewHolder.getView(R.id.tvCardType);
            tvCardType.setText(dataBean.getCardType());

            TextView tvCarValidStartDate = (TextView) viewHolder.getView(R.id.tvCarValidStartDate);
            tvCarValidStartDate.setText(dataBean.getCarValidStartDate());

            TextView tvCarValidEndDate = (TextView) viewHolder.getView(R.id.tvCarValidEndDate);
            tvCarValidEndDate.setText(dataBean.getCarValidEndDate());

            TextView tvSurplusDays = (TextView) viewHolder.getView(R.id.tvSurplusDays);
            tvSurplusDays.setText(String.valueOf(dataBean.getSurplusDays()));

            TextView tvUserName = (TextView) viewHolder.getView(R.id.tvUserName);
            tvUserName.setText(dataBean.getUserName());

            TextView tvUserNO = (TextView) viewHolder.getView(R.id.tvUserNO);
            tvUserNO.setText(dataBean.getUserNO());

            TextView tvDeptName = (TextView) viewHolder.getView(R.id.tvDeptName);
            tvDeptName.setText(dataBean.getDeptName());

            TextView tvMobNumber = (TextView) viewHolder.getView(R.id.tvMobNumber);
            tvMobNumber.setText(dataBean.getMobNumber());
        }
    }

    public class MyTextWatcher implements TextWatcher
    {
        private EditText mEt;

        public MyTextWatcher(EditText et)
        {
            this.mEt = et;
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after)
        {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count)
        {

        }

        @Override
        public void afterTextChanged(Editable s)
        {
            switch (mEt.getId())
            {
                case R.id.txtUserNo:
                    L.e("txtUserNo==================");
                    if (rbtUserNo.isChecked())
                    {
                        List<SelectModel> lstSM = new ArrayList<SelectModel>();
                        SelectModel sm = new SelectModel();
                        sm.getConditions().add(sm.new conditions("UserNO", "like", "%" + txtUserNo.getText().toString().trim() + "%", "and"));
                        lstSM.add(sm);
                        requestDealLineCardIssue(lstSM);
                    }
                    break;
                case R.id.txtCarNo:
                    L.e("txtCarNo==================");
                    if (rbtCarNo.isChecked())
                    {
                        List<SelectModel> lstSM = new ArrayList<SelectModel>();
                        SelectModel sm = new SelectModel();
                        sm.getConditions().add(sm.new conditions("CPH", "like", "%" + txtCarNo.getText().toString().trim() + "%", "and"));
                        lstSM.add(sm);
                        requestDealLineCardIssue(lstSM);
                    }
                    break;
                default:
                    break;
            }
        }
    }
}
