package com.example.administrator.myparkingos.volleyUtil.callback;

import com.example.administrator.myparkingos.util.L;
import com.google.gson.Gson;

/**
 * Created by Administrator on 2017-04-20.
 */
public class GsonCallback<T> extends LinkCallback
{
    private Object reqData;
    private final Gson mGson;
    private final Class<T> mClass;
    private int mIntParam = -1;
    private String mUrl;

    public GsonCallback(Class<T> clazz, Listener listener, Object reqData, String url, int intParam)
    {
        mCallBack = listener;
        mGson = new Gson();
        mClass = clazz;
        this.reqData = reqData;
        mIntParam = intParam;
        mUrl = url;
    }

    @Override
    public void onRequest()
    {
        super.onRequest();
    }

    @Override
    public void onSuccess(String s)
    {
        super.onSuccess(s);
        if (s == null)
            return;

        try
        {
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("onSucess###")
                    .append("URL[").append(mUrl).append("],")
                    .append("reqData[").append(reqData).append("],")
                    .append("mIntParam[").append(mIntParam).append("],")
                    .append("respString[").append(s).append("]");

            L.e(stringBuffer.toString());
            if (mCallBack != null)
            {
                mCallBack.success(reqData, mGson.fromJson(s, mClass), mUrl, mIntParam);
            }
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    @Override
    public void onError(String errorString)
    {
        super.onError(errorString);

        if (mCallBack != null)
        {
            mCallBack.error(reqData, mUrl, errorString);
        }
    }

    private Listener mCallBack;
    public interface Listener<T>
    {
        void success(Object reqData, T respData, String url, int paramInt);
        void error(Object data, String url, String errorString);
    }

}
