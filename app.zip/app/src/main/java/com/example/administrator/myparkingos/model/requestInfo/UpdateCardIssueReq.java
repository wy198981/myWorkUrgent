package com.example.administrator.myparkingos.model.requestInfo;

/**
 * Created by Administrator on 2017-05-16.
 */
public class UpdateCardIssueReq
{
    private String token; // Y 用户登录时候获取的token值
    private String jsonModel; // Y JSON格式的数据Model。
    private String CallBack; // N 是否使用JSONP方式。关于JSONP方式请参考Javascript跨域访问一节。
    private Boolean ChangeBillingType; // N 如果修改了车牌号且旧车牌号的车辆在场内时是否修改该场内车辆的计费类型为临时车A

    @Override
    public String toString()
    {
        return "UpdateCardIssueReq{" +
                "token='" + token + '\'' +
                ", jsonModel='" + jsonModel + '\'' +
                ", CallBack='" + CallBack + '\'' +
                ", ChangeBillingType=" + ChangeBillingType +
                '}';
    }

    public Boolean getChangeBillingType()
    {
        return ChangeBillingType;
    }

    public void setChangeBillingType(Boolean changeBillingType)
    {
        ChangeBillingType = changeBillingType;
    }

    public String getToken()
    {
        return token;
    }

    public void setToken(String token)
    {
        this.token = token;
    }

    public String getJsonModel()
    {
        return jsonModel;
    }

    public void setJsonModel(String jsonModel)
    {
        this.jsonModel = jsonModel;
    }

    public String getCallBack()
    {
        return CallBack;
    }

    public void setCallBack(String callBack)
    {
        CallBack = callBack;
    }
}
