package com.example.administrator.myparkingos.model.responseInfo;

import java.util.List;

/**
 * Created by Administrator on 2017-07-07.
 */
public class GetCarInReportResp
{
    private String rcode; // 参考错误码列表
    private String msg; // 错误信息
    private DataBean data; // 场内各类型车辆数量汇总。结构参考下面的说明。

    @Override
    public String toString()
    {
        return "GetCarInReportResp{" +
                "rcode='" + rcode + '\'' +
                ", msg='" + msg + '\'' +
                ", data=" + data +
                '}';
    }

    public String getRcode()
    {
        return rcode;
    }

    public void setRcode(String rcode)
    {
        this.rcode = rcode;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg(String msg)
    {
        this.msg = msg;
    }

    public DataBean getData()
    {
        return data;
    }

    public void setData(DataBean data)
    {
        this.data = data;
    }

    public static class DataBean
    {
        private int MthCount; // N	月卡车数量
        private int MtpCount; // N	月临车数量
        private int TmpCount; // N	临时车数量
        private int TfrCount; // N	临免车数量
        private int StrCount; // N	储值车数量
        private int OptCount; // N	人工开闸数量
        private int FreCount; // N	免费车数量
        private int TotalCount; // N	车辆总数
        private List<GetCarInResp.DataBean> InRecords; // N	场内车辆详细信息。数据结构参考进场记录Model结构。

        @Override
        public String toString()
        {
            return "DataBean{" +
                    "MthCount=" + MthCount +
                    ", MtpCount=" + MtpCount +
                    ", TmpCount=" + TmpCount +
                    ", TfrCount=" + TfrCount +
                    ", StrCount=" + StrCount +
                    ", OptCount=" + OptCount +
                    ", FreCount=" + FreCount +
                    ", TotalCount=" + TotalCount +
                    ", InRecords=" + InRecords +
                    '}';
        }

        public int getMthCount()
        {
            return MthCount;
        }

        public void setMthCount(int mthCount)
        {
            MthCount = mthCount;
        }

        public int getMtpCount()
        {
            return MtpCount;
        }

        public void setMtpCount(int mtpCount)
        {
            MtpCount = mtpCount;
        }

        public int getTmpCount()
        {
            return TmpCount;
        }

        public void setTmpCount(int tmpCount)
        {
            TmpCount = tmpCount;
        }

        public int getTfrCount()
        {
            return TfrCount;
        }

        public void setTfrCount(int tfrCount)
        {
            TfrCount = tfrCount;
        }

        public int getStrCount()
        {
            return StrCount;
        }

        public void setStrCount(int strCount)
        {
            StrCount = strCount;
        }

        public int getOptCount()
        {
            return OptCount;
        }

        public void setOptCount(int optCount)
        {
            OptCount = optCount;
        }

        public int getFreCount()
        {
            return FreCount;
        }

        public void setFreCount(int freCount)
        {
            FreCount = freCount;
        }

        public int getTotalCount()
        {
            return TotalCount;
        }

        public void setTotalCount(int totalCount)
        {
            TotalCount = totalCount;
        }

        public List<GetCarInResp.DataBean> getInRecords()
        {
            return InRecords;
        }

        public void setInRecords(List<GetCarInResp.DataBean> inRecords)
        {
            InRecords = inRecords;
        }
    }
}
