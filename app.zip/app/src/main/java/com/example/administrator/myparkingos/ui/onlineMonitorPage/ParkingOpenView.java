package com.example.administrator.myparkingos.ui.onlineMonitorPage;

import android.app.Activity;
import android.app.Dialog;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.myUserControlLibrary.niceSpinner.NiceSpinner;


/**
 * Created by Administrator on 2017-02-16.
 * 【在线监控】 --> 左侧【开闸】按钮 -->> 【电脑开闸】
 */
public class ParkingOpenView implements View.OnClickListener
{
    private final Activity mActivity;
    private final Dialog dialog;
    private EditText txtCardNO;
    private NiceSpinner cmbCarNumber;
    private Spinner cmbCardType;
    private NiceSpinner cmbKZ;
    private Button btnOK;
    private Button btnCancel;

    public ParkingOpenView(Activity activity)
    {
        this.mActivity = activity;
        dialog = new Dialog(activity); // @android:style/Theme.Dialog
        dialog.setContentView(R.layout.opendoor_activity);
        dialog.setCanceledOnTouchOutside(true);

        Window window = dialog.getWindow();
        WindowManager m = activity.getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = window.getAttributes(); // 获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 1 / 3); // 改变的是dialog框在屏幕中的位置而不是大小
        p.width = (int) (d.getWidth() * 1 / 2.5); // 宽度设置为屏幕的0.65
        window.setAttributes(p);

        dialog.setTitle(mActivity.getResources().getString(R.string.computeOpenDoor));
        initView();
    }

    private void initView()
    {
        txtCardNO = (EditText) dialog.findViewById(R.id.txtCardNO);
        cmbCarNumber = (NiceSpinner) dialog.findViewById(R.id.cmbCarNumber);
        cmbCardType = (Spinner) dialog.findViewById(R.id.cmbCardType);

        cmbKZ = (NiceSpinner) dialog.findViewById(R.id.cmbKZ);
        cmbKZ.setSpinnerListener(new NiceSpinner.SpinnerListener()
        {
            @Override
            public void OnSpinnerItemClick(int pos)
            {

            }
        });

        btnOK = (Button) dialog.findViewById(R.id.btnOK);
        btnOK.setOnClickListener(this);
        btnCancel = (Button) dialog.findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(this);
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.btnCancel:
                dismiss();
                break;
        }
    }

    public void show()
    {
        if (dialog != null)
        {
            dialog.show();
        }
    }

    public void dismiss()
    {
        if (dialog != null && dialog.isShowing())
        {
            dialog.dismiss();
        }
    }
}
