package com.example.administrator.myparkingos.model.responseInfo;

import java.util.List;

/**
 * Created by Administrator on 2017-06-06.
 */
public class GetBlacklistResp
{
    private String rcode;      // Y 参考错误码列表
    private String msg;        // Y 错误信息
    private int PageIndex; // N 当前页码。仅当查询时指定了分页参数才有此值。
    private int PageSize;  // N 分页大小。仅当查询时指定了分页参数才有此值。
    private int TotalRows; // N 总行数。仅当查询时指定了分页参数才有此值。
    //Data	参考说明中的描述	N	如果没有指定ExportFields参数则为数据Model数组，否则为下载导出文件的完整URL
    private List<DataBean> data;

    public List<DataBean> getData()
    {
        return data;
    }

    public void setData(List<DataBean> data)
    {
        this.data = data;
    }

    @Override
    public String toString()
    {
        return "GetBlacklistResp{" +
                "rcode='" + rcode + '\'' +
                ", msg='" + msg + '\'' +
                ", PageIndex=" + PageIndex +
                ", PageSize=" + PageSize +
                ", TotalRows=" + TotalRows +
                ", data=" + data +
                '}';
    }

    public String getRcode()
    {
        return rcode;
    }

    public void setRcode(String rcode)
    {
        this.rcode = rcode;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg(String msg)
    {
        this.msg = msg;
    }

    public int getPageIndex()
    {
        return PageIndex;
    }

    public void setPageIndex(int pageIndex)
    {
        PageIndex = pageIndex;
    }

    public int getPageSize()
    {
        return PageSize;
    }

    public void setPageSize(int pageSize)
    {
        PageSize = pageSize;
    }

    public int getTotalRows()
    {
        return TotalRows;
    }

    public void setTotalRows(int totalRows)
    {
        TotalRows = totalRows;
    }

    public static class DataBean
    {
        private long ID; // Y 自增长唯一标识
        private String CPH; // Y 车牌号
        private String StartTime; // Y 开始日期
        private String EndTime; // Y 结束日期
        private String Reason; // Y 原因
        private String DownloadSignal; // Y 下载标识
        private int AddDelete; // Y

        public DataBean()
        {
        }

        public DataBean(String CPH, String startTime, String endTime, String reason, int addDelete)
        {
            this.CPH = CPH;
            StartTime = startTime;
            EndTime = endTime;
            Reason = reason;
            AddDelete = addDelete;
        }

        public long getID()
        {
            return ID;
        }

        public void setID(long ID)
        {
            this.ID = ID;
        }

        public String getCPH()
        {
            return CPH;
        }

        public void setCPH(String CPH)
        {
            this.CPH = CPH;
        }

        public String getStartTime()
        {
            return StartTime;
        }

        public void setStartTime(String startTime)
        {
            StartTime = startTime;
        }

        public String getEndTime()
        {
            return EndTime;
        }

        public void setEndTime(String endTime)
        {
            EndTime = endTime;
        }

        public String getReason()
        {
            return Reason;
        }

        public void setReason(String reason)
        {
            Reason = reason;
        }

        public String getDownloadSignal()
        {
            return DownloadSignal;
        }

        public void setDownloadSignal(String downloadSignal)
        {
            DownloadSignal = downloadSignal;
        }

        public int getAddDelete()
        {
            return AddDelete;
        }

        public void setAddDelete(int addDelete)
        {
            AddDelete = addDelete;
        }

        @Override
        public String toString()
        {
            return "GetBlacklistResp{" +
                    "ID=" + ID +
                    ", CPH='" + CPH + '\'' +
                    ", StartTime='" + StartTime + '\'' +
                    ", EndTime='" + EndTime + '\'' +
                    ", Reason='" + Reason + '\'' +
                    ", DownloadSignal='" + DownloadSignal + '\'' +
                    ", AddDelete=" + AddDelete +
                    '}';
        }
    }
}
