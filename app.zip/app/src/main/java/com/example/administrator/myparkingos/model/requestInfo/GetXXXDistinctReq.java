package com.example.administrator.myparkingos.model.requestInfo;

/**
 * Created by Administrator on 2017-07-07.
 */
public class GetXXXDistinctReq
{
    private String token; // 用户登录时候获取的token值
    private String FieldNames; // 字段名列表，各字段名间以逗号分隔。
    private String jsonModel; // 查询Model。查询Model结构与数据的Model结构基本一致。查询Model内各个字段间的逻辑关系为与关系。
    private String jsonSearchParam; // 对于需要按范围查询的字段，可修改查询Model结构，增加两个字段，字段名分别为需要查询的字段名后加_start和_end(不分大小写)，并在新增的字段中设置查询的值。对于后加_start的字段服务器采用>=比较符，对于后加_end的字段服务器采用<比较符。
    private String OrderField; // 对于查询Model中字段值为空(null)的字段，服务器将忽略。
    private String ExportFields; // 例如，查询生日在90年代范围内的JSON如下：
    private String CallBack; // {“BirthDate_Start”:”1990-1-1”,”BirthDate_End”:”2000-1-1”}

    @Override
    public String toString()
    {
        return "GetXXXDistinctReq{" +
                "token='" + token + '\'' +
                ", FieldNames='" + FieldNames + '\'' +
                ", jsonModel='" + jsonModel + '\'' +
                ", jsonParam='" + jsonSearchParam + '\'' +
                ", OrderField='" + OrderField + '\'' +
                ", ExportFields='" + ExportFields + '\'' +
                ", CallBack='" + CallBack + '\'' +
                '}';
    }

    public String getJsonSearchParam()
    {
        return jsonSearchParam;
    }

    public void setJsonSearchParam(String jsonSearchParam)
    {
        this.jsonSearchParam = jsonSearchParam;
    }

    public String getToken()
    {
        return token;
    }

    public void setToken(String token)
    {
        this.token = token;
    }

    public String getFieldNames()
    {
        return FieldNames;
    }

    public void setFieldNames(String fieldNames)
    {
        FieldNames = fieldNames;
    }

    public String getJsonModel()
    {
        return jsonModel;
    }

    public void setJsonModel(String jsonModel)
    {
        this.jsonModel = jsonModel;
    }

    public String getOrderField()
    {
        return OrderField;
    }

    public void setOrderField(String orderField)
    {
        OrderField = orderField;
    }

    public String getExportFields()
    {
        return ExportFields;
    }

    public void setExportFields(String exportFields)
    {
        ExportFields = exportFields;
    }

    public String getCallBack()
    {
        return CallBack;
    }

    public void setCallBack(String callBack)
    {
        CallBack = callBack;
    }
}
