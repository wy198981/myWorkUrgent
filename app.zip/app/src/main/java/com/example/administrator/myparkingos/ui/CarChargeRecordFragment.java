package com.example.administrator.myparkingos.ui;

import android.support.v4.app.Fragment;

/**
 * Created by Administrator on 2017-07-06.
 */
public class CarChargeRecordFragment extends Fragment
{
}
