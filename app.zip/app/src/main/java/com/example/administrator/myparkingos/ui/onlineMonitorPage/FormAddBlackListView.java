package com.example.administrator.myparkingos.ui.onlineMonitorPage;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.text.format.Time;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.constant.CR;
import com.example.administrator.myparkingos.constant.JsonSearchParam;
import com.example.administrator.myparkingos.constant.RCodeEnum;
import com.example.administrator.myparkingos.model.GetServiceData;
import com.example.administrator.myparkingos.model.beans.BlackListOpt;
import com.example.administrator.myparkingos.model.beans.Model;
import com.example.administrator.myparkingos.model.beans.gson.EntityBlackList;
import com.example.administrator.myparkingos.model.requestInfo.GetCommXXConditionReq;
import com.example.administrator.myparkingos.model.requestInfo.GetDeleteListReq;
import com.example.administrator.myparkingos.model.requestInfo.GetXXXCommonReq;
import com.example.administrator.myparkingos.model.requestInfo.UpdateCommXXListReq;
import com.example.administrator.myparkingos.model.responseInfo.GetBlacklistResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCommonXXXResp;
import com.example.administrator.myparkingos.myUserControlLibrary.DateTimePicker;
import com.example.administrator.myparkingos.myUserControlLibrary.MessageBox;
import com.example.administrator.myparkingos.util.L;
import com.example.administrator.myparkingos.util.T;
import com.example.administrator.myparkingos.util.TimeConvertUtils;
import com.example.administrator.myparkingos.volleyUtil.callback.GsonCallback;
import com.jude.http.LoadController;
import com.jude.http.RequestManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

/**
 * Created by Administrator on 2017-03-13.
 */
public class FormAddBlackListView implements GsonCallback.Listener
{
    private Dialog dialog;
    private Activity mActivity;
    private Spinner spinProvince;
    private EditText etInputCarPlate;
    private EditText etReason;
    private Button btnAdd;
    private Button btnQuery;
    private Button btnDelete;
    private Button btnQuit;
    private ListView listView;

    private class ListViewData
    {
        public List<GetBlacklistResp.DataBean> blackList; // 存放的显示数据
        public List<Boolean> isCheck;//存放是否选中某列数据
    }

    private ListViewData mListViewData = new ListViewData();
    private BlackListAdapter blackListAdapter;
    private DateTimePicker dtpStart;
    private DateTimePicker dtpEnd;
    private String[] stringArray;

    public static final String METHOD_GETBLACKLIST = "GetBlacklist";
    public static final String METHOD_DELETEBLACKLISTBY = "DeleteBlacklistBy";
    public static final String METHOD_ADDBLACKLIST = "AddBlacklist";
    public static final String METHOD_DELETEBLACKLISTBYIDLIST = "DeleteBlacklistByIDList";
    public static final String METHOD_UPDATEBLACKLISTLIST = "UpdateBlacklistList";


    public FormAddBlackListView(Activity activity)
    {
        this.mActivity = activity;

        dialog = new Dialog(activity); // @android:style/Theme.Dialog
        dialog.setContentView(R.layout.form_addblacklist);
        dialog.setCanceledOnTouchOutside(true);

        Window window = dialog.getWindow();
        WindowManager m = activity.getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = window.getAttributes(); // 获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 1 / 2); // 改变的是dialog框在屏幕中的位置而不是大小
        p.width = (int) (d.getWidth() * 1 / 2); // 宽度设置为屏幕的0.65
        window.setAttributes(p);

        initView();
        dialog.getWindow().setBackgroundDrawableResource(R.drawable.parkdowncard_background);
        dialog.setTitle(activity.getResources().getString(R.string.parkMontior_blackListVehicle));
    }

    private void initDate()
    {
        dtpStart.setDateTime(TimeConvertUtils.getCurrentYMD());
        dtpEnd.setDateTime(TimeConvertUtils.getNextYMD());

        setSpinnerProvince(Model.LocalProvince);
    }

    private void setSpinnerProvince(String province)
    {
        for (int i = 0; i < stringArray.length; i++)
        {
            if (province.equals(stringArray[i]))
            {
                spinProvince.setSelection(i);
                break;
            }
        }
    }

    public void prepareLoadData()
    {
        initDate();
        requestBlackList(null);
    }

    /**
     * 请求获取黑名单列表数据
     */
    private void requestBlackList(String jsonSearchParam)
    {
        GetXXXCommonReq getXXXCommonReq = new GetXXXCommonReq();
        getXXXCommonReq.setToken(Model.token);
        if (!TextUtils.isEmpty(jsonSearchParam))
        {
            getXXXCommonReq.setJsonSearchParam(jsonSearchParam);
        }

        String resultUrl = GetServiceData.getResultUrl(METHOD_GETBLACKLIST, getXXXCommonReq);

        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetBlacklistResp.class, this, getXXXCommonReq, resultUrl, -1));
    }

    private void initView()
    {
        spinProvince = (Spinner) dialog.findViewById(R.id.spinProvince);
        etInputCarPlate = (EditText) dialog.findViewById(R.id.etInputCarPlate);

        etReason = (EditText) dialog.findViewById(R.id.etReson);
        btnAdd = (Button) dialog.findViewById(R.id.btnAddNew);
        btnQuery = (Button) dialog.findViewById(R.id.btnQuery);
        btnDelete = (Button) dialog.findViewById(R.id.btnDelete);
        btnQuit = (Button) dialog.findViewById(R.id.btnQuit);
//        dataGridView = (DataGridView) dialog.findViewById(R.id.dataGridViewInfo);
        listView = (ListView) dialog.findViewById(R.id.listView);


        btnAdd.setOnClickListener(dialogListener);
        btnQuery.setOnClickListener(dialogListener);
        btnDelete.setOnClickListener(dialogListener);
        btnQuit.setOnClickListener(dialogListener);

        dtpStart = (DateTimePicker) dialog.findViewById(R.id.dtpStart);
        dtpEnd = (DateTimePicker) dialog.findViewById(R.id.dtpEnd);

        stringArray = mActivity.getResources().getStringArray(R.array.provinceArray);
        // spinProvince设置相应的数据即可
        ArrayAdapter adapter = new ArrayAdapter(mActivity.getApplicationContext(), R.layout.blacklist_spinner_province
                , stringArray);
        spinProvince.setAdapter(adapter);

        mListViewData.blackList = new ArrayList<>();
        mListViewData.isCheck = new ArrayList<>();
        blackListAdapter = new BlackListAdapter(mListViewData);
        listView.setAdapter(blackListAdapter);
    }

    private View.OnClickListener dialogListener = new View.OnClickListener()
    {
        @Override
        public void onClick(View v)
        {
            switch (v.getId())
            {
                case R.id.btnAddNew:
                    onBtnAddNew();
                    break;
                case R.id.btnQuery:
                    onBtnSelect();
                    break;
                case R.id.btnDelete:
                    onBtnDel();
                    break;
                case R.id.btnQuit:
                    dismiss();
                    break;
                default:
                {
                    break;
                }
            }
        }
    };

    private int deleteCount = 0;

    /**
     * 点击删除按钮
     */
    private void onBtnDel()
    {
        deleteCount = 0;
        if (!checkBlackListValid())
        {
            T.showShort(mActivity, "没有记录可以删除");
            return;
        }

        int index = 0;
        long[] DelBlacklistIDList = new long[mListViewData.isCheck.size()];
        List<GetBlacklistResp.DataBean> UpdBlacklistList = new ArrayList<>();

        for (int i = 0; i < mListViewData.isCheck.size(); i++)
        {
            if (mListViewData.isCheck.get(i))
            {
                L.e("点击第" + i + "列数据");
                GetBlacklistResp.DataBean dataBean = mListViewData.blackList.get(i);
                if (dataBean.getDownloadSignal().equals(CR.stringPadLeft("", 256, '0')))
                {
                    DelBlacklistIDList[index] = dataBean.getID();
                    index++;
                }
                else
                {
                    UpdBlacklistList.add(dataBean);
                }
            }
        }

        if (index > 0)
        {
            requestDeleteDataByIDList(Arrays.copyOf(DelBlacklistIDList, index));
        }

        if (UpdBlacklistList.size() > 0)
        {
            requstUpdateDataList(UpdBlacklistList);
        }

        deleteCount = index + UpdBlacklistList.size();
    }

    private void requstUpdateDataList(List<GetBlacklistResp.DataBean> srcDataBean)
    {
        UpdateCommXXListReq updateCommXXListReq = new UpdateCommXXListReq();
        updateCommXXListReq.setToken(Model.token);
        updateCommXXListReq.setJsonModelList(JsonSearchParam.getWhenJsonModel(srcDataBean));

        String resultUrl = GetServiceData.getResultUrl(METHOD_UPDATEBLACKLISTLIST, updateCommXXListReq);

        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetCommonXXXResp.class, this, updateCommXXListReq, resultUrl, -1));
    }

    private void requestDeleteDataByIDList(long[] DelBlacklistIDList)
    {
        GetDeleteListReq getDeleteListReq = new GetDeleteListReq();
        getDeleteListReq.setToken(Model.token);
        getDeleteListReq.setIDList(JsonSearchParam.getWhenJsonModel(DelBlacklistIDList));

        String resultUrl = GetServiceData.getResultUrl(METHOD_DELETEBLACKLISTBYIDLIST, getDeleteListReq);

        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetCommonXXXResp.class, this, getDeleteListReq, resultUrl, -1));
    }

    private boolean checkBlackListValid()
    {
        if (mListViewData.blackList.size() == 0)
        {
            L.e("mEntityBlackLists.size() == 0");
            return false;
        }
        return true;
    }

    /**
     * 点击按钮查询
     */
    private void onBtnSelect()
    {
        if (!checkCPHView())
        {
            return;
        }

        requestSelectBlackList(getCPH());
    }

    private void requestSelectBlackList(String cph)
    {
        String time = TimeConvertUtils.longToString(System.currentTimeMillis());
        requestBlackList(JsonSearchParam.getSelectBlackList(cph, time, time));
    }

    private String getCPHNotProvince()
    {
        return etInputCarPlate.getText().toString().trim();
    }

    private String getCPH()
    {
        return spinProvince.getSelectedItem().toString() + getCPHNotProvince();
    }

    private String getReason()
    {
        return etReason.getText().toString().trim().toUpperCase();
    }

    /**
     * 点击按钮添加
     */
    private void onBtnAddNew()
    {
        if (!checkCPHView())
        {
            return;
        }

        String reason = getReason();
        if (TextUtils.isEmpty(reason))
        {
            MessageBox.show(mActivity, "添加黑名单原因不能为空!");
            return;
        }

        GetBlacklistResp.DataBean dataBean = new GetBlacklistResp.DataBean();
        dataBean.setCPH(getCPH());
        dataBean.setStartTime(TimeConvertUtils.toLongDateString(dtpStart.getDateTime()));
        dataBean.setEndTime(TimeConvertUtils.toLongDateString(dtpEnd.getDateTime()));
        dataBean.setReason(reason);
        dataBean.setAddDelete(0);
        dataBean.setDownloadSignal(CR.stringPadLeft("", 256, '0'));

        requestAddBlackList(dataBean);
    }

    private boolean checkCPHView()
    {
        String cphNotProvince = getCPHNotProvince();
        if (TextUtils.isEmpty(cphNotProvince))
        {
            MessageBox.show(mActivity, "车牌号码不能为空!");
            return false;
        }

        String cph = getCPH();
        if (!CR.CheckUpCPH(cph, false))
        {
            MessageBox.show(mActivity, "车牌号码不合法!");
            return false;
        }
        return true;
    }

    /**
     * 添加黑名单
     *
     * @param dataBean
     */
    private void requestAddBlackList(GetBlacklistResp.DataBean dataBean)
    {
        requestDeleteBeforeAddBlackList(dataBean.getCPH());
        requestAfterAddBlackList(dataBean);// 会不会并发执行
    }

    /**
     * 添加黑名单即可
     *
     * @param dataBean
     */
    private void requestAfterAddBlackList(GetBlacklistResp.DataBean dataBean)
    {
        GetXXXCommonReq getXXXCommonReq = new GetXXXCommonReq();
        getXXXCommonReq.setToken(Model.token);
        getXXXCommonReq.setJsonModel(JsonSearchParam.getWhenJsonModel(dataBean));

        String resultUrl = GetServiceData.getResultUrl(METHOD_ADDBLACKLIST, getXXXCommonReq);

        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetCommonXXXResp.class, this, getXXXCommonReq, resultUrl, -1));
    }

    /**
     * 在删除之前，先删除这个车牌对应的黑名单
     *
     * @param cph
     */
    private void requestDeleteBeforeAddBlackList(String cph)
    {
        GetCommXXConditionReq getCommXXConditionReq = new GetCommXXConditionReq();
        getCommXXConditionReq.setToken(Model.token);
        getCommXXConditionReq.setJsonConditions(JsonSearchParam.getDeletBlackBy(cph));

        String resultUrl = GetServiceData.getResultUrl(METHOD_DELETEBLACKLISTBY, getCommXXConditionReq);

        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetCommonXXXResp.class, this, getCommXXConditionReq, resultUrl, -1));
    }

    public void show()
    {
        if (dialog != null)
        {
            prepareLoadData();// 显示之前加载数据
            dialog.show();
        }
    }

    public void dismiss()
    {
        if (dialog != null && dialog.isShowing())
        {
            clearDataInView();
            dialog.dismiss();
        }
    }

    private int retComm = 0;

    @Override
    public void success(Object reqData, Object respData, String url, int paramInt)
    {
        CR.printGsonResp(reqData, respData, url, paramInt);
        if (respData instanceof GetBlacklistResp)
        {
            GetBlacklistResp blacklistResp = (GetBlacklistResp) respData;
            L.e(blacklistResp.toString());
            if (Integer.parseInt(blacklistResp.getRcode()) != RCodeEnum.OK.getValue())
            {
                L.e(blacklistResp.getMsg());
            }
            else
            {
                if (blacklistResp.getData() == null)
                {
                    L.e("blacklistResp.getData() == null");
                }
                else
                {
                    updateBlackListViewData(blacklistResp.getData());
                }
            }
        }
        else if (respData instanceof GetCommonXXXResp)
        {
            GetCommonXXXResp commonXXXResp = (GetCommonXXXResp) respData;
            if (Integer.parseInt(commonXXXResp.getRcode()) != RCodeEnum.OK.getValue())
            {
                L.e(commonXXXResp.getMsg());
                return;
            }

            if (reqData instanceof GetXXXCommonReq)
            {
                if (commonXXXResp.getData() > 0)
                {
//                    gsd.AddLog("黑名单车辆", Model.sUserName + ":添加黑名单车辆：" + blacklist.CPH);
                    MessageBox.show(mActivity, "添加成功!");
                    requestBlackList(null);
                }
            }
            else if (reqData instanceof GetDeleteListReq)
            {
                retComm += commonXXXResp.getData();
                L.e("retComm:" + retComm + ",deleteCount:" + deleteCount);
                if (retComm == deleteCount)
                {
                    MessageBox.show(mActivity, "删除成功!");
                    requestBlackList(null);
                    retComm = 0;
                }
            }
            else if (reqData instanceof UpdateCommXXListReq)
            {
                retComm += commonXXXResp.getData();
                L.e("retComm:" + retComm + ",deleteCount:" + deleteCount);
                if (retComm == deleteCount)
                {
                    MessageBox.show(mActivity, "删除成功!");
                    requestBlackList(null);
                    retComm = 0;
                }
            }


        }
    }

    private void updateBlackListViewData(List<GetBlacklistResp.DataBean> data)
    {
        setData(data);
    }

    @Override
    public void error(Object data, String url, String errorString)
    {
        L.e("连接服务器失败");
    }

    class BlackListAdapter extends BaseAdapter
    {
        private ListViewData mList;

        public BlackListAdapter(ListViewData list)
        {
            mList = list;
        }

        @Override
        public int getCount()
        {
            return mList.isCheck.size();
        }

        @Override
        public Object getItem(int position)
        {
            return mList.isCheck.get(position);
        }

        @Override
        public long getItemId(int position)
        {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent)
        {

            ViewHolder holder = null;
            if (convertView == null)
            {
                holder = new ViewHolder();
                convertView = (mActivity).getLayoutInflater().inflate(
                        R.layout.blacklistview_item, null); // 需要使用getLayoutInflater方法，即需要在该context中
                holder.tv1 = (TextView) convertView.findViewById(R.id.tvText1);
                holder.tv2 = (TextView) convertView.findViewById(R.id.tvText2);
                holder.tv3 = (TextView) convertView.findViewById(R.id.tvText3);
                holder.tv4 = (TextView) convertView.findViewById(R.id.tvText4);
                holder.tv5 = (TextView) convertView.findViewById(R.id.tvText5);
                holder.checkBox = (CheckBox) convertView.findViewById(R.id.checkBox);
                holder.checkBox.setChecked(false);
                holder.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
                {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
                    {
                        if (isChecked)
                        {
                            L.e("onCheckedChanged", "ischeck" + isChecked);
                            mList.isCheck.remove(position);
                            mList.isCheck.add(position, true);
                        }
                        else
                        {
                            L.e("onCheckedChanged", "ischeck" + isChecked);
                            mList.isCheck.remove(position);
                            mList.isCheck.add(position, false);
                        }
                    }
                });



                convertView.setTag(holder);// 保存起来，设置标记
            }
            else
            {
                holder = (ViewHolder) convertView.getTag();// 获取标记
            }
            holder.tv1.setText(mList.blackList.get(position).getCPH());
            holder.tv2.setText(mList.blackList.get(position).getStartTime());
            holder.tv3.setText(mList.blackList.get(position).getEndTime());
            holder.tv4.setText(mList.blackList.get(position).getReason());
            holder.tv5.setText(String.valueOf(mList.blackList.get(position).getAddDelete()));
            return convertView;
        }

        class ViewHolder
        {
            public CheckBox checkBox;
            public TextView tv1;
            public TextView tv2;
            public TextView tv3;
            public TextView tv4;
            public TextView tv5;
        }
    }

    public void setData(List<GetBlacklistResp.DataBean> data)
    {
        mListViewData.blackList.clear(); //先清空
        mListViewData.isCheck.clear();

        if (data != null)
        {
            for (int i = 0; i < data.size(); i++)
            {
                mListViewData.isCheck.add(false);
            }
        }

        mListViewData.blackList.addAll(data);
        blackListAdapter.notifyDataSetChanged();
    }

    public void clearDataInView()
    {
        etInputCarPlate.setText("");
        etReason.setText("");
    }
}
