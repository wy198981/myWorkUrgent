package com.example.administrator.myparkingos.ui.onlineMonitorPage;

import android.app.Activity;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.example.administrator.myparkingos.constant.CR;
import com.example.administrator.myparkingos.constant.JsonSearchParam;
import com.example.administrator.myparkingos.constant.PlateColorEnum;
import com.example.administrator.myparkingos.constant.QueueMessageTypeEnum;
import com.example.administrator.myparkingos.constant.RCodeEnum;
import com.example.administrator.myparkingos.model.GetServiceData;
import com.example.administrator.myparkingos.model.beans.Model;
import com.example.administrator.myparkingos.model.requestInfo.AddOptLogReq;
import com.example.administrator.myparkingos.model.requestInfo.CaclChargeAmountReq;
import com.example.administrator.myparkingos.model.requestInfo.CancelChargeReq;
import com.example.administrator.myparkingos.model.requestInfo.GetCardTypeDefReq;
import com.example.administrator.myparkingos.model.requestInfo.GetFreeReasonReq;
import com.example.administrator.myparkingos.model.requestInfo.GetParkDiscountJHSetReq;
import com.example.administrator.myparkingos.model.requestInfo.SetCarOutReq;
import com.example.administrator.myparkingos.model.requestInfo.SetCarOutWithoutEntryRecordReq;
import com.example.administrator.myparkingos.model.requestInfo.UpdateChargeAmountReq;
import com.example.administrator.myparkingos.model.requestInfo.UpdateChargeAsFreeReq;
import com.example.administrator.myparkingos.model.requestInfo.UpdateChargeInfoReq;
import com.example.administrator.myparkingos.model.requestInfo.UpdateChargeWithCaptureImageReq;
import com.example.administrator.myparkingos.model.responseInfo.AddOptLogResp;
import com.example.administrator.myparkingos.model.responseInfo.CaclChargeAmountResp;
import com.example.administrator.myparkingos.model.responseInfo.CancelChargeResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCardTypeDefResp;
import com.example.administrator.myparkingos.model.responseInfo.GetFreeReasonResp;
import com.example.administrator.myparkingos.model.responseInfo.GetParkDiscountJHSetResp;
import com.example.administrator.myparkingos.model.responseInfo.SetCarOutResp;
import com.example.administrator.myparkingos.model.responseInfo.SetCarOutWithoutEntryRecordResp;
import com.example.administrator.myparkingos.model.responseInfo.UpdateChargeAmountResp;
import com.example.administrator.myparkingos.model.responseInfo.UpdateChargeAsFreeResp;
import com.example.administrator.myparkingos.model.responseInfo.UpdateChargeInfoResp;
import com.example.administrator.myparkingos.model.responseInfo.UpdateChargeWithCaptureImageResp;
import com.example.administrator.myparkingos.myUserControlLibrary.MessageBox;
import com.example.administrator.myparkingos.util.L;
import com.example.administrator.myparkingos.util.OpenGateCallBack;
import com.example.administrator.myparkingos.util.SDCardUtils;
import com.example.administrator.myparkingos.util.T;
import com.example.administrator.myparkingos.util.TimeConvertUtils;
import com.example.administrator.myparkingos.volleyUtil.callback.GsonCallback;
import com.example.sfmudpsdk_android.LoadLsNoX2010znyktOutGateModel;
import com.jude.http.RequestManager;

import java.io.File;
import java.util.Date;
import java.util.List;

/**
 * Created by Administrator on 2017-04-12.
 */
public class ParkingTempGob_bigViewSub extends ParkingTempGob_bigView implements GsonCallback.Listener
{
    private SetCarOutResp.DataBean mModel;
    private int mIndex;
    private PlateColorEnum plateColor;
    private String mFileJpg;
    private Handler mHandler;
    private Activity mActivity;
    private List<GetFreeReasonResp.DataBean> reasonList;
    private List<GetParkDiscountJHSetResp.DataBean> discountJHSetList;
    private List<GetCardTypeDefResp.DataBean> typeDefRespData;

    public static final String METHOD_GETFREEREASON = "GetFreeReason";
    public static final String METHOD_GETPARKDISCOUNTJHSET = "GetParkDiscountJHSet";
    public static final String METHOD_GETCARDTYPEDEF = "GetCardTypeDef";
    public static final String METHOD_SETCAROUTWITHOUTENTRYRECORD = "SetCarOutWithoutEntryRecord";
    public static final String METHOD_UPDATECHARGEAMOUNT = "UpdateChargeAmount";
    public static final String METHOD_CACLCHARGEAMOUNT = "CaclChargeAmount";
    public static final String METHOD_CANCELCHARGE = "CancelCharge";
    public static final String METHOD_UPDATECHARGEWITHCAPTUREIMAGE = "UpdateChargeWithCaptureImage";
    public static final String METHOD_UPDATECHARGEASFREE = "UpdateChargeAsFree";
    public static final String METHOD_UPDATECHARGEINFO = "UpdateChargeInfo";

    public ParkingTempGob_bigViewSub(
            Activity activity
            , ParkingTempGob_bigView.E_VIEW_TYPE viewType
            , PlateColorEnum colorEnum
            , int index
            , SetCarOutResp.DataBean model
            , String fileJpg
            , Handler handler
    )
    {
        super(activity, viewType);
        this.mActivity = activity;
        this.mModel = model;
        this.mIndex = index;
        this.plateColor = colorEnum;
        this.mFileJpg = fileJpg;
        this.mHandler = handler;
    }

    public void InitDataSource()
    {
        requestGetFreeReason();
        requestGetParkDiscountJHSet();
    }

    private void requestGetParkDiscountJHSet()
    {
        GetParkDiscountJHSetReq jhSetReq = new GetParkDiscountJHSetReq();
        jhSetReq.setToken(Model.token);
        String resultUrl = GetServiceData.getResultUrl(METHOD_GETPARKDISCOUNTJHSET, jhSetReq);
        resultUrl += "&" + "Address";

        RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetParkDiscountJHSetResp.class, this, jhSetReq, resultUrl, -1));
    }

    @NonNull
    private void requestGetFreeReason()
    {
        GetFreeReasonReq reasonReq = new GetFreeReasonReq();
        reasonReq.setToken(Model.token);
        String resultUrl = GetServiceData.getResultUrl(METHOD_GETFREEREASON, reasonReq);
        resultUrl += "&" + "ItemID";

        RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetFreeReasonResp.class, this, reasonReq, resultUrl, -1));
    }

    @Override
    public void loadedDataWhenHaveInRecord()
    {
        super.loadedDataWhenHaveInRecord();
        InitDataSource(); // 更新原因和打折地点
        // 显示图片数据，输入默认，输出即为传递的图片
        if (new File(mFileJpg).exists())
        {
            setCarInPicture(BitmapFactory.decodeFile(mFileJpg)); // mFileJpg即为传入图片的路径
        }
        showDataToControl();

        setNeedMoneyOnFinal(String.valueOf(mModel.getYSJE()) != null ? String.valueOf(mModel.getYSJE()) : "0.0");

        String cardType = getCmdCardType();
        if ((CR.GetCardType(cardType, 0).substring(0, 3).equals("Tmp") || CR.GetCardType(cardType, 0).substring(0, 3).equals("Mtp"))
                && Model.Channels[mIndex].iBigSmall == 0 && Model.iBillPrint == 1 && Model.iBillPrintAuto > 0 && Double.parseDouble(getStopPayMoney()) > 0)
        {
//           btnPrint_Click(null, null);
        }

//        cmbCardType.SelectionChanged += cmbCardType_SelectionChanged;

        //没有启用收费窗口可更改卡类或者启用了且选择了播报语音则在打开收费窗口时报价
        if (Model.iSetTempCardType <= 0 || Model.iModiTempType_VoiceSF > 0)
        {
            ReportCharge();
        }
//
//        //如果启用了自动关闭收费窗口功能则启动定时器
        if (Model.iAutoMinutes > 0)
        {
            autoCloseWindowInMinutes();//注意相应的次数
//            tmrCloseForm = new DispatcherTimer();
//            tmrCloseForm.Interval = new TimeSpan(0, 0, 1);
//            tmrCloseForm.Tick += tmrCloseForm_Tick;
//            tmrCloseForm.Start();
        }
    }

    public void autoCloseWindowInMinutes()
    {
        mHandler.postDelayed(new Runnable()
        {
            @Override
            public void run()
            {
                cancel();
            }
        }, 1 * 5000);
    }

    @Override
    public void loadedDataWhenNotInRecord()
    {
        if (mModel == null)
        {
            L.i("mModel 为空");
            return;
        }
        updateViewBySetOutResp();

        File file = new File(mFileJpg);
        if (file.exists())
        {
            setChargePicture1(BitmapFactory.decodeFile(mFileJpg));// 显示在出口中
        }
//        SetImageSource(imgIn, Properties.Resources.Car2);
//
//        if (System.IO.File.Exists(localImagePath))
//        {
//            SetImageSource(imgOut, localImagePath);
//        }
//        else
//            SetImageSource(imgOut, Properties.Resources.Car2);

    }

    private void ReportCharge()//播报语音
    {
        try
        {
            String strTime;
            if (Model.iCtrlShowPlate == 1 || Model.iCtrlShowStayTime == 1)
            {
                String cardType = CR.GetCardType(getCmdCardType(), 1);

//            2017-05-04 15:43:35 日期格式
                int[] diff = TimeConvertUtils.processTwo(CR.prepareDetectString(mModel.getInTime(), mModel.getOutTime()), mModel.getOutTime());
                if (Model.iCtrlShowStayTime == 0)
                {
                    strTime = "FFFF";
                }
                final LoadLsNoX2010znyktOutGateModel outGateModel = new LoadLsNoX2010znyktOutGateModel();
                outGateModel.strCPH = mModel.getCPH();
                outGateModel.CarTypeenum = (null != cardType ? CR.getCardTypeEnum(cardType.substring(0, 3)) : CR.getCardTypeEnum(mModel.getCardType().substring(0, 3)));
                outGateModel.strCardCW = "";
                outGateModel.iDay = diff[0];
                outGateModel.iHour = diff[1];
                outGateModel.iMinutes = diff[2];
                outGateModel.CYkDay = 0;
                outGateModel.SFJE = (int) Double.parseDouble(getNeedPayMoney());//
                outGateModel.iIDNoticeDay = 0;


                L.e("cardType:" + cardType);
                CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_LSNOX2010ZNYKTOUTGATE, outGateModel, mIndex);
            }
            else
            {
                int MyTempMoney = 0;
                double SFJE = Double.parseDouble(getNeedPayMoney());
                if (Model.iXsd == 0)
                {
                    if (Model.iChargeType == 3)//北京收费
                    {
                        if (Model.iXsdNum == 1)
                        {
                            MyTempMoney = (int) (SFJE * 10);
                        }
                        else
                        {
                            if (SFJE > 655)
                            {
                                String strQIAN = CR.MoneyToChinese(getNeedPayMoney());
                                String strsLoad = "73" + CR.GetChineseMoney(strQIAN) + "74";
                                CR.sendModeToQueue(QueueMessageTypeEnum.queue_SendCombinationVioce, strsLoad, mIndex);
                                SurplusCPH();
                                return;
                            }
                            MyTempMoney = (int) (SFJE * 100);
                        }
                    }
                    else
                    {
                        MyTempMoney = (int) SFJE;
                    }
                }
                else
                {
                    MyTempMoney = (int) (SFJE * 10);
                }
                if (Model.bSfDec)
                {
                    CR.sendModeToQueue(QueueMessageTypeEnum.queue_ShowLed, MyTempMoney, mIndex);
                }
                else
                {
                    CR.sendModeToQueue(QueueMessageTypeEnum.queue_ShowLed, MyTempMoney, mIndex);
                }
                SurplusCPH();
            }
        }
        catch (Exception ex)
        {
            requestAddOptLog("出场收费" + ":ReportCharge", ex.getMessage() + "\n" + ex.toString());
            MessageBox.show(mActivity, ex.getMessage() + "\n" + ":Baojia", "错误");
        }
    }

    private void requestAddOptLog(String OptMenu, String OptContent)
    {
        AddOptLogReq addOptLogReq = CR.initAddOptLog(OptMenu, OptContent);
        String resultUrl = GetServiceData.getInstance().getResultUrl(ParkingMonitoringActivity.METHOD_ADDOPTLOG, addOptLogReq);
        RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(AddOptLogResp.class, this, addOptLogReq, resultUrl, -1));
    }

    private void SurplusCPH()
    {

    }

    private void showDataToControl()
    {
        requestGetCarTypeDef(mModel.getCardType());

        setCPHInHaveCarInRecord(mModel.getCPH());
        setCPHInNoInRecord(mModel.getCPH());

        setInTime((null == mModel.getInTime()) ? "" : mModel.getInTime());
        setOutTime(mModel.getOutTime());
        setDuringTime(mModel.getStayTime());
        setChargeMoney(String.valueOf(mModel.getSFJE())); //设置停车收费
        setNeedMoneyOnFinal(String.valueOf(mModel.getYSJE()));// 应收车费

        if (TextUtils.isEmpty(mModel.getStayTime()))
        {
            if (TextUtils.isEmpty(mModel.getInTime()))
            {
                setDuringTime("0分");// inTime为空，且getStayTime还没有时间时,即stayTime设置为0;
            }
        }

        // 车辆类型
        String selectCardType = mModel.getCardType();
        setCardTypeSpinnerIndexByText(selectCardType);

        L.i("selectCardType:" + selectCardType + "CR.GetCardType(selectCardType, 0):" + CR.GetCardType(selectCardType, 1));
        setCarTypeByChinese(CR.GetCardType(selectCardType, 1));
    }

    private void updateViewBySetOutResp()
    {
        setCPHInNoInRecord(mModel.getCPH());
        if (mModel.getSimilarCPHIssued() != null && mModel.getSimilarCPHIssued().size() > 0)
        {
            setListViewCarIssueData(mModel.getSimilarCPHIssued());
        }

        if (mModel.getSimilarCPHInPark() != null && mModel.getSimilarCPHInPark().size() > 0)
        {
            setListViewCarInPark(mModel.getSimilarCPHInPark());
        }
        if ((mModel.getSimilarCPHInPark() != null && mModel.getSimilarCPHInPark().size() > 0)
                || (mModel.getSimilarCPHIssued() != null && mModel.getSimilarCPHIssued().size() > 0))
        {
            setConfirmButtonEnable(true);
        }
        else
        {
            setConfirmButtonEnable(false);
        }
    }


    public void setCallback(ICallBack callback)
    {
        this.callback = callback;
    }

    private ICallBack callback;

    @Override
    public void success(Object reqData, Object respData, String url, int paramInt)
    {
        CR.printGsonResp(reqData, respData, url, paramInt);
        if (reqData instanceof AddOptLogResp)
        {

        }
        else if (respData instanceof GetFreeReasonResp)
        {
            GetFreeReasonResp getFreeReasonResp = (GetFreeReasonResp) respData;
            if (getFreeReasonResp.getData() == null)
                return;
            reasonList = getFreeReasonResp.getData();
            reasonList.add(0, new GetFreeReasonResp.DataBean(0, ""));
            setReasonList(reasonList);
        }
        else if (respData instanceof GetParkDiscountJHSetResp)
        {
            GetParkDiscountJHSetResp getParkDiscountJHSetResp = (GetParkDiscountJHSetResp) respData;
            if (getParkDiscountJHSetResp.getData() == null)
                return;

            discountJHSetList = getParkDiscountJHSetResp.getData();
            discountJHSetList.add(0, new GetParkDiscountJHSetResp.DataBean(0, "", 0L, ""));
            setDiscountAddressList(discountJHSetList);
        }
        else if (respData instanceof GetCardTypeDefResp)
        {
            GetCardTypeDefResp getCardTypeDefResp = (GetCardTypeDefResp) respData;
            if (getCardTypeDefResp.getData() == null)
                return;

            typeDefRespData = getCardTypeDefResp.getData();
            L.e("typeDefRespData:" + typeDefRespData);
            setCardTypeSpinner(typeDefRespData);
        }
        else if (respData instanceof SetCarOutWithoutEntryRecordResp)// 点击了 无入场纪录
        {
            SetCarOutWithoutEntryRecordResp withoutEntryRecordResp = (SetCarOutWithoutEntryRecordResp) respData;
            RCodeEnum rCodeEnum = RCodeEnum.valueOf(Integer.parseInt(withoutEntryRecordResp.getRcode()));
            switch (rCodeEnum)
            {
                case OK:
                case RepeatAdmission:
                case MthBeOverdueToTmpCharge:
                    break;
                default:
                    MessageBox.show(mActivity, withoutEntryRecordResp.getMsg());
                    return;
            }

            if (withoutEntryRecordResp.getData() == null)
                return;
            mModel = withoutEntryRecordResp.getData();
            if (mModel.getSFJE() > 0)
            {
                mType = E_VIEW_TYPE.E_VIEW_CHARGE_HAVA_RECORD;
                showViewByType(E_VIEW_TYPE.E_VIEW_CHARGE_HAVA_RECORD);
                initControlStatusBySysSetting();
                showDataToControl();
                InitDataSource(); // 更新原因和打折地点
                // 显示图片数据，输入默认，输出即为传递的图片
                if (new File(mFileJpg).exists())
                {
                    setCarInPicture(BitmapFactory.decodeFile(mFileJpg)); // mFileJpg即为传入图片的路径
                }

                setNeedMoneyOnFinal(String.valueOf(mModel.getYSJE()) != null ? String.valueOf(mModel.getYSJE()) : "0.0");

                String cardType = getCmdCardType();
                if ((CR.GetCardType(cardType, 0).substring(0, 3).equals("Tmp") || CR.GetCardType(cardType, 0).substring(0, 3).equals("Mtp")) &&
                        Model.Channels[mIndex].iBigSmall == 0 && Model.iBillPrint == 1 && Model.iBillPrintAuto > 0 && Double.parseDouble(getStopPayMoney()) > 0)
                {
//           btnPrint_Click(null, null);
                }

                //没有启用收费窗口可更改卡类或者启用了且选择了播报语音则在打开收费窗口时报价
                if (Model.iSetTempCardType <= 0 || Model.iModiTempType_VoiceSF > 0)
                {
                    ReportCharge();
                }
                if (Model.iAutoMinutes > 0)
                {
                    //自动关闭窗口
                }
                return;
            }
            else
            {
                MessageBox.showCanSetCallback(mActivity, "请确认", getCPHInHaveRecord() + " 没有场内记录，将直接开闸不收费，并保存出场记录和操作日志！\n请确认是否继续？"
                        , new MessageBox.IMessageBoxListener()
                        {
                            @Override
                            public void onClickPositive(DialogInterface dialog)
                            {

                            }

                            @Override
                            public void onClickNegative(DialogInterface dialog)
                            {
                                dialog.cancel();
                            }
                        });
            }

            sendOpenGateAndTempOutOpen();
        }
        else if (respData instanceof SetCarOutResp)
        {
            SetCarOutResp setCarOutResp = (SetCarOutResp) respData;
            int parseInt = Integer.parseInt(setCarOutResp.getRcode());
            RCodeEnum code = RCodeEnum.valueOf(parseInt);
            switch (code)
            {
                case OK:
                    break;
                default:
                    MessageBox.show(mActivity, setCarOutResp.getMsg());
                    return;
            }

            if (setCarOutResp.getData() == null)
                return;
            initControlStatusBySysSetting();
            showDataToControl();
            InitDataSource(); // 更新原因和打折地点

            // 车辆类型
            String selectCardType = mModel.getCardType();
            setCardTypeSpinnerIndexByText(selectCardType);

            L.i("selectCardType:" + selectCardType + "CR.GetCardType(selectCardType, 0):" + CR.GetCardType(selectCardType, 1));
            setCarTypeByChinese(CR.GetCardType(selectCardType, 1));

            boolean IsFoue = false;
            if (mModel.getCardType().substring(0, 3) == "Tmp" || mModel.getCardType().substring(0, 3) == "Mtp")
            {
                if (IsFoue == false && (Model.iSetTempCardType == 0 || (Model.iSetTempCardType == 1 && Model.iModiTempType_VoiceSF == 1)))  //2016-05-07 zsd add Model.bSetTempCardType == false
                {
                    ReportCharge();
                }
            }
            else
            {
                //CPHDataHandler(txtCPH0.Text, Convert.ToInt32(modulus));
            }
            mType = E_VIEW_TYPE.E_VIEW_CHARGE_HAVA_RECORD;
            showViewByType(E_VIEW_TYPE.E_VIEW_CHARGE_HAVA_RECORD);
        }
        else if (respData instanceof UpdateChargeAmountResp)
        {
            UpdateChargeAmountResp amountResp = (UpdateChargeAmountResp) respData;
            int ret = amountResp.getData();
            if (ret <= 0)
            {
                MessageBox.show(mActivity, "提交服务失败");
            }
        }
        else if (reqData instanceof UpdateChargeInfoResp)
        {
            UpdateChargeInfoResp infoResp = (UpdateChargeInfoResp) reqData;
            if (infoResp.getData() <= 0)
            {
                MessageBox.show(mActivity, "提交服务失败");
            }
        }
        else if (respData instanceof CaclChargeAmountResp)
        {
            CaclChargeAmountResp chargeAmountResp = (CaclChargeAmountResp) respData;
            if (chargeAmountResp.getData() == null)
            {
                setChargeMoney("0");
                setNeedMoneyOnFinal("0");
            }
            else
            {
                setChargeMoney(String.valueOf(chargeAmountResp.getData().getSFJE()));
                setNeedMoneyOnFinal(String.valueOf(chargeAmountResp.getData().getSFJE()));
            }
        }
        else if (respData instanceof CancelChargeResp)
        {
            CancelChargeResp cancelChargeResp = (CancelChargeResp) respData;
            int ret = cancelChargeResp.getData(); // 即只有当取消成功才会取消界面
            if (ret <= 0)
            {
                MessageBox.show(mActivity, "取消收费失败！" + "\r\n" + "btnOK_Click");
                return;
            }
            cancel();
        }
        else if (respData instanceof UpdateChargeAsFreeResp)
        {
            UpdateChargeAsFreeResp resp = (UpdateChargeAsFreeResp) respData;
            if (resp.getData() <= 0)
            {
                MessageBox.show(mActivity, "提交数据到服务器失败");
            }
        }
    }

    private void dealOpenGateReturnVal(String strRst)
    {
        if (!strRst.equals("2"))// strRst 还是需要和开闸有关的;
        {
            if (callback != null)
            {
                mModel.setYSJE(Double.parseDouble(getStopPayMoney())); // 可能出现问题;需要进行的数据的异常的处理;
                mModel.setYSJE(Double.parseDouble(getNeedPayMoney()));
                mModel.setCardType(CR.GetCardType(getCmdCardType(), 0));
                callback.updateAppearanceRecord(mModel, mIndex, mFileJpg);
            }
            this.cancel();
        }
    }

    @Override
    public void error(Object data, String url, String errorString)
    {
        T.showShort(mActivity, "连接服务器失败");
    }

    public interface ICallBack
    {
        void updateAppearanceRecord(SetCarOutResp.DataBean appearanceModel, int laneIndex, String localImagePath);

        void tempGob_big_Photo(String count);

        void binData(String CardType, double SFJE);
    }

    @Override
    public void onClickPrintBill()//打印小票
    {
    }

    @Override
    public void onClickNoRecordPass() //没有入场记录
    {
        SetCarOutWithoutEntryRecordReq req = new SetCarOutWithoutEntryRecordReq();
        req.setToken(Model.token);
        req.setCPH(getCPHInNotRecord());
        req.setCtrlNumber(mModel.getCtrlNumber());
        req.setStationId(Model.stationID);
        req.setCPColor(mModel.getCPColor());

        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_SETCAROUTWITHOUTENTRYRECORD, req);
        RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(SetCarOutWithoutEntryRecordResp.class, this, req, resultUrl, -1));
    }

    @Override
    public void onClickConfirmed() // 确认按钮
    {
        SetCarOutReq req = new SetCarOutReq();
        req.setToken(Model.token);
        req.setCPH(getCPHInNotRecord());
        req.setCtrlNumber(Model.Channels[mIndex].iCtrlID);
        req.setCPColor(plateColor.getColorValue());
        req.setStationId(Model.stationID);

        String resultUrl = GetServiceData.getInstance().getResultUrl(ParkingMonitoringActivity.METHOD_SETCAROUT, req);
        RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(SetCarOutResp.class, this, req, resultUrl, -1));
    }

    @Override
    public void onClickGiveUp()
    {
        super.onClickGiveUp();
        MessageBox.showCanSetCallback(mActivity, "请确认是否放弃开闸？\t\r若点击【是】，道闸将不会打开，但收费记录仍将保存，放弃开闸不能作为未收费的依据！！"
                , new MessageBox.IMessageBoxListener()
                {
                    @Override
                    public void onClickPositive(DialogInterface dialog)
                    {
                        if (Model.iSetTempMoney == 1)
                        {
                            requestUpdateChargeAmount();
                        }
                        else if (Model.iSetTempCardType == 1 || Model.iDiscount == 1)
                        {
                            GetParkDiscountJHSetResp.DataBean dzItem = null;
                            GetCardTypeDefResp.DataBean cardItem = null;
                            if (Model.iDiscount == 1)
                            {
                                if (discountJHSetList != null && discountJHSetList.size() > 0)
                                {
                                    dzItem = discountJHSetList.get(getDiscountListIndex());
                                }
                            }
                            if (Model.iSetTempCardType == 1)
                            {
                                if (typeDefRespData != null && typeDefRespData.size() > 0)
                                {
                                    cardItem = typeDefRespData.get(getCardTypeListIndex());
                                }
                            }
                            requestUpdateChargeInfo(dzItem, cardItem);
                        }

                        mModel.setYSJE(Double.parseDouble(getNeedPayMoney()));
                        mModel.setSFJE(Double.parseDouble(getStopPayMoney()));
                        mModel.setCardType(getCmdCardType());

                        if (null != callback)
                            callback.updateAppearanceRecord(mModel, mIndex, mFileJpg);
                        dialog.cancel();
                        cancel();
                    }

                    @Override
                    public void onClickNegative(DialogInterface dialog)
                    {
                    }
                });
    }

    @Override
    public void onClickChargeFree()// 免费放行
    {
        MessageBox.showCanSetCallback(mActivity, "请确认是否免费放行？\t\r若点击【是】，该车辆将被免费放行！"
                , new MessageBox.IMessageBoxListener()
                {
                    @Override
                    public void onClickPositive(DialogInterface dialog)// 点击ok
                    {
                        requestUpdateChargeAsFree();
                        sendOpenGateAndTempOutOpen();
                    }

                    @Override
                    public void onClickNegative(DialogInterface dialog)
                    {
                    }
                });

    }

    private void requestUpdateChargeAsFree()
    {
        UpdateChargeAsFreeReq req = new UpdateChargeAsFreeReq();
        req.setToken(Model.token);
        req.setCardNO(mModel.getCardNO());
        req.setCardType(CR.GetCardType(getTextViewCardType(), 0));

        String yyyyMMddHHmmss;
        if (TextUtils.isEmpty(getOutTime()))
        {
            yyyyMMddHHmmss = TimeConvertUtils.longToString("yyyyMMddHHmmss", System.currentTimeMillis());
        }
        else
        {
            yyyyMMddHHmmss = toNetNeedFormatString(getOutTime());
        }

        req.setOutTime(yyyyMMddHHmmss);
        req.setFreeReason(getSelectReason()); //文本为中文，需要进行字符编码;

        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_UPDATECHARGEASFREE, req);
        RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(UpdateChargeAsFreeResp.class, this, req, resultUrl, -1));
    }


    @Override
    public void onClickPicCapture() // 图像抓拍
    {
        super.onClickPicCapture();
        try
        {
            MessageBox.showCanSetCallback(mActivity, "请确认是否免费放行？\n 若点击【是】，该车辆将被免费放行！", new MessageBox.IMessageBoxListener()
            {
                @Override
                public void onClickPositive(DialogInterface dialog)// 点击ok
                {
                    if (callback != null)
                    {
                        callback.tempGob_big_Photo(Model.sIDCaptureCard); //构建上传的路径
                    }

                    ImageCaptureView frm = new ImageCaptureView(mActivity);//获取图像之后，才会触发回调
                    frm.show();

                    testUploadPicture();

                    sendOpenGateAndTempOutOpen();
                    dialog.cancel();
                }

                @Override
                public void onClickNegative(DialogInterface dialog)
                {
                }
            });
        }
        catch (Exception ex)
        {
            requestAddOptLog(title + ":btnPapers_Click", ex.getMessage() + "\n" + ex.toString());
            MessageBox.show(mActivity, ex.getMessage() + "\n" + ":btnPapers_Click", "错误");
        }

    }

    private void testUploadPicture()
    {
        //上传bitmap到服务器也是可以的
        new Thread(new Runnable()
        {
            @Override
            public void run()
            {
                String file = SDCardUtils.getSDCardPath() + "TESO_GetFaceFeature1111.jpg";
                Bitmap bitmap = BitmapFactory.decodeFile(file);
                requestUpdateChargeWithCaptureImage(bitmap);
            }
        }).start();
    }

    private void requestUpdateChargeWithCaptureImage(Bitmap bitmap)
    {
        UpdateChargeWithCaptureImageReq req = new UpdateChargeWithCaptureImageReq();
        req.setToken(Model.token);
        req.setCardNO(mModel.getCardNO());
        req.setCardType(CR.GetCardType(getTextViewCardType(), 0));
        req.setOutTime(toNetNeedFormatString(getOutTime()));
        UpdateChargeWithCaptureImageResp resp = GetServiceData.getInstance().UpdateChargeWithCaptureImage(req, bitmap);
        if (resp != null)
        {
            L.i("UpdateChargeWithCaptureImageResp:" + resp.toString());
        }
    }


    /// <summary>
    /// 支付方式，0现金，1微信，2支付宝
    /// </summary>
    private int iPayType = 0;// 从界面上可以获得
    boolean breakFlag = false;

    @Override
    public void onClickCutOff()// 开闸放行
    {
        super.onClickCutOff();

        try
        {
//        if ((DateTime.Now - tmLastKeyUp).TotalMilliseconds < 100)    //扫描枪的输入速度才会这么快 ????
//        {
//            return;
//        }
            if (Model.iDetailLog == 1)
            {
                requestAddOptLog(super.title, "临时卡开闸发行！收费：" + getNeedPayMoney() + "元");
            }

            if (Model.iSetTempMoney == 1)
            {
                requestUpdateChargeAmount();
            }
            else if (Model.iSetTempCardType == 1 || Model.iDiscount == 1)
            {
                GetParkDiscountJHSetResp.DataBean dzItem = null;
                GetCardTypeDefResp.DataBean cardItem = null;
                if (Model.iDiscount == 1)
                {
                    if (discountJHSetList != null && discountJHSetList.size() > 0) // 地点
                    {
                        dzItem = discountJHSetList.get(getDiscountListIndex());
                    }
                }
                if (Model.iSetTempCardType == 1)
                {
                    if (typeDefRespData != null && typeDefRespData.size() > 0)
                    {
                        cardItem = typeDefRespData.get(getCardTypeListIndex());
                    }
                }

                requestUpdateChargeInfo(dzItem, cardItem);
            }

            sendOpenGateAndTempOutOpen();

        }
        catch (Exception ex)
        {
            requestAddOptLog(title + ":btnCutOff_Click", ex.getMessage() + "\n" + ex.toString());
            MessageBox.show(mActivity, ex.getMessage() + "\n" + ":btnCutOff_Click", "错误");
        }

    }

    private int count = 0;

    @NonNull
    private void sendOpenGateAndTempOutOpen()
    {
        CR.sendModeToQueue(QueueMessageTypeEnum.queue_openGate_callback, new OpenGateCallBack()
        {
            @Override
            public void success(String strRst)
            {
                if (Model.bOut485)//不加延时摄像机播报不了这个语音 控制板正常
                {
                    SystemClock.sleep(30);
                }

                L.i("ok..........");
                CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_TEMPOUTOPEN, null, mIndex);
                breakFlag = true;
                count = 0;
                dealOpenGateReturnVal(strRst);
            }

            @Override
            public void failed()
            {
                L.i("failed ..........");
                if (count < 4)
                {
                    sendOpenGateAndTempOutOpen();
                }
                count++;
            }
        }, mIndex, count == 0 ? 0 : 1000); // 还是设置回调接口
    }

    private void requestUpdateChargeInfo(GetParkDiscountJHSetResp.DataBean dzItem, GetCardTypeDefResp.DataBean cardItem)
    {
        UpdateChargeInfoReq req = new UpdateChargeInfoReq();
        req.setToken(Model.token);
        req.setCardNO(mModel.getCardNO());
        req.setCardType(CR.GetCardType(getTextViewCardType(), 0));

        String yyyyMMddHHmmss;
        if (mModel.getOutTime() == null)
        {
            yyyyMMddHHmmss = TimeConvertUtils.longToString("yyyyMMddHHmmss", System.currentTimeMillis());
        }
        else
        {
            yyyyMMddHHmmss = toNetNeedFormatString(mModel.getOutTime());
        }

        req.setOutTime(yyyyMMddHHmmss);
        req.setNewCardType((cardItem == null) ? mModel.getCardType() : cardItem.getCardType());
        req.setNewPayType(String.valueOf(iPayType));
        req.setYSJE(Double.parseDouble(getStopPayMoney())); // 停车收费
        req.setSFJE(Double.parseDouble(getNeedPayMoney())); // 收费金额
        req.setDiscountSetId(null == dzItem ? 0 : (int) dzItem.getID());

        String resultUrl = GetServiceData.getResultUrl(METHOD_UPDATECHARGEINFO, req);
        RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(UpdateChargeInfoResp.class, this, req, resultUrl, -1));
    }

    public String toNetNeedFormatString(String time)
    {
        if (time == null)
        {
            return null;
        }

        Date date = TimeConvertUtils.stringToDate(time);
        String yyyyMMddHHmmss = TimeConvertUtils.dateToString("yyyyMMddHHmmss", date);
        return yyyyMMddHHmmss;
    }

    private void requestUpdateChargeAmount()
    {
        UpdateChargeAmountReq amountReq = new UpdateChargeAmountReq();
        amountReq.setToken(Model.token);
        amountReq.setCardNO(mModel.getCardNO());
        amountReq.setCardType(mModel.getCardType());

        //转换时间格式
        String yyyyMMddHHmmss = TimeConvertUtils.longToString("yyyyMMddHHmmss", System.currentTimeMillis());

        amountReq.setOutTime(mModel.getOutTime() == null ? yyyyMMddHHmmss : toNetNeedFormatString(mModel.getOutTime()));
        amountReq.setNewPayType(String.valueOf(iPayType));
        amountReq.setNewYSJE(Double.parseDouble(getStopPayMoney())); // 停车收费
        amountReq.setNewSFJE(Double.parseDouble(getNeedPayMoney())); // 收费金额

        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_UPDATECHARGEAMOUNT, amountReq);
        RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(UpdateChargeAmountResp.class, this, amountReq, resultUrl, -1));
    }

    @Override
    public void onClickVoicePay()// 语音报价
    {
        ReportCharge();
    }

    @Override
    public void onClickCancelCharge()
    {
        if (mModel == null)
        {
            L.i("onClickCancelCharge mModel == null");
            return;
        }

        requestCancelCharge();
    }

    @Nullable
    private void requestCancelCharge()
    {
        CancelChargeReq cancelChargeReq = new CancelChargeReq();
        cancelChargeReq.setToken(Model.token);
        cancelChargeReq.setCardNO(mModel.getCardNO());

        String yyyyMMddHHmmss = TimeConvertUtils.dateToString("yyyyMMddHHmmss", TimeConvertUtils.stringToDate(mModel.getOutTime()));
        cancelChargeReq.setOutTime(yyyyMMddHHmmss);
        cancelChargeReq.setCardType(mModel.getCardType());
        String resultUrl = GetServiceData.getResultUrl(METHOD_CANCELCHARGE, cancelChargeReq);

        RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(CancelChargeResp.class, this, cancelChargeReq, resultUrl, -1));
    }

    private void requestGetCarTypeDef(String cardType)
    {
        GetCardTypeDefReq typeDefReq = new GetCardTypeDefReq();
        typeDefReq.setToken(Model.token);
        typeDefReq.setJsonSearchParam(JsonSearchParam.getWhenGetCarTypeDef(cardType));
        String resultUrl = GetServiceData.getResultUrl(METHOD_GETCARDTYPEDEF, typeDefReq);
        resultUrl += "&" + "Identifying";

        RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetCardTypeDefResp.class, this, typeDefReq, resultUrl, -1));
    }

    @Override
    public void onSelectCarTypeChange(int pos)
    {
        L.i("onSelectCarTypeChange ==========================");
//        CardTypeDef CardType;

        String CardType = getCmdCardType();
//        CardType = cmbCardType.SelectedItem as CardTypeDef;

        if (null == CardType || CardType.equals("无效卡") || !Model.bTemp8) // ?
        {
            if (null != callback)
            {
                callback.binData((null == CardType ? "" : CardType), Double.parseDouble(getNeedPayMoney()));
//                CardTypeSFJEHandler((null == CardType ? "" : CardType.CardType), txtSFJE.Value);
            }
            return;

        }

        CaclSFJE(true);

        if (null != callback)
        {
            callback.binData(CardType, Double.parseDouble(getNeedPayMoney()));
        }
    }

    private void CaclSFJE(boolean ReportChargeInSound)
    {
        String inTime = mModel.getInTime();
        String outTime = mModel.getOutTime();

        if (!TextUtils.isEmpty(mModel.getInTime()))
        {
            inTime = mModel.getOutTime();
        }

        if (!TextUtils.isEmpty(mModel.getOutTime()))
        {
            outTime = inTime;
        }

        long discountID = -1;
        if (discountJHSetList != null && discountJHSetList.size() > 1) // 地点
        {
            discountID = discountJHSetList.get(getDiscountListIndex()).getID();
        }

        String getCardType = CR.GetCardType(getCmdCardType(), 0);
        String cphInHaveRecord = getCPHInHaveRecord();

        requstCaclChargeAmount(inTime, outTime, discountID, getCardType, cphInHaveRecord);

        if (ReportChargeInSound)
        {
            ReportCharge();
        }
    }

    private void requstCaclChargeAmount(String inTime, String outTime, long discountID, String getCardType, String cphInHaveRecord)
    {
        CaclChargeAmountReq amountReq = new CaclChargeAmountReq();
        amountReq.setToken(Model.token);
        amountReq.setCardNO(mModel.getCardNO());
        amountReq.setStationId(Model.stationID);
        amountReq.setCardType(getCardType.equals("无效卡") ? null : getCardType);
        amountReq.setDiscountSetId(discountID == -1 ? null : discountID);
        amountReq.setInTime(toNetNeedFormatString(inTime));
        amountReq.setOutTime(toNetNeedFormatString(outTime));
        amountReq.setCPH(cphInHaveRecord == null ? null : cphInHaveRecord);

        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_CACLCHARGEAMOUNT, amountReq);
        RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(CaclChargeAmountResp.class, this, amountReq, resultUrl, -1));
    }
}
