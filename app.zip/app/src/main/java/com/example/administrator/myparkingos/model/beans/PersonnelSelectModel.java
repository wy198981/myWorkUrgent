package com.example.administrator.myparkingos.model.beans;

/**
 * Created by Administrator on 2017-07-03.
 */
public class PersonnelSelectModel
{
    private String UserNO;
    private String UserNam;
    private String Department;
    private String HomeAddres;
    private String IDCard;
    private String MobNumber;

    public String getUserNO()
    {
        return UserNO;
    }

    public void setUserNO(String userNO)
    {
        UserNO = userNO;
    }

    public String getUserNam()
    {
        return UserNam;
    }

    public void setUserNam(String userNam)
    {
        UserNam = userNam;
    }

    public String getDepartment()
    {
        return Department;
    }

    public void setDepartment(String department)
    {
        Department = department;
    }

    public String getHomeAddres()
    {
        return HomeAddres;
    }

    public void setHomeAddres(String homeAddres)
    {
        HomeAddres = homeAddres;
    }

    public String getIDCard()
    {
        return IDCard;
    }

    public void setIDCard(String IDCard)
    {
        this.IDCard = IDCard;
    }

    public String getMobNumber()
    {
        return MobNumber;
    }

    public void setMobNumber(String mobNumber)
    {
        MobNumber = mobNumber;
    }

    @Override
    public String toString()
    {
        return "PersonnelSelectModel{" +
                "UserNO='" + UserNO + '\'' +
                ", UserNam='" + UserNam + '\'' +
                ", Department='" + Department + '\'' +
                ", HomeAddres='" + HomeAddres + '\'' +
                ", IDCard='" + IDCard + '\'' +
                ", MobNumber='" + MobNumber + '\'' +
                '}';
    }
}
