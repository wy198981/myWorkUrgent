package com.example.administrator.myparkingos.ui;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.constant.ConstantSharedPrefs;
import com.example.administrator.myparkingos.constant.NetworkConfig;
import com.example.administrator.myparkingos.model.GetServiceData;
import com.example.administrator.myparkingos.model.requestInfo.GetStationSetAndOperatorsWithoutLoginReq;
import com.example.administrator.myparkingos.model.responseInfo.GetStationSetAndOperatorsWithoutLoginResp;
import com.example.administrator.myparkingos.myUserControlLibrary.MessageBox;
import com.example.administrator.myparkingos.util.SPUtils;
import com.example.administrator.myparkingos.util.ScreenUtils;
import com.example.administrator.myparkingos.volleyUtil.callback.GsonCallback;
import com.jude.http.LoadController;
import com.jude.http.RequestManager;

/**
 * Created by Administrator on 2017-02-16.
 * 【登录界面】 -->> 【服务器参数设置】
 */
public class FormServerSetView implements View.OnClickListener
{
    private final Dialog dialog;
    private final String title;
    private Activity mActivity;
    private EditText etServerIP;
    private EditText etServerPort;
    private Button btnSave;

    private String serviceIP = NetworkConfig.ServerIP;
    private String servicePort = NetworkConfig.ServerPort;
    private GetStationSetAndOperatorsWithoutLoginResp respData;

    private Handler mHandler = new Handler();
    private LoadController loadController;

    private int connectServerState = -1; // -1 init; 0 connect but failed; 1 connect success
    public FormServerSetView(Activity activity)
    {
        this.mActivity = activity;
        dialog = new Dialog(activity, R.style.serverSetting_dialog); // @android:style/Theme.Dialog

        Window window = dialog.getWindow();
        WindowManager m = activity.getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = window.getAttributes(); // 获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 1 / 4); // 改变的是dialog框在屏幕中的位置而不是大小
        p.width = (int) (d.getWidth() * 1 / 4); // 宽度设置为屏幕的0.65
        window.setAttributes(p);
        title = mActivity.getResources().getString(R.string.page_serverSetting);
        dialog.setTitle(title);

        dialog.setContentView(R.layout.activity_serverset);
        dialog.setCanceledOnTouchOutside(true);

        readConfigFromFile();

        initView();
    }

    private void initView()
    {
        etServerIP = (EditText) dialog.findViewById(R.id.etServerIP);
        etServerPort = (EditText) dialog.findViewById(R.id.etServerPort);
        btnSave = (Button) dialog.findViewById(R.id.btnAdd);

        etServerIP.setText(serviceIP);
        etServerPort.setText(servicePort);
        btnSave.setOnClickListener(this);
    }


    private void readConfigFromFile()
    {
        if (SPUtils.checkPathExist(mActivity.getApplicationContext(), ConstantSharedPrefs.FileAppSetting))
        {
            serviceIP = (String) SPUtils.get(ConstantSharedPrefs.FileAppSetting, mActivity.getApplicationContext()
                    , ConstantSharedPrefs.ServiceIP, "");
            servicePort = (String) SPUtils.get(ConstantSharedPrefs.FileAppSetting, mActivity.getApplicationContext()
                    , ConstantSharedPrefs.ServicePort, "");
        }
    }

    private boolean submit()
    {
        boolean result = true;
        // validate
        String etServerIPString = getServerIP();
        if (TextUtils.isEmpty(etServerIPString))
        {
            Toast.makeText(mActivity, "etServerIPString不能为空", Toast.LENGTH_SHORT).show();
            result = false;
        }

        String etServerPortString = getServerPort();
        if (TextUtils.isEmpty(etServerPortString))
        {
            Toast.makeText(mActivity, "etServerPortString不能为空", Toast.LENGTH_SHORT).show();
            result = false;
        }
        return result;
    }

    private String getServerIP()
    {
        return etServerIP.getText().toString().trim();
    }

    private String getServerPort()
    {
        return etServerPort.getText().toString().trim();
    }


    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.btnAdd:
                if (!submit())
                {
                    return;
                }

                GetServiceData.getInstance().setAddressAndPort(getServerIP(), getServerPort());
                requestGetStationSetAndOperatorsWithoutLogin();
                mHandler.postDelayed(new Runnable()
                {
                    @Override
                    public void run()
                    {
//                        if (getOperatorsWithoutLoginResp == null || getStationSetWithoutLoginResp == null)
                        if (connectServerState == 1)
                        {
                            SPUtils.put(ConstantSharedPrefs.FileAppSetting, mActivity.getApplicationContext()
                                    , ConstantSharedPrefs.ServiceIP, etServerIP.getEditableText().toString());
                            SPUtils.put(ConstantSharedPrefs.FileAppSetting, mActivity.getApplicationContext()
                                    , ConstantSharedPrefs.ServicePort, etServerPort.getEditableText().toString());
                            dismiss();
                            onClickSave();
                        }
                        else if (connectServerState == -1) //  no return
                        {
                            MessageBox.show(mActivity, "服务连接失败，请重新设置或者检查服务是否正常启动!");
                            if (loadController != null)
                            {
                                loadController.cancel(); //结束网络连接
                            }
                        }
                        else if (connectServerState == 0)// connect, but failed
                        {

                        }
                    }
                }, 3000);
                break;
        }
    }

    private void requestGetStationSetAndOperatorsWithoutLogin()
    {
        GetStationSetAndOperatorsWithoutLoginReq loginReq = new GetStationSetAndOperatorsWithoutLoginReq();
        String resultUrl = GetServiceData.getResultUrl("GetStationSetAndOperatorsWithoutLogin", new GetStationSetAndOperatorsWithoutLoginReq());
        loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetStationSetAndOperatorsWithoutLoginResp.class, new GsonCallback.Listener()
                {
                    @Override
                    public void success(Object reqData, Object respData, String url, int paramInt)
                    {
                        FormServerSetView.this.respData = (GetStationSetAndOperatorsWithoutLoginResp) respData;
                        if (!((GetStationSetAndOperatorsWithoutLoginResp) respData).getRcode().equals("200"))
                        {
                            MessageBox.show(mActivity, ((GetStationSetAndOperatorsWithoutLoginResp) respData).getMsg());
                            connectServerState = 0;
                        }
                        else
                        {
                            connectServerState = 1;
                        }
                    }

                    @Override
                    public void error(Object data, String url, String errorString)
                    {

                    }
                }, loginReq, resultUrl, -1));
    }


    public void onClickSave()
    {

    }

    public void show()
    {
        if (dialog != null)
        {
            dialog.show();
        }
    }

    public void dismiss()
    {
        if (dialog != null)
        {
            dialog.dismiss();
        }
    }
}
