package com.example.administrator.myparkingos.ui.onlineMonitorPage;

import android.annotation.TargetApi;
import android.app.Dialog;
import android.content.Context;
import android.os.Build;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.constant.CR;
import com.example.administrator.myparkingos.constant.ColumnName;
import com.example.administrator.myparkingos.constant.JsonSearchParam;
import com.example.administrator.myparkingos.constant.OrderField;
import com.example.administrator.myparkingos.model.beans.JiHaoSelectInfo;
import com.example.administrator.myparkingos.model.beans.Model;
import com.example.administrator.myparkingos.model.responseInfo.GetCardIssueResp2;
import com.example.administrator.myparkingos.model.responseInfo.GetCardTypeDefResp;
import com.example.administrator.myparkingos.model.responseInfo.GetParkJHSetResp;
import com.example.administrator.myparkingos.model.responseInfo.GetRightsByGroupIDResp;
import com.example.administrator.myparkingos.model.responseInfo.GetUserInfoResp;
import com.example.administrator.myparkingos.myUserControlLibrary.DateTimePicker;
import com.example.administrator.myparkingos.myUserControlLibrary.MessageBox;
import com.example.administrator.myparkingos.myUserControlLibrary.niceSpinner.NiceSpinner;
import com.example.administrator.myparkingos.myUserControlLibrary.scrollerList.MyAdapter;
import com.example.administrator.myparkingos.myUserControlLibrary.scrollerList.MyListView;
import com.example.administrator.myparkingos.myUserControlLibrary.scrollerList.MyOnItemClickListener;
import com.example.administrator.myparkingos.util.L;
import com.example.administrator.myparkingos.util.RegexUtil;
import com.example.administrator.myparkingos.util.ScreenUtils;
import com.example.administrator.myparkingos.util.T;
import com.example.administrator.myparkingos.util.TimeConvertUtils;

import org.w3c.dom.Text;

import java.sql.Time;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2017-03-10.
 */
@TargetApi(Build.VERSION_CODES.KITKAT)
public class ParkingPlateRegisterView implements View.OnClickListener
{
    protected ParkingMonitoringActivity mActivity;
    private Dialog dialog;
    private HorizontalScrollView horizontalScrollView;
    /**
     * 控件 start
     */
    private Spinner cmbHeader;
    private EditText txtCarNumber;
    private Button btnAddMutliCar;
    private NiceSpinner cmbUserNO;
    private EditText etUserNo;
    private NiceSpinner cmbCarType;
    private EditText etCarNo;
    private DateTimePicker dtpStart;
    private EditText txtUserName;
    private DateTimePicker dtpEnd;
    private EditText txtMobileNumber;
    private EditText txtCarPlace;
    private EditText txtCarCount;
    private NiceSpinner cmbCarBrand;
    private EditText txtAddress;
    private EditText txtCardYJ;
    private EditText txtMoney;
    private EditText txtRemarks;
    private CheckBox chkAutoUserNo;
    private CheckBox chkAutoCardNo;
    private CheckBox chkDCWDC;
    private ListView lvMutliCarNO;
    private Button btnSelect;
    private Button btnAddPerson;
    private ListView lvAllNo;
    private CheckBox chkAllSelect;
    private Button btnAddView;
    private Button btnSaveView;
    private Button btnCancelView;
    private Button btnPrintView;
    private Button btnExitView;
    private EditText txtSelectCPH;
    private EditText txtSelectUserNo;
    private EditText txtSelectUserName;
    private EditText txtSelectCarPlace;
    private EditText txtSelectAddress;

    /**
     * 控件 end
     */

    private int[] columns;
    private String[] from = new String[]{
            ColumnName.c1, ColumnName.c2, ColumnName.c3, ColumnName.c4, ColumnName.c5, ColumnName.c6, ColumnName.c7, ColumnName.c8
            , ColumnName.c9, ColumnName.c10, ColumnName.c11, ColumnName.c12, ColumnName.c13, ColumnName.c14, ColumnName.c15, ColumnName.c16
            , ColumnName.c17, ColumnName.c18, ColumnName.c19
    };
    private String flag;

    public static final String CONST_CAR_NO = "88000001";
    public static final String CONST_CAR_NO_PREFIX = "88"; // 前缀
    public static final String CONST_USER_NO = "A00001";
    public static final String CONST_USER_NO_PREFIX = "A";

    private ArrayList<HashMap<String, String>> items = new ArrayList<HashMap<String, String>>();

    private ArrayList<ArrayList<JiHaoSelectInfo>> JiHaoSelectList;
    private MyListView cardIssueListV;

    private MyAdapter listViewMyJiHaoAdapter;
    private MyJiHaoAdapter MyJiHaoAdapter;
    private String mTitle;


    public ParkingPlateRegisterView()
    {
    }

    public ParkingPlateRegisterView(ParkingMonitoringActivity activity)
    {
        this.mActivity = activity;
        dialog = new Dialog(mActivity); // @android:style/Theme.Dialog
        dialog.setContentView(R.layout.packplate_register);

        initDialog();
        initView();
        initAction();

        initData();
    }

    private void setViewEnableWhenStart()
    {
        chkAutoUserNo.setChecked(true);
        chkAutoCardNo.setChecked(true);

        btnAddView.setEnabled(false);
        btnSaveView.setEnabled(true);
        btnCancelView.setEnabled(false);
        btnPrintView.setEnabled(false);
        btnExitView.setEnabled(true);
    }

    public void setViewWhenAddSuccess()
    {
        btnAddView.setEnabled(true);
        btnSaveView.setEnabled(false);
        btnCancelView.setEnabled(true);
        btnPrintView.setEnabled(true);
        txtCarCount.setText("");
    }

    public void setViewWhenCanceCardIssue()
    {
        btnAddView.setEnabled(true);
        btnSaveView.setEnabled(false);
        btnCancelView.setEnabled(false);
        btnPrintView.setEnabled(true);
    }

    private void initAction()
    {
        btnAddView.setOnClickListener(this);
        btnSaveView.setOnClickListener(this);
        btnCancelView.setOnClickListener(this);
        btnPrintView.setOnClickListener(this);
        btnExitView.setOnClickListener(this);
        btnAddMutliCar.setOnClickListener(this);
        btnSelect.setOnClickListener(this);
        btnAddPerson.setOnClickListener(this);

        chkAllSelect.setOnCheckedChangeListener(myCheckBoxEvent);
        chkAutoUserNo.setOnCheckedChangeListener(myCheckBoxEvent);

        chkAutoCardNo.setOnCheckedChangeListener(myCheckBoxEvent);
        chkDCWDC.setOnCheckedChangeListener(myCheckBoxEvent);
    }

    private void initData()
    {
        initJiHaoListView(); // 显示机号
        initDCWDCListView();
        initNiceSpinnerView(); //显示品牌和省份下拉列表
        initDataGridView();// 显示dataGridView数据
    }

    private ArrayAdapter<String> DCWDCAdapter;
    private List<String> DCWDClistData;

    private void initDCWDCListView()
    {
        DCWDClistData = new ArrayList<>();
        DCWDCAdapter = new ArrayAdapter<String>(mActivity, android.R.layout.simple_list_item_1, DCWDClistData);
        lvMutliCarNO.setAdapter(DCWDCAdapter);
    }

    private void initDialog()
    {
        dialog.setCanceledOnTouchOutside(true);
        Window dialogWindow = dialog.getWindow();
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
        dialogWindow.setGravity(Gravity.CENTER);

        int screenWidth = ScreenUtils.getScreenWidth(mActivity);
        int screenHeight = ScreenUtils.getScreenHeight(mActivity);
        lp.width = screenWidth * 2 / 3; // 宽度
        lp.height = screenHeight * 2 / 3; // 高度

        dialogWindow.setAttributes(lp);

        mTitle = mActivity.getResources().getString(R.string.parkMontior_licenseVehicleRegister);

        dialog.setTitle(mTitle);
    }

    private void initView()
    {
        cmbHeader = (Spinner) dialog.findViewById(R.id.cmbHeader);
        txtCarNumber = (EditText) dialog.findViewById(R.id.txtCarNumber);
        btnAddMutliCar = (Button) dialog.findViewById(R.id.btnAddMutliCar);
        cmbUserNO = (NiceSpinner) dialog.findViewById(R.id.cmbUserNO);
        cmbCarType = (NiceSpinner) dialog.findViewById(R.id.cmbCarType);
        etCarNo = (EditText) dialog.findViewById(R.id.etCarNo);
        etUserNo = (EditText) dialog.findViewById(R.id.etUserNo);
        dtpStart = (DateTimePicker) dialog.findViewById(R.id.dtpStart);
        txtUserName = (EditText) dialog.findViewById(R.id.txtUserName);
        dtpEnd = (DateTimePicker) dialog.findViewById(R.id.dtpEnd);
        txtMobileNumber = (EditText) dialog.findViewById(R.id.txtMobileNumber);
        txtCarPlace = (EditText) dialog.findViewById(R.id.txtCarPlace);
        txtCarCount = (EditText) dialog.findViewById(R.id.txtCarCount);
        cmbCarBrand = (NiceSpinner) dialog.findViewById(R.id.cmbCarBrand);
        txtAddress = (EditText) dialog.findViewById(R.id.txtAddress);
        txtCardYJ = (EditText) dialog.findViewById(R.id.txtCardYJ);
        txtMoney = (EditText) dialog.findViewById(R.id.txtMoney);
        txtRemarks = (EditText) dialog.findViewById(R.id.txtRemarks);
        chkAutoUserNo = (CheckBox) dialog.findViewById(R.id.chkAutoUserNo);
        chkAutoCardNo = (CheckBox) dialog.findViewById(R.id.chkAutoCardNo);
        chkDCWDC = (CheckBox) dialog.findViewById(R.id.chkDCWDC);
        lvMutliCarNO = (ListView) dialog.findViewById(R.id.lvMutliCarNO);//多车位多车
        btnSelect = (Button) dialog.findViewById(R.id.btnSelect);
        btnAddPerson = (Button) dialog.findViewById(R.id.btnAddPerson);
        lvAllNo = (ListView) dialog.findViewById(R.id.lvAllNo);
        chkAllSelect = (CheckBox) dialog.findViewById(R.id.chkAllSelect);
        btnAddView = (Button) dialog.findViewById(R.id.btnAddView);
        btnSaveView = (Button) dialog.findViewById(R.id.btnSaveView);
        btnCancelView = (Button) dialog.findViewById(R.id.btnCancelView);
        btnPrintView = (Button) dialog.findViewById(R.id.btnPrintView);
        btnExitView = (Button) dialog.findViewById(R.id.btnExitView);

        txtSelectCPH = (EditText) dialog.findViewById(R.id.txtSelectCPH);
        txtSelectUserNo = (EditText) dialog.findViewById(R.id.txtSelectUserNo);
        txtSelectUserName = (EditText) dialog.findViewById(R.id.txtSelectUserName);
        txtSelectCarPlace = (EditText) dialog.findViewById(R.id.txtSelectCarPlace);
        txtSelectAddress = (EditText) dialog.findViewById(R.id.txtSelectAddress);

        if (tagBtnText == null)
        {
            tagBtnText = new ArrayList<String>();
        }

        tagBtnText.add((String) btnAddView.getTag() == null ? "" : (String) btnAddView.getTag());
        tagBtnText.add((String) btnSaveView.getTag() == null ? "" : (String) btnSaveView.getTag());
        tagBtnText.add((String) btnCancelView.getTag() == null ? "" : (String) btnCancelView.getTag());
        tagBtnText.add((String) btnPrintView.getTag() == null ? "" : (String) btnPrintView.getTag());
        tagBtnText.add((String) btnExitView.getTag() == null ? "" : (String) btnExitView.getTag());

        txtSelectCPH.addTextChangedListener(new MyTextWatcher(txtSelectCPH));
        txtSelectUserNo.addTextChangedListener(new MyTextWatcher(txtSelectUserNo));
        txtSelectUserName.addTextChangedListener(new MyTextWatcher(txtSelectUserName));
        txtSelectCarPlace.addTextChangedListener(new MyTextWatcher(txtSelectCarPlace));
        txtSelectAddress.addTextChangedListener(new MyTextWatcher(txtSelectAddress));
    }

    private List<String> tagBtnText;

    private ArrayAdapter provinceAdapter;
    private String[] provinceArray;
    private String[] brandArray;

    public void setCmbHeader(String province)
    {
        for (int i = 0; i < provinceArray.length; i++)
        {
            if (provinceArray[i].equals(province))
            {
                cmbHeader.setSelection(i);
                break;//选中指定的省份
            }
        }
    }

    private void initNiceSpinnerView()
    {
        provinceArray = mActivity.getResources().getStringArray(R.array.provinceArray);
        provinceAdapter = new ArrayAdapter(mActivity.getApplicationContext(), R.layout.blacklist_spinner_province, provinceArray);
        cmbHeader.setAdapter(provinceAdapter);
        setCmbHeader(Model.LocalProvince);

        brandArray = mActivity.getResources().getStringArray(R.array.brandArray);
        cmbCarBrand.refreshData(Arrays.asList(brandArray), 0);
        cmbCarBrand.setSpinnerListener(new NiceSpinner.SpinnerListener()
        {
            @Override
            public void OnSpinnerItemClick(int pos)
            {

            }
        });


        cmbUserNO.refreshData("", 0);
        cmbUserNO.setSpinnerListener(new NiceSpinner.SpinnerListener()
        {
            @Override
            public void OnSpinnerItemClick(int pos)
            {

            }
        });

        cmbCarType.refreshData("", 0);
        cmbCarType.setSpinnerListener(new NiceSpinner.SpinnerListener()
        {
            @Override
            public void OnSpinnerItemClick(int pos)
            {

            }
        });
    }

    private void initStartEndTime()
    {
        dtpStart.setDateTime(TimeConvertUtils.getCurrentYMD());
        dtpEnd.setDateTime(TimeConvertUtils.getNextYMD());
    }

    public void setCardType(List<GetCardTypeDefResp.DataBean> cardTypeList)
    {
        if (cardTypeList == null)
        {
            return;
        }
        List<String> inList = null;

        for (GetCardTypeDefResp.DataBean item : cardTypeList)
        {
            if (inList == null)
            {
                inList = new ArrayList<String>();
            }
            inList.add(item.getCardType());
        }

        cmbCarType.refreshData(inList, 0);
    }

    public void setUserNo(List<GetUserInfoResp.DataBean> userData)
    {
        if (userData == null)
        {
            return;
        }

        List<String> inList = null;
        for (GetUserInfoResp.DataBean item : userData)
        {
            if (inList == null)
            {
                inList = new ArrayList<String>();
            }
            inList.add(item.getUserNO());
        }

        cmbUserNO.refreshData(inList, 0);
    }

    public void setUserNo(String userNo)
    {
        cmbUserNO.addEachData(userNo, 0);
    }

    private void initDataGridView()
    {
        horizontalScrollView = (HorizontalScrollView) dialog.findViewById(R.id.plate_register_hs);
        columns = new int[]{
                R.id.column1, R.id.column2, R.id.column3,
                R.id.column4, R.id.column5, R.id.column6, R.id.column7,
                R.id.column8, R.id.column9, R.id.column10, R.id.column11,
                R.id.column12, R.id.column13, R.id.column14, R.id.column15, R.id.column16,
                R.id.column17, R.id.column18, R.id.column19
        };

        listViewMyJiHaoAdapter = new MyAdapter(mActivity, items, R.layout.plate_register_item,
                from, columns, R.color.difColor3, R.color.difColor3);
        listViewMyJiHaoAdapter.setMyOnItemClickListener(new MyOnItemClickListener()
        {
            @Override
            public void OnItemClickListener(
                    View view, int line, int row,
                    long id
            )
            {
                // TODO Auto-generated method stub
//                Toast.makeText(mActivity, "OnItemClickListener:" + row + 1 + "/" + line, Toast.LENGTH_SHORT).show();
                dgvCardIssueSelectIndex = line;//表示点击了第几行数据
                onListViewItemClick(line);
            }

            @Override
            public void OnItemLongClickListener(View view, int line, int row, long id)
            {
                onListViewLongItemClick(line);
//                Toast.makeText(mActivity, "OnItemLongClickListener:" + row + 1 + "/" + line, Toast.LENGTH_SHORT).show();
            }
        });


        cardIssueListV = new MyListView(mActivity, horizontalScrollView, columns, R.id.plate_register_hs, R.id.plate_register_list, R.id.plate_register_head, listViewMyJiHaoAdapter);

//        initGridViewDataTest();
    }

    /**
     * 表示长安点击了第几行数据
     *
     * @param line
     */
    protected void onListViewLongItemClick(int line)
    {

    }

    /**
     * 表示点击的是第几行数据
     *
     * @param line
     */
    protected void onListViewItemClick(int line)
    {
        if (mList == null || mList.size() == 0)
        {
            return;
        }
        flag = "edit";
        GetCardIssueResp2.DataBean dataBean = mList.get(line);
        txtUserName.setText(dataBean.getUserName());
        setCmbHeader(dataBean.getCPH().substring(0, 1));
        txtCarNumber.setText(dataBean.getCPH().substring(1));

        cmbUserNO.setTextContent(dataBean.getUserNO());
        cmbCarType.setTextContent(dataBean.getCardType());
        etCarNo.setText(dataBean.getCardNO());

        dtpStart.setDateTime(TimeConvertUtils.toShortDateString(dataBean.getCarValidStartDate()));
        dtpEnd.setDateTime(TimeConvertUtils.toShortDateString(dataBean.getCarValidEndDate()));

        txtMobileNumber.setText(dataBean.getMobNumber());
        txtCarPlace.setText(dataBean.getCarPlace());
        txtCarCount.setText(String.valueOf(dataBean.getCarPlaceNo()));
        cmbCarBrand.setTextContent(dataBean.getCarType());
        txtAddress.setText(dataBean.getHomeAddress());
        txtCardYJ.setText(String.valueOf(dataBean.getCardYJ()));
        txtMoney.setText(String.valueOf(dataBean.getBalance()));

        setMachineChecked(dataBean.getCarValidMachine());

        setGridViewItemWhenClick();
    }

    private void setGridViewItemWhenClick()
    {
        btnAddView.setEnabled(true);
        btnCancelView.setEnabled(isDelete);
        btnCancelView.setEnabled(true);
        btnSaveView.setEnabled(true);
        btnPrintView.setEnabled(false);

        cmbCarType.setEnabled(false);

        dtpStart.setEnabled(false);
        dtpEnd.setEnabled(false);
        cmbUserNO.setEnabled(false);
        txtMoney.setEnabled(false);
        txtCardYJ.setEnabled(false);
    }

    /**
     * 将机号选中，即可
     *
     * @param carValidMachine
     */
    private void setMachineChecked(String carValidMachine)
    {
        if (TextUtils.isEmpty(carValidMachine))
        {
            return;
        }

        resetAllMachine();
        L.e("carValidMachine:" + carValidMachine);
        for (int i = 0; i < carValidMachine.length(); i++)
        {
            if (carValidMachine.substring(i, i + 1).equals("0"))
            {
                setAllMachine(i + 1);
            }
        }
        MyJiHaoAdapter.notifyDataSetChanged();
    }

    private void resetAllMachine()
    {
        for (ArrayList<JiHaoSelectInfo> o : JiHaoSelectList)
        {
            for (JiHaoSelectInfo m : o)
            {
                m.setChecked(false);
            }
        }
    }

    public void setAllMachine(int inputMachine)
    {
        for (ArrayList<JiHaoSelectInfo> o : JiHaoSelectList)
        {
            for (JiHaoSelectInfo m : o)
            {
                if (m.getJiHaoTxt().equals(String.valueOf(inputMachine)))
                {
                    m.setChecked(true);
                    break;
                }
            }
        }
    }


    /**
     * 保存在GridView的数据
     *
     * @param inList
     */
    public List<GetCardIssueResp2.DataBean> mList;

    public void saveGridViewData(List<GetCardIssueResp2.DataBean> inList)
    {
        if (mList == null)
        {
            mList = new ArrayList<GetCardIssueResp2.DataBean>();
        }
        else
        {
            mList.clear();
        }

        if (inList == null || inList.size() == 0)
        {
            return;
        }

        for (GetCardIssueResp2.DataBean obj : inList)
        {
            mList.add(obj);
        }
    }

    public List<GetCardIssueResp2.DataBean> getGridViewData()
    {
        return mList;
    }

    public void setGridViewData(ArrayList<HashMap<String, String>> inItems)
    {
        items.clear();
        if (inItems == null || inItems.size() <= 0)
        {
        }
        else
        {
            items.addAll(inItems);
        }
        listViewMyJiHaoAdapter.notifyDataSetChanged();
    }


    /**
     * 显示机号数据，每一行显示5个数
     */
    private int row = 0;
    private int column = 5;// 列数时固定的

    public void setJiHaoData(List<GetParkJHSetResp.DataBean> inList)
    {
        if (inList == null || inList.size() == 0)
        {
            return;
        }
        JiHaoSelectList.clear();

        row = ((inList.size() % column == 0) ? (inList.size() / column) : (inList.size() / column + 1));
        L.i("row:" + row); // row = 7;
        for (int i = 0; i < row; i++) // 31个数，共有 1 - 30，加上127
        {
            ArrayList<JiHaoSelectInfo> tempList = new ArrayList<JiHaoSelectInfo>();
            for (int j = 0; j < column && (i * column + j) < inList.size(); j++)
            {
                tempList.add(new JiHaoSelectInfo(String.valueOf(inList.get(i * column + j).getCtrlNumber()), false));
            }
            JiHaoSelectList.add(tempList);
        }
        MyJiHaoAdapter.notifyDataSetChanged();
    }

    private void initJiHaoListView()
    {
        JiHaoSelectList = new ArrayList<ArrayList<JiHaoSelectInfo>>(); // 31个数，共有 1 - 30，加上127
        MyJiHaoAdapter = new MyJiHaoAdapter(mActivity, JiHaoSelectList);
        lvAllNo.setAdapter(MyJiHaoAdapter);
    }

    public void show()
    {
        if (dialog != null && dialog.isShowing() == false)
        {
            startLoadData();
            dialog.show();
        }
    }

    private String sum = "";

    private String initSumValue()
    {
        StringBuffer stringBuffer = new StringBuffer();
        for (int i = 0; i < 128; i++)
        {
            stringBuffer.append("1");
        }
        return stringBuffer.toString();
    }

    protected void startLoadData()
    {
        setViewEnableWhenStart(); // 设置刚开始时的界面状态设置

//        dealRights();
        sum = initSumValue();
        flag = "add";
        initStartEndTime();// 每一次显示的start-end时间的变化
    }

    public void dismiss()
    {
        if (dialog != null && dialog.isShowing())
        {
            dialog.dismiss();
            // 将节面的数据清空下
            cleanWhenExitView();
            hiddenDCDW();
            hiddenListView();

            // 可以将网路的请求全部清除掉
        }
    }

    private boolean MachineChecked = false;

    private void CarValidMachine()
    {
        MachineChecked = false;
        sum = "";
        for (int i = 0; i < 128; i++)
            sum += "1";

        for (ArrayList<JiHaoSelectInfo> o : JiHaoSelectList)
        {
            for (JiHaoSelectInfo m : o)
            {
                if (m.isChecked() == true)
                {
                    MachineChecked = true;
                    String Jihao = m.getJiHaoTxt();

                    sum = new StringBuffer(sum.substring(0, Integer.parseInt(Jihao) - 1)).append("0")
                            .append(sum.substring(Integer.parseInt(Jihao))).toString();
                }
            }
        }
    }


    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.btnAddView://新增
            {
                btnAdd_Click();
                break;
            }
            case R.id.btnCancelView://注销
            {
                btnCancel_Click();
                break;
            }
            case R.id.btnSaveView://保存
            {
                btnSave_Click();
                break;
            }
            case R.id.btnPrintView://打印小票 ---
            {
                btnPrint_Click();
                break;
            }
            case R.id.btnExitView://退出
                dismiss();
                break;
            case R.id.btnAddMutliCar:// 多车位多车的添加
                btnDCDW_Click();
                break;
            case R.id.btnSelect://查询
                btnSelectCondition_Click();
                break;
            case R.id.btnAddPerson://添加人事信息
                btnAddPersonInfo_Click();
                break;
            default:
                break;

        }
    }

    protected void btnAddPersonInfo_Click()
    {

    }

    protected void btnSelectCondition_Click()
    {

    }

    /**
     * 点击多车位多车的点击按钮
     */
    private void btnDCDW_Click()
    {
        String cph = getCPH();
        if (TextUtils.isEmpty(cph))
        {
            MessageBox.show(mActivity, "请输入车牌");
            return;
        }

        String strCPH = "京津冀晋蒙辽吉黑沪苏浙皖闽赣鲁豫鄂湘粤桂琼渝川贵云藏陕甘青宁新港澳台警使武领学民航";
        if (!cph.equals("") && cph.length() != 7)
        {
            if (cph.length() == 8 && (
                    cph.substring(0, 2).equals("WJ")
                            || cph.substring(2, 1 + 2).equals("F")
                            || cph.substring(2, 1 + 2).equals("D")
                            || cph.substring(cph.length() - 1).equals("F")
                            || cph.substring(cph.length() - 1).equals("D")
            ))
            {
            }
            else
            {
                MessageBox.show(mActivity, "车牌号不规范!请重新输入！\n\n【" + cph + "】会引起车牌数据显示错误");
                return;
            }
        }
        else if (cph.length() == 7 && cph.substring(0, 2).equals("WJ") && strCPH.contains(cph.substring(2, 1 + 2)))
        {
            MessageBox.show(mActivity, "武警车牌号不规范!请重新输入！\n\n【" + cph + "】会引起车牌数据显示错误");
            return;
        }

        if (!RegexUtil.IsLetterOrFigureNotIO(cph.substring(1)))
        {
            MessageBox.show(mActivity, "车牌号不规范!请重新输入！\n\n【" + cph + "】会引起车牌数据显示错误");
            return;
        }

        if (!DCWDClistData.contains(cph))
        {
            DCWDClistData.add(cph);
            DCWDCAdapter.notifyDataSetChanged();
            lvMutliCarNO.setSelection(DCWDClistData.size() - 1);
        }
    }

    protected void btnPrint_Click()
    {

    }

    /**
     * 点击保存按钮
     */
    protected boolean btnSave_Click()
    {
        try
        {
            CarValidMachine();

            if (TextUtils.isEmpty(cmbCarType.getCurrentText()))
            {
                MessageBox.show(mActivity, "请选择车辆类型!");
                return false;
            }

            if (!MachineChecked)
            {
                MessageBox.show(mActivity, "请选择停车场机号!");
                return false;
            }


            if (TextUtils.isEmpty(txtUserName.getText().toString().trim()))
            {
                MessageBox.show(mActivity, "请输入人员姓名!");
                return false;
            }


            if (TextUtils.isEmpty(txtMoney.getText().toString().trim()))
            {
                txtMoney.setText("0");
            }

            if (txtMoney.getText().toString().length() > 0 && Double.parseDouble(txtMoney.getText().toString()) >= 65535)
            {
                MessageBox.show(mActivity, "交纳金额不能大于65534");
                return false;
            }

            if (TextUtils.isEmpty(txtCardYJ.getText().toString().trim()))
            {
                txtCardYJ.setText("0");
            }

            String cph = getCPH();
            if (TextUtils.isEmpty(cph))
            {
                MessageBox.show(mActivity, "请输入车牌!");
                return false;
            }

            if (!CR.CheckUpCPH(cph, false))
            {
                MessageBox.show(mActivity, "车牌号不规范!请重新输入！\n\n【" + cph + "】会引起车牌数据显示错误");
                return false;
            }


            GetCardIssueResp2.DataBean cardIssue = getCardIssue();
            L.e("btnSave_ClickWhenChkDCWDC cardIssue:" + cardIssue.toString());
            if (chkDCWDC.isChecked())
            {
                if (DCWDClistData.size() > 0)
                {
                    btnSave_ClickWhenChkDCWDC(cardIssue, toArrays(DCWDClistData), chkAutoCardNo.isChecked(), chkAutoUserNo.isChecked(), false, false);//请求服务器
                }
                else
                {
                    btnSave_ClickWhenChkDCWDC(cardIssue, null, chkAutoCardNo.isChecked(), chkAutoUserNo.isChecked(), false, false);
                }

            }
            else
            {
                if (flag.equals("add"))
                {
                    btnSave_ClickWhenChkDCWDC(cardIssue, null, chkAutoCardNo.isChecked(), chkAutoUserNo.isChecked(), false, false);
                }
                else
                {

                    if (dgvCardIssueSelectIndex >= 0 && mList != null && mList.size() > 0)
                    {//如果
                        cardIssue.setID(mList.get(dgvCardIssueSelectIndex).getID());//对于listView的数据的显示还是使用相应的实体，更好些;
                    }
                    btnSave_ClickWhenChkDCWDC(cardIssue, null, chkAutoCardNo.isChecked(), chkAutoUserNo.isChecked(), true, false);
                }
            }
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return true;
    }

    private String[] toArrays(List<String> inList)
    {
        if (inList == null)
        {
            return null;
        }
        String[] strings = new String[inList.size()];
        int i = 0;
        for (String obj : inList)
        {
            strings[i] = obj;
            i++;
        }
        return strings;
    }

    private int dgvCardIssueSelectIndex = -1;

    /**
     * 当多车位多车选中时，触发的服务器的请求
     *
     * @param cardIssue
     * @param dcwdClistData
     * @param autoCarNo
     * @param autoUserNo
     */
    public void btnSave_ClickWhenChkDCWDC(
            GetCardIssueResp2.DataBean cardIssue
            , String[] dcwdClistData
            , boolean autoCarNo
            , boolean autoUserNo
            , boolean Overwrite // 当存在相同车辆编号或车牌号的记录是否覆盖。默认为否
            , boolean ChangeBillingType/* 如果车辆已入场是否更改场内记录的车辆类型。默认为否*/
    )
    {

    }

    public GetCardIssueResp2.DataBean getCardIssue()
    {
        GetCardIssueResp2.DataBean cardIssue = new GetCardIssueResp2.DataBean();
        cardIssue.setCardNO(CR.stringPadLeft(etCarNo.getText().toString().trim(), 8, '0'));
        cardIssue.setUserNO(cmbUserNO.getCurrentText());
        cardIssue.setCardState("0");
        cardIssue.setCardYJ(TextUtils.isEmpty(txtCardYJ.getText().toString().trim()) ? 0 : Double.parseDouble(txtCardYJ.getText().toString().trim()));
        cardIssue.setSubSystem("10000");
        cardIssue.setCarCardType(CR.GetCardType(cmbCarType.getCurrentText(), 0));
//        cardIssue.setIssueDate();//时间格式
        cardIssue.setCarIssueUserCard(Model.sUserCard);
        cardIssue.setBalance(TextUtils.isEmpty(txtMoney.getText().toString().trim()) ? 0 : Double.parseDouble(txtMoney.getText().toString().trim()));
        cardIssue.setCarValidEndDate(dtpEnd.getDateTime());
        cardIssue.setCarValidStartDate(dtpStart.getDateTime());
        cardIssue.setCPH(getCPH());
        cardIssue.setCarType(cmbCarType.getCurrentText());
        cardIssue.setCarPlace(txtCarPlace.getText().toString().trim());
        cardIssue.setCarValidMachine(sum);
        cardIssue.setCarValidZone("0000000001000000");
        cardIssue.setCarMemo(txtRemarks.getText().toString().trim());
        cardIssue.setIssueUserCard(Model.sUserCard);
        cardIssue.setCarIssueDate(TimeConvertUtils.longToString(System.currentTimeMillis()));
        cardIssue.setHolidayLimited("0000000");
        cardIssue.setTempnumber(0);
        cardIssue.setUserInfo("");
        cardIssue.setTimeTeam("");

        if (chkAutoUserNo.isChecked())//人员编号
        {
            cardIssue.setUserNO(etUserNo.getText().toString());
        }
        else
        {
            cardIssue.setUserNO(cmbUserNO.getCurrentText());
        }

        cardIssue.setUserName(txtUserName.getText().toString().trim());
        cardIssue.setHomeAddress(txtAddress.getText().toString().trim());
        cardIssue.setWorkTime(TimeConvertUtils.longToString(System.currentTimeMillis()));
        cardIssue.setBirthDate(TimeConvertUtils.longToString(System.currentTimeMillis()));
        cardIssue.setMobNumber(txtMobileNumber.getText().toString().trim());
        cardIssue.setCarPlaceNo(TextUtils.isEmpty(txtCarCount.getText().toString().trim()) ? 1 : Integer.parseInt(txtCarCount.getText().toString().trim()));
        return cardIssue;
    }

    class MyJiHaoAdapter extends BaseAdapter
    {
        private Context context;
        private ArrayList<ArrayList<JiHaoSelectInfo>> mList;

        public MyJiHaoAdapter(Context context, ArrayList<ArrayList<JiHaoSelectInfo>> inList)
        {
            mList = inList;
            this.context = context;
        }

        @Override
        public int getCount()
        {
            if (mList == null)
            {
                return 0;
            }
            return mList.size();
        }

        @Override
        public Object getItem(int position)
        {
            return position;
        }

        @Override
        public long getItemId(int position)
        {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent)
        {
            ArrayList<Button> buttonsList;
            if (convertView == null)
            {
                LayoutInflater inflater = (LayoutInflater) context
                        .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(R.layout.lvallno_item, null);

                buttonsList = new ArrayList<Button>();
                buttonsList.add((Button) convertView.findViewById(R.id.view1));
                buttonsList.add((Button) convertView.findViewById(R.id.view2));
                buttonsList.add((Button) convertView.findViewById(R.id.view3));
                buttonsList.add((Button) convertView.findViewById(R.id.view4));
                buttonsList.add((Button) convertView.findViewById(R.id.view5));

                convertView.setTag(buttonsList);
            }
            else
            {
                buttonsList = (ArrayList<Button>) convertView.getTag();
            }

            // 数据有限的情况的处理 position 表示第几行数据，
            if (position == row - 1)// 只有最后一行特殊处理
            {
                for (int i = 0; i < column; i++)
                {
                    if (i < mList.get(position).size())
                    {
                        final int currentRow = position;
                        final int currentColumn = i;

                        final JiHaoSelectInfo jiHaoSelectInfo = mList.get(position).get(i);
                        final String jiHao = jiHaoSelectInfo.getJiHaoTxt();
                        final Button button = buttonsList.get(i);
                        button.setText(jiHao);
                        button.setGravity(Gravity.CENTER);

                        if (jiHaoSelectInfo.isChecked() == true)
                        {
                            button.setBackgroundResource(R.drawable.jihao_select_yes);
                        }
                        else
                        {
                            button.setBackgroundResource(R.drawable.jihao_select_not);
                        }

                        button.setOnClickListener(new View.OnClickListener()
                        {
                            @Override
                            public void onClick(View v)
                            {
                                T.showShort(mActivity, "点击了，第" + currentRow + "行"
                                        + ", 第" + currentColumn + "列," + "机号为" + jiHao);
                                if (jiHaoSelectInfo.isChecked() == false)
                                {
                                    jiHaoSelectInfo.setChecked(true);
                                    button.setBackgroundResource(R.drawable.jihao_select_yes);
                                }
                                else
                                {
                                    jiHaoSelectInfo.setChecked(false);
                                    button.setBackgroundResource(R.drawable.jihao_select_not);
                                }
                            }
                        });
                    }
                    else
                    {
                        buttonsList.get(i).setVisibility(View.INVISIBLE);
                    }
                }
            }
            else
            {
                for (int i = 0; i < column; i++)
                {
                    final int currentRow = position;
                    final int currentColumn = i;
                    final Button o = buttonsList.get(i);
                    if (o.getVisibility() != View.VISIBLE)
                    {
                        o.setVisibility(View.VISIBLE);
                    }
                    final JiHaoSelectInfo jiHaoSelectInfo = mList.get(position).get(i);
                    final String jiHao = jiHaoSelectInfo.getJiHaoTxt();
                    o.setText(jiHao);
                    o.setGravity(Gravity.CENTER);
                    if (jiHaoSelectInfo.isChecked() == true)
                    {
                        o.setBackgroundResource(R.drawable.jihao_select_yes);
                    }
                    else
                    {
                        o.setBackgroundResource(R.drawable.jihao_select_not);
                    }

                    o.setOnClickListener(new View.OnClickListener()
                    {
                        @Override
                        public void onClick(View v)
                        {
                            T.showShort(mActivity, "点击了，第" + currentRow + "行"
                                    + ", 第" + currentColumn + "列," + "机号为" + jiHao);

                            if (jiHaoSelectInfo.isChecked() == false)
                            {
                                jiHaoSelectInfo.setChecked(true);
                                o.setBackgroundResource(R.drawable.jihao_select_yes);
                            }
                            else
                            {
                                jiHaoSelectInfo.setChecked(false);
                                o.setBackgroundResource(R.drawable.jihao_select_not);
                            }
                        }
                    });
                }
            }
            return convertView;
        }

    }

    private List<String> spinnerUserNoList = new ArrayList<String>();

    private CompoundButton.OnCheckedChangeListener myCheckBoxEvent = new CompoundButton.OnCheckedChangeListener()
    {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
        {
            switch (buttonView.getId())
            {
                case R.id.chkAutoCardNo:
                    if (buttonView.isChecked())
                    {
                        etCarNo.setEnabled(false);
                        btnAdd_OnAutoNO();
                    }
                    else
                    {
                        etCarNo.setEnabled(true);
                    }
                    break;
                case R.id.chkAutoUserNo:
                    if (buttonView.isChecked())
                    {
                        btnAdd_OnAutoNO();
                        cmbUserNO.setVisibility(View.GONE);
                        etUserNo.setVisibility(View.VISIBLE);
                    }
                    else
                    {
                        cmbUserNO.setVisibility(View.VISIBLE);
                        etUserNo.setVisibility(View.GONE);
                    }
                    break;
                case R.id.chkDCWDC:
                    if (buttonView.isChecked())
                    {
                        btnAddMutliCar.setVisibility(View.VISIBLE);
                        lvMutliCarNO.setVisibility(View.VISIBLE);
                    }
                    else
                    {
                        btnAddMutliCar.setVisibility(View.INVISIBLE);
                        lvMutliCarNO.setVisibility(View.INVISIBLE);
                    }
                    break;
                case R.id.chkAllSelect:
                    if (buttonView.isChecked())
                    {
                        for (ArrayList<JiHaoSelectInfo> o : JiHaoSelectList)
                        {
                            for (JiHaoSelectInfo m : o)
                            {
                                m.setChecked(true);
                            }
                        }
                    }
                    else
                    {
                        for (ArrayList<JiHaoSelectInfo> o : JiHaoSelectList)
                        {
                            for (JiHaoSelectInfo m : o)
                            {
                                m.setChecked(false);
                            }
                        }
                    }
                    MyJiHaoAdapter.notifyDataSetChanged();
                default:
                    break;
            }
        }
    };


    /**
     * 获取选择的机号
     *
     * @return
     */
    public List<String> getSelectJiHao()
    {
        List<String> intList = new ArrayList<>();
        for (ArrayList<JiHaoSelectInfo> o : JiHaoSelectList)
        {
            for (JiHaoSelectInfo m : o)
            {
                if (m.isChecked() == true)
                    intList.add(m.getJiHaoTxt());
            }
        }
        return intList;
    }

    public boolean getAutoCardNoIsChecked()
    {
        return chkAutoCardNo.isChecked();
    }

    public boolean getAutoUserNoIsChecked()
    {
        return chkAutoUserNo.isChecked();
    }

    public void setUserNoEnable(boolean value)
    {
        etUserNo.setEnabled(value);
    }

    public void setUserNoText(String value)
    {
        etUserNo.setVisibility(View.VISIBLE);
        etUserNo.setText(value);
        cmbUserNO.setVisibility(View.GONE);
    }

    public String getUserNo()
    {
        return etUserNo.getText().toString();
    }

    public void setCarNoEnable(boolean value)
    {
        etCarNo.setEnabled(value);
    }

    public void setCarNoText(String text)
    {
        etCarNo.setText(text);
    }

    public String getCarNo()
    {
        return etCarNo.getText().toString().trim();
    }


    boolean isAdd = false;
    boolean isDelete = false;

    private void dealRights()//设置相应按钮的权限
    {
        for (GetRightsByGroupIDResp.DataBean o : Model.lstRights)
        {
            if (o.getFormName().equals(mActivity.getResources().getString(R.string.parkMontior_licenseVehicleRegister)))
            {
                for (String item : tagBtnText)
                {
                    if (item.equals(o.getItemName()))
                    {
                        L.e("item:" + item + ",isCanOperate:" + o.isCanOperate());
                        switch (item)
                        {
                            case "btnAdd":
                                btnSaveView.setEnabled(o.isCanOperate());
                                isAdd = o.isCanOperate();
                                break;
                            case "btnDelete":
                                btnCancelView.setEnabled(o.isCanOperate());
                                isDelete = o.isCanOperate();
                                break;
                            case "btnPrint":
                                btnPrintView.setEnabled(o.isCanOperate());
                                break;
                        }
                    }
                }
            }
        }
    }

    public String getCPH()
    {
        return cmbHeader.getSelectedItem().toString() + txtCarNumber.getText().toString();
    }

    /**
     * 点击了添加按钮
     */
    protected void btnAdd_Click()
    {
        flag = "add";
        setCmbHeader(Model.LocalProvince);
        cmbCarType.setSelectIndex(0);

        dtpStart.setDateTime(TimeConvertUtils.getCurrentYMD());
        dtpEnd.setDateTime(TimeConvertUtils.getNextYMD());

        txtCarPlace.setText("");
        txtRemarks.setText("");
        txtUserName.setText("");
        txtMobileNumber.setText("");
        txtAddress.setText("");
        txtMoney.setText("0.00");
        txtCardYJ.setText("0.00");
        txtCarNumber.setText("");

        btnSaveView.setEnabled(true);
        txtCardYJ.setEnabled(true);
        txtMoney.setEnabled(true);
        txtAddress.setEnabled(true);
        txtMobileNumber.setEnabled(true);
        dtpEnd.setEnabled(true);
        dtpStart.setEnabled(true);

        txtUserName.setEnabled(true);
        cmbCarType.setEnabled(true);
        dgvCardIssueSelectIndex = -1;

        btnAdd_OnAutoNO();
    }

    protected void btnAdd_OnAutoNO()
    {

    }

    /**
     * 点击注销按钮
     */
    protected void btnCancel_Click()
    {
    }

    private void cleanWhenExitView()
    {
        txtCarNumber.setText("");
        txtUserName.setText("");
        txtMobileNumber.setText("");
        txtCarCount.setText("");
        txtAddress.setText("");
        txtCardYJ.setText("0");
        txtMoney.setText("");
        txtRemarks.setText("");
        txtCarPlace.setText("");
    }

    /**
     * 多车位多车的隐藏
     */
    private void hiddenDCDW()
    {
        btnAddMutliCar.setVisibility(View.INVISIBLE);
        lvMutliCarNO.setVisibility(View.INVISIBLE);
        if (DCWDClistData.size() != 0)
        {
            DCWDClistData.clear();
            DCWDCAdapter.notifyDataSetInvalidated();
        }

        chkDCWDC.setChecked(false);
    }

    private void hiddenListView()
    {
        chkAllSelect.setChecked(false);
        JiHaoSelectList.clear();
        MyJiHaoAdapter.notifyDataSetChanged();

        items.clear();
        listViewMyJiHaoAdapter.notifyDataSetChanged();
        if (mList != null)
            mList.clear();

        dgvCardIssueSelectIndex = -1;
    }


    public void setViewTextOnUserNo(GetCardIssueResp2.DataBean dataBean)
    {
        txtUserName.setText(dataBean.getUserName());
        //cmbCarNumber.Text = lstCI[0].CPH;

        setCmbHeader(dataBean.getCPH().substring(0, 1));
        txtCarNumber.setText(dataBean.getCPH().substring(1));

        cmbUserNO.setTextContent(dataBean.getUserNO());
        cmbCarType.setTextContent(dataBean.getCarCardType());

        etCarNo.setText(dataBean.getCardNO());

        dtpStart.setDateTime(TimeConvertUtils.toShortDateString(dataBean.getCarValidStartDate()));
        dtpEnd.setDateTime(TimeConvertUtils.toShortDateString(dataBean.getCarValidEndDate()));
        txtMobileNumber.setText(dataBean.getMobNumber());
        txtCarPlace.setText(dataBean.getCarPlace());
        txtCarCount.setText(String.valueOf(dataBean.getCarPlaceNo()));
//        cmbCarType.setText(dataBean.getCardType());
        cmbUserNO.setTextContent(dataBean.getCarType());

        txtAddress.setText(dataBean.getHomeAddress());
        txtCardYJ.setText(String.valueOf(dataBean.getCardYJ()));
        txtMoney.setText(String.valueOf(dataBean.getBalance()));

        setMachineChecked(dataBean.getCarValidMachine());
    }

    public void setUserName(String userName)
    {
        txtUserName.setText(userName);
    }

    public class MyTextWatcher implements TextWatcher
    {
        private EditText mEt;

        public MyTextWatcher(EditText et)
        {
            this.mEt = et;
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after)
        {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count)
        {

        }

        @Override
        public void afterTextChanged(Editable s)
        {
            String str = mEt.getText().toString();
            Map<String, Object> map = new LinkedHashMap<String, Object>();

            String jsonParam = "";
            switch (mEt.getId())
            {
                case R.id.txtSelectCPH:
                    map.put("CPH", "%" + str + "%");
                    jsonParam = JsonSearchParam.getWhenGetCarChePIss(map);
                    break;
                case R.id.txtSelectUserNo:
                    map.put("UserNo", "%" + str + "%");
                    jsonParam = JsonSearchParam.getWhenGetCarChePIss(map);
                    break;
                case R.id.txtSelectUserName:
                    map.put("UserName", "%" + str + "%");
                    jsonParam = JsonSearchParam.getWhenGetCarChePIss(map);
                    break;
                case R.id.txtSelectCarPlace:
                    map.put("CarPlace", "%" + str + "%");
                    jsonParam = JsonSearchParam.getWhenGetCarChePIss(map);
                    break;
                case R.id.txtSelectAddress:
                    map.put("HomeAddress", "%" + str + "%");
                    jsonParam = JsonSearchParam.getWhenGetCarChePIss(map);
                    break;
                default:
                    break;
            }

            String orderParam = OrderField.getSelectCardIssue("desc");
            updateCardIssueWhenSelectCondition(jsonParam, orderParam);
        }
    }

    protected void updateCardIssueWhenSelectCondition(String jsonParam, String orderParam)
    {

    }
}
