package com.example.administrator.myparkingos.ui.onlineMonitorPage.report;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.constant.CR;
import com.example.administrator.myparkingos.constant.RCodeEnum;
import com.example.administrator.myparkingos.model.GetServiceData;
import com.example.administrator.myparkingos.model.beans.Model;
import com.example.administrator.myparkingos.model.requestInfo.GetXXXCommonReq;
import com.example.administrator.myparkingos.model.responseInfo.GetCarInReportFormDataResp;
import com.example.administrator.myparkingos.ui.FragmentChargeRecordManager;
import com.example.administrator.myparkingos.ui.FragmentParkRecordManager;
import com.example.administrator.myparkingos.util.AppOperation;
import com.example.administrator.myparkingos.util.L;
import com.example.administrator.myparkingos.volleyUtil.callback.GsonCallback;
import com.jude.http.LoadController;
import com.jude.http.RequestManager;

/**
 * Created by Administrator on 2017-02-16.
 * 【在线监控】 -->> 【收费记录】
 * 车辆收费记录
 */
public class ReportCarChargeActivity extends AppCompatActivity implements View.OnClickListener, GsonCallback.Listener
{
    private TextView tvInParkSelect;
    private TextView tvInParkResult;
    private ImageView ivExit;
    private FragmentChargeRecordManager fragmentChargeRecordManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reportcarcharge_activity);
        Window window = getWindow();
        WindowManager m = getWindowManager();

        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = window.getAttributes(); // 获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 2 / 3); // 改变的是dialog框在屏幕中的位置而不是大小
        p.width = (int) (d.getWidth() * 1 / 2); // 宽度设置为屏幕的0.65
        window.setAttributes(p);
        initView();
        initFragment(savedInstanceState);

        requestGetCarInReportFormData();
    }

    private void requestGetCarInReportFormData()
    {
        GetXXXCommonReq getXXXCommonReq = new GetXXXCommonReq();
        getXXXCommonReq.setToken(Model.token);

        String resultUrl = GetServiceData.getResultUrl("GetCarOutReportFormData", getXXXCommonReq);

        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetCarInReportFormDataResp.class, this, getXXXCommonReq, resultUrl, -1)); //请求的数据和OutReport数据是一样的
    }

    private void initView()
    {
        tvInParkSelect = (TextView) findViewById(R.id.tvInParkSelect);
        tvInParkResult = (TextView) findViewById(R.id.tvInParkResult);

        tvInParkSelect.setOnClickListener(this);
        tvInParkResult.setOnClickListener(this);
        ivExit = (ImageView) findViewById(R.id.ivExit);
        ivExit.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                finish();
            }
        });
    }

    private void initFragment(Bundle savedInstanceState)
    {
        FragmentManager supportFragmentManager = getSupportFragmentManager();

        fragmentChargeRecordManager = new FragmentChargeRecordManager(supportFragmentManager);
        fragmentChargeRecordManager.init(savedInstanceState);

        tvInParkSelect.setBackgroundColor(Color.TRANSPARENT);
        tvInParkResult.setBackgroundResource(R.color.colorNoClick);
    }

    @Override
    public void onClick(View v)
    {
        if (v.getId() == R.id.tvInParkSelect)
        {
            fragmentChargeRecordManager.showFragment(0);
            tvInParkSelect.setBackgroundColor(Color.TRANSPARENT);
            tvInParkResult.setBackgroundResource(R.color.colorNoClick);
        }
        else if (v.getId() == R.id.tvInParkResult)
        {
            fragmentChargeRecordManager.showFragment(1);
            tvInParkSelect.setBackgroundResource(R.color.colorNoClick);
            tvInParkResult.setBackgroundColor(Color.TRANSPARENT);
        }
    }

    @Override
    public void success(Object reqData, Object respData, String url, int paramInt)
    {
        CR.printGsonResp(reqData, respData, url, paramInt);
        if (respData instanceof GetCarInReportFormDataResp)
        {
            GetCarInReportFormDataResp carInReportFormDataResp = (GetCarInReportFormDataResp) respData;
            L.e(carInReportFormDataResp.toString());
            if (Integer.parseInt(carInReportFormDataResp.getRcode()) != RCodeEnum.OK.getValue())
            {
                L.e(carInReportFormDataResp.getMsg());
            }
            else
            {
                if (carInReportFormDataResp.getData() == null)
                {
                    L.e("getCardIssueResp.getData() == null");
                }
                else
                {
                    updateGetCarInReportFormDataToView(carInReportFormDataResp.getData());
                }
            }
        }
    }

    private void updateGetCarInReportFormDataToView(GetCarInReportFormDataResp.BeanData data)
    {
        fragmentChargeRecordManager.setStartTime(data.getStartTime());
        fragmentChargeRecordManager.setEndTime(data.getEndTime());

        fragmentChargeRecordManager.setSelectGridData(data.getFields());
        fragmentChargeRecordManager.setSelectPlan(data.getSavedPlans());
    }

    @Override
    public void error(Object data, String url, String errorString)
    {
        L.e("连接服务器失败");
    }
}
