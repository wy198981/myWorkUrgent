package com.example.administrator.myparkingos.ui;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.util.L;

import java.util.List;

/**
 * Created by Administrator on 2017-03-06.
 */
public class ChargeInfoFragment extends Fragment
{
    private TextView tvPersonNo;
    private TextView tvPersonName;
    private TextView tvCarNo;
    private TextView tvDeptName;
    private TextView tvCarType;
    private TextView tvFreeMoney;
    private TextView tvInTime;
    private TextView tvOutTime;
    private TextView tvPayMoney;
    private TextView tvAmountMoney;
    private TextView tvRemainerMoney;
    private LinearLayout llChargeInfoItem;
    private TextView tvAmountMoneyLabel;
    private TextView tvAmountMoneyUnit;
    private TextView tvRemainerMoneyUnit;
    private TextView tvRemainerMoneyLabel;
    private TextView tvPayMoneyUnit;
    private TextView tvPayMoneyLabel;
    private TextView tvFreeMoneyUnit;
    private TextView tvFreeMoneyLabel;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        View root = inflater.inflate(R.layout.parkmonitor_chargeinfo_item, container, false);

        L.e("ChargeInfoFragment======================= onCreateView");
        initView(root);
        return root;

    }

    private void initView(View root)
    {
        tvPersonNo = (TextView) root.findViewById(R.id.etUserNo);
        tvPersonName = (TextView) root.findViewById(R.id.personName);
        tvCarNo = (TextView) root.findViewById(R.id.tvCarNo);
        tvDeptName = (TextView) root.findViewById(R.id.tvDeptName);
        tvCarType = (TextView) root.findViewById(R.id.tvCarType);
        tvInTime = (TextView) root.findViewById(R.id.tvInTime);
        tvOutTime = (TextView) root.findViewById(R.id.tvOutTime);

        tvFreeMoneyUnit = (TextView) root.findViewById(R.id.tvFreeMoneyUnit);
        tvFreeMoneyLabel = (TextView) root.findViewById(R.id.tvFreeMoneyLabel);
        tvFreeMoney = (TextView) root.findViewById(R.id.tvFreeMoney);

        tvPayMoney = (TextView) root.findViewById(R.id.tvPayMoney);
        tvPayMoneyUnit = (TextView) root.findViewById(R.id.tvPayMoneyUnit);
        tvPayMoneyLabel = (TextView) root.findViewById(R.id.tvPayMoneyLabel);

        tvAmountMoney = (TextView) root.findViewById(R.id.tvAmountMoney);
        tvAmountMoneyLabel = (TextView) root.findViewById(R.id.tvAmountMoneyLabel);
        tvAmountMoneyUnit = (TextView) root.findViewById(R.id.tvAmountMoneyUnit);

        tvRemainerMoney = (TextView) root.findViewById(R.id.tvRemainerMoney); // 11
        tvRemainerMoneyLabel = (TextView) root.findViewById(R.id.tvRemainerMoneyLabel);
        tvRemainerMoneyUnit = (TextView) root.findViewById(R.id.tvRemainerMoneyUnit); // 11


        llChargeInfoItem = (LinearLayout) root.findViewById(R.id.llChargeInfoItem);


        tvPersonNo.setText("");
        tvPersonName.setText("");
        tvCarNo.setText("");
        tvDeptName.setText("");
        tvCarType.setText("");
        tvFreeMoney.setText("00.00");
        tvInTime.setText("");
        tvOutTime.setText("");
        tvPayMoney.setText("00.00");
        tvAmountMoney.setText("00.00");
        tvRemainerMoney.setText("00.00");
    }

    /**
     * 设置界面的数据，数据应该是拼接出来的
     */
    public void setData(List<String> inList)
    {
        if (inList == null || inList.size() != 11) // 11个标签数据
        {
            L.i("inList == null || inList.size() != 11" + "inList.size():" + inList.size());
            return;
        }
        tvPersonNo.setText(inList.get(0));
        tvPersonName.setText(inList.get(1));
        tvCarNo.setText(inList.get(2));
        tvDeptName.setText(inList.get(3));
        tvCarType.setText(inList.get(4));
        tvFreeMoney.setText(inList.get(5));
        tvInTime.setText(inList.get(6));
        tvOutTime.setText(inList.get(7));
        tvPayMoney.setText(inList.get(8));
        tvAmountMoney.setText(inList.get(9));
        tvRemainerMoney.setText(inList.get(10));
    }

    public void setCarType(String text)
    {
        tvCarType.setText(text);
    }

    public void setPayMoney(String text)
    {
        tvPayMoney.setText(text);
    }

    public void setRemainerMoneyLabel(String text)
    {
        tvRemainerMoneyLabel.setText(text);
    }

    public void setRemainerMoneyLabelVisiable(int type)
    {
        tvRemainerMoneyLabel.setVisibility(type);
    }

    public void setRemainerMoneyUnitVisble(int type)
    {
        tvRemainerMoneyUnit.setVisibility(type);
    }

    public void setRemainerMoneyValue(String text)
    {
        if (text == null) return;
        tvRemainerMoney.setText(text);
    }

    public void setRemainerMoneyValueVisiable(int type)
    {
        tvRemainerMoney.setVisibility(type);
    }

    public void setFreeMoney(String money)
    {
        tvFreeMoney.setText(money);
    }

    public void setAmountMoney(String money)
    {
        tvAmountMoney.setText(money);
    }

    public void setAmountMoneyVisible(int type)
    {
        tvAmountMoney.setVisibility(type);
    }

    public void setAmountMoneyLableVisible(int type)
    {
        tvAmountMoneyLabel.setVisibility(type);
    }

    public void setAmountMoneyUnitVisible(int type)
    {
        tvAmountMoneyUnit.setVisibility(type);
    }

    public void setInTime(String inTime)
    {
        tvInTime.setText(inTime);
    }

    public void setOutTime(String outTime)
    {
        tvOutTime.setText(outTime);
    }

    public void setPersonNO(String personNO)
    {
        tvPersonNo.setText(personNO);
    }

    public void setCarNO(String carNo)
    {
        tvCarNo.setText(carNo);
    }

    public void setPersonName(String personName)
    {
        tvPersonName.setText(personName);
    }

    public void setDeptName(String deptName)
    {
        tvDeptName.setText(deptName);
    }


}
