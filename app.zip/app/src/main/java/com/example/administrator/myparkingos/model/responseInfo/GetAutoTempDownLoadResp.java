package com.example.administrator.myparkingos.model.responseInfo;

import java.util.List;

/**
 * Created by Administrator on 2017-06-06.
 */
public class GetAutoTempDownLoadResp // 车牌变更应答
{
    private String rcode;      // Y 参考错误码列表
    private String msg;        // Y 错误信息
    private int PageIndex; // N 当前页码。仅当查询时指定了分页参数才有此值。
    private int PageSize;  // N 分页大小。仅当查询时指定了分页参数才有此值。
    private int TotalRows; // N 总行数。仅当查询时指定了分页参数才有此值。
    //Data	参考说明中的描述	N	如果没有指定ExportFields参数则为数据Model数组，否则为下载导出文件的完整URL
    private List<DataBean> data;

    public String getRcode()
    {
        return rcode;
    }

    public void setRcode(String rcode)
    {
        this.rcode = rcode;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg(String msg)
    {
        this.msg = msg;
    }

    public int getPageIndex()
    {
        return PageIndex;
    }

    public void setPageIndex(int pageIndex)
    {
        PageIndex = pageIndex;
    }

    public int getPageSize()
    {
        return PageSize;
    }

    public void setPageSize(int pageSize)
    {
        PageSize = pageSize;
    }

    public int getTotalRows()
    {
        return TotalRows;
    }

    public void setTotalRows(int totalRows)
    {
        TotalRows = totalRows;
    }

    public List<DataBean> getData()
    {
        return data;
    }

    public void setData(List<DataBean> data)
    {
        this.data = data;
    }

    @Override
    public String toString()
    {
        return "GetAutoTempDownLoadResp{" +
                "rcode='" + rcode + '\'' +
                ", msg='" + msg + '\'' +
                ", PageIndex=" + PageIndex +
                ", PageSize=" + PageSize +
                ", TotalRows=" + TotalRows +
                ", data=" + data +
                '}';
    }

    public static class DataBean
    {
        private long ID; // Y 自增长唯一标识
        private String CPH; // Y 车牌号
        private String CarCardType; // N 车辆类型。如：TmpA、MthA
        private String InTime; // Y 入场时间。
        private String CarValidStartDate; // N 有效起日
        private String CarValidEndDate; // N 有效止日
        private String DownloadSignal; // N 下载状态。二进制字符串，每一位表示一个工作站是否成功下载。1 成功下载，0 未下载或下载失败。
        private int InOut; // Y 更新标识。0 代表修改前的车牌，需要删除；1 代表修改后的车牌，需要下载。

        public int getInOut()
        {
            return InOut;
        }

        public void setInOut(int inOut)
        {
            InOut = inOut;
        }

        public long getID()
        {
            return ID;
        }

        public void setID(long ID)
        {
            this.ID = ID;
        }

        public String getCPH()
        {
            return CPH;
        }

        public void setCPH(String CPH)
        {
            this.CPH = CPH;
        }

        public String getCarCardType()
        {
            return CarCardType;
        }

        public void setCarCardType(String carCardType)
        {
            CarCardType = carCardType;
        }

        public String getInTime()
        {
            return InTime;
        }

        public void setInTime(String inTime)
        {
            InTime = inTime;
        }

        public String getCarValidStartDate()
        {
            return CarValidStartDate;
        }

        public void setCarValidStartDate(String carValidStartDate)
        {
            CarValidStartDate = carValidStartDate;
        }

        public String getCarValidEndDate()
        {
            return CarValidEndDate;
        }

        public void setCarValidEndDate(String carValidEndDate)
        {
            CarValidEndDate = carValidEndDate;
        }

        public String getDownloadSignal()
        {
            return DownloadSignal;
        }

        public void setDownloadSignal(String downloadSignal)
        {
            DownloadSignal = downloadSignal;
        }

        @Override
        public String toString()
        {
            return "DataBean{" +
                    "ID='" + ID + '\'' +
                    ", CPH='" + CPH + '\'' +
                    ", CarCardType=" + CarCardType +
                    ", InTime='" + InTime + '\'' +
                    ", CarValidStartDate='" + CarValidStartDate + '\'' +
                    ", CarValidEndDate='" + CarValidEndDate + '\'' +
                    ", DownloadSignal='" + DownloadSignal + '\'' +
                    ", InOut=" + InOut +
                    '}';
        }
    }
}
