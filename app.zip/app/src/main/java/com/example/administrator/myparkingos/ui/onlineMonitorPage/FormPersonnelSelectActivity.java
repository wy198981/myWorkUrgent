package com.example.administrator.myparkingos.ui.onlineMonitorPage;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.Display;
import android.view.Window;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.EditText;

import com.example.administrator.mydistributedparkingos.R;

/**
 * Created by Administrator on 2017-02-16.
 * 【在线监控】 -->> 【车辆登记】 -->> 【查询】
 */
public class FormPersonnelSelectActivity extends AppCompatActivity
{
    private CheckBox ckbUserNO;
    private EditText txtUserNO;
    private CheckBox ckbUserName;
    private EditText txtUserName;
    private CheckBox ckbDepartment;
    private EditText txtDeptName;
    private CheckBox ckbHomeAddress;
    private EditText txtHomeAddress;
    private CheckBox ckbIDCard;
    private EditText txtIDCard;
    private CheckBox ckbMobNumber;
    private EditText txtMobNumber;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personnelselect);
        initView();


        Window window = getWindow();
        WindowManager m = getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = window.getAttributes(); // 获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 1 / 3); // 改变的是dialog框在屏幕中的位置而不是大小
        p.width = (int) (d.getWidth() * 1 / 3); // 宽度设置为屏幕的0.65
        window.setAttributes(p);
    }

    private void initView()
    {
        ckbUserNO = (CheckBox) findViewById(R.id.ckbUserNO);
        txtUserNO = (EditText) findViewById(R.id.txtUserNO);
        ckbUserName = (CheckBox) findViewById(R.id.ckbUserName);
        txtUserName = (EditText) findViewById(R.id.txtUserName);
        ckbDepartment = (CheckBox) findViewById(R.id.ckbDepartment);
        txtDeptName = (EditText) findViewById(R.id.txtDeptName);
        ckbHomeAddress = (CheckBox) findViewById(R.id.ckbHomeAddress);
        txtHomeAddress = (EditText) findViewById(R.id.txtHomeAddress);
        ckbIDCard = (CheckBox) findViewById(R.id.ckbIDCard);
        txtIDCard = (EditText) findViewById(R.id.txtIDCard);
        ckbMobNumber = (CheckBox) findViewById(R.id.ckbMobNumber);
        txtMobNumber = (EditText) findViewById(R.id.txtMobNumber);
    }

    
}
