package com.example.administrator.myparkingos.ui;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.util.L;

import java.util.List;

/**
 * Created by Administrator on 2017-03-06.
 */
public class ChargeSpaceFragment extends Fragment
{
    private TextView tvMonCarNum;
    private TextView tvFreeCarNum;
    private TextView tvTempCarNum;
    private TextView tvStoreCarNum;
    private TextView tvManualNum;
    private LinearLayout llChargeSpaceItem;
    private TextView tvOutCountHint;
    private TextView tvOutCount;

    public ChargeSpaceFragment()
    {

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        L.e("ChargeSpaceFragment======================= onCreateView");
        View root = inflater.inflate(R.layout.parkmonitor_chargespace_item, container, false);
        initView(root);
        return root;
    }

    private void initView(View root)
    {
        tvMonCarNum = (TextView) root.findViewById(R.id.tvMonCarNum);
        tvFreeCarNum = (TextView) root.findViewById(R.id.tvFreeCarNum);
        tvTempCarNum = (TextView) root.findViewById(R.id.tvTempCarNum);
        tvStoreCarNum = (TextView) root.findViewById(R.id.tvStoreCarNum);
        tvManualNum = (TextView) root.findViewById(R.id.tvManualNum);
        llChargeSpaceItem = (LinearLayout) root.findViewById(R.id.llChargeSpaceItem);
        tvOutCountHint = (TextView) root.findViewById(R.id.tvOutCountHint);
        tvOutCount = (TextView) root.findViewById(R.id.tvOutCount);

        if (outCountHint != null)
        {
            setOutCountHintTextAndVisble(outCountHint);
        }

        if (outCount != null)
        {
            setOutCountText(outCount);
        }

        if (mthCount != null)
        {
            setMthCount(mthCount);
        }

        if (tempCarNum != null)
        {
            setTmpCount(tempCarNum);
        }

        if (freeCount != null)
        {
            setFreeCount(freeCount);
        }

        if (manualCount != null)
        {
            setManualNum(mthCount);
        }

        if (storeCarCount != null)
        {
            setStoreCarNum(storeCarCount);
        }
    }

    private String outCountHint;
    private String outCount;
    private String mthCount;
    private String tempCarNum;
    private String freeCount;
    private String manualCount;
    private String storeCarCount;

    public void setData(List<String> inList)
    {
        if (inList == null || inList.size() != 5) // 5表示只有5段数据显示
        {
            L.i("inList == null || inList.size() != 5" + "inList.size():" + inList.size());
            return;
        }

        tvMonCarNum.setText(inList.get(0));
        tvFreeCarNum.setText(inList.get(1));
        tvTempCarNum.setText(inList.get(2));
        tvStoreCarNum.setText(inList.get(3));
        tvManualNum.setText(inList.get(4));
    }


    public void setOutCountHintTextAndVisble(String text)
    {
        if (tvOutCountHint == null)
        {
            outCountHint = text;
        }
        else
        {
            if (tvOutCountHint.getVisibility() != View.VISIBLE)
            {
                tvOutCountHint.setVisibility(View.VISIBLE);
            }
            tvOutCountHint.setText(text);
        }
    }

    public void setOutCountHintText(String text)
    {
        if (tvOutCountHint == null)
        {
            outCountHint = text;
        }
        else
        {
            tvOutCountHint.setText(text);
        }

    }


    public void setOutCountTextAndVisble(String count)
    {
        if (tvOutCount == null)
        {
            outCount = count;
        }
        else
        {
            if (tvOutCount.getVisibility() != View.VISIBLE)
            {
                tvOutCount.setVisibility(View.VISIBLE);
            }
            tvOutCount.setText(count);
        }
    }

    public void setOutCountText(String text)
    {
        if (tvOutCount == null)
        {
            outCount = text;
        }
        else
        {
            tvOutCount.setText(text);
        }
    }


    public void setMthCount(String count)
    {
        if (tvMonCarNum == null)
        {
            mthCount = count;
        }
        else
        {
            tvMonCarNum.setText(count);
        }
    }


    public void setTmpCount(String count)
    {
        if (tvTempCarNum == null)
        {
            tempCarNum = count;
        }
        else
        {
            tvTempCarNum.setText(count);
        }
    }


    public void setFreeCount(String count)
    {
        if (tvFreeCarNum == null)
        {
            freeCount = count;
        }
        else
        {
            tvFreeCarNum.setText(count);
        }
    }


    public void setStoreCarNum(String count)
    {
        if (tvStoreCarNum == null)
        {
            storeCarCount = count;
        }
        else
        {
            tvStoreCarNum.setText(count);
        }
    }


    public void setManualNum(String count)
    {
        if (tvManualNum == null)
        {
            manualCount = count;
        }
        else
        {
            tvManualNum.setText(count);
        }
    }
}
