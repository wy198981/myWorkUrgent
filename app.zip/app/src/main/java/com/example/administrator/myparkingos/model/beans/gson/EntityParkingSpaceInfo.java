package com.example.administrator.myparkingos.model.beans.gson;

/**
 * Created by Administrator on 2017-03-06.
 */
public class EntityParkingSpaceInfo
{

}
