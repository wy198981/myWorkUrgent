package com.example.administrator.myparkingos.ui.carParkSettingPager;

/**
 * Created by Administrator on 2017-02-16.
 * 【车场设置】 -->> 【收费设置】 -->> 【收费相关设置】 -->> 【收费模式】 (这里没有起作用)
 */
public class ParkingHoliday
{
}
