package com.example.administrator.myparkingos.model.requestInfo;

import java.util.Arrays;

/**
 * Created by Administrator on 2017-05-12.
 */
public class SaveUserAndCardIssueReq
{
    private String token; // Y 用户登录时候获取的token值
    private String jsonUserModel; // Y JSON格式的用户数据Model。
    private String jsonIssueModel; // Y JSON格式的卡片发行数据Model。
    //    private String[] CPList; // N 多车牌登记到同一个人名下时通过此参数传车牌号。当此参数不为空时jsonIssueModel中的车牌不处理。
    private String CPList;
    private boolean AutoUserNo; // N 是否自动生成人员编号。默认否
    private boolean AutoCardNo; // N 是否自动生成车辆编号。默认否
    private boolean Overwrite; // N 当存在相同车辆编号或车牌号的记录是否覆盖。默认为否。
    private boolean ChangeBillingType; // N 如果车辆已入场是否更改场内记录的车辆类型。默认为否。
    private String CallBack; // N 是否使用JSONP方式。关于JSONP方式请参考Javascript跨域访问一节。

    public static SaveUserAndCardIssueReq copySelf(SaveUserAndCardIssueReq inReq)
    {
        SaveUserAndCardIssueReq saveUserAndCardIssueReq = new SaveUserAndCardIssueReq();
        saveUserAndCardIssueReq.setToken(inReq.getToken());
        saveUserAndCardIssueReq.setJsonIssueModel(inReq.getJsonIssueModel());
        saveUserAndCardIssueReq.setJsonUserModel(inReq.getJsonUserModel());
        saveUserAndCardIssueReq.setCPList(inReq.getCPList());
        saveUserAndCardIssueReq.setAutoCardNo(inReq.getAutoCardNo());
        saveUserAndCardIssueReq.setOverwrite(inReq.getOverwrite());
        saveUserAndCardIssueReq.setAutoUserNo(inReq.getAutoUserNo());
        saveUserAndCardIssueReq.setChangeBillingType(inReq.getChangeBillingType());
        return saveUserAndCardIssueReq;
    }

    @Override
    public String toString()
    {
        return "SaveUserAndCardIssueReq{" +
                "token='" + token + '\'' +
                ", jsonUserModel='" + jsonUserModel + '\'' +
                ", jsonIssueModel='" + jsonIssueModel + '\'' +
                ", CPList=" + CPList +
                ", AutoUserNo=" + AutoUserNo +
                ", AutoCardNo=" + AutoCardNo +
                ", Overwrite=" + Overwrite +
                ", ChangeBillingType=" + ChangeBillingType +
                ", CallBack='" + CallBack + '\'' +
                '}';
    }

    public String getToken()
    {
        return token;
    }

    public void setToken(String token)
    {
        this.token = token;
    }

    public String getJsonUserModel()
    {
        return jsonUserModel;
    }

    public void setJsonUserModel(String jsonUserModel)
    {
        this.jsonUserModel = jsonUserModel;
    }

    public String getJsonIssueModel()
    {
        return jsonIssueModel;
    }

    public void setJsonIssueModel(String jsonIssueModel)
    {
        this.jsonIssueModel = jsonIssueModel;
    }

    public String getCPList()
    {
        return CPList;
    }

    public void setCPList(String CPList)
    {
        this.CPList = CPList;
    }

    public boolean getAutoUserNo()
    {
        return AutoUserNo;
    }

    public void setAutoUserNo(boolean autoUserNo)
    {
        AutoUserNo = autoUserNo;
    }

    public boolean getAutoCardNo()
    {
        return AutoCardNo;
    }

    public void setAutoCardNo(boolean autoCardNo)
    {
        AutoCardNo = autoCardNo;
    }

    public boolean getOverwrite()
    {
        return Overwrite;
    }

    public void setOverwrite(boolean overwrite)
    {
        Overwrite = overwrite;
    }

    public boolean getChangeBillingType()
    {
        return ChangeBillingType;
    }

    public void setChangeBillingType(boolean changeBillingType)
    {
        ChangeBillingType = changeBillingType;
    }

    public String getCallBack()
    {
        return CallBack;
    }

    public void setCallBack(String callBack)
    {
        CallBack = callBack;
    }
}
