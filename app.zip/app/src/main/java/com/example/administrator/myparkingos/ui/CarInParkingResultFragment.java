package com.example.administrator.myparkingos.ui;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.widget.TextViewCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.constant.CR;
import com.example.administrator.myparkingos.constant.ColumnName;
import com.example.administrator.myparkingos.model.responseInfo.GetCarInReportResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCarInResp;
import com.example.administrator.myparkingos.myUserControlLibrary.scrollerList.MyAdapter;
import com.example.administrator.myparkingos.myUserControlLibrary.scrollerList.MyListView;
import com.example.administrator.myparkingos.myUserControlLibrary.scrollerList.MyOnItemClickListener;
import com.example.administrator.myparkingos.ui.onlineMonitorPage.report.ExportExcelView;
import com.example.administrator.myparkingos.util.L;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Administrator on 2017-07-06.
 */
public class CarInParkingResultFragment extends Fragment implements View.OnClickListener
{
    private FragmentActivity mActivity;
    private ImageView picIn;
    private TextView lblMtpCount;
    private TextView lblTmpCount;
    private TextView lblStrCount;
    private TextView lblFreCount;
    private TextView lblCarCount;
    private Button btnPrint;
    private Button btnExport;
    private ExportExcelView exportExcelView;
    private ListView carInList;
    private HorizontalScrollView carInParkHS;
    private ArrayList<HashMap<String, String>> items;
    private int[] columns;

    private String[] from = new String[]{
            ColumnName.c1, ColumnName.c2, ColumnName.c3, ColumnName.c4, ColumnName.c5, ColumnName.c6, ColumnName.c7, ColumnName.c8
            , ColumnName.c9, ColumnName.c10, ColumnName.c11, ColumnName.c12, ColumnName.c13, ColumnName.c14, ColumnName.c15, ColumnName.c16
            , ColumnName.c17, ColumnName.c18
    };
    private MyAdapter adapter;
    private MyListView myLisView;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        mActivity = getActivity();
        View root = inflater.inflate(R.layout.carinpark_result_fg, container, false);

        initView(root);
        return root;
    }

    private void initView(View root)
    {
        picIn = (ImageView) root.findViewById(R.id.picIn);
        lblMtpCount = (TextView) root.findViewById(R.id.lblMtpCount);
        lblTmpCount = (TextView) root.findViewById(R.id.lblTmpCount);
        lblStrCount = (TextView) root.findViewById(R.id.lblStrCount);
        lblFreCount = (TextView) root.findViewById(R.id.lblFreCount);
        lblCarCount = (TextView) root.findViewById(R.id.lblCarCount);
        btnPrint = (Button) root.findViewById(R.id.btnPrint);
        btnExport = (Button) root.findViewById(R.id.btnExport);

        btnPrint.setOnClickListener(this);
        btnExport.setOnClickListener(this);

        initListView(root);
    }

    private void initListView(View root)
    {
        carInParkHS = (HorizontalScrollView) root.findViewById(R.id.carInParkHS);

        items = new ArrayList<HashMap<String, String>>();
        columns = new int[]{
                R.id.column1, R.id.column2, R.id.column3,
                R.id.column4, R.id.column5, R.id.column6, R.id.column7,
                R.id.column8, R.id.column9, R.id.column10, R.id.column11,
                R.id.column12, R.id.column13, R.id.column14, R.id.column15, R.id.column16, R.id.column17, R.id.column18

        };
        adapter = new MyAdapter(mActivity, items, R.layout.carinpark_result,
                from, columns, R.color.difColor3, R.color.difColor3);
        adapter.setMyOnItemClickListener(new MyOnItemClickListener()
        {
            @Override
            public void OnItemClickListener(
                    View view, int line, int row,
                    long id
            )
            {
//                Toast.makeText(MainActivity.this, row + 1 + "/" + line, Toast.LENGTH_SHORT).show();
                Log.i("touch", row + "/" + (line + 1));

            }

            @Override
            public void OnItemLongClickListener(View view, int line, int row, long id)
            {

            }
        });
        myLisView = new MyListView(mActivity, carInParkHS, columns, R.id.carInParkHS, R.id.carInList, R.id.carInHead, adapter);
    }

    GetCarInReportResp.DataBean mReportResp;

    public void setShowContent(GetCarInReportResp.DataBean inReportResp)
    {
        mReportResp = inReportResp;

        lblMtpCount.setText(String.valueOf(inReportResp.getMthCount()));
        lblTmpCount.setText(String.valueOf(inReportResp.getTmpCount()));
        lblStrCount.setText(String.valueOf(inReportResp.getStrCount()));
        lblFreCount.setText(String.valueOf(inReportResp.getFreCount()));
        lblCarCount.setText(String.valueOf(inReportResp.getTotalCount()));

        L.e(inReportResp.toString());
        List<GetCarInResp.DataBean> inRecords = mReportResp.getInRecords();
        if (inRecords == null)
        {
            return;
        }

        setRecordData(inRecords);
    }

    private void setRecordData(List<GetCarInResp.DataBean> inRecords)
    {
        if (inRecords.size() == 0)
        {
            return;
        }
        ArrayList<HashMap<String, String>> inItems = new ArrayList<HashMap<String, String>>();

        for (GetCarInResp.DataBean data : inRecords)
        {
            HashMap<String, String> item = new HashMap<String, String>();
            item.put(ColumnName.c1, CR.prepareDetectString(data.getCardNO(), ""));
            item.put(ColumnName.c2, CR.prepareDetectString(data.getCPH(), ""));
            item.put(ColumnName.c3, CR.prepareDetectString(data.getChineseName(), ""));
            item.put(ColumnName.c4, CR.prepareDetectString(data.getInTime(), ""));
            item.put(ColumnName.c5, String.valueOf(data.getSFJE()));
            item.put(ColumnName.c6, CR.prepareDetectString(data.getInGateName(), ""));
            item.put(ColumnName.c7, String.valueOf(data.getOnlineState_In()));
            item.put(ColumnName.c8, CR.prepareDetectString(data.getUserNO(), ""));
            item.put(ColumnName.c9, String.valueOf(data.getUserName()));
            item.put(ColumnName.c10, String.valueOf(data.getBalance()));
            item.put(ColumnName.c11, String.valueOf(data.getCarparkNO()));
            item.put(ColumnName.c12, String.valueOf(data.getBigSmall()));
            item.put(ColumnName.c13, CR.prepareDetectString(data.getInUser(), ""));
            item.put(ColumnName.c14, CR.prepareDetectString(data.getOutUser(), "")); // ZJPic
            item.put(ColumnName.c15, CR.prepareDetectString(data.getInPic(), ""));
            item.put(ColumnName.c16, CR.prepareDetectString(data.getDeptName(), ""));
            item.put(ColumnName.c17, CR.prepareDetectString(data.getInOperatorCard(), ""));
            item.put(ColumnName.c18, CR.prepareDetectString(data.getInOperator(), ""));
            inItems.add(item);
        }
        setData(inItems);
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.btnPrint:
                // 打印的对话框-----
                break;
            case R.id.btnExport:
                if (exportExcelView == null)// 显示的数据有点区别而已(可以后续来作优化)
                {
                    exportExcelView = new ExportExcelView(mActivity);
                }
                exportExcelView.show();
                break;
        }
    }

    /**
     * 重新更新数据
     *
     * @param inItems
     */
    public void setData(ArrayList<HashMap<String, String>> inItems)
    {
        if (inItems == null || inItems.size() <= 0)
        {
            return;
        }
        items.clear();
        items.addAll(inItems);
        if (adapter == null) // adapter还没有显示出来
        {
            L.i("setJiHaoData(ArrayList<HashMap<String, String>> inItems)");
        }
        else
        {
            adapter.notifyDataSetChanged();
        }
    }

    public void cleanData()
    {
        items.clear();
        if (adapter == null) // adapter还没有显示出来
        {
            L.i("setJiHaoData(ArrayList<HashMap<String, String>> inItems)");
        }
        else
        {
            adapter.notifyDataSetChanged();
        }
    }
}
