package com.example.administrator.myparkingos.model.responseInfo;


/**
 * Created by Administrator on 2017-05-12.
 */
public class SaveUserAndCardIssueObjResp
{
    private String rcode; // Y 参考错误码列表
    private String msg; // Y 错误信息

    public String getRcode()
    {
        return rcode;
    }

    public void setRcode(String rcode)
    {
        this.rcode = rcode;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg(String msg)
    {
        this.msg = msg;
    }

    @Override
    public String toString()
    {
        return "SaveUserAndCardIssueObjResp{" +
                "rcode='" + rcode + '\'' +
                ", msg='" + msg + '\'' +
                '}';
    }
}
