package com.example.administrator.myparkingos.model.requestInfo;

/**
 * Created by Administrator on 2017-07-05.
 */
public class GetDeleteListReq
{
    private String token;//Y	用户登录时候获取的token值
    private String IDList;//Y	JSON格式的ID值数组
    private String CallBack;//N	是否使用JSONP方式。关于JSONP方式请参考Javascript跨域访问一节。

    @Override
    public String toString()
    {
        return "GetDeleteListReq{" +
                "token='" + token + '\'' +
                ", IDList='" + IDList + '\'' +
                ", CallBack='" + CallBack + '\'' +
                '}';
    }

    public String getToken()
    {
        return token;
    }

    public void setToken(String token)
    {
        this.token = token;
    }

    public String getIDList()
    {
        return IDList;
    }

    public void setIDList(String IDList)
    {
        this.IDList = IDList;
    }

    public String getCallBack()
    {
        return CallBack;
    }

    public void setCallBack(String callBack)
    {
        CallBack = callBack;
    }
}
