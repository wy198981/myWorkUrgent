package com.example.administrator.myparkingos.ui.onlineMonitorPage;

import android.app.Activity;
import android.app.Dialog;
import android.text.TextUtils;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.constant.JsonSearchParam;
import com.example.administrator.myparkingos.util.L;

/**
 * Created by Administrator on 2017-02-16.
 * 【在线监控】 -->> 【车辆登记】 -->> 【查询】
 */
public class FormPersonnelSelectView implements CompoundButton.OnCheckedChangeListener
{
    private final Activity mActivity;
    private final Dialog dialog;
    private CheckBox ckbUserNO;
    private EditText txtUserNO;
    private CheckBox ckbUserName;
    private EditText txtUserName;
    private CheckBox ckbDepartment;
    private EditText txtDeptName;
    private CheckBox ckbHomeAddress;
    private EditText txtHomeAddress;
    private CheckBox ckbIDCard;
    private EditText txtIDCard;
    private CheckBox ckbMobNumber;
    private EditText txtMobNumber;
    private Button btnSave;


    public FormPersonnelSelectView(Activity activity)
    {
        mActivity = activity;
        dialog = new Dialog(activity); // @android:style/Theme.Dialog
        dialog.setContentView(R.layout.activity_personnelselect);
        dialog.setCanceledOnTouchOutside(true);

        Window window = dialog.getWindow();
        WindowManager m = activity.getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = window.getAttributes(); // 获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 1 / 3); // 改变的是dialog框在屏幕中的位置而不是大小
        p.width = (int) (d.getWidth() * 1 / 3); // 宽度设置为屏幕的0.65
        window.setAttributes(p);
        dialog.getWindow().setBackgroundDrawableResource(R.drawable.parkdowncard_background);
        dialog.setTitle(activity.getResources().getString(R.string.parkNoRegister_select));

        initView();
    }



    private void initView()
    {
        ckbUserNO = (CheckBox) dialog.findViewById(R.id.ckbUserNO);
        txtUserNO = (EditText) dialog.findViewById(R.id.txtUserNO);
        ckbUserName = (CheckBox) dialog.findViewById(R.id.ckbUserName);
        txtUserName = (EditText) dialog.findViewById(R.id.txtUserName);
        ckbDepartment = (CheckBox) dialog.findViewById(R.id.ckbDepartment);
        txtDeptName = (EditText) dialog.findViewById(R.id.txtDeptName);
        ckbHomeAddress = (CheckBox) dialog.findViewById(R.id.ckbHomeAddress);
        txtHomeAddress = (EditText) dialog.findViewById(R.id.txtHomeAddress);
        ckbIDCard = (CheckBox) dialog.findViewById(R.id.ckbIDCard);
        txtIDCard = (EditText) dialog.findViewById(R.id.txtIDCard);
        ckbMobNumber = (CheckBox) dialog.findViewById(R.id.ckbMobNumber);
        txtMobNumber = (EditText) dialog.findViewById(R.id.txtMobNumber);
        btnSave = (Button) dialog.findViewById(R.id.btnSave);


        ckbUserNO.setOnCheckedChangeListener(this);
        ckbUserName.setOnCheckedChangeListener(this);
        ckbDepartment.setOnCheckedChangeListener(this);
        ckbHomeAddress.setOnCheckedChangeListener(this);
        ckbIDCard.setOnCheckedChangeListener(this);
        ckbMobNumber.setOnCheckedChangeListener(this);

        btnSave.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                onBtnClickSave();
                dismiss();
            }
        });
    }

    private void onBtnClickSave()
    {
        String UserNO = getEditText(txtUserNO);
        String UserName = getEditText(txtUserName);
        String Department = getEditText(txtDeptName);
        String HomeAddress = getEditText(txtHomeAddress);
        String IDCard = getEditText(txtIDCard);
        String MobNumber = getEditText(txtMobNumber);

        L.e("userNo:" + UserNO);
        requestGetCPHDJfxPersonnel(JsonSearchParam.getCPHDJfxPersonnelData(UserNO, UserName, Department, HomeAddress, IDCard, MobNumber));
    }

    protected void requestGetCPHDJfxPersonnel(String cphdJfxPersonnelData)
    {

    }

    private String getEditText(EditText et)
    {
        return et.getText().toString().trim();
    }

    private void initCheckBox()
    {
        ckbUserNO.setChecked(false);
        ckbUserName.setChecked(false);
        ckbDepartment.setChecked(false);
        ckbHomeAddress.setChecked(false);
        ckbIDCard.setChecked(false);
        ckbMobNumber.setChecked(false);

        txtUserNO.setEnabled(false);
        txtUserName.setEnabled(false);
        txtDeptName.setEnabled(false);
        txtHomeAddress.setEnabled(false);
        txtIDCard.setEnabled(false);
        txtMobNumber.setEnabled(false);
    }

    /**
     * 显示数据
     */
    public void show()
    {
        if (dialog != null && dialog.isShowing() == false)
        {
            initCheckBox();
            dialog.show();
        }
    }


    /**
     * 隐藏
     */
    public void dismiss()
    {
        if (dialog != null && dialog.isShowing())
        {
            dialog.dismiss();
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
    {
        switch (buttonView.getId())
        {
            case R.id.ckbUserNO:
                if (ckbUserNO.isChecked())
                {
                    txtUserNO.setEnabled(true);
                }
                else
                {
                    txtUserNO.setEnabled(false);
                    txtUserNO.setText("");
                }
                break;
            case R.id.ckbUserName:
                if (ckbUserName.isChecked())
                {
                    txtUserName.setEnabled(true);
                }
                else
                {
                    txtUserName.setEnabled(false);
                    txtUserName.setText("");
                }
                break;
            case R.id.ckbDepartment:
                if (ckbDepartment.isChecked())
                {
                    txtDeptName.setEnabled(true);
                }
                else
                {
                    txtDeptName.setEnabled(false);
                    txtDeptName.setText("");
                }
                break;
            case R.id.ckbHomeAddress:
                if (ckbHomeAddress.isChecked())
                {
                    txtHomeAddress.setEnabled(true);
                }
                else
                {
                    txtHomeAddress.setEnabled(false);
                    txtHomeAddress.setText("");
                }
                break;
            case R.id.ckbIDCard:
                if (ckbIDCard.isChecked())
                {
                    txtIDCard.setEnabled(true);
                }
                else
                {
                    txtIDCard.setEnabled(false);
                    txtIDCard.setText("");
                }
                break;
            case R.id.ckbMobNumber:
                if (ckbMobNumber.isChecked())
                {
                    txtMobNumber.setEnabled(true);
                }
                else
                {
                    txtMobNumber.setEnabled(false);
                    txtMobNumber.setText("");
                }
                break;
            default:
                break;
        }
    }
}
