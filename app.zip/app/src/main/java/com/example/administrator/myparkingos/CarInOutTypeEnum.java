package com.example.administrator.myparkingos;

/**
 * Created by Administrator on 2017-04-24.
 */
public class CarInOutTypeEnum
{
}
