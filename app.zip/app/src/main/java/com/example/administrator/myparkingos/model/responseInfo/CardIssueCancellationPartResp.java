package com.example.administrator.myparkingos.model.responseInfo;

/**
 * Created by Administrator on 2017-05-12.
 */
public class CardIssueCancellationPartResp
{
    private String rcode; // 参考错误码列表
    private String msg; // 错误信息

    @Override
    public String toString()
    {
        return "CardIssueCancellationPartResp{" +
                "rcode='" + rcode + '\'' +
                ", msg='" + msg + '\'' +
                '}';
    }

    public String getRcode()
    {
        return rcode;
    }

    public void setRcode(String rcode)
    {
        this.rcode = rcode;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg(String msg)
    {
        this.msg = msg;
    }

}
