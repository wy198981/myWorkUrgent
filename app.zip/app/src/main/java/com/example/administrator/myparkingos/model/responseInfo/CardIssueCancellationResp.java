package com.example.administrator.myparkingos.model.responseInfo;

/**
 * Created by Administrator on 2017-05-12.
 */
public class CardIssueCancellationResp
{
    private String rcode; // 参考错误码列表
    private String msg; // 错误信息
    private int data; // 受影响的行数

    @Override
    public String toString()
    {
        return "CardIssueCancellationResp{" +
                "rcode='" + rcode + '\'' +
                ", msg='" + msg + '\'' +
                ", data=" + data +
                '}';
    }

    public String getRcode()
    {
        return rcode;
    }

    public void setRcode(String rcode)
    {
        this.rcode = rcode;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg(String msg)
    {
        this.msg = msg;
    }

    public int getData()
    {
        return data;
    }

    public void setData(int data)
    {
        this.data = data;
    }
}
