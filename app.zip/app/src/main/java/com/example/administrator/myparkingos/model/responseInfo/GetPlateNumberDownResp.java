package com.example.administrator.myparkingos.model.responseInfo;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Objects;

/**
 * Created by Administrator on 2017-06-05.
 */
public class GetPlateNumberDownResp
{
    private String rcode; // Y 参考错误码列表
    private String msg; // Y 错误信息
    private List<Bean> data; // N 对象数组

    public static class Bean<T> // T 根据传入参数返回不同的值，当DownType为0,1时，object为发行Model；当DownType为2,3时,object为黑名单Model;当DownType为4时,object为车牌变更Model;其他默认为0
    {
        private List<GetCheDaoSetResp.DataBean> lstCDS;
        private T model;

        public List<GetCheDaoSetResp.DataBean> getLstCDS()
        {
            return lstCDS;
        }

        public void setLstCDS(List<GetCheDaoSetResp.DataBean> lstCDS)
        {
            this.lstCDS = lstCDS;
        }

        public T getModel()
        {
            return model;
        }

        public void setModel(T model)
        {
            this.model = model;
        }


        @Override
        public String toString()
        {
            return "Bean{" +
                    "lstCDS=" + lstCDS +
                    ", model=" + model +
                    '}';
        }
    }

    public String getRcode()
    {
        return rcode;
    }

    public void setRcode(String rcode)
    {
        this.rcode = rcode;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg(String msg)
    {
        this.msg = msg;
    }

    public List<Bean> getData()
    {
        return data;
    }

    public void setData(List<Bean> data)
    {
        this.data = data;
    }

    @Override
    public String toString()
    {
        return "GetPlateNumberDownResp{" +
                "rcode='" + rcode + '\'' +
                ", msg='" + msg + '\'' +
                ", data=" + data +
                '}';
    }
}
