package com.example.administrator.myparkingos;

import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.common.data.cipher.Base64Cipher;
import com.example.administrator.myparkingos.constant.CR;
import com.example.administrator.myparkingos.constant.ConstantSharedPrefs;
import com.example.administrator.myparkingos.constant.JsonSearchParam;
import com.example.administrator.myparkingos.constant.NetworkConfig;
import com.example.administrator.myparkingos.model.GetServiceData;
import com.example.administrator.myparkingos.model.beans.Model;
import com.example.administrator.myparkingos.model.beans.ThreadMessage;
import com.example.administrator.myparkingos.model.requestInfo.GetOperatorsReq;
import com.example.administrator.myparkingos.model.requestInfo.GetOperatorsWithoutLoginReq;
import com.example.administrator.myparkingos.model.requestInfo.GetRightsByGroupIDReq;
import com.example.administrator.myparkingos.model.requestInfo.GetServerTimeReq;
import com.example.administrator.myparkingos.model.requestInfo.GetStationSetAndOperatorsWithoutLoginReq;
import com.example.administrator.myparkingos.model.requestInfo.GetStationSetWithoutLoginReq;
import com.example.administrator.myparkingos.model.requestInfo.GetSysSettingObjectReq;
import com.example.administrator.myparkingos.model.requestInfo.LoginUserReq;
import com.example.administrator.myparkingos.model.responseInfo.GetOperatorsResp;
import com.example.administrator.myparkingos.model.responseInfo.GetOperatorsWithoutLoginResp;
import com.example.administrator.myparkingos.model.responseInfo.GetRightsByGroupIDResp;
import com.example.administrator.myparkingos.model.responseInfo.GetServerTimeResp;
import com.example.administrator.myparkingos.model.responseInfo.GetStationSetAndOperatorsWithoutLoginResp;
import com.example.administrator.myparkingos.model.responseInfo.GetStationSetWithoutLoginResp;
import com.example.administrator.myparkingos.model.responseInfo.GetSysSettingObjectResp;
import com.example.administrator.myparkingos.model.responseInfo.LoginUserResp;
import com.example.administrator.myparkingos.myUserControlLibrary.niceSpinner.NiceSpinner;
import com.example.administrator.myparkingos.ui.FormServerSetView;
import com.example.administrator.myparkingos.ui.loginHintProcess.ParkingDownCardActvity;
import com.example.administrator.myparkingos.ui.loginHintProcess.ParkingDownCardView;
import com.example.administrator.myparkingos.ui.loginHintProcess.ParkingReadRecordView;
import com.example.administrator.myparkingos.ui.onlineMonitorPage.ParkingMonitoringActivity;
import com.example.administrator.myparkingos.util.AppOperation;
import com.example.administrator.myparkingos.util.DensityUtil;
import com.example.administrator.myparkingos.util.L;
import com.example.administrator.myparkingos.util.MD5Utils;
import com.example.administrator.myparkingos.util.RegexUtil;
import com.example.administrator.myparkingos.util.SPUtils;
import com.example.administrator.myparkingos.util.T;
import com.example.administrator.myparkingos.util.TimeConvertUtils;
import com.example.administrator.myparkingos.util.WeakHandler;
import com.example.administrator.myparkingos.volleyUtil.callback.GsonCallback;
import com.example.sfmudpsdk_android.ConstantClass;
import com.example.sfmudpsdk_android.GetTimeModel;
import com.example.sfmudpsdk_android.UDPSendbll;
import com.jude.http.LoadController;
import com.jude.http.RequestListener;
import com.jude.http.RequestManager;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener, GsonCallback.Listener
{
    private final String TAG = "LoginActivity";

    private EditText et_password;
    private Button btnLogin;
    private Button btnParkSet;
    private Button btnServerParamSet;
    private int indexUserName = 0; // 初始化为0,
    private int indexStationId = 0;

    private String curStationID = "";

    /**
     * 从服务器请求数据的数据的返回列表
     */
    private String md5Password;

    private NiceSpinner spinnerUsername;
    private NiceSpinner spinnerstation;

    private GetOperatorsWithoutLoginResp getOperatorsWithoutLoginResp;
    private GetStationSetWithoutLoginResp getStationSetWithoutLoginResp;

    private LoginUserResp loginUserResp;
    private GetServerTimeResp serverTime;
    private GetOperatorsResp getOperatorsResp;
    private GetRightsByGroupIDResp getRightsByGroupIDResp;


    private GetStationSetAndOperatorsWithoutLoginResp getStationSetAndOperatorsWithoutLoginResp;
    private List<GetOperatorsResp.DataBean> getOperators;
    private List<GetStationSetWithoutLoginResp.DataBean> getStation;


    public static final String METHOD_GETSTATIONSETANDOPERATORSWITHOUTLOGIN = "GetStationSetAndOperatorsWithoutLogin";
    public static final String METHOD_GETOPERATORSWITHOUTLOGIN = "GetOperatorsWithoutLogin";
    public static final String METHOD_GETSTATIONSETWITHOUTLOGIN = "GetStationSetWithoutLogin";
    public static final String METHOD_LOGINUSER = "LoginUser";
    public static final String METHOD_GETSYSSETTINGOBJECT = "GetSysSettingObject";
    public static final String METHOD_GETSERVERTIME = "getServerTime";
    public static final String METHOD_GETOPERATORS = "GetOperators";
    public static final String METHOD_GETRIGHTSBYGROUPID = "GetRightsByGroupID";
    public static final String METHOD_GETCHEDAOSET = "GetCheDaoSet";
    public static final String METHOD_GetCheDaoSetAndCamera = "GetCheDaoSetAndCamera";
    private FormServerSetView formServerSetView;
    private ParkingDownCardView parkingDownCardView;
    private ParkingReadRecordView parkingReadRecord;
    private TextView tvUserName;
    private LoadController loadController;
    private ImageView ivExit;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login1);

        Window window = getWindow();
        WindowManager m = getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = window.getAttributes(); // 获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 1 / 2.5); // 改变的是dialog框在屏幕中的位置而不是大小
        p.width = (int) (d.getWidth() * 1 / 2.5); // 宽度设置为屏幕的0.65
        window.setAttributes(p);

        setTitle(getResources().getString(R.string.page_login));

        initView();
        login_Loaded();
        EventBus.getDefault().register(this);
//        testTextSize();
    }

    private void testTextSize()
    {
        tvUserName = (TextView) findViewById(R.id.tvUserName);
        int[] devicePx = DensityUtil.getDevicePx(this);
        L.e("weight:" + devicePx[0] + ",height:" + devicePx[1]);
        L.e("tvUserName.size:" + tvUserName.getTextSize() + ",dip:" + DensityUtil.px2dip(this, tvUserName.getTextSize())); // tvUserName.size:16.0,dip:16

        L.e("getDensity:" + DensityUtil.getDensity(this) + ",getDensityDpi:" + DensityUtil.getDensityDpi(this));
        // textView.size:28.0 DensityUtil.px2dip(this, textView.getTextSize()):14 14dp就有28px像素大小了； getDensity:1.0,getDensityDpi:160.0
    }

    @Override
    protected void onRestart()
    {
        super.onRestart();
        L.i("indexUserName:" + indexUserName + ",indexStationId:" + indexStationId);
        login_Loaded();
    }

    /**
     * 创建配置文件，在程序执行时，即配置信息(可以将其放在Application进行初始化)
     */
    private void createConfigSettings()
    {
        SPUtils.put(ConstantSharedPrefs.FileAppSetting, getApplicationContext(), ConstantSharedPrefs.ServiceIP, NetworkConfig.ServerIP);
        SPUtils.put(ConstantSharedPrefs.FileAppSetting, getApplicationContext(), ConstantSharedPrefs.ServicePort, NetworkConfig.ServerPort);
    }

    private void initView()
    {
        et_password = (EditText) findViewById(R.id.et_password);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnParkSet = (Button) findViewById(R.id.btnParkSet);
        btnServerParamSet = (Button) findViewById(R.id.btnServerParamSet);

        btnLogin.setOnClickListener(this);
        btnParkSet.setOnClickListener(this);
        btnServerParamSet.setOnClickListener(this);

        spinnerUsername = (NiceSpinner) findViewById(R.id.spinnerUsername);
        spinnerUsername.setSpinnerListener(new NiceSpinner.SpinnerListener()
        {
            @Override
            public void OnSpinnerItemClick(int pos)
            {
                indexUserName = pos; // 记录当前的位置
            }
        });

        spinnerstation = (NiceSpinner) findViewById(R.id.spinnerstation);
        spinnerstation.setSpinnerListener(new NiceSpinner.SpinnerListener()
        {
            @Override
            public void OnSpinnerItemClick(int pos)
            {
                indexStationId = pos;
            }
        });
        ivExit = (ImageView) findViewById(R.id.ivExit);
        ivExit.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                finish();
            }
        });
//        AppOperation.hiddenSoftInput(this.getWindow(), et_password);
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.btnLogin:
                btnLogin_Click();
                break;
            case R.id.btnParkSet:
                btnParkSet_Click();
                break;
            case R.id.btnServerParamSet:
                btnSet_Click(); //服务器设置
                break;
        }
    }

    /**
     * 点击车场设置
     */
    private void btnParkSet_Click()
    {
        final String ip = "192.168.2.250";
        new Thread(new Runnable()
        {
            @Override
            public void run()
            {
//                UDPSendbll udpSendbll = new UDPSendbll(0);
//                GetTimeModel getTimeModel = new GetTimeModel();
//                long currentTimeMillis = System.currentTimeMillis();
//                getTimeModel.strTime = TimeConvertUtils.longToString(currentTimeMillis);
//                getTimeModel.iWeek = TimeConvertUtils.getWeeks(currentTimeMillis);
//
//                udpSendbll.SetTime(ip, 9, getTimeModel);
//                L.e("getTimeModel.strTime:" + getTimeModel.strTime + ",getTimeModel.iWeek:" + getTimeModel.iWeek);
//                GetTimeModel getTimeModelout = new GetTimeModel();
//
//                udpSendbll.GetTime(ip, 9, getTimeModelout);
//                L.e("getTimeModelout:" + getTimeModelout.toString());
            }
        }).start();

//        new Thread(new Runnable()
//        {
//            @Override
//            public void run()
//            {
////                String url = "http://192.168.2.247:8099/LicensedCarOut?UrlStr=weixin://wxpay/bizpayurl?pr=X0ql1v5&VoiceStr=粤123123请扫描二维码出场&Key=B48E52FD5ED092D3FA09FCD46561B2B9";
//                String url = "http://192.168.2.247:8099/UnlicensedCarOut?UrlStr=http://zjhwx.tunnel.qydev.com/dwz%3Fest=out%26ctlno=24&VoiceStr=无牌车请扫描二维码出场&Key=8CE81540386627E471B95A158B27A903";
//                RequestManager
//                        .getInstance()
//                        .get(url, new RequestListener()
//                        {
//                            @Override
//                            public void onRequest()
//                            {
//
//                            }
//
//                            @Override
//                            public void onSuccess(String s)
//                            {
//                                L.e("onSuccess ----------------------s" + s);
//                            }
//
//                            @Override
//                            public void onError(String s)
//                            {
//                                L.e("onSuccess ----------------------s" + s);
//                            }
//                        });
//            }
//        }).start();
    }


    /**
     * 点击服务器设置按钮
     */
    private void btnSet_Click()
    {
        if (formServerSetView == null)
        {
            formServerSetView = new FormServerSetView(this)
            {
                @Override
                public void onClickSave()
                {
                    login_Loaded();
                }
            };
        }
        formServerSetView.show();
    }

    /**
     * 点击登录按钮
     */
    private void btnLogin_Click()
    {
        if (!checkUIInput()) return;
        final String password = et_password.getEditableText().toString();
        try
        {
            md5Password = MD5Utils.MD5(password);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        Model.sUserPwd = md5Password;
        requestLoginUser();
    }


    /**
     * 检测ui的合法性数据
     *
     * @return
     */
    private boolean checkUIInput()
    {
        String username = spinnerUsername.getCurrentText();
        if (TextUtils.isEmpty(username))
        {
            Toast.makeText(LoginActivity.this, "请选择操作员", Toast.LENGTH_SHORT).show();
            return false;
        }

        String station = spinnerstation.getCurrentText();
        if (TextUtils.isEmpty(station))
        {
            Toast.makeText(LoginActivity.this, "请选择工作站", Toast.LENGTH_SHORT).show();
            return false;
        }

        L.i("username:" + username + ",station:" + station);
        return true;
    }

    private void login_Loaded()
    {
        if (SPUtils.checkPathExist(getApplicationContext(), ConstantSharedPrefs.FileAppSetting))
        {
            String serviceIP = (String) SPUtils.get(ConstantSharedPrefs.FileAppSetting, getApplicationContext()
                    , ConstantSharedPrefs.ServiceIP, "");
            String servicePort = (String) SPUtils.get(ConstantSharedPrefs.FileAppSetting, getApplicationContext()
                    , ConstantSharedPrefs.ServicePort, "");
            String tempStationID = (String) SPUtils.get(ConstantSharedPrefs.FileAppSetting, getApplicationContext()
                    , ConstantSharedPrefs.StationID, "");

            L.i("serverIP:" + serviceIP + ",servicePort:" + servicePort);
            GetServiceData.getInstance().setAddressAndPort(serviceIP, servicePort);

            boolean b = RegexUtil.checkDigit(tempStationID);
            curStationID = b ? tempStationID : "";// 已经读取了工作数据
            if (!RegexUtil.checkIpAddress(serviceIP) || !RegexUtil.checkDecimals(servicePort))
            {
                Log.i(TAG, "RegexUtil serviceIP:" + serviceIP + ",servicePort:" + servicePort);
                Toast.makeText(LoginActivity.this, "服务IP或端口格式不正确,请重新配置", Toast.LENGTH_SHORT).show();
            }
            else
            {
//                requestGetOperatorNoLogin();
//                requestGetStationNoLogin();
                requestGetStationSetAndOperatorsWithoutLogin();

                mHandler.postDelayed(new Runnable()
                {
                    @Override
                    public void run()
                    {
//                        if (getOperatorsWithoutLoginResp == null || getStationSetWithoutLoginResp == null)
                        if (getStationSetAndOperatorsWithoutLoginResp == null || !getStationSetAndOperatorsWithoutLoginResp.getRcode().equals("200"))
                        {
                            loadController.cancel();
                            btnSet_Click();
                        }
                    }
                }, 3000);
            }
        }
        else
        {
            showDialog("配置文件丢失，请联系管理员");
        }
    }


    private void updateStationName()
    {
        if (getStationSetWithoutLoginResp != null
                && getStationSetWithoutLoginResp.getData() != null)
        {
            setSpinnerStationName(getStationSetWithoutLoginResp.getData());
        }

        if (getStation != null)
        {
            setSpinnerStationName(getStation);
        }
    }

    private void setSpinnerStationName(List<GetStationSetWithoutLoginResp.DataBean> data)
    {
        if (data != null || data.size() > 0)
        {
            List<String> stationList = new ArrayList<String>();
            for (int i = 0; i < data.size(); i++)
            {
                stationList.add(String.valueOf(data.get(i).getStationName()));// 把站点名放到列表中
            }
            int selectIndex = indexStationId;
            if (stationList.size() > 0)
            {
                if (curStationID != null && curStationID != "")
                {
                    for (int i = 0; i < data.size(); i++)
                    {
                        if (Short.parseShort(curStationID) == data.get(i).getStationId())
                        {
                            selectIndex = i;
                            break;
                        }

                    }
                }

            }
            spinnerstation.refreshData(stationList, selectIndex);
        }
    }

    /**
     * 更新ui界面的数据
     */
    private void updateUserName()
    {
        if (getOperatorsWithoutLoginResp != null
                && getOperatorsWithoutLoginResp.getData() != null)
        {
            setSpinnerUserName(getOperatorsWithoutLoginResp.getData());
        }

        if (getOperators != null)
        {
            setSpinnerUserName(getOperators, 0);
        }
    }

    private void setSpinnerUserName(List<GetOperatorsResp.DataBean> data, int type)// 这里只是为了将接口隔开
    {
        if (data != null || data.size() > 0)
        {
            List<String> userList = new ArrayList<String>();
            for (int i = 0; i < data.size(); i++)
            {
                userList.add(data.get(i).getUserName());
            }
            spinnerUsername.refreshData(userList, indexUserName);
        }
    }


    private void setSpinnerUserName(List<GetOperatorsWithoutLoginResp.DataBean> data)
    {
        if (data != null || data.size() > 0)
        {
            List<String> userList = new ArrayList<String>();
            for (int i = 0; i < data.size(); i++)
            {
                userList.add(data.get(i).getUserName());
            }
            spinnerUsername.refreshData(userList, indexUserName);
        }
    }

    private WeakHandler mHandler = new WeakHandler();


    /**
     * 判断是否有指定的权限
     *
     * @param fromName
     * @param itemName
     * @return
     */
    private boolean isHaveRightsByName(String fromName, String itemName)
    {
        boolean result = false;
        // 从right获取出相应的权限
        for (int i = 0; i < Model.lstRights.size(); i++)
        {
            GetRightsByGroupIDResp.DataBean tmpRights = Model.lstRights.get(i);
            if (tmpRights.getFormName().equalsIgnoreCase(fromName)
                    && tmpRights.getItemName().equalsIgnoreCase(itemName))
            {
                if (tmpRights.isCanOperate())
                {
                    result = true;
                    break;
                }
            }
        }
        return result;
    }

    private int getStationIdFromList(int index)
    {
        if (getStation != null
                && getStation.size() > 0
                && (index >= 0 && index < getStation.size()))
        {
            return getStation.get(index).getStationId();
        }
        return 0;
    }

    private int getCarparkNOFromList(int index)
    {
        if (getStation != null
                && getStation.size() > 0
                && (index >= 0 && index < getStation.size()))
        {
            return getStation.get(index).getCarparkNO();
        }
        return 0;
    }

    private String getUserNoFromList(int index)
    {
        if (getOperators != null
                && getStation.size() > 0
                && (index >= 0 && index < getStation.size()))
        {
            return getOperators.get(index).getUserNO();
        }
        return null;
    }


    @TargetApi(Build.VERSION_CODES.KITKAT)
    private void handlerLoginRequest()
    {
        Model.stationID = getStationIdFromList(indexStationId);
        Model.iParkingNo = getCarparkNOFromList(indexStationId);

        if (SPUtils.checkPathExist(getApplicationContext(), ConstantSharedPrefs.FileAppSetting)) // 配置文件存在
        {
            L.i("curStationID:" + curStationID + ", Model.stationID:" + Model.stationID);
            if (!TextUtils.isEmpty(curStationID) && RegexUtil.checkDigit(curStationID))
            {
                if (Model.stationID == Integer.parseInt(curStationID))//相等
                {
                    enterNextSetting();
                }
                else // 不相等
                {
                    // 界面判断是否需要切换工作站点
                    showWorkStationSwitchDialog("是否切换工作站，请谨慎操作?", indexStationId);
                }
            }
            else// 初次登录时，站点不存在时
            {
                SPUtils.put(ConstantSharedPrefs.FileAppSetting, getApplicationContext(),
                        ConstantSharedPrefs.StationID, String.valueOf(Model.stationID));
                curStationID = String.valueOf(Model.stationID);
                enterNextSetting();
            }
        }
    }

    private void enterNextSetting()
    {
        requestGetSysSettingsObject();

        requestGetServerTime();

        // 数据定义

        // 准备工作
        //判断用户卡号是否相等的，即同一个用户登录
        if (Model.sUserCard.equals(SPUtils.get(ConstantSharedPrefs.FileAppSetting, getApplicationContext(),
                ConstantSharedPrefs.UserCode, "0")))
        {
            // LoginDate 可以存放毫秒数
            long result = (long) SPUtils.get(ConstantSharedPrefs.FileAppSetting, getApplicationContext()
                    , ConstantSharedPrefs.LoginDate, 0L);
            Model.dLoginTime = result;
        }
        else
        {
            SPUtils.put(ConstantSharedPrefs.FileAppSetting, getApplicationContext(),
                    ConstantSharedPrefs.UserCode, Model.sUserCard);
            long l = System.currentTimeMillis();
            SPUtils.put(ConstantSharedPrefs.FileAppSetting, getApplicationContext(),
                    ConstantSharedPrefs.LoginDate, l);
            Model.dLoginTime = l;
        }
        // 设置本地日期格式

        // 获取操作员信息
        GetOperatorsReq getOperatorsReq = new GetOperatorsReq();
        getOperatorsReq.setToken(Model.token);
        getOperatorsReq.setJsonSearchParam(JsonSearchParam.getWhenGetOperators(getUserNoFromList(indexUserName)));

        requestGetOperators(getOperatorsReq);
    }


    private void handlerGetOperators()
    {
        if (getOperatorsResp != null && getOperatorsResp.getData() != null
                && getOperatorsResp.getData().size() > 0)
        {
            Model.sUserName = getOperatorsResp.getData().get(0).getUserName();
            Model.sUserCard = getOperatorsResp.getData().get(0).getCardNO();
            Model.sGroupNo = getOperatorsResp.getData().get(0).getUserLevel();

            // 获取权限组
            GetRightsByGroupIDReq getRightsByGroupIDReq = new GetRightsByGroupIDReq();
            getRightsByGroupIDReq.setToken(Model.token);
            getRightsByGroupIDReq.setGroupID(Model.sGroupNo);

            requestGetRightsByGroupID(getRightsByGroupIDReq);
        }
    }


    @NonNull
    private GetServerTimeReq initGetServerTime()
    {
        GetServerTimeReq getServerTimeReq = new GetServerTimeReq();
        getServerTimeReq.setToken(Model.token);
        return getServerTimeReq;
    }


    private void showDialog(String str)
    {
        new AlertDialog.Builder(this).setTitle("提示信息")
                .setMessage(str).setPositiveButton("确认", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                btnSet_Click();
            }
        }).show();
    }

    private void showWorkStationSwitchDialog(String str, final int index)
    {
        new AlertDialog.Builder(this).setTitle("提示信息")
                .setMessage(str).setPositiveButton("确认", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)// 对比StationId是否相等
            {
                int id = getStationIdFromList(index);

                //保存站点即可
                SPUtils.put(ConstantSharedPrefs.FileAppSetting, getApplicationContext()
                        , ConstantSharedPrefs.StationID, String.valueOf(id));
                curStationID = String.valueOf(id);

                enterNextSetting();
            }
        }).setNegativeButton("取消", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {

            }
        }).show();
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        mHandler.removeCallbacksAndMessages(null);
    }

    private void requestGetStationSetAndOperatorsWithoutLogin()
    {
        GetStationSetAndOperatorsWithoutLoginReq loginReq = new GetStationSetAndOperatorsWithoutLoginReq();
        String resultUrl = GetServiceData.getResultUrl(METHOD_GETSTATIONSETANDOPERATORSWITHOUTLOGIN, new GetStationSetAndOperatorsWithoutLoginReq());
        loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetStationSetAndOperatorsWithoutLoginResp.class, this, loginReq, resultUrl, -1));
    }

    /**
     * 1 获取操作员信息
     */
    private void requestGetOperatorNoLogin()
    {
        GetOperatorsWithoutLoginReq withoutLoginReq = new GetOperatorsWithoutLoginReq();
        String resultUrl = GetServiceData.getResultUrl(METHOD_GETOPERATORSWITHOUTLOGIN, withoutLoginReq);
        RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetOperatorsWithoutLoginResp.class, this, withoutLoginReq, resultUrl, -1));
    }

    /**
     * 2 获取站点消息
     */
    private void requestGetStationNoLogin()
    {
        GetStationSetWithoutLoginReq stationReq = new GetStationSetWithoutLoginReq();
        stationReq.setOrderField("StationId");

        final String resultUrl = GetServiceData.getResultUrl(METHOD_GETSTATIONSETWITHOUTLOGIN, stationReq);
        RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetStationSetWithoutLoginResp.class, this, stationReq, resultUrl, -1));
    }

    /**
     * 3，请求登录
     */
    private void requestLoginUser()
    {
        LoginUserReq loginUserReq = initLoginUserReq();
        String resultUrl = GetServiceData.getResultUrl(METHOD_LOGINUSER, loginUserReq);
        RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(LoginUserResp.class, this, loginUserReq, resultUrl, -1));
    }

    /**
     * 请求系统时间
     */
    private void requestGetServerTime()
    {
        GetServerTimeReq getServerTimeReq = initGetServerTime();
        String url = GetServiceData.getResultUrl(METHOD_GETSERVERTIME, initGetServerTime());
        RequestManager
                .getInstance()
                .get(url, new GsonCallback<>(GetServerTimeResp.class, this, getServerTimeReq, url, -1));
    }

    /**
     * 系统设置
     */
    private void requestGetSysSettingsObject()
    {
        GetSysSettingObjectReq getSysSettingObjectReq = initSysSettingObject();
        String resultUrl = GetServiceData.getResultUrl(METHOD_GETSYSSETTINGOBJECT, initSysSettingObject());
        RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetSysSettingObjectResp.class, this, getSysSettingObjectReq, resultUrl, -1));
    }

    /**
     * 请求操作员
     *
     * @param getOperatorsReq
     */
    private void requestGetOperators(GetOperatorsReq getOperatorsReq)
    {
        String operatorUrl = GetServiceData.getResultUrl(METHOD_GETOPERATORS, getOperatorsReq);
        RequestManager
                .getInstance()
                .get(operatorUrl, new GsonCallback<>(GetOperatorsResp.class, this, getOperatorsReq, operatorUrl, -1));
    }

    /**
     * 请求权限
     *
     * @param getRightsByGroupIDReq
     */
    private void requestGetRightsByGroupID(GetRightsByGroupIDReq getRightsByGroupIDReq)
    {
        String url = GetServiceData.getResultUrl(METHOD_GETRIGHTSBYGROUPID, getRightsByGroupIDReq);
        RequestManager
                .getInstance()
                .get(url, new GsonCallback<>(GetRightsByGroupIDResp.class, this, getRightsByGroupIDReq, url, -1));
    }

    @NonNull
    private LoginUserReq initLoginUserReq()
    {
        LoginUserReq loginUserReq = new LoginUserReq();
        loginUserReq.setPassword(md5Password);
        String tempUserNO = "";
        if (getOperatorsWithoutLoginResp != null
                && getOperatorsWithoutLoginResp.getData() != null
                && getOperatorsWithoutLoginResp.getData().size() != 0)
        {
            tempUserNO = getOperatorsWithoutLoginResp.getData().get(indexUserName).getUserNO();
        }

        if (getOperators != null && getOperators.size() > 0)
        {
            tempUserNO = getOperators.get(indexUserName).getUserNO();
        }
        loginUserReq.setUserNo(tempUserNO);
        return loginUserReq;
    }


    @NonNull
    private GetSysSettingObjectReq initSysSettingObject()
    {
        GetSysSettingObjectReq getSysSettingObjectReq = new GetSysSettingObjectReq();
        getSysSettingObjectReq.setToken(Model.token);
        getSysSettingObjectReq.setStationID(getStationIdFromList(indexStationId));
        return getSysSettingObjectReq;
    }

    @Override
    public void success(Object reqData, Object respData, String url, int paramInt)
    {
        CR.printGsonResp(reqData, respData, url, paramInt);
        if (respData instanceof GetOperatorsWithoutLoginResp)
        {
            getOperatorsWithoutLoginResp = (GetOperatorsWithoutLoginResp) respData;
            if (!(getOperatorsWithoutLoginResp.getRcode().equals("200")))
            {
                L.e("getOperatorsWithoutLoginResp:" + getOperatorsWithoutLoginResp.getMsg());
                return;
            }
            updateUserName();
        }
        else if (respData instanceof GetStationSetWithoutLoginResp)
        {
            getStationSetWithoutLoginResp = (GetStationSetWithoutLoginResp) respData;
            if (!(getStationSetWithoutLoginResp.getRcode().equals("200")))
            {
                L.e("GetStationSetWithoutLoginResp:" + getStationSetWithoutLoginResp.getMsg());
                return;
            }
            updateStationName();
        }
        else if (respData instanceof GetStationSetAndOperatorsWithoutLoginResp)
        {
            getStationSetAndOperatorsWithoutLoginResp = (GetStationSetAndOperatorsWithoutLoginResp) respData;

            if (!getStationSetAndOperatorsWithoutLoginResp.getRcode().equals("200"))
            {
                L.e("getStationSetAndOperatorsWithoutLoginResp:" + getStationSetAndOperatorsWithoutLoginResp.getMsg());
                return;
            }

            if (getStationSetAndOperatorsWithoutLoginResp.getData() != null)
            {
                getOperators = getStationSetAndOperatorsWithoutLoginResp.getData().getOperators();
            }

            if (getStationSetAndOperatorsWithoutLoginResp.getData() != null)
            {
                getStation = getStationSetAndOperatorsWithoutLoginResp.getData().getStations();
            }

            updateUserName();
            updateStationName();
        }
        else if (respData instanceof LoginUserResp)
        {
            loginUserResp = (LoginUserResp) respData;
            if (loginUserResp != null && loginUserResp.getData() != null)
            {
                if (Integer.parseInt(loginUserResp.getRcode()) != 200)
                {
                    T.showShort(LoginActivity.this, loginUserResp.getMsg());
                }
                else
                {
                    Model.token = loginUserResp.getData().getToken(); // 登录成功
                }
            }
            else
            {
                T.showShort(LoginActivity.this, "登录服务器失败");
            }
            handlerLoginRequest();
        }
        else if (respData instanceof GetSysSettingObjectResp)
        {
            GetSysSettingObjectResp resp = (GetSysSettingObjectResp) respData;
            if (!resp.getRcode().equals("200"))
            {
                L.e("GetSysSettingObjectResp:" + resp.getMsg());
                return;
            }
            Model.setSysSettingToPubVar(resp.getData());
        }
        else if (respData instanceof GetServerTimeResp)
        {
            serverTime = (GetServerTimeResp) respData;
            if (!serverTime.getRcode().equals("200"))
            {
                L.e("serverTime:" + serverTime.getMsg());
            }
        }
        else if (respData instanceof GetOperatorsResp)
        {
            getOperatorsResp = (GetOperatorsResp) respData;
            if (!getOperatorsResp.getRcode().equals("200"))
            {
                L.e("getOperatorsResp:" + getOperatorsResp.getMsg());
                return;
            }
            handlerGetOperators();
        }
        else if (respData instanceof GetRightsByGroupIDResp)
        {
            getRightsByGroupIDResp = (GetRightsByGroupIDResp) respData;
            if (getRightsByGroupIDResp != null && getRightsByGroupIDResp.getData() != null)
            {
                Model.lstRights = getRightsByGroupIDResp.getData();
            }

            if (!getRightsByGroupIDResp.getRcode().equals("200"))
            {
                L.e("getRightsByGroupIDResp:" + getRightsByGroupIDResp.getMsg());
                return;
            }

            if (Model.lstRights == null || Model.lstRights.size() <= 0)
            {
                Toast.makeText(LoginActivity.this, "无进入在线监控权限", Toast.LENGTH_SHORT).show();
            }
            else
            {
                // 获取是否有在线监控的权限
                if (isHaveRightsByName("在线监控", "cmdView"))
                {
//                    parkingDownCardView = new ParkingDownCardView(this); // 下载车牌
//                    parkingDownCardView.show();//
                    // 弹出对话框显示ParkingReadRecord的显示

                    // 最后显示监控界面
                    Intent intent = new Intent(LoginActivity.this, ParkingDownCardActvity.class);
                    startActivity(intent);
                }
                else
                {
                    Toast.makeText(LoginActivity.this, "无进入在线监控权限", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void dealRecvDownAndReadMessage(ThreadMessage message)
    {
        switch (message.getWhat())
        {
            case 1: // 表示下载车牌的线程结束了
//                L.e("表示下载车牌的线程结束了");
//                if (parkingDownCardView != null)
//                {
//                    parkingDownCardView.dismiss();
//                }
//                parkingReadRecord = new ParkingReadRecordView(this);
//                parkingReadRecord.show();
                break;
            case 2:// 表示读取记录线程结束了
//                L.e("表示读取记录线程结束了");
//                if (parkingReadRecord != null)
//                {
//                    parkingReadRecord.dismiss();
//                }
//                Intent intent = new Intent(LoginActivity.this, ParkingMonitoringActivity.class);
//                startActivity(intent);
            default:
                break;
        }
    }

    @Override
    public void error(Object data, String url, String errorString)
    {
        T.showShort(LoginActivity.this, "连接服务器失败");
    }


}