package com.example.administrator.myparkingos.ui.onlineMonitorPage;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v4.util.ArrayMap;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;

import com.callNative.CallNative;
import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.BaseApplication;
import com.example.administrator.myparkingos.HttpPostRequest;
import com.example.administrator.myparkingos.LoginActivity;
import com.example.administrator.myparkingos.common.data.cipher.Base64Cipher;
import com.example.administrator.myparkingos.common.utils.BitmapUtil;
import com.example.administrator.myparkingos.constant.CR;
import com.example.administrator.myparkingos.constant.ColumnName;
import com.example.administrator.myparkingos.constant.ConstantSharedPrefs;
import com.example.administrator.myparkingos.constant.DeviceStringTool;
import com.example.administrator.myparkingos.constant.JsonSearchParam;
import com.example.administrator.myparkingos.constant.OpenWayEnum;
import com.example.administrator.myparkingos.constant.OrderField;
import com.example.administrator.myparkingos.constant.PlateColorEnum;
import com.example.administrator.myparkingos.constant.QueueMessageTypeEnum;
import com.example.administrator.myparkingos.constant.RCodeEnum;
import com.example.administrator.myparkingos.easythread.Callback;
import com.example.administrator.myparkingos.easythread.EasyThread;
import com.example.administrator.myparkingos.model.GetServiceData;
import com.example.administrator.myparkingos.model.beans.CardIdInfo;
import com.example.administrator.myparkingos.model.beans.Model;
import com.example.administrator.myparkingos.model.beans.ModelNode;
import com.example.administrator.myparkingos.model.requestInfo.AddIDInfoReq;
import com.example.administrator.myparkingos.model.requestInfo.AddOptLogReq;
import com.example.administrator.myparkingos.model.requestInfo.CancelChargeReq;
import com.example.administrator.myparkingos.model.requestInfo.GetCarInReq;
import com.example.administrator.myparkingos.model.requestInfo.GetCarOutReq;
import com.example.administrator.myparkingos.model.requestInfo.GetCardIssueReq;
import com.example.administrator.myparkingos.model.requestInfo.GetCardTypeDefReq;
import com.example.administrator.myparkingos.model.requestInfo.GetCheDaoSetReq;
import com.example.administrator.myparkingos.model.requestInfo.GetParkingInfoReq;
import com.example.administrator.myparkingos.model.requestInfo.GetXXXCommonReq;
import com.example.administrator.myparkingos.model.requestInfo.KeepAliveReq;
import com.example.administrator.myparkingos.model.requestInfo.LogOutReq;
import com.example.administrator.myparkingos.model.requestInfo.LoginUserReq;
import com.example.administrator.myparkingos.model.requestInfo.SetCarInConfirmReq;
import com.example.administrator.myparkingos.model.requestInfo.SetCarInReq;
import com.example.administrator.myparkingos.model.requestInfo.SetCarInWithoutCPHReq;
import com.example.administrator.myparkingos.model.requestInfo.SetCarOutReq;
import com.example.administrator.myparkingos.model.requestInfo.UploadCaptureImageReq;
import com.example.administrator.myparkingos.model.responseInfo.AddOptLogResp;
import com.example.administrator.myparkingos.model.responseInfo.CancelChargeResp;
import com.example.administrator.myparkingos.model.responseInfo.GetAutoTempDownLoadResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCarInResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCarOutResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCardIssueResp2;
import com.example.administrator.myparkingos.model.responseInfo.GetCardTypeDefResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCheDaoSetResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCommonXXXResp;
import com.example.administrator.myparkingos.model.responseInfo.GetLedSettingResp;
import com.example.administrator.myparkingos.model.responseInfo.GetNetCameraSetResp;
import com.example.administrator.myparkingos.model.responseInfo.GetParkingInfoResp;
import com.example.administrator.myparkingos.model.responseInfo.GetPlateNumberDownBlackListResp;
import com.example.administrator.myparkingos.model.responseInfo.GetPlateNumberDownCardIssueResp;
import com.example.administrator.myparkingos.model.responseInfo.GetPlateNumberDownTempLoadResp;
import com.example.administrator.myparkingos.model.responseInfo.GetRightsByGroupIDResp;
import com.example.administrator.myparkingos.model.responseInfo.KeepAliveResp;
import com.example.administrator.myparkingos.model.responseInfo.LogOutResp;
import com.example.administrator.myparkingos.model.responseInfo.LoginUserResp;
import com.example.administrator.myparkingos.model.responseInfo.SetCarInConfirmResp;
import com.example.administrator.myparkingos.model.responseInfo.SetCarInResp;
import com.example.administrator.myparkingos.model.responseInfo.SetCarInWithoutCPHResp;
import com.example.administrator.myparkingos.model.responseInfo.SetCarOutResp;
import com.example.administrator.myparkingos.model.responseInfo.UploadCaptureImageResp2;
import com.example.administrator.myparkingos.myUserControlLibrary.MessageBox;
import com.example.administrator.myparkingos.ui.FragmentChargeManager;
import com.example.administrator.myparkingos.ui.FragmentDetailManager;
import com.example.administrator.myparkingos.ui.Summary;
import com.example.administrator.myparkingos.ui.loginHintProcess.ParkingDownCardActvity;
import com.example.administrator.myparkingos.ui.onlineMonitorPage.report.ReportCarChargeActivity;
import com.example.administrator.myparkingos.ui.onlineMonitorPage.report.ReportDealLineView;
import com.example.administrator.myparkingos.ui.onlineMonitorPage.report.ReportInParkActivity;
import com.example.administrator.myparkingos.util.ConcurrentQueueHelper;
import com.example.administrator.myparkingos.util.ExeUtil;
import com.example.administrator.myparkingos.util.L;
import com.example.administrator.myparkingos.util.OpenGateCallBack;
import com.example.administrator.myparkingos.util.RegexUtil;
import com.example.administrator.myparkingos.util.SDCardUtils;
import com.example.administrator.myparkingos.util.T;
import com.example.administrator.myparkingos.util.TimeConvertUtils;
import com.example.administrator.myparkingos.volleyUtil.callback.GsonCallback;
import com.example.sfmudpsdk_android.ConstantClass;
import com.example.sfmudpsdk_android.DownTempCPHModel;
import com.example.sfmudpsdk_android.GetTimeModel;
import com.example.sfmudpsdk_android.LoadLsNoX2010znyktInGateModel;
import com.example.sfmudpsdk_android.LoadLsNoX2010znyktOutGateModel;
import com.example.sfmudpsdk_android.VoiceInYWModel;
import com.jude.http.LoadController;
import com.jude.http.RequestManager;
import com.jude.http.RequestMap;
import com.litesuits.common.utils.FileUtil;
import com.vz.tcpsdk;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created by Administrator on 2017-02-16.
 * 【在线监控】主界面
 */
public class ParkingMonitoringActivity extends AppCompatActivity implements GsonCallback.Listener
{
    private FragmentChargeManager fragmentChargeManager = null;
    private FragmentDetailManager fragmentDetailManager = null;
    private ParkingMonitoringView parkingMonitoringView;
    private ParkingInNoPlateView parkingInNoPlateView;
    private ParkingOutNOPlateNoView parkingOutNOPlateNoView;
    private ParkingPlateRegisterView parkingPlateRegisterView;
    private FormAddBlackListView formAddBlackListView;
    private ReportDealLineView reportDealLineView;
    private ParkingChangeView parkingChangeShifts;
    private QueueTask queueTask;
    private ExeUtil exe;

    private GetParkingInfoResp getParkingInfoResp;
    private ParkingChannelSelectView parkingChannelSelectView;

    private List<GetCheDaoSetResp.DataBean> lstCDS;

    public static final String METHOD_GETCARDTYPEDEF = "GetCardTypeDef";
    public static final String METHOD_GetCheDaoSetAndCamera = "GetCheDaoSetAndCamera";
    public static final String METHOD_GETCHEDAOSET = "GetCheDaoSet";
    public static final String METHOD_GETNETCAMERASET = "GetNetCameraSet";
    public static final String METHOD_GETCARIN = "GetCarIn";
    public static final String METHOD_GETCAROUT = "GetCarOut";
    public static final String METHOD_GETPARKINGINFO = "GetParkingInfo";
    public static final String METHOD_UPLOADCAPTUREIMAGE = "UploadCaptureImage";
    public static final String METHOD_SETCARINWITHOUTCPH = "SetCarInWithoutCPH";
    public static final String METHOD_SETCARIN = "SetCarIn";
    public static final String METHOD_ADDOPTLOG = "AddOptLog";
    public static final String METHOD_GETLEDSETTING = "GetLedSetting";
    public static final String METHOD_SETCAROUT = "SetCarOut";
    public static final String METHOD_CANCELCHARGE = "CancelCharge";
    public static final String METHOD_GETCARDISSUE = "GetCardIssue";
    public static final String METHOD_SETCARINCONFIRMED = "SetCarInConfirmed";
    public static final String METHOD_LOGOUT = "LogOut";
    public static final String METHOD_KEEPALIVE = "KeepAlive";
    private final static String METHOD_ADDOFFLINEINOUT = "AddOfflineInOut";
    private final static String METHOD_ADDIDINFO = "AddIDInfo";// 这个接口只在没有图片时用
    private final static String METHOD_ADDIDINFOWITHPHOTO = "AddIDInfoWithPhoto";// 这个接口在有图片的时候都可以使用
    private final static String METHOD_ADDIDINFOFROMBODY = "AddIDInfoFromBody";

    private List<LoadController> mList;

    private long loadTime;

    private EasyThread executor;

    private final int ArraySize = 11;
    // 全局参数
    /// <summary>
    /// 取条码延时
    /// </summary>
    private int[] iPaperDelay = new int[ArraySize];

    /// <summary>
    /// 图片是否抓拍
    /// </summary>
    private boolean[] bReadPicAuto = new boolean[ArraySize];

    /// <summary>
    /// 图片路径
    /// </summary>
    private String[] strReadPicFile = new String[ArraySize];

    /// <summary>
    /// 图片路径
    /// </summary>
    private String[] strReadPicFileJpg = new String[ArraySize]; // 存放的是文件的路径

    private String[] strCarNoColor = new String[ArraySize];
    /// <summary>
    /// 识别车牌号
    /// </summary>
    private String[] autoCarNo = new String[ArraySize];

    private boolean[] bOffLine = new boolean[ArraySize];
    private boolean[] bLoadFullCW = new boolean[ArraySize];
    private boolean[] forbidIn = new boolean[ArraySize];
    private boolean[] bStopInInit = new boolean[ArraySize];
    private boolean[] bIsMoth = new boolean[ArraySize];

    /// <summary>
    /// 摄像头类型
    /// </summary>
    private String[] strVideoType = new String[ArraySize];
    private boolean isOne;

    /// <summary>
    /// 控制机显示屏延时显示剩余车位
    /// </summary>
    private int iCtrlLedDelay;

    private int KEEYALIVE_SENCONDS = 3000; // 心跳间隔时间
    private DownloadOffLineCardThread downloadOffLineCardThread;
    private Base64Cipher base64Cipher;
    private BaseApplication application;
    private ParkingOpenView parkingOpenView;
    private ReportInParkActivity reportInParkActivity;

    @Override
    protected void onCreate(@Nullable final Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        parkingMonitoringView = new ParkingMonitoringView(this, R.layout.activity_parkingmonitor, mHandler)
        {
            @Override
            public void chargeInfoToFragmentChange() //点击收费信息，切换Fragment
            {
                fragmentChargeManager.showFragment(0);
            }

            @Override
            public void carSpaceInfoToFragmentChange()// 点击车位信息，切换fragment
            {
                fragmentChargeManager.showFragment(1);
            }

            @Override
            public void carInParkingDetailToFragmentChange()//点击场内车辆明细
            {
                fragmentDetailManager.showFragment(0);
            }

            @Override
            public void chargeDetailToFragmentChange()//点击车辆收费明细
            {
                fragmentDetailManager.showFragment(1);
            }

            /**
             * 点击车入场按钮
             */
            @Override
            public void onClickCarInBtn()
            {
                // 当面对多个通道时，出现通道的选择
                if (inChannelNum >= 2)
                {
                    parkingChannelSelectView = new ParkingChannelSelectView(ParkingMonitoringActivity.this, CAR_CHANNEL_IN)
                    {
                        @Override
                        public void onSelectInOutName(String currentText)
                        {
                            int channelIndex = getCtrlIndexByInoutName(currentText);
                            if (channelIndex < 0)
                                L.i("getCtrlIndexByInoutName" + currentText + "no find");
                            else
                                popuCarInDialog(channelIndex, Model.Channels[channelIndex].iCtrlID);
                        }

                        @Override
                        public void prepareLoadData()
                        {
                            List<String> data = getInOutListNameByType(CAR_CHANNEL_IN);
                            parkingChannelSelectView.setSpinnerData(data);
                        }
                    };
                    parkingChannelSelectView.show();
                }
                else if (inChannelNum == 1)
                {
                    int channelIndex = getChannelIndex(CAR_CHANNEL_IN);
                    if (channelIndex < 0)
                        L.i("getChannelIndex " + CAR_CHANNEL_IN + " no find");
                    else
                        popuCarInDialog(channelIndex, Model.Channels[channelIndex].iCtrlID);
                }
                else
                {
                    T.showShort(ParkingMonitoringActivity.this, "没有车辆入场通道");
                }
            }

            /**
             * 弹出车辆进场的画面
             */
            private void popuCarInDialog(final int index, final int ctrlNumber)
            {
                ParkingPlateNoInputView carInDialog = new ParkingPlateNoInputView(ParkingMonitoringActivity.this, CAR_CHANNEL_IN)
                {
                    /**
                     * 提前加载数据
                     */
                    @Override
                    public void prepareLoadData()
                    {
                        super.prepareLoadData();
                        setProvince(Model.LocalProvince);
                    }

                    @Override
                    protected void onCarInBtnOk(final String CPH)
                    {
                        SetCarInReq setCarInReq = initSetCarIn(CPH, ctrlNumber);
                        // 获取本地路径的fileName
                        String tempImageSavePath = CR.createTempImageSavePath(ParkingMonitoringActivity.this, CAR_CHANNEL_IN);
                        saveBitmapToFile(index, tempImageSavePath);
                        L.e("onCarInBtnOk:" + tempImageSavePath);
                        CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_CAR_IN_TYPE_AUTO, CPH, setCarInReq, index, tempImageSavePath);
                    }

                    /**
                     * 当text查询时，出现模糊查找
                     * @param Precision
                     */
                    @Override
                    public void onClickInTextInput(final String cph, final int Precision)
                    {
                        GetCardIssueReq cardIssueReq = initGetCardIssueReq(cph);

                        String resultUrl = GetServiceData.getResultUrl(METHOD_GETCARDISSUE, cardIssueReq);
                        L.i("in onClickInTextInput:" + resultUrl + ", cph, " + cph);
                        LoadController loadController = RequestManager
                                .getInstance()
                                .get(resultUrl, new GsonCallback<>(GetCardIssueResp2.class, new GsonCallback.Listener()
                                {
                                    @Override
                                    public void success(Object reqData, Object respData, String url, int paramInt)
                                    {
                                        CR.printGsonResp(reqData, respData, url, paramInt);
                                        GetCardIssueResp2 respList = (GetCardIssueResp2) respData;
                                        ArrayList<String> strings = new ArrayList<>();
                                        if (respList != null && respList.getData() != null && respList.getData().size() > 0)
                                        {
                                            for (GetCardIssueResp2.DataBean o : respList.getData())
                                            {
                                                strings.add(o.getCPH());
                                            }
                                            if (strings.size() == 1 && strings.get(0).substring(1).equals(cph.substring(1)))
                                            {
                                            }//表示查询的数据相等了
                                            else
                                            {
                                                showPopWindow();
                                                setCompleteCPHText(strings);
                                            }
                                        }
                                    }

                                    @Override
                                    public void error(Object data, String url, String errorString)
                                    {
                                        T.showShort(ParkingMonitoringActivity.this, "网络连接失败");
                                    }
                                }, cardIssueReq, resultUrl, index));
                        mList.add(loadController);
                    }
                };
                carInDialog.show();
            }

            /**
             * 点击出场按钮
             */
            @Override
            public void onClickCarOutBtn()
            {
                if (outChannelNum >= 2)
                {
                    parkingChannelSelectView = new ParkingChannelSelectView(ParkingMonitoringActivity.this, CAR_CHANNEL_OUT)
                    {
                        @Override
                        public void onSelectInOutName(String currentText)
                        {
                            int channelIndex = getCtrlIndexByInoutName(currentText);
                            if (channelIndex < 0)
                                L.e("getCtrlIndexByInoutName" + currentText + "no find");
                            else
                                popuSetCarOut(channelIndex, Model.Channels[channelIndex].iCtrlID);
                        }

                        @Override
                        public void prepareLoadData()
                        {
                            List<String> data = getInOutListNameByType(CAR_CHANNEL_OUT);
                            parkingChannelSelectView.setSpinnerData(data);
                        }
                    };
                    parkingChannelSelectView.show();
                }
                else if (outChannelNum == 1)
                {
                    int channelIndex = getChannelIndex(CAR_CHANNEL_OUT);
                    if (channelIndex < 0)
                        L.i("getChannelIndex " + CAR_CHANNEL_OUT + " no find");
                    else
                        popuSetCarOut(channelIndex, Model.Channels[channelIndex].iCtrlID);
                }
                else
                {
                    T.showShort(ParkingMonitoringActivity.this, "没有车辆出场通道");
                }
            }

            /**
             * 弹出车辆出场画面
             * @param index
             * @param ctrlNumber
             */
            private void popuSetCarOut(final int index, final int ctrlNumber)
            {
                ParkingPlateNoInputView carOutDialog = new ParkingPlateNoInputView(ParkingMonitoringActivity.this, CAR_CHANNEL_OUT)
                {
                    @Override
                    public void prepareLoadData()
                    {
                        super.prepareLoadData();
                        setProvince(Model.LocalProvince);
                    }

                    @Override
                    public void onCarOutBtnOk(final String CPH) // 车辆出场，直接发送出场消息
                    {
                        SetCarOutReq req = initSetCarOutReq(CPH, ctrlNumber);
                        String tempImageSavePath = CR.createTempImageSavePath(ParkingMonitoringActivity.this, CAR_CHANNEL_OUT);
                        saveBitmapToFile(index, tempImageSavePath);
                        L.e("onCarOutBtnOk:" + tempImageSavePath);
                        CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_CAR_OUT_TYPE_AUTO, CPH, req, index, tempImageSavePath);
                    }

                    @Override
                    public void onClickOutTextInput(final String resultCPH, int length)
                    {
                        GetCarInReq getCarInReq = initSelectComeCPH_Like(resultCPH);
                        String resultUrl = GetServiceData.getResultUrl(METHOD_GETCARIN, getCarInReq);
                        L.i("out onClickInTextInput:" + resultUrl + ", resultCPH, " + resultCPH);
                        LoadController loadController = RequestManager
                                .getInstance()
                                .get(resultUrl, new GsonCallback<>(GetCarInResp.class, new GsonCallback.Listener()
                                {
                                    @Override
                                    public void success(Object reqData, Object respData, String url, int paramInt)
                                    {
                                        CR.printGsonResp(reqData, respData, url, paramInt);
                                        GetCarInResp getCarInResp = (GetCarInResp) respData;
                                        ArrayList<String> strings = new ArrayList<>();
                                        if (getCarInResp != null && getCarInResp.getData() != null && getCarInResp.getData().size() > 0)
                                        {
                                            for (GetCarInResp.DataBean o : getCarInResp.getData())
                                            {
                                                strings.add(o.getCPH());
                                            }
                                            if (strings.size() == 1 && strings.get(0).substring(1).equals(resultCPH.substring(1)))
                                            {
                                            }//表示查询的数据相等了
                                            else
                                            {
                                                showPopWindow();
                                                setCompleteCPHText(strings);
                                            }
                                        }
                                    }

                                    @Override
                                    public void error(Object data, String url, String errorString)
                                    {
                                        T.showShort(ParkingMonitoringActivity.this, "网络连接失败");
                                    }
                                }, getCarInReq, resultUrl, index));
                        mList.add(loadController);
                    }
                };
                carOutDialog.show();
            }

            /**
             * 点击无牌车入场按钮,通道可以在里面进行选择
             */
            @Override
            public void onClickNoPlateCarInBtn()
            {
                if (inChannelNum >= 2)
                {
                    parkingChannelSelectView = new ParkingChannelSelectView(ParkingMonitoringActivity.this, CAR_CHANNEL_IN)
                    {
                        @Override
                        public void onSelectInOutName(String currentText)
                        {
                            int channelIndex = getCtrlIndexByInoutName(currentText);
                            if (channelIndex < 0)
                                L.i("getCtrlIndexByInoutName" + currentText + "no find");
                            else
                                popuNoPlateSetCarIn(channelIndex, Model.Channels[channelIndex].iCtrlID);
                        }

                        @Override
                        public void prepareLoadData()
                        {
                            List<String> data = getInOutListNameByType(CAR_CHANNEL_IN);
                            parkingChannelSelectView.setSpinnerData(data);
                        }
                    };
                    parkingChannelSelectView.show();
                }
                else if (inChannelNum == 1)
                {
                    int channelIndex = getChannelIndex(CAR_CHANNEL_IN);
                    if (channelIndex < 0)
                        L.i("getChannelIndex " + CAR_CHANNEL_IN + " no find");
                    else
                        popuNoPlateSetCarIn(channelIndex, Model.Channels[channelIndex].iCtrlID);
                }
                else
                {
                    T.showShort(ParkingMonitoringActivity.this, "没有车辆入场通道");
                }
            }

            /**
             * 弹出无牌车入场界面
             */
            private void popuNoPlateSetCarIn(final int index, final int ctrlNumber)
            {
                if (parkingInNoPlateView == null)
                {
                    parkingInNoPlateView = new ParkingInNoPlateView(ParkingMonitoringActivity.this, index, ctrlNumber)
                    {
                        @Override
                        public void prepareLoadData()
                        {
                            parkingInNoPlateView.setRoadNameData(Model.Channels[index].sInOutName);//显示下拉列表

                            String tempImageSavePath = CR.createTempImageSavePath(ParkingMonitoringActivity.this, CAR_CHANNEL_IN);
                            saveBitmapToFile(index, tempImageSavePath);
                            L.e("popuNoPlateSetCarIn:" + tempImageSavePath);
                            parkingInNoPlateView.setImage(tempImageSavePath);
                        }
                    };
                }
                parkingInNoPlateView.show();
            }

            /**
             * 点击无牌车出场按钮,通道可以在里面进行选择
             */
            @Override
            public void onClickNoPlateCarOutBtn()
            {
                if (outChannelNum >= 2)
                {
                    parkingChannelSelectView = new ParkingChannelSelectView(ParkingMonitoringActivity.this, CAR_CHANNEL_OUT)
                    {
                        @Override
                        public void onSelectInOutName(String currentText)
                        {
                            int channelIndex = getCtrlIndexByInoutName(currentText);
                            if (channelIndex < 0)
                                L.i("getCtrlIndexByInoutName" + currentText + "no find");
                            else
                                popuNoPlateSetCarOut(channelIndex, Model.Channels[channelIndex].iCtrlID);
                        }


                        @Override
                        public void prepareLoadData()
                        {
                            List<String> data = getInOutListNameByType(CAR_CHANNEL_OUT);
                            parkingChannelSelectView.setSpinnerData(data);
                        }
                    };
                    parkingChannelSelectView.show();
                }
                else if (outChannelNum == 1)
                {
                    int channelIndex = getChannelIndex(CAR_CHANNEL_OUT);
                    if (channelIndex < 0)
                        L.i("getChannelIndex " + CAR_CHANNEL_OUT + " no find");
                    else
                        popuNoPlateSetCarOut(channelIndex, Model.Channels[channelIndex].iCtrlID);
                }
                else
                {
                    T.showShort(ParkingMonitoringActivity.this, "没有车辆出场通道");
                }
            }

            /**
             * 弹出无牌车出场界面
             */
            private void popuNoPlateSetCarOut(int channelIndex, int iCtrlID)
            {
                if (parkingOutNOPlateNoView == null)
                {
                    parkingOutNOPlateNoView = new ParkingOutNOPlateNoView(ParkingMonitoringActivity.this, channelIndex)
                    {
                        @Override
                        public void prepareInitData(int index)
                        {
                            parkingOutNOPlateNoView.setRoadNameData(Model.Channels[index].sInOutName);//显示下拉列表

                            String tempImageSavePath = CR.createTempImageSavePath(ParkingMonitoringActivity.this, CAR_CHANNEL_OUT);
                            saveBitmapToFile(index, tempImageSavePath);
                            parkingOutNOPlateNoView.setJpgFile(tempImageSavePath);
                        }
                    };

                    parkingOutNOPlateNoView.setListener(new ParkingOutNOPlateNoView.CPHRefreshListener()
                    {
                        @Override
                        public void InNoCPHRefresh(int laneIndex, String localPath, String networkPath)
                        {
                            L.e("InNoCPHRefresh");
                            GetBinInOut();
                            requestGetParkingInfo();
                            ImageProcessing(localPath, networkPath, laneIndex, false, true, false);

                        }
                    });
                }

                parkingOutNOPlateNoView.show();
            }

            /**
             * 弹出车辆注册界面
             */
            @Override
            public void onClickCarRegisterBtn()
            {
                if (parkingPlateRegisterView == null)
                {
                    parkingPlateRegisterView = new ParkingPlateRegisterViewSub(ParkingMonitoringActivity.this);
                }
                parkingPlateRegisterView.show();
            }

            /**
             * 点击刷新重新获取数据
             */
            @Override
            public void onClickRefreshDetail()
            {
                GetBinInOut();
            }

            /**
             * 点击黑名单按钮
             */
            @Override
            public void onClickBlackListBtn()
            {
                if (formAddBlackListView == null)
                {
                    formAddBlackListView = new FormAddBlackListView(ParkingMonitoringActivity.this);
                }
                formAddBlackListView.show();
            }

            /**
             * 点击弹出期限查询按钮
             */
            @Override
            public void onClickDealLineQueryBtn()
            {
                if (reportDealLineView == null)
                {
                    reportDealLineView = new ReportDealLineView(ParkingMonitoringActivity.this);
                }
                reportDealLineView.show();
            }

            /**
             * 点击弹出换班登录按钮
             */
            @Override
            public void onClickShiftLoginBtn()
            {
                if (parkingChangeShifts == null)
                {
                    parkingChangeShifts = new ParkingChangeView(ParkingMonitoringActivity.this)
                    {
                        @Override
                        protected void updateStatus(String record)
                        {
                            parkingMonitoringView.showStatusBar(Model.sUserName, Model.sUserCard
                                    , TimeConvertUtils.longToString(Model.dLoginTime), "");
                            parkingMonitoringView.setOperatorHintInfo(record);
                        }
                    };
                }
                parkingChangeShifts.show();
            }

            /**
             * 点击弹出收费记录按钮
             */
            @Override
            public void onClickChargeRecordBtn()
            {
                L.e("点击弹收费记录按钮-------------------------");
                Intent intent = new Intent(ParkingMonitoringActivity.this, ReportCarChargeActivity.class);
                startActivity(intent);
            }

            /**
             * 点击弹出场内车辆按钮
             */
            @Override
            public void onClickGroundVehicleBtn()
            {
                L.e("点击弹出场内车辆按钮-------------------------");
                Intent intent = new Intent(ParkingMonitoringActivity.this, ReportInParkActivity.class);
                startActivity(intent);
            }

            /**
             * 退出系统时触发的操作
             */
            @Override
            public void onClickExitSystem()
            {
                ParkingMonitoringActivity.this.finish();
            }

            @Override
            protected void onGetCtrlTime()
            {
                super.onGetCtrlTime();
                new Thread(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        final String time = getTime();
                        mHandler.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                T.showLong(ParkingMonitoringActivity.this, time);
                            }
                        });
                    }
                }).start();
            }

            @Override
            protected void onClickOpen(int index)
            {
                T.showShort(ParkingMonitoringActivity.this, "onClickOpen：" + index);
                if (parkingOpenView == null)
                {
                    parkingOpenView = new ParkingOpenView(ParkingMonitoringActivity.this);
                }
                parkingOpenView.show();
            }

            @Override
            protected void onClickClose(int index)
            {
                MessageBox.show(ParkingMonitoringActivity.this, "确定关闸吗？ 【通道为" + index + "】", "关闸");
            }

            @Override
            protected void onManualOperate(int index)
            {
                T.showShort(ParkingMonitoringActivity.this, "手动触发【" + index + "】");
            }
        };

        application = (BaseApplication) getApplication();

        if (mList == null)
        {
            mList = new ArrayList<>();
        }

        tcpsdk.getInstance().setup();

        initView(savedInstanceState); // 这个地方需要优化

        initFields();
        initControl();

        startAliveTime = System.currentTimeMillis();
        mHandler.sendEmptyMessageDelayed(MSG_KeppAlive, KEEYALIVE_SENCONDS);// 心跳

        exe = new ExeUtil();
        queueTask = new QueueTask(true);// 对于队列中数据的处理，还是重新开始测试;
        queueTask.start();

        initEasyThread();// 如果是使用多线程，则这里使用线程池来做

        initTimerUpdateStatusTime();

        //开启对于图片删除进行管理
        delImageTaskThread = new DelImageTaskThread();
        delImageTaskThread.start();

        base64Cipher = new Base64Cipher();
        // 开启线程进行脱机车牌的处理
        downloadOffLineCardThread = new DownloadOffLineCardThread();
        downloadOffLineCardThread.start();
    }

    /**
     * 自动更改屏机号
     */
    private void AutoModiPingJH()//这个不做了
    {
        for (int i = 0; i < Model.iChannelCount; i++)
        {
            String IP = Model.Channels[i].sIP;
            String rtnStr = "";
            if (Model.Channels[i].iXieYi == 1)//TCP发送
            {
                if (RegexUtil.checkIpAddress(IP))//解析IP正确是否
                {
                    // 将数据放到队列中，保持其线性执行
                    byte JiHao = (byte) (Model.Channels[i].iCtrlID & 0xff);
                    byte byteCmd = 0x42;
                    byte[] Data = CR.GetByteArray("01" + "01");
                    int flag = 1;
//                    rtnStr = sendbll.DisplayCmdX1(Convert.ToByte(Model.Channels[i].iCtrlID), 0x42, CR.GetByteArray(Convert.ToInt32(1).ToString("X2") + Convert.ToInt32(1).ToString("X2")), 1);
                }
                else
                {
                    //MessageBox.Show("输入的IP不正确！", Language.LanguageXML.GetName("CR/Prompt"));
                }
            }
        }
    }

    // 下载脱机车牌
    public class DownloadOffLineCardThread extends Thread
    {
        private boolean downloadFlag = false;
        private int iCartCount = 0;
        private int DecCount = 0;
        private int iDownloadTmp = 0;
        private int timeCount = 0;


        public DownloadOffLineCardThread()
        {
            downloadFlag = true;
        }

        private boolean checkIsEnd()
        {
            return downloadFlag;
        }

        @Override
        public void run()
        {
            super.run();
            while (downloadFlag)// 不断循环定时的下载脱机车牌
            {
                SystemClock.sleep(800);
                runTimerTask();
            }

            L.e("DownloadOffLineCardThread run end...................");
        }

        private void runTimerTask()
        {
            try
            {
                iCartCount++;
                if (iCartCount > 60)
                {
                    GetBinInOut();
                    iCartCount = 0;
                }
                DecCount++;

                if (Model.Quit_Flag == false)// 起到什么作用
                {
                    return;
                }
                if (Model.OverCharge_Flag == true)// // 起到什么作用
                {
                    return;
                }

                if (DecCount > 120)
                {
//                if (Model.bZhuCe) // 这个没用
//                {
//                    if (CR.IsTime(Model.strTmpInTime))
//                    {
//                        DateTime dtStart = Convert.ToDateTime("2014-06-27 00:00:00");
//                        DateTime dtEnd = Convert.ToDateTime(Model.strTmpInTime);
//                        if (DateTime.Now > dtEnd)
//                        {
//                            fThread.Abort();
//                            fThreadtimer3.Abort();
//                            MessageBox.Show("系统数据溢出 DH ！", "提示");
//                            System.Windows.Forms.Application.ExitThread();
//                        }
//                    }
//                }
                    DecCount = 0;
                    //DogDetection();
                }

                lostFlag++;
                iDownloadTmp++;
                timeCount++;
                if (iDownloadTmp > 20)
                {
                    iDownloadTmp = 0;
                    if (Model.strKZJ.equals("1") && Model.bIsKZB && Model.iTempDown == 0)// 什么时候触发呢?
                    {
                        L.e("Model.strKZJ.equals(\"1\") && Model.bIsKZB && Model.iTempDown == 0");
                        TempDownLoad();//下载脱机临时车 -- 服务写死了 Model.iTempDown == 1,所以现在这里没有执行了
                    }
                }

                if (lostFlag > 20)
                {
                    L.e("lostFlag > 20");
                    loadCar();
                    mHandler.post(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            parkingMonitoringView.setOperatorHintInfo("");
                        }
                    });
                    lostFlag = 0;
                }
//            L.e("timeCount:" + timeCount + ",Model.iLoadTimeType:" + Model.iLoadTimeType +
//                    ",bIsKZB:" + Model.bIsKZB + ",Model.strKZJ:" + Model.strKZJ);

                if (timeCount >= Model.iLoadTimeInterval * 60 || Model.iLoadTimeType == 0)
                {
                    if (Model.strKZJ.equals("1") && Model.bIsKZB)// 脱机车牌的下载
                    {
                        L.e("NewDownCPHCard..................");
                        NewDownCPHCard(ParkingDownCardActvity.DownTypeEnum.CardIssue); // 下载各种类型
//                        if (!checkIsEnd()) return;//方便快速结束任务
                        NewDownCPHCard(ParkingDownCardActvity.DownTypeEnum.CardLoss); // 下载各种类型
//                        if (checkIsEnd()) return;
                        NewDownCPHCard(ParkingDownCardActvity.DownTypeEnum.ErrorCPH); // 下载各种类型
//                        if (checkIsEnd()) return;
                        NewDownCPHCard(ParkingDownCardActvity.DownTypeEnum.BlackListIssue); // 下载各种类型
//                        if (checkIsEnd()) return;
                        NewDownCPHCard(ParkingDownCardActvity.DownTypeEnum.BlackListLoss); // 下载各种类型
//                        if (checkIsEnd()) return;
                    }

                    L.e("System.currentTimeMillis() - loadTime:" + (System.currentTimeMillis() - loadTime));
                    L.e("1000 * Model.iLoadTimeInterval:" + (1000 * Model.iLoadTimeInterval));
                    if (System.currentTimeMillis() - loadTime >= 1000 * Model.iLoadTimeInterval) // 只有指定的时间，将获取服务器时间
                    {
                        String serverTime = HttpPostRequest.getServerTime();
                        if (serverTime != null)
                        {
                            L.e("serverTime:" + serverTime); // 2017-06-21 17:02:10

                            long stringToLong = TimeConvertUtils.stringToLong(serverTime);
                            String longToString = TimeConvertUtils.longToString("yyyyMMdd.HHmmss", stringToLong);
//                        String format = String.format("%d%d%d-%d%d%d", arrayDate[0], arrayDate[1], arrayDate[2], arrayDate[3], arrayDate[4], arrayDate[5]);
                            L.e("aa format:" + longToString);
                            CallNative.getInstance().setSystemTime(longToString);
                        }
//                CR.SetSysTime(gsd.GetSysTime()); // 设置当前系统的时间 可以暂时的后面
                        AutoAddDate(); // 校准主板时间
                        loadTime = System.currentTimeMillis();
                    }
                    Model.iLoadTimeType = 1; // 这个条件不是很重要的;
                    timeCount = 0;
                }
            }
            catch (Exception ex)
            {
                ex.printStackTrace();
            }
        }

        public void endDownLoad()
        {
            downloadFlag = false;
        }
    }

    private void AutoAddDate()
    {
        setTime();
    }

    private void NewDownCPHCard(ParkingDownCardActvity.DownTypeEnum downTypeEnum)
    {
        switch (downTypeEnum)
        {
            case CardIssue:
                List<GetPlateNumberDownCardIssueResp.Bean> lstCard = HttpPostRequest.getPlateNumberDownCmdByCardIssue();
                if (lstCard == null)
                {
                    return;
                }
                for (int i = 0; i < lstCard.size(); i++)
                {
                    String oldstr = "";
                    String newstr = "";
                    String ret = "";
                    for (int j = 0; j < lstCard.get(i).getLstCDS().size(); j++)
                    {
                        oldstr += "1";
                        GetCheDaoSetResp.DataBean dataBean = lstCard.get(i).getLstCDS().get(j);

                        if (dataBean.DownCmdList.size() > 0)
                        {
                            // 需要对其返回值来处理，所以还是采用全局封装更好; // TODO
                            ret = SendDownCmd(dataBean.getIP(), base64Cipher.decrypt(dataBean.DownCmdList.get(0).getBytes()));
//                            ret = sendbll.SendDownCmd(lstCard[i].lstCDS[j].IP, lstCard[i].lstCDS[j].CtrlNumber, lstCard[i].lstCDS[j].DownCmdList[0], lstCard[i].lstCDS[j].XieYi);
                            if (ret.equals("0"))
                            {
                                newstr += "1";
                            }
                        }
                    }

                    if (oldstr.equals(newstr))
                    {
                        String sumBiao = lstCard.get(i).getModel().getCPHDownloadSignal().substring(0, Model.stationID - 1) + lstCard.get(i).getModel().getCPHDownloadSignal().substring(Model.stationID);
                        HttpPostRequest.requestUpdateCPHDownLoad((int) lstCard.get(i).getModel().getID(), sumBiao);
                    }
                }
                break;
            case CardLoss:
                List<GetPlateNumberDownCardIssueResp.Bean> cardLoss = HttpPostRequest.getPlateNumberDownCmdByCardLoss();
                if (cardLoss == null)
                {
                    return;
                }
                for (int i = 0; i < cardLoss.size(); i++)
                {
                    String oldstr = "";
                    String newstr = "";
                    String ret = "";
                    for (int j = 0; j < cardLoss.get(i).getLstCDS().size(); j++)
                    {
                        oldstr += "1";
                        GetCheDaoSetResp.DataBean dataBean = cardLoss.get(i).getLstCDS().get(j);

                        if (dataBean.DownCmdList.size() > 0)
                        {
                            ret = SendDownCmd(dataBean.getIP(), base64Cipher.decrypt(dataBean.DownCmdList.get(0).getBytes()));
//                            ret = sendbll.SendDownCmd(lstCard[i].lstCDS[j].IP, lstCard[i].lstCDS[j].CtrlNumber, lstCard[i].lstCDS[j].DownCmdList[0], lstCard[i].lstCDS[j].XieYi);
                            if (ret.equals("0"))
                            {
                                newstr += "1";
                            }
                        }
                    }

                    if (oldstr.equals(newstr))
                    {
                        String sumBiao = cardLoss.get(i).getModel().getCPHDownloadSignal().substring(0, Model.stationID - 1) + cardLoss.get(i).getModel().getCPHDownloadSignal().substring(Model.stationID);
                        HttpPostRequest.requestUpdateCPHDownLoad((int) cardLoss.get(i).getModel().getID(), sumBiao);
                    }
                }
                break;
            case ErrorCPH:
                List<GetPlateNumberDownTempLoadResp.Bean> plateNumberDownCmdByErrorCPH = HttpPostRequest.getPlateNumberDownCmdByErrorCPH();
                if (plateNumberDownCmdByErrorCPH == null)
                {
                    return;
                }
                for (int i = 0; i < plateNumberDownCmdByErrorCPH.size(); i++)
                {
                    String oldstr = "";
                    String newstr = "";
                    for (int j = 0; j < plateNumberDownCmdByErrorCPH.get(i).getLstCDS().size(); j++)
                    {
                        oldstr += "1";
                        GetCheDaoSetResp.DataBean dataBean = plateNumberDownCmdByErrorCPH.get(i).getLstCDS().get(j);
                        String ret = "";
                        if (dataBean.DownCmdList.size() > 0)
                        {
                            ret = SendDownCmd(dataBean.getIP(), base64Cipher.decrypt(dataBean.DownCmdList.get(0).getBytes()));
//                            ret = sendbll.SendDownCmd(lstCard[i].lstCDS[j].IP, lstCard[i].lstCDS[j].CtrlNumber, lstCard[i].lstCDS[j].DownCmdList[0], lstCard[i].lstCDS[j].XieYi);
                            if (ret.equals("0"))
                            {
                                newstr += "1";
                            }
                        }
                    }

                    if (oldstr.equals(newstr))
                    {
                        String sumBiao = plateNumberDownCmdByErrorCPH.get(i).getModel().getDownloadSignal().substring(0, Model.stationID - 1)
                                + plateNumberDownCmdByErrorCPH.get(i).getModel().getDownloadSignal().substring(Model.stationID);
                        HttpPostRequest.requestUpdateAutoCPHDownLoad((int) plateNumberDownCmdByErrorCPH.get(i).getModel().getID(), sumBiao);
                    }
                }
                break;
            case BlackListIssue:
                List<GetPlateNumberDownBlackListResp.Bean> blacklistIssue = HttpPostRequest.getPlateNumberDownCmdByBlacklistIssue();
                if (blacklistIssue == null)
                {
                    return;
                }
                for (int i = 0; i < blacklistIssue.size(); i++)
                {
                    String oldstr = "";
                    String newstr = "";
                    for (int j = 0; j < blacklistIssue.get(i).getLstCDS().size(); j++)
                    {
                        oldstr += "1";
                        GetCheDaoSetResp.DataBean dataBean = blacklistIssue.get(i).getLstCDS().get(j);
                        String ret = "";
                        if (dataBean.DownCmdList.size() > 0)
                        {
                            ret = SendDownCmd(dataBean.getIP(), base64Cipher.decrypt(dataBean.DownCmdList.get(0).getBytes()));
//                            ret = sendbll.SendDownCmd(lstCard[i].lstCDS[j].IP, lstCard[i].lstCDS[j].CtrlNumber, lstCard[i].lstCDS[j].DownCmdList[0], lstCard[i].lstCDS[j].XieYi);
                            if (ret.equals("0"))
                            {
                                newstr += "1";
                            }
                        }
                    }

                    if (oldstr.equals(newstr))
                    {
                        String sumBiao = blacklistIssue.get(i).getModel().getDownloadSignal().substring(0, Model.stationID - 1)
                                + blacklistIssue.get(i).getModel().getDownloadSignal().substring(Model.stationID);
                        HttpPostRequest.requestBlackListDownload((int) blacklistIssue.get(i).getModel().getID(), sumBiao);
                    }
                }
                break;
            case BlackListLoss:
                List<GetPlateNumberDownBlackListResp.Bean> blacklistLoss = HttpPostRequest.getPlateNumberDownCmdByBlacklistLoss();
                if (blacklistLoss == null)
                {
                    return;
                }
                for (int i = 0; i < blacklistLoss.size(); i++)
                {
                    String oldstr = "";
                    String newstr = "";
                    for (int j = 0; j < blacklistLoss.get(i).getLstCDS().size(); j++)
                    {
                        oldstr += "1";
                        GetCheDaoSetResp.DataBean dataBean = blacklistLoss.get(i).getLstCDS().get(j);
                        String ret = "";
                        if (dataBean.DownCmdList.size() > 0)
                        {
                            ret = SendDownCmd(dataBean.getIP(), base64Cipher.decrypt(dataBean.DownCmdList.get(0).getBytes()));
//                            ret = sendbll.SendDownCmd(lstCard[i].lstCDS[j].IP, lstCard[i].lstCDS[j].CtrlNumber, lstCard[i].lstCDS[j].DownCmdList[0], lstCard[i].lstCDS[j].XieYi);
                            if (ret.equals("0"))
                            {
                                newstr += "1";
                            }
                        }
                    }

                    if (oldstr.equals(newstr))
                    {
                        String sumBiao = blacklistLoss.get(i).getModel().getDownloadSignal().substring(0, Model.stationID - 1) + "0" + blacklistLoss.get(i).getModel().getDownloadSignal().substring(Model.stationID);
                        if (sumBiao.equals(CR.stringPadLeft("", sumBiao.length(), '0')))
//                if (sumBiao == ("").PadLeft(sumTBiao.Length, '0'))
                        {
//                    gsd.DeleteMYBlacklist(lstBL[i].model.ID);
                            HttpPostRequest.requestDeleteMyBlacklist((int) blacklistLoss.get(i).getModel().getID());
                        }
                        else
                        {
                            HttpPostRequest.requestBlackListDownload((int) blacklistLoss.get(i).getModel().getID(), sumBiao);
                        }
                    }
                }
                break;
            default:
                break;
        }
    }

    /**
     * 加载车位
     */
    private void loadCar()
    {
        requestGetParkingInfo();
    }

    private void deleteSubCarNo(List<GetAutoTempDownLoadResp.DataBean> autoTempDownLoad)
    {
        if (autoTempDownLoad == null || autoTempDownLoad.size() == 0)
        {
            L.e("autoTempDownLoad == null || autoTempDownLoad.size() == 0");
            return;
        }

        for (GetAutoTempDownLoadResp.DataBean item : autoTempDownLoad)
        {
            int biaozhi = Model.stationID;//需要替换的标志位
            String strbiaozhi = item.getDownloadSignal();
            String strCPH = item.getCPH();
            String sumBiao = "";
            String str1 = strbiaozhi.substring(0, biaozhi - 1);
            String str2 = strbiaozhi.substring(biaozhi);
            sumBiao = str1 + "0" + str2;

            String strSum = "";
            String strDownSum = "";

            for (int j = 0; j < Model.iChannelCount; j++)
            {
                if (Model.Channels[j].iInOut == 1)//判断这张卡片是否发行这个车道
                {
                    strSum += "1";
                    String a = "";
                    if (Model.Channels[j].iXieYi == 1)
                    {
                        DownTempCPHModel downTempCPHModel = new DownTempCPHModel();
                        downTempCPHModel.strCPH = strCPH;
                        downTempCPHModel.strInTime = item.getInTime();
                        downTempCPHModel.iOptType = 1; // 0表示加载，1表示删除
                        CR.sendModeToQueue(QueueMessageTypeEnum.queue_DownLoadToTempCPH, downTempCPHModel, j);
                    }


                    if (a.equals("0"))
                    {
                        strDownSum += "1";
                        //Ibll.UpdateDownLoad(CarNO, sumBiao);
                    }
                }
            }

            if (strSum.equals(strDownSum))
            {
                if (sumBiao.equals("000000000000000"))
                {
//                        gsd.DeleteTemp(strCPH);
                    HttpPostRequest.DeleteTemp(strCPH);
                }
                else
                {
                    HttpPostRequest.UpdateTempDownLoad(strCPH, sumBiao);
//                        gsd.UpdateTempDownLoad(strCPH, sumBiao);
                }
            }
        }
    }

    private void loadSubCarNo(List<GetAutoTempDownLoadResp.DataBean> tempDownLoad)
    {
        if (tempDownLoad == null || tempDownLoad.size() == 0)
        {
            L.e("tempDownLoad == null || tempDownLoad.size() == 0");
            return;
        }

        for (GetAutoTempDownLoadResp.DataBean temp : tempDownLoad)
        {
            int biaozhi = Model.stationID;//需要替换的标志位
            String strbiaozhi = temp.getDownloadSignal();
            String sumBiao = "";
            String str1 = strbiaozhi.substring(0, biaozhi - 1);
            String str2 = strbiaozhi.substring(biaozhi);
            sumBiao = str1 + "1" + str2;
            String strCPH = temp.getCPH();

            String strSum = "";
            String strDownSum = "";

            for (int j = 0; j < Model.iChannelCount; j++)
            {
                if (Model.Channels[j].iInOut == 1)//判断这张卡片是否发行这个车道
                {
                    strSum += "1";
                    String a = "";
                    if (Model.Channels[j].iXieYi == 1)
                    {
                        DownTempCPHModel downTempCPHModel = new DownTempCPHModel();
                        downTempCPHModel.strCPH = strCPH;
                        downTempCPHModel.strInTime = temp.getInTime();
                        downTempCPHModel.iOptType = 0;
                        CR.sendModeToQueue(QueueMessageTypeEnum.queue_DownLoadToTempCPH, downTempCPHModel, j);
                    }
                    else
                    {
                        a = "0";
                    }

                    if (a.equals("0"))
                    {
                        strDownSum += "1";
                    }
                }
            }

            if (strSum.equals(strDownSum))
            {
                if (sumBiao.equals("000000000000000"))
                {
//                        gsd.DeleteTemp(strCPH);
                    HttpPostRequest.DeleteTemp(strCPH);
                }
                else
                {
                    HttpPostRequest.UpdateTempDownLoad(strCPH, sumBiao);
//                        gsd.UpdateTempDownLoad(strCPH, sumBiao);
                }
            }
        }
    }

    private void TempDownLoad() //
    {
        HttpPostRequest.GetDeleteTemp(); // //统计容量

        List<GetAutoTempDownLoadResp.DataBean> autoTempDownLoad = HttpPostRequest.getAutoTempDownLoad(Model.stationID, 1, 1);//删除下位机卡号
        deleteSubCarNo(autoTempDownLoad);

        List<GetAutoTempDownLoadResp.DataBean> tempDownLoad = HttpPostRequest.getAutoTempDownLoad(Model.stationID, 0, 0);  //加载临时卡 卡号
        loadSubCarNo(tempDownLoad);
    }

    private int diffMinutes(long currTime, int setHours)
    {
        return 0;
    }

    private long LastDelImageDate = 0L;

    private DelImageTaskThread delImageTaskThread;

    private class DelImageTaskThread extends Thread
    {
        private boolean runningFlag = false;

        public DelImageTaskThread()
        {
            runningFlag = true;
        }

        @Override
        public void run()//可以做成一个服务;
        {
            CR.checkImagePath(ParkingMonitoringActivity.this);
            String dirFullName = "";  //完整路径的目录名
            String dirName = Model.sImageSavePath + Model.stationID;

            while (runningFlag)
            {
                SystemClock.sleep(1000 * 6);
                long currentTimeMillis = System.currentTimeMillis();
                if (!TimeConvertUtils.isSameDay(currentTimeMillis, LastDelImageDate))
                {
                    int diffMinutes = diffMinutes(currentTimeMillis, Model.iImageAutoDelTime);
                    if (diffMinutes > 0 && diffMinutes <= 30) // //相差30分钟以内才执行
                    {
                        //对于目录 CaptureImage/1/20170509/XXX.jpg
                        File file = new File(dirName);
                        if (!file.exists())
                        {
                            continue;
                        }

                        File[] files = file.listFiles();
                        for (File o : files)
                        {
                            if (o.isFile())
                            {
                                long yyyyMMddHH = TimeConvertUtils.stringToLong("yyyyMMddHH", o.getName());
                                if (currentTimeMillis - yyyyMMddHH > Model.iImageSaveDays * 60 * 60 * 24 * 1000)
                                {
                                    o.delete();
                                }
                            }
                        }
                    }
                }
                else
                {
                    LastDelImageDate = currentTimeMillis;
                }

            }
            L.e("DelImageTaskThread run end...................");
        }

        void setEnd()
        {
            runningFlag = false;
        }
    }


    /**
     * 定时的更新系统时间
     */
    private void initTimerUpdateStatusTime()
    {
        mHandler.postDelayed(new Runnable()
        {
            @Override
            public void run()
            {
                parkingMonitoringView.setSystemTime(TimeConvertUtils.longToString(System.currentTimeMillis()));
                initTimerUpdateStatusTime();
            }
        }, 1000);
    }

    private void executeByThreadPools(String threadName, ThreadCallback threadCallback, Runnable runnable)
    {
        if (executor == null) return;
        executor.name(threadName)
                .callback(threadCallback)
                .execute(runnable);
    }

    private void executeByThreadPools(String threadName, Callback callback, Runnable runnable)
    {
        if (executor == null) return;
        executor.name(threadName)
                .callback(callback)
                .execute(runnable);
    }

    private void initEasyThread()
    {
        executor = EasyThread.Builder
                .fixed(Runtime.getRuntime().availableProcessors() * 2 + 1) // cpu的效率得到最大程度执行
                .priority(Thread.MAX_PRIORITY)
                .name("thread name")
                .build();
    }

    private int getCtrlIndexByInoutName(String currentText)
    {
        int resultValue = -1;
        for (int i = 0; i < Model.iChannelCount; i++)
        {
            if (Model.Channels[i].sInOutName.equals(currentText))
            {
                resultValue = i;
                break;
            }
        }
        return resultValue;
    }

    @NonNull
    private List<String> getInOutListNameByType(int type)
    {
        ArrayList<String> strings = new ArrayList<>();
        for (int i = 0; i < Model.iChannelCount; i++)
        {
            if (Model.Channels[i].iInOut == type)
            {
                strings.add(Model.Channels[i].sInOutName);
            }
        }
        return strings;
    }

    private SetCarOutReq initSetCarOutReq(String cph, int ctrlNumber)
    {
        SetCarOutReq req = new SetCarOutReq(); // 发送进场数据
        req.setCPH(cph);
        req.setToken(Model.token);
        req.setCtrlNumber(ctrlNumber);
        req.setStationId(Model.stationID);
        return req;
    }

    private int getChannelIndex(int type)
    {
        int resultValue = -1;
        for (int i = 0; i < Model.iChannelCount; i++)
        {
            if (Model.Channels[i].iInOut == type)
            {
                resultValue = i;
                break;
            }
        }
        return resultValue;
    }

    private void initView(@Nullable Bundle savedInstanceState)
    {
        // 初始化按钮颜色
        parkingMonitoringView.onClickInCarChargeInfo();
        parkingMonitoringView.onClickInCarInParkingDetail();

        // 初始化fragment
        initFragment(savedInstanceState); // 这个地方还是影响！！！
    }


    /**
     * 根据无牌车返回的数据，提示发送语音
     */
    private void dealCarInWithOutCPH(SetCarInWithoutCPHResp resp, int index)
    {
        RCodeEnum rCodeEnum = RCodeEnum.valueOf(Integer.parseInt(resp.getRcode()));
        final SetCarInWithoutCPHResp.DataBean dataBean = resp.getData();

        L.i(resp.toString());

        if (!strReadPicFileJpg[index].equals(""))
            filesJpg = strReadPicFileJpg[index];

        switch (rCodeEnum)
        {
            case OK:
            case RepeatAdmission:
                //开闸发语音
                CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_OPENGATE, null, index);
                CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_REPEATADMISSION, ConstantClass.VoiceEnum.WelCome, index);
//                cmd.VoiceDisplay(VoiceType.Welcome, laneIndex);
                InNoCPHHandler(index, filesJpg, dataBean.getImagePath());
                break;
            case SummaryCarFull:
            {
                MessageBox.show(ParkingMonitoringActivity.this, "车位已满!");
                break;
            }
            default:
            {
                MessageBox.show(ParkingMonitoringActivity.this, resp.getMsg());
                break;
            }
        }
    }


    private void InNoCPHHandler(int laneIndex, String localPath, String networkPath)
    {
        RefreshInOut();

        if (null != localPath && localPath.length() > 0)
        {
            if (new File(localPath).exists())
            {
                String fileName = moveFile(localPath, networkPath);
                ImageProcessing(fileName, networkPath, laneIndex, false, true, false);
            }
        }
    }

    /**
     * 根据车辆进场，提示发送语音数据和开闸
     * 注意返回数据的车牌和原始的车牌号可能不同
     *
     * @param setCarInResp
     */
    private boolean dealSetCarInResponse(final SetCarInResp setCarInResp, final String srcCPH, final int index, final PlateColorEnum colorType)
    {
        if (index < 0 || index > Model.iChannelCount - 1)
        {
            return false;
        }

        try
        {
            if (!strReadPicFileJpg[index].equals(""))
                filesJpg = strReadPicFileJpg[index]; //注意 strReadPicFileJpg在什么复制???

            L.e("filesJpg:" + filesJpg);
            parkingMonitoringView.setCPHText(index, srcCPH);

            RCodeEnum rCodeEnum = RCodeEnum.valueOf(Integer.parseInt(setCarInResp.getRcode()));
            SetCarInResp.DataBean carIn = setCarInResp.getData();

            boolean isMonthBeOverdue = false;
            boolean isMonthFull = false;

            switch (rCodeEnum)
            {
                case BlackList:// [车牌号] 禁止入场请与管理处联系
                {
                    String detectString = CR.prepareDetectString(carIn.getCPH(), srcCPH); // 需要作一些临时性的处理
                    updateCarHintToFragment(MSG_CarHintInfoAfterResume
                            , detectString + ":" + CR.prepareDetectString(carIn.getBlackReason(), ""));
                    String chineseCPH = DeviceStringTool.GetChineseCPH(detectString) + "D2AF";
                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_BLACKLIST, chineseCPH, index);
                    return false;
                }
                case NoThisLanePermission:// 无授权请与管理处联系
                {
                    updateCarHintToFragment(MSG_CarHintInfoAfterResume, "在 " + carIn.getCtrlNumber() + " 号机上无权限！");
                    parkingMonitoringView.setOperatorHintInfo(carIn.getCtrlNumber() + " 号机上无权限!");
                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_NOTHISLANEPERMISSION, ConstantClass.VoiceEnum.Invalid, index);
                    return false;
                }
                case BeOverdue://已过期请与管理处联系
                {
                    parkingMonitoringView.setCPHText(index, CR.prepareDetectString(carIn.getCPH(), srcCPH));
                    parkingMonitoringView.setOperatorHintInfo("已过期，请到管理处延期!");
                    updateCarHintToFragment(MSG_CarHintInfoAfterResume, "已过期，请到管理处延期!");
                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_BEOVERDUE, ConstantClass.VoiceEnum.Overstayed, index);
                    return false;
                }
                case PersonalFull://车位占用禁止入场
                {
                    parkingMonitoringView.setOperatorHintInfo("此车禁止入场，入场车辆数已经超过车位个数");
                    updateCarHintToFragment(MSG_CarHintInfoAfterResume, "此车禁止入场，入场车辆数已经超过车位个数。");
                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_PERSONALFULL, "9ED2", index);
                    return false;
                }
                case ProhibitCurrent://禁止通行，什么时候触发?
                {
                    updateCarHintToFragment(MSG_CarHintInfoAfterResume, "此车已入场[" + carIn.getInOutName() + "]");
                    parkingMonitoringView.setOperatorHintInfo("此车已入场[" + carIn.getInOutName() + "]");
                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_PROHIBITCURRENT, ConstantClass.VoiceEnum.Alreadyadmission, index);
                    return false;
                }
                case ProhibitCutOff://禁止开闸
                {
                    String strsLoad = "";
                    if (Model.Channels[index].iInOut == 0)
                    {
                        if (Model.bAutoTemp)
                        {
                            strsLoad = "ADB6";
                        }
                        else
                        {
                            strsLoad = "ADD2";
                        }
                    }
                    else
                    {
                        strsLoad = "ADD4";
                    }
                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_PROHIBITCUTOFF, strsLoad, index);
                    return false;
                }
                case SummaryCarFull:
                {
                    updateCarHintToFragment(MSG_CarHintInfoAfterResume, "车位已满!");
                    parkingMonitoringView.setOperatorHintInfo("车位已满!");
                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_CARFULL, 5, index);
                    return false;
                }
                case TemporaryCarFull:
                {
                    updateCarHintToFragment(MSG_CarHintInfoAfterResume, "临时车位已满!");
                    parkingMonitoringView.setOperatorHintInfo("临时车位已满!");
                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_CARFULL, 5, index);
                    return false;
                }
                case MonthCarFull:
                {
                    updateCarHintToFragment(MSG_CarHintInfoAfterResume, "月租车位已满!");
                    parkingMonitoringView.setOperatorHintInfo("月租车位已满!");
                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_CARFULL, 5, index);
                    return false;
                }
                case PrepaidCarFull:
                {
                    updateCarHintToFragment(MSG_CarHintInfoAfterResume, "储值车位已满!");
                    parkingMonitoringView.setOperatorHintInfo("储值车位已满!");
                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_CARFULL, 5, index);
                    return false;
                }
                case BalanceNotEnough:
                {
                    updateCarHintToFragment(MSG_CarHintInfoAfterResume, "余额不足，请先充值!");
                    parkingMonitoringView.setOperatorHintInfo("余额不足，请先充值!");
                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_BALANCENOTENOUGH, null, index);
                    return false;
                }
                case AllCharacterSamePlateNoHandle:
                {
                    parkingMonitoringView.setOperatorHintInfo("字符相同的车牌不处理!");
                    return false;
                }
                case AllLetterPlateNoHandle:
                {
                    parkingMonitoringView.setOperatorHintInfo("全字母车牌不处理!");
                    return false;
                }
                case TemporaryCarNotInSmall:
                {
                    updateCarHintToFragment(MSG_CarHintInfoAfterResume, "临时车禁止驶入小车场!");
                    parkingMonitoringView.setOperatorHintInfo("临时车禁止驶入小车场!");

                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_TEMPORARYCARNOTINSMALL, "ADD2", index);

                    AddOptLogReq addOptLogReq = CR.initAddOptLog("在线监控:FillOutData", "临时车禁止驶入小车场" + carIn.getCardNO());
                    String resultUrl = GetServiceData.getResultUrl(METHOD_ADDOPTLOG, addOptLogReq);
                    LoadController controller = RequestManager
                            .getInstance()
                            .get(resultUrl, new GsonCallback<>(AddOptLogResp.class, this, addOptLogReq, resultUrl, index));
                    mList.add(controller);
                    return false;
                }
                case ConfirmCutOff:
                {
                    ShowImage(index, carIn.getImagePath());

                    popuTempCPHView(setCarInResp, srcCPH, "确定开闸", index, colorType.getColorValue(), filesJpg);

                    String substring = carIn.getCardType().substring(0, 3);
                    String loadField = "";
                    if (substring.equals("Mth"))
                    {
                        loadField = "ABD3";
                    }
                    else if (substring.equals("Tmp") || substring.equals("Mtp"))
                    {
                        loadField = "ADD3";
                    }

                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_CONFIRMCUTOFF, loadField, index);
                    return false;
                }
                case MonthCarFullConfirmCutOff:
                {
                    ShowImage(index, carIn.getImagePath());
                    updateCarHintToFragment(MSG_CarHintInfoAfterResume, "月租车位已满!");
                    popuTempCPHView(setCarInResp, srcCPH, "车场满位，确定开闸", index, colorType.getColorValue(), filesJpg);
                    parkingMonitoringView.setOperatorHintInfo("月租车位已满!");
                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_CARFULLCONFIRMCUTOFF, 5, index);
                    return false;
                }
                case TemporaryCarFulllConfirmCutOff:
                {
                    updateCarHintToFragment(MSG_CarHintInfoAfterResume, "临时车位已满!");
                    parkingMonitoringView.setOperatorHintInfo("临时车位已满!");
                    popuTempCPHView(setCarInResp, srcCPH, "车场满位，确定开闸", index, colorType.getColorValue(), filesJpg);
                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_CARFULLCONFIRMCUTOFF, 5, index);
                    return false;
                }
                case PrepaidCarFullConfirmCutOff:
                {
                    updateCarHintToFragment(MSG_CarHintInfoAfterResume, "储值车位已满!");
                    parkingMonitoringView.setOperatorHintInfo("储值车位已满!");

                    popuTempCPHView(setCarInResp, srcCPH, "车场满位，确定开闸", index, colorType.getColorValue(), filesJpg);
                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_CARFULLCONFIRMCUTOFF, 5, index);
                    return false;
                }
                case SummaryCarFullConfirmCutOff:
                {
                    updateCarHintToFragment(MSG_CarHintInfoAfterResume, "车位已满!");
                    parkingMonitoringView.setOperatorHintInfo("车位已满!");
                    popuTempCPHView(setCarInResp, srcCPH, "车场满位，确定开闸", index, colorType.getColorValue(), filesJpg);
                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_CARFULLCONFIRMCUTOFF, 5, index);
                    return false;
                }
                case MthBeOverdueToTmpCharge:
                {
                    updateCarHintToFragment(MSG_CarHintInfoAfterResume, "已过期,临时车,请通行");
                    parkingMonitoringView.setOperatorHintInfo("已过期,临时车,请通行");
                    CR.sendModeToQueue(QueueMessageTypeEnum.queue_MthBeOverdueToTmpCharge, "6CADAC", index);
                    isMonthBeOverdue = true;
                    break;
                }
                case MthFullToTmpCharge:
                {
                    updateCarHintToFragment(MSG_CarHintInfoAfterResume, "车位占用，临时车，请通行");
                    parkingMonitoringView.setOperatorHintInfo("车位占用，临时车，请通行");
                    isMonthFull = true;
                    String strsLoad = DeviceStringTool.GetChineseCPH(carIn.getCPH()) + "9EADAC";
                    CR.sendModeToQueue(QueueMessageTypeEnum.queue_MthBeOverdueToTmpCharge, strsLoad, index);
                    break;
                }
                case RepeatAdmission:
                {
                    updateCarHintToFragment(MSG_CarHintInfoAfterResume, "重复入场");
                    break;
                }
                case OK:
                {
                    break;
                }
                default:
                {
                    L.e("no find type:" + setCarInResp.getRcode());

                    MessageBox.show(ParkingMonitoringActivity.this, setCarInResp.getMsg());
                    return false;
                }
            }

            String cardType = carIn.getCardType();
            OpenWayEnum openWayEnum = OpenWayEnum.valueOf(Integer.parseInt(carIn.getOpenMode()));
            if (cardType.length() > 3)
            {
                String strCardCW = carIn.getCarPlace() == null ? "" : carIn.getCarPlace();
                if ((
                        cardType.substring(0, 3).equals("Mth")
                                || cardType.substring(0, 3).equals("Str")
                                || cardType.substring(0, 3).equals("Fre")
                ) && openWayEnum == OpenWayEnum.AutoCutOff)
                {
                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_OPENGATE, null, index);
                    if (isMonthBeOverdue || isMonthFull)
                    {
                    }
                    else
                    {
                        if (strCardCW.equals(""))
                        {
                            strCardCW = "FFFF";
                        }
                        if (strCardCW.length() != 4)
                        {
                            String CarCW = strCardCW;
                            for (int i = 0; i < 4 - strCardCW.length(); i++)
                            {
                                CarCW = "0" + CarCW;
                            }
                            strCardCW = CarCW.substring(CarCW.length() - 4, CarCW.length());
                        }
                        LoadLsNoX2010znyktInGateModel inGateModel = new LoadLsNoX2010znyktInGateModel();
                        inGateModel.CarTypeenum = CR.getCardTypeEnum(carIn.getCardType().substring(0, 3));
                        inGateModel.strCPH = carIn.getCPH();
                        inGateModel.strCardCW = strCardCW;
                        inGateModel.CYkDay = carIn.getRemainingDays() < 0 ? 0 : carIn.getRemainingDays();//设置还是有多少天
                        inGateModel.CCzkMoney = (int) carIn.getBalance();
                        inGateModel.bCtrlShowCW = true;
                        inGateModel.iIDNoticeDay = Model.iIDNoticeDay < 0 ? 0 : Model.iIDNoticeDay;//设置播报的日期的限制
                        // 发送入场语音
                        CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_LOADLSNOX2010ZNYKTINGATE, inGateModel, index); // 对于免费车，少于十天不用播报语音，这里需要判断处理
                    }
                }
                else if (cardType.substring(0, 3).equals("Tmp")
                        || cardType.substring(0, 3).equals("Mtp") // 月临车
                    /*|| bReadAuto == true*/) // bReadAuto 表示读卡还是识别???

                {
                    if (openWayEnum == OpenWayEnum.AutoCutOff)
                    {
                        strCardCW = "FFFF";
                        CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_OPENGATE, null, index);//可能出出现超时的情况

                        LoadLsNoX2010znyktInGateModel inGateModel = new LoadLsNoX2010znyktInGateModel();
                        inGateModel.CarTypeenum = CR.getCardTypeEnum(carIn.getCardType().substring(0, 3));
                        inGateModel.strCPH = carIn.getCPH();
                        inGateModel.strCardCW = strCardCW;
                        inGateModel.CYkDay = carIn.getRemainingDays() < 0 ? 0 : carIn.getRemainingDays();
                        inGateModel.CCzkMoney = 0;
                        inGateModel.bCtrlShowCW = true;
                        inGateModel.iIDNoticeDay = Model.iIDNoticeDay < 0 ? 0 : Model.iIDNoticeDay;//设置播报的日期的限制
                        CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_LOADLSNOX2010ZNYKTINGATE, inGateModel, index);// 发送入场语音
                    }
                    else
                    {
                        ShowImage(index, carIn.getImagePath());
                        CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_CONFIRMCUTOFF, "ADD3", index);
                        popuTempCPHView(setCarInResp, srcCPH, "临时车确定开闸", index, colorType.getColorValue(), filesJpg);
                        return true;
                    }
                }
                else if (cardType.substring(0, 3).equals("Mth")
                        && openWayEnum == OpenWayEnum.ConfirmCutOff)
                {
                    ShowImage(index, carIn.getImagePath());
                    popuTempCPHView(setCarInResp, srcCPH, "月租车确定开闸", index, colorType.getColorValue(), filesJpg);
                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_CONFIRMCUTOFF, "ABD3", index);
                    return true;
                }
                if (openWayEnum == OpenWayEnum.NoCutOff && cardType.substring(0, 3).equals("Tmp"))
                {
                }
                else
                {
                    SurplusCPH(index, carIn.getCPH(), carIn.getCardType(), carIn.getRemainingPlaceCount(), carIn.getBalance(), 0);
                }

                if (Model.iPersonVideo == 1)// 人像抓拍
                {
//                    ImageProcessing(filesJpg, carIn.getImagePath(), index, ptr4, true); //
                }
                else
                {
                    ImageProcessing(filesJpg, carIn.getImagePath(), index, true, true, false);
                }

                updateSetCarIn(carIn);
            }
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            MessageBox.show(ParkingMonitoringActivity.this, ex.getMessage() + "\n", "dealSetCarInResponse");
        }
        return true;
    }

    @Override
    public void success(Object reqData, Object respData, String url, int paramInt)
    {
        try
        {
            if (!(respData instanceof KeepAliveResp))
            {
                CR.printGsonResp(reqData, respData, url, paramInt);// 调试
            }

            if (respData instanceof GetCardTypeDefResp)
            {
                GetCardTypeDefResp resp = (GetCardTypeDefResp) respData;
                if (Integer.parseInt(resp.getRcode()) != RCodeEnum.OK.getValue())
                {
                    L.e(resp.getMsg());
                }
                CR.BinDic(resp.getData());
            }
            else if (respData instanceof GetCheDaoSetResp)
            {
                GetCheDaoSetResp getCheDaoSetResp = (GetCheDaoSetResp) respData;
                if (getCheDaoSetResp == null || getCheDaoSetResp.getData() == null)
                {
                    return;
                }
                lstCDS = getCheDaoSetResp.getData();
            }
            else if (respData instanceof GetNetCameraSetResp)//播放相应的视频数据即可
            {
                GetNetCameraSetResp getNetCameraSetResp = (GetNetCameraSetResp) respData;
                int index = paramInt;

                List<GetNetCameraSetResp.DataBean> getNetCameraSetRespData = getNetCameraSetResp.getData();
                if (respData == null || getNetCameraSetRespData.size() == 0) return; // 数据可能为空

                String videoType = getNetCameraSetRespData.get(0).getVideoType();
                switch (videoType)
                {
                    case "ZNYKTY5":
                    {
                        L.i("videoType:" + videoType + " index:" + index);
                        parkingMonitoringView.playVideoByIndex(index, getNetCameraSetRespData.get(0).getVideoIP(), mHandler);
                        break;
                    }
                }
            }
            else if (respData instanceof GetCarInResp)
            {
                GetCarInResp carInResp = (GetCarInResp) respData;
                updateCarInParkingDetail(carInResp.getData());
            }
            else if (respData instanceof GetCarOutResp)
            {
                GetCarOutResp carOutResp = (GetCarOutResp) respData;
                updateCarChargeDetail(carOutResp.getData());
            }
            else if (respData instanceof GetParkingInfoResp)
            {
                getParkingInfoResp = (GetParkingInfoResp) respData;
                if (getParkingInfoResp.getData() == null) return;
                updateGetParkingInfo(getParkingInfoResp.getData());
            }
            else if (respData instanceof SetCarInResp)//入场处理
            {
                SetCarInResp setCarInResp = (SetCarInResp) respData;
                if (setCarInResp == null)
                {
                    return;
                }

                SetCarInReq setCarInReq = (SetCarInReq) reqData;
                boolean returnValue = dealSetCarInResponse(setCarInResp, setCarInReq.getCPH(), paramInt, PlateColorEnum.valueOf(setCarInReq.getCPColor())); // 处理进场的语音处理
                if (returnValue == true)
                {
                    return;
                }
                else
                {
                    strReadPicFileJpg[paramInt] = "";
                    requestGetParkingInfo();
                }
            }
            else if (respData instanceof SetCarOutResp)
            {
                SetCarOutResp carOutResp = (SetCarOutResp) respData;
                if (carOutResp == null || carOutResp.getData() == null)
                {
                    return;
                }

                SetCarOutReq setCarOutReq = (SetCarOutReq) reqData;
                boolean returnValue = dealSetCarOutResponse(carOutResp, setCarOutReq.getCPH(), paramInt, PlateColorEnum.valueOf(setCarOutReq.getCPColor()));//进行出场的处理
                if (returnValue == true)
                {
                    return;
                }
                else
                {
                    strReadPicFileJpg[paramInt] = "";
                    requestGetParkingInfo();
                }
            }
            else if (respData instanceof CancelChargeResp)
            {
                CancelChargeResp chargeResp = (CancelChargeResp) respData;

                if (chargeResp == null) return;
                if (chargeResp.getData() <= 0)
                {
                    MessageBox.show(ParkingMonitoringActivity.this, "取消收费失败！" + "\n" + "btnOK_Click");
                }
            }
            else if (respData instanceof SetCarInWithoutCPHResp)
            {
                SetCarInWithoutCPHResp setCarInWithoutCPHResp = (SetCarInWithoutCPHResp) respData;
                dealCarInWithOutCPH(setCarInWithoutCPHResp, paramInt);
            }
            else if (respData instanceof KeepAliveResp)
            {
                KeepAliveResp keepAliveResp = (KeepAliveResp) respData;
                if (Integer.parseInt(keepAliveResp.getRcode()) != RCodeEnum.OK.getValue())
                {
                    // token失效了
                    mHandler.removeMessages(MSG_KeppAlive);
                    restartLoginUser();
                }
                else
                {
                    // 继续心跳
                    mHandler.sendEmptyMessageDelayed(MSG_KeppAlive, KEEYALIVE_SENCONDS);
                }
            }
            else if (respData instanceof LoginUserResp)
            {
                LoginUserResp loginUserResp = (LoginUserResp) respData;
                if (loginUserResp.getData() == null) return;
                Model.token = loginUserResp.getData().getToken();
                reconnectionCount = 0;
                parkingMonitoringView.setOperatorHintInfo("重连服务成功!");
                mHandler.sendEmptyMessageDelayed(MSG_KeppAlive, KEEYALIVE_SENCONDS);
            }
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            MessageBox.show(ParkingMonitoringActivity.this, ex.toString());
        }
    }

    private int reconnectionCount = 0;

    @Override
    public void error(Object repData, String url, String errorString)
    {
        T.showShort(ParkingMonitoringActivity.this, "连接服务器失败");
        if (repData instanceof LoginUserReq)// 登录失败
        {
            reconnectionCount++;
            parkingMonitoringView.setOperatorHintInfo("服务已断开或网络异常，正在拼命重连,次数：" + reconnectionCount);
            mHandler.postDelayed(new Runnable()
            {
                @Override
                public void run()
                {
                    restartLoginUser();
                }
            }, 5000);
        }
        else if (repData instanceof KeepAliveReq)
        {
            mHandler.removeMessages(MSG_KeppAlive);
            restartLoginUser();
        }
    }

    class SurplusCPHTransmit
    {
        public int laneIndex;
        public String plateNumber;
        public String cardType;
        public int surplusCarCount;
        public float balance;
        public float charge;

        @Override
        public String toString()
        {
            return "SurplusCPHReq{" +
                    "laneIndex=" + laneIndex +
                    ", plateNumber='" + plateNumber + '\'' +
                    ", cardType='" + cardType + '\'' +
                    ", surplusCarCount=" + surplusCarCount +
                    ", balance=" + balance +
                    ", charge=" + charge +
                    '}';
        }
    }

    private void dealSurplusCPHRespData(List<GetLedSettingResp.DataBean> lstLS, SurplusCPHTransmit surplusCPHTransmit)
    {
        if (lstLS == null)
        {
            L.e("dealSurplusCPHRespData: 返回的数据为 lstLS == null");
            return;
        }

        for (GetLedSettingResp.DataBean ls : lstLS)
        {
            String showWay = ls.getShowWay();
            String SendSum, StrSum = "";
            boolean bMW = false;
            if (showWay.contains("3"))
            {
                if (showWay.contains("4"))
                {
                    if (surplusCPHTransmit.plateNumber.length() == 7
                            && surplusCPHTransmit.plateNumber.equals("0000000")
                            && !surplusCPHTransmit.plateNumber.equals("6666666")
                            && !surplusCPHTransmit.plateNumber.equals("京000000")
                            && !surplusCPHTransmit.plateNumber.equals("8888888")
                            && !surplusCPHTransmit.plateNumber.equals(""))
                    {
                        StrSum = surplusCPHTransmit.plateNumber;
                    }
                }
                //不显示车牌
                else
                {
                    int iCoutRemainCar = 0;
                    if (Model.iFreeCardNoInPlace == 1 && surplusCPHTransmit.cardType.substring(0, 3).equals("Fre"))
                    {
                        iCoutRemainCar = surplusCPHTransmit.surplusCarCount;
                    }
                    else
                    {
                        if (Model.Channels[surplusCPHTransmit.laneIndex].iInOut == 0)
                        {
                            iCoutRemainCar = surplusCPHTransmit.surplusCarCount - 1;
                        }
                        else
                        {
                            iCoutRemainCar = surplusCPHTransmit.surplusCarCount + 1;
                        }
                    }

                    if (iCoutRemainCar < 1)
                    {
                        if (ls.getCPHEndStr().equals(""))
                        {
                            if (ls.getPattern().equals("2"))
                            {
//                                StrSum = iCoutRemainCar.ToString("0000"); // 1 ->ToString 0001
                                StrSum = CR.stringPadLeft(String.valueOf(iCoutRemainCar), 4, '0');
                            }
                            else if (ls.getPattern().equals("8"))
                            {
//                                StrSum = "剩余车位:" + iCoutRemainCar.ToString("000");
                                StrSum = "剩余车位:" + CR.stringPadLeft(String.valueOf(iCoutRemainCar), 3, '0');
                            }
                            else
                            {
//                                StrSum = "空车位" + iCoutRemainCar.ToString("000");
                                StrSum = "空车位" + CR.stringPadLeft(String.valueOf(iCoutRemainCar), 3, '0');
                            }
                        }
                        else
                        {
//                            StrSum = ls.getCPHEndStr() + iCoutRemainCar.ToString("000");
                            StrSum = ls.getCPHEndStr() + CR.stringPadLeft(String.valueOf(iCoutRemainCar), 3, '0');
                        }
                    }
                }
            }
            else
            {
                if (showWay.contains("4"))
                {
                    if (surplusCPHTransmit.plateNumber.length() == 7
                            && !surplusCPHTransmit.plateNumber.equals("0000000")
                            && !surplusCPHTransmit.plateNumber.equals("6666666")
                            && !surplusCPHTransmit.plateNumber.equals("京000000")
                            && !surplusCPHTransmit.plateNumber.equals("8888888")
                            && !surplusCPHTransmit.plateNumber.equals(""))
                    {
                        StrSum = surplusCPHTransmit.plateNumber;
                    }
                }
            }

            if (showWay.contains("6"))
            {
                if ((
                        surplusCPHTransmit.cardType.substring(0, 3).equals("Tmp")
                                || surplusCPHTransmit.cardType.substring(0, 3).equals("Str")
                )
                        && Model.Channels[surplusCPHTransmit.laneIndex].iInOut == 1
                        )
                {
                    String money = "此次收费" + surplusCPHTransmit.charge + "元";
                    StrSum += StrSum != "" ? " " + money : money;
                    if (surplusCPHTransmit.cardType.substring(0, 3).equals("Str"))
                    {
                        StrSum += "余额" + surplusCPHTransmit.balance + "元";
                    }
                }
            }
            if (showWay.contains("5") && (
                    !showWay.contains("6")
                            || (
                            !surplusCPHTransmit.cardType.substring(0, 3).equals("Tmp")
                                    && !surplusCPHTransmit.cardType.substring(0, 3).equals("Str")
                    )
            ))
            {
                StrSum += StrSum != "" ? " " + ls.getCPHEndStr() : ls.getCPHEndStr();
            }
            if (StrSum != "")
            {
                String Jstrs = "";
                if (bMW)
                {
                    Jstrs = "01" + ls.getSpeed() + "00" + ls.getColor() + ls.getSumTime() + CR.GetStrTo16(StrSum);
                }
                else
                {
                    Jstrs = ls.getMove() + ls.getSpeed() + ls.getStopTime() + ls.getColor() + ls.getSumTime() + CR.GetStrTo16(StrSum);
                }

                int sum = 0;
                byte[] array = CR.GetByteArray(Jstrs);
//                foreach( byte by in array)
                for (int i = 0; i < array.length; i++)
                {
                    sum += array[i];
                }
                sum = sum % 256;

//                SendSum = "CC" + Convert.ToInt32(ls.SurplusID).ToString("X2") + "BB5154" + sum.ToString("X2") + Jstrs + "FF";
                SendSum = "CC" + String.format("%x", Integer.parseInt(ls.getSurplusID())) + "BB5154" + String.format("%x", sum) + Jstrs + "FF";
                //构建了SendSum的字符串即可;
                if (Model.Channels[surplusCPHTransmit.laneIndex].iXieYi == 1)
                {
//                    SedBll sedBll = new SedBll(Model.Channels[laneIndex].sIP, 1007, 1005);
//                    sedBll.SurplusCtrlLedShow(Convert.ToByte(Model.Channels[laneIndex].iCtrlID), SendSum, 1);
                }
            }
            lostFlag = 0;
        }
    }

    // 根据条件查询剩余车位屏信息
    private void SurplusCPH(int laneIndex, String plateNumber, String cardType, int surplusCarCount, float balance, float charge)
    {
        //请求SurplusCar的数据
        GetXXXCommonReq req = new GetXXXCommonReq();
        req.setJsonSearchParam(JsonSearchParam.getWhenGetLedSetting(Model.Channels[laneIndex].iCtrlID, String.valueOf(Model.stationID)));
        req.setToken(Model.token);

        //将数据进行相应的传递
        final SurplusCPHTransmit surplusCPHTransmit = new SurplusCPHTransmit();
        surplusCPHTransmit.laneIndex = laneIndex;
        surplusCPHTransmit.plateNumber = plateNumber;
        surplusCPHTransmit.cardType = cardType;
        surplusCPHTransmit.surplusCarCount = surplusCarCount;
        surplusCPHTransmit.balance = balance;
        surplusCPHTransmit.charge = charge;

        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_GETLEDSETTING, req);
        LoadController controller = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetLedSettingResp.class, new GsonCallback.Listener()
                {
                    @Override
                    public void success(Object reqData, Object respData, String url, int paramInt)
                    {
                        CR.printGsonResp(reqData, respData, url, paramInt);
                        GetLedSettingResp getLedSettingResp = (GetLedSettingResp) respData;
                        dealSurplusCPHRespData(getLedSettingResp.getData(), surplusCPHTransmit);
                    }

                    @Override
                    public void error(Object data, String url, String errorString)
                    {
                        T.showShort(ParkingMonitoringActivity.this, "连接服务器失败");
                    }

                }, req, resultUrl, laneIndex));
        mList.add(controller);
    }

    private void popuTempCPHView(final SetCarInResp setCarInResp, final String srcCPH, String title, final int index, final int colorType, final String filesJpg)
    {
        Map<String, Object> map = new ArrayMap<String, Object>();
        map.put("laneIndex", index);
        map.put("plateNumber", setCarInResp.getData().getCPH());
        map.put("newPlateNumber", setCarInResp.getData().getCPH());
        map.put("title", title);

        ParkingTempCPHView parkingTempCPHView = new ParkingTempCPHView(ParkingMonitoringActivity.this, map)
        {
            @Override
            public void onClickOk(final SetCarInConfirmReq setCarInConfirmReq, final String inOutName)
            {
                setCarInConfirmReq.setStationId(Model.stationID);
                setCarInConfirmReq.setToken(Model.token);
                setCarInConfirmReq.setCPColor(colorType);
                // 通过入口车道名，来获取相应的机号
                setCarInConfirmReq.setCtrlNumber(Model.Channels[getCtrlIndexByInoutName(inOutName)].iCtrlID);

                String resultUrl = GetServiceData.getResultUrl(METHOD_SETCARINCONFIRMED, setCarInConfirmReq);
                LoadController controller = RequestManager
                        .getInstance()
                        .get(resultUrl, new GsonCallback<>(SetCarInConfirmResp.class, new GsonCallback.Listener()
                        {
                            @Override
                            public void success(Object reqData, Object respData, String url, int paramInt)
                            {
                                CR.printGsonResp(reqData, respData, url, paramInt);
                                SetCarInConfirmResp setCarInConfirmResp = (SetCarInConfirmResp) respData;
                                RCodeEnum rCodeEnum = RCodeEnum.valueOf(Integer.parseInt(setCarInConfirmResp.getRcode()));
                                switch (rCodeEnum)
                                {
                                    case MthFullToTmpCharge:
                                    case MthBeOverdueToTmpCharge:
                                    case RepeatAdmission:
                                    case OK:
                                        CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_OPENGATE, null, index); //开闸
                                        if (setCarInConfirmResp.getData() != null)
                                        {
                                            LoadLsNoX2010znyktInGateModel inGateModel = new LoadLsNoX2010znyktInGateModel();
                                            inGateModel.CarTypeenum = CR.getCardTypeEnum(setCarInConfirmResp.getData().getCardType().substring(0, 3));
                                            inGateModel.strCPH = CR.prepareDetectString(setCarInConfirmResp.getData().getCPH(), "");
                                            inGateModel.CYkDay = setCarInConfirmResp.getData().getRemainingDays();
                                            inGateModel.strCardCW = CR.prepareDetectString(setCarInConfirmResp.getData().getCarPlace(), "");
                                            inGateModel.iIDNoticeDay = setCarInConfirmResp.getData().getRemainingPlaceCount();
                                            //发送入场语音
                                            CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_LOADLSNOX2010ZNYKTINGATE, inGateModel, index);

                                            // 更新界面数据
                                            UpdateApproachRecord(setCarInConfirmResp.getData(), index, filesJpg);
                                        }
                                        break;
                                    default:
                                        MessageBox.show(ParkingMonitoringActivity.this, setCarInConfirmResp.getMsg());
                                        break;
                                }
                            }

                            @Override
                            public void error(Object data, String url, String errorString)
                            {
                                T.showShort(ParkingMonitoringActivity.this, "网络连接失败");
                            }
                        }, setCarInConfirmReq, resultUrl, -1));
                mList.add(controller);
            }

            @Override
            public void onClickCancel()
            {
                cancel();
            }

            @Override
            public void prepareLoadData()
            {
                L.i("prepareLoadData srcCPH:" + srcCPH);
                setCPH(srcCPH);
                String inOutName = setCarInResp.getData().getInOutName();
                List<String> inOutListNameByType = getInOutListNameByType(CAR_CHANNEL_IN);

                int selectIndex = 0;
                for (int i = 0; i < inOutListNameByType.size(); i++)
                {
                    if (inOutListNameByType.get(i).equals(inOutName))
                    {
                        selectIndex = i;
                        break;
                    }
                }
                setSpinnerRoadName(inOutListNameByType, selectIndex);

                if (Model.iAutoMinutes == 1)//定时关闭
                {
                    mHandler.postDelayed(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            cancel();
                        }
                    }, Model.iAutoSetMinutes);
                }
            }
        };
        parkingTempCPHView.show();
    }

    // 更新进场的界面数据更新
    private void UpdateApproachRecord(SetCarInConfirmResp.DataBean data, int index, String filesJpg)
    {
        parkingMonitoringView.setCPHText(index, data.getCPH());
        fragmentChargeManager.setChargeInfoInTime(data.getInTime());
        fragmentChargeManager.setChargeInfoCarNO(CR.prepareDetectString(data.getCardNO(), ""));
        fragmentChargeManager.setChargeInfoCardType(CR.GetCardType(data.getCardType(), 1));
        fragmentChargeManager.setChargeInfoDeptName(data.getDeptName());
        fragmentChargeManager.setChargeInfoPersonNO(data.getUserNO());
        fragmentChargeManager.setChargeInfoPersonName(data.getUserName());
        fragmentChargeManager.setChargeInfoReminderValue(String.format("%.2f", data.getBalance()));
        parkingMonitoringView.setSurplusCarCount(String.valueOf(data.getRemainingPlaceCount()));

        if (null != filesJpg && filesJpg.length() > 0)//判断 filesJpg是否存在
        {
            if (new File(filesJpg).exists())
            {
                //注意路径的转换
                String convertPath;
                if (data.getImagePath() != null)
                {
                    convertPath = data.getImagePath().replace("\\", "/");
                }
                else
                {
                    convertPath = "";
                }

                CR.checkImagePath(ParkingMonitoringActivity.this);
                String fileName = Model.sImageSavePath + File.separator + convertPath; // 构建新路径
                String parentDir = fileName.substring(0, fileName.lastIndexOf("/"));

                File parentFile = new File(parentDir);
                if (!parentFile.exists())
                {
                    parentFile.mkdirs();
                }

                File filesJpgContent = new File(filesJpg);
                //将filesJpg拷贝到fileName中即可
                FileUtil.fileChannelCopy(filesJpgContent, new File(fileName));
                try
                {
                    FileUtil.deleteFile(filesJpgContent);
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }

                ImageProcessing(fileName, data.getImagePath(), index, false, true, false);//上传文件
            }
            else
            {
                L.e("UpdateApproachRecord " + filesJpg + "不存在");
            }
        }
        //2017-03-21
        GetBinInOut();
        requestGetParkingInfo();
    }

    private void updateCarHintToFragment(int what, String msg)
    {
        int currentIndex = fragmentChargeManager.getCurrentIndex();
        Message message = mHandler.obtainMessage();
        message.what = what;
        message.arg1 = currentIndex;
        message.obj = msg;
        mHandler.sendMessage(message);
    }

    /**
     * 发送心跳消息，不然30秒就会出现过期的情况
     */
    private void sendKeepAlive()
    {
        KeepAliveReq keepAliveReq = new KeepAliveReq(Model.token);
        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_KEEPALIVE, new KeepAliveReq(Model.token));
        LoadController controller = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(KeepAliveResp.class, this, keepAliveReq, resultUrl, -1));
        mList.add(controller);
    }

    private int[] CheDaoIndex; // 按照一定的规则将重新组织视频画面的显示
    private int inChannelNum = 0;// 表示当前入口车道的个数
    private int outChannelNum = 0;// 表示当前出口车道的个数

    private void initFields()
    {
        for (int i = 0; i < 11; i++)
        {
            strReadPicFile[i] = "";
            strReadPicFileJpg[i] = "";
//            strCardTmp[i] = "";
            strCarNoColor[i] = "";
            autoCarNo[i] = "";
            bOffLine[i] = false;
            bLoadFullCW[i] = true;
            forbidIn[i] = false;
            bStopInInit[i] = false;
            bIsMoth[i] = false;
        }

        requestGetCardTypeDef();// 获取车辆类型 即固定车和储值车，临时车

        // 判断是否换班
        if (CR.GetAppConfig(getApplicationContext(), ConstantSharedPrefs.UserCode, "").equals(Model.sUserCard))
        {
            Model.dLoginTime = (long) CR.GetAppConfig(getApplicationContext(), ConstantSharedPrefs.LoginDate, 0L);
        }
        else
        {
            CR.UpdateAppConfig(getApplicationContext(), ConstantSharedPrefs.UserCode, Model.sUserCard);
            CR.UpdateAppConfig(getApplicationContext(), ConstantSharedPrefs.LoginDate, System.currentTimeMillis());
            Model.dLoginTime = System.currentTimeMillis();
        }
        ComeGoFlagSumCar();

        requestGetCheDaoSet();// 为了之后的读取记录的逻辑;

        Model.iLoadTimeType = 0;
//        loadTime = DateTime.Now.AddDays(-1);

        L.e("Model.iEnableVideo == 1:" + Model.iEnableVideo);
        L.e("Model.iEnableNetVideo == 1:" + Model.iEnableNetVideo);
        if (Model.iEnableVideo == 1 || Model.iEnableNetVideo == 1)
        {
            playVideo();
        }
    }

    private void ComeGoFlagSumCar()
    {
        for (int i = 0; i < Model.iChannelCount; i++)
        {
            if (Model.Channels[i].iInOut == 0)
            {
                isOne = true;
            }
            else if (Model.Channels[i].iInOut == 1 || Model.Channels[i].iInOut == 3)
            {
                //isTwo = true;
                if (Model.Channels[i].iInOut == 3)
                {
                    //MyShoukaji = 1;
                }
            }
            else if (Model.Channels[i].iInOut == 4)
            {
                isOne = true;
                //isTwo = true;
            }
        }
    }


    private void requestGetCheDaoSet()
    {
        GetCheDaoSetReq req = new GetCheDaoSetReq();
        req.setToken(Model.token);
        req.setJsonSearchParam(JsonSearchParam.getWhenGetCheDaoSet(String.valueOf(Model.stationID)));
        req.setOrderField(OrderField.getWhenGetCheDaoSet("desc", "asc", "asc"));
        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_GETCHEDAOSET, req);
        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetCheDaoSetResp.class, this, req, resultUrl, -1));
        mList.add(loadController);
    }

    private void requestGetCardTypeDef()
    {
        GetCardTypeDefReq cardTypeDefReq = new GetCardTypeDefReq();
        cardTypeDefReq.setToken(Model.token);

        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_GETCARDTYPEDEF, cardTypeDefReq);
        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetCardTypeDefResp.class, this, cardTypeDefReq, resultUrl, -1));
        mList.add(loadController);
    }

    private int getChannelIndexByIP(String ip)
    {
        if (ip == null) return -1;
        for (int i = 0; i < Model.iChannelCount; i++) // 2
        {
            List<GetNetCameraSetResp.DataBean> lstNCS = Model.Channels[i].CameraList;
            if (null == lstNCS || lstNCS.size() == 0)
            {
                continue;
            }
            if (lstNCS.get(0).getVideoIP().equals(ip))
            {
                for (int chanl = 0; chanl < 4; chanl++)
                {
                    if (Model.Channels[i].iOnLine == 1
                            && Model.Channels[i].sInOutName.equals(parkingMonitoringView.getChannelInOutName(chanl)))
                    {
                        L.i("chanl:" + chanl);
                        return chanl;
                    }
                }
            }
        }
        return -1;
    }

    private void playVideo()
    {
        int VzCount = 0;

        L.e("playVideo:" + Model.iChannelCount);
        for (int i = 0; i < Model.iChannelCount; i++) // 2
        {
            List<GetNetCameraSetResp.DataBean> lstNCS = Model.Channels[i].CameraList;
            if (null == lstNCS)
            {
                continue;
            }

            if (Model.Channels[i].iInOut == CAR_CHANNEL_IN)
            {
                inChannelNum++;
            }

            if (Model.Channels[i].iInOut == CAR_CHANNEL_OUT)
            {
                outChannelNum++;
            }

            for (int chanl = 0; chanl < 4; chanl++)//chanl分别取得是通道的数据
            {
                String channelInOutName = parkingMonitoringView.getChannelInOutName(chanl);
                if (Model.Channels[i].iOnLine == 1
                        && Model.Channels[i].sInOutName.equals(channelInOutName))
                {
                    if (Model.Channels[i].iCtrlID == Model.Channels[i].iOpenID)
                    {
                        if (lstNCS.size() > 0)
                        {
                            String videotype = lstNCS.get(0).getVideoType();
                            strVideoType[chanl] = videotype;
                            if (VzCount == 0)
                            {
//                                VoiceInit(strVideoType[chanl]);
                                VzCount++;
                            }

                            if (lstNCS.size() > 1)//这里的有两个相机
                            {
                                strVideoType[chanl + 2] = lstNCS.get(1).getVideoType();
                                if (VzCount == 0)
                                {
//                                    VoiceInit(strVideoType[chanl + 2]);
                                    VzCount++;
                                }
                            }

                            Model.strVideoType = videotype;
                            L.e("videotype:" + videotype);
                            switch (videotype)
                            {
                                case "ZNYKTY2":
                                    break;
                                case "ZNYKTY3":
                                    break;
                                case "ZNYKTY4":
                                    break;
                                case "ZNYKTY5":
                                case "ZNYKTY6":
                                case "ZNYKTY15"://这里建立了chanl 和 getVideoIP对应的关系
                                    parkingMonitoringView.playVideoByIndex(chanl, lstNCS.get(0).getVideoIP(), mHandler);
                                    break;
                            }
                        }
                    }
                }
            }
        }
    }

    private void initControl()
    {
        parkingMonitoringView.showStatusBar(Model.sUserName, Model.sUserCard,
                TimeConvertUtils.longToString(Model.dLoginTime), TimeConvertUtils.longToString(System.currentTimeMillis()));

//        获取进场和出场信息对应着 场内车辆明细和车辆收费明细
        RefreshInOut();
    }

    private void RefreshInOut()
    {
        GetBinInOut();

//       统计获取车位信息，显示到界面即可
        requestGetParkingInfo();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState)
    {
        L.e("onSaveInstanceState===fragmentChargeManager.getCurrentIndex()" + fragmentChargeManager.getCurrentIndex());
        L.e("onSaveInstanceState===fragmentDetailManager.getCurrentIndex()" + fragmentChargeManager.getCurrentIndex());

        //“内存重启”时保存当前的fragment名字
        super.onSaveInstanceState(outState);

        outState.putInt(FragmentChargeManager.CURRENT_FRAGMENT, fragmentChargeManager.getCurrentIndex());
        outState.putInt(FragmentDetailManager.CURRENT_FRAGMENT, fragmentDetailManager.getCurrentIndex());
    }

    private void initFragment(Bundle savedInstanceState)
    {
        FragmentManager supportFragmentManager = getSupportFragmentManager();

        fragmentChargeManager = new FragmentChargeManager(supportFragmentManager);
        fragmentChargeManager.init(savedInstanceState);

        fragmentDetailManager = new FragmentDetailManager(supportFragmentManager);
        fragmentDetailManager.init(savedInstanceState);
    }


    public static final int MSG_GetCarIn = 0x01;
    public static final int MSG_GetCarOut = 0x02;
    public static final int MSG_ParkingInfo = 0x3;
    public static final int MSG_ChargeInfo = 0x04;
    public static final int MSG_SETCarIn = 0X05;
    public static final int MSG_SETCarOut = 0X06;
    public static final int MSG_KeppAlive = 0x07;
    public long startAliveTime;

    public static final int MSG_UpdateBlackListData = 0x08;
    public static final int MSG_SET_CarChannel = 0x11;

    public static final int MSG_START_VIDEO_PLAY = 0x09;
    public static final int MSG_STOIP_VIDEO_PLAY = 0x10;

    public int CAR_CHANNEL_OUT = 1; // 表示车辆出口标记
    public int CAR_CHANNEL_IN = 0; // 表示车辆入口标记

    public final static int MSG_TokenFailed = 0x12;
    public final static int MSG_CarHintInfoAfterResume = 013; // 恢复到之前的收费信息
    public static final int MSG_SETCarInWithOutCPH = 0x14;
    public static final int MSG_SETCarInComfirmed = 0x15;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(final Message msg)
        {
            switch (msg.what)
            {
                case MSG_KeppAlive:
                {
                    sendKeepAlive();
                    break;
                }
                case MSG_START_VIDEO_PLAY:
                {
                    String objIP = (String) msg.obj;
                    L.i("MSG_START_VIDEO_PLAY ### ip==>>", objIP);
                    int resultChannel = getChannelIndexByIP(objIP);
                    if (resultChannel < 0)
                    {
                    }
                    else
                        parkingMonitoringView.setSurfaceEnableWhenPlayVideo(resultChannel);
                    break;
                }
                case MSG_STOIP_VIDEO_PLAY:
                {
                    String objIP = (String) msg.obj;
                    L.i("MSG_STOIP_VIDEO_PLAY ### ip==>>", objIP);
                    int resultChannel = getChannelIndexByIP(objIP);
                    if (resultChannel < 0)
                    {
                    }
                    else
                        parkingMonitoringView.setTextEnableWhenStopVideo(resultChannel);
                    break;
                }
                case MSG_TokenFailed:
                {
                    finish();
                    break;
                }
                case MSG_CarHintInfoAfterResume:
                {
                    final int arg1 = msg.arg1;
                    String prompt = (String) msg.obj;

                    parkingMonitoringView.showInChargeFragment(prompt);
//                    fragmentChargeManager.setTextData(prompt);

                    mHandler.postDelayed(new Runnable()
                    {
                        @Override
                        public void run()
                        {
//                            fragmentChargeManager.showFragment(arg1);
                            parkingMonitoringView.resumeInChargeFragment();
                        }
                    }, 1000 * 2);
                    break;
                }
                default:
                {
                    break;
                }
            }
        }
    };

    private void updateSetCarIn(SetCarInResp.DataBean data)
    {
        if (data == null)
            return;

        fragmentChargeManager.setChargeInfoPersonNO(data.getUserNO());
        fragmentChargeManager.setChargeInfoPersonName(data.getUserName());
        fragmentChargeManager.setChargeInfoDeptName(data.getDeptName());
        fragmentChargeManager.setChargeInfoCarNO(data.getCardNO());
        fragmentChargeManager.setChargeInfoCardType(CR.GetCardType(data.getCardType(), 1));
        fragmentChargeManager.setChargeInfoInTime(data.getInTime());
        fragmentChargeManager.setChargeInfoOutTime("");
        fragmentChargeManager.setChargeInfoPayMoney("0.00");

        parkingMonitoringView.setChargeMoney("00.00");

        parkingMonitoringView.setSurplusCarCount(String.valueOf(data.getRemainingPlaceCount()));
        if (data.getCardType().substring(0, 3).equals("Mth")
                || data.getCardType().substring(0, 3).equals("Fre"))
        {
            fragmentChargeManager.setChargeInfoReminderValueVisiable(View.INVISIBLE);
            fragmentChargeManager.settChargeInfoReminderUnitVisble(View.INVISIBLE);
        }
        else
        {
            fragmentChargeManager.setChargeInfoReminderValueVisiable(View.VISIBLE);
            fragmentChargeManager.settChargeInfoReminderUnitVisble(View.VISIBLE);
            fragmentChargeManager.setChargeInfoReminderHint("剩余金额：");
            fragmentChargeManager.setChargeInfoReminderValue(String.format("%.2f", data.getBalance()));
        }
    }

    private void updateSetCarInByOut(SetCarOutResp.DataBean data)
    {
        fragmentChargeManager.setChargeInfoPersonNO(data.getUserNO());
        fragmentChargeManager.setChargeInfoPersonName(data.getUserName());
        fragmentChargeManager.setChargeInfoDeptName(data.getDeptName());
        fragmentChargeManager.setChargeInfoCarNO(data.getCardNO());
        fragmentChargeManager.setChargeInfoCardType(CR.GetCardType(data.getCardType(), 1));
        fragmentChargeManager.setChargeInfoInTime(data.getInTime());
        fragmentChargeManager.setChargeInfoOutTime(data.getOutTime());
        fragmentChargeManager.setChargeInfoPayMoney(String.format("%.2f", data.getSFJE()));

        parkingMonitoringView.setChargeMoney(String.format("%.2f", data.getSFJE()));

        if (data.getCardType().substring(0, 3).equals("Mth")
                || data.getCardType().substring(0, 3).equals("Fre"))
        {
            fragmentChargeManager.setChargeInfoValidMoneyVisiable(View.INVISIBLE);
            fragmentChargeManager.setChargeInfoReminderValueVisiable(View.INVISIBLE);
        }
        else
        {
            fragmentChargeManager.setChargeInfoValidMoneyVisiable(View.VISIBLE);
            fragmentChargeManager.setChargeInfoReminderValueVisiable(View.VISIBLE);

            fragmentChargeManager.setChargeInfoReminderValue(String.format("%.2f", data.getBalance()));
            fragmentChargeManager.setChargeInfoValidMoneyValue("剩余金额：");
        }
    }

    private void updateCarChargeDetail(List<GetCarOutResp.DataBean> data)
    {
        if (data == null || data.size() <= 0)
        {
            fragmentDetailManager.cleanCargeDetailData();
            return;
        }

        ArrayList<HashMap<String, String>> items = new ArrayList<HashMap<String, String>>();
        for (int i = 0; i < data.size(); i++)
        {
            HashMap<String, String> item = new HashMap<String, String>();

            item.put(ColumnName.c1, CR.prepareDetectString(data.get(i).getCPH(), ""));
            item.put(ColumnName.c2, CR.prepareDetectString(data.get(i).getChineseName(), ""));
            item.put(ColumnName.c3, CR.prepareDetectString(data.get(i).getInTime(), ""));
            item.put(ColumnName.c4, CR.prepareDetectString(data.get(i).getOutTime(), ""));
            item.put(ColumnName.c5, String.valueOf(data.get(i).getSFJE()));
            item.put(ColumnName.c6, CR.prepareDetectString(data.get(i).getInGateName(), ""));
            item.put(ColumnName.c7, CR.prepareDetectString(data.get(i).getOutGateName(), ""));
            item.put(ColumnName.c8, CR.prepareDetectString(data.get(i).getUserNO(), ""));
            item.put(ColumnName.c9, CR.prepareDetectString(data.get(i).getUserName(), ""));
            item.put(ColumnName.c10, CR.prepareDetectString(data.get(i).getCardNO(), ""));
            item.put(ColumnName.c11, CR.prepareDetectString(data.get(i).getBalance() + "", ""));//免费原因 FreeReason
            item.put(ColumnName.c12, String.valueOf(data.get(i).getYSJE()));
            item.put(ColumnName.c13, CR.prepareDetectString(data.get(i).getSFTime(), ""));
            item.put(ColumnName.c14, CR.prepareDetectString(data.get(i).getInOperator(), "")); // 收费人员 SFOperator
            item.put(ColumnName.c15, CR.prepareDetectString(data.get(i).getInOperatorCard(), ""));//收费人员编号
            item.put(ColumnName.c16, CR.prepareDetectString(data.get(i).getInGateName(), ""));//收费口名 SFGate

            item.put(ColumnName.c17, CR.prepareDetectString("", ""));//超时标志 OvertimeSymbol
            item.put(ColumnName.c18, CR.prepareDetectString(data.get(i).getOvertimeSFTime(), ""));//超时收费时间 OvertimeSFTime
            item.put(ColumnName.c29, String.valueOf(data.get(i).getOvertimeSFJE()));//超时收费金额 OvertimeSFJE
            item.put(ColumnName.c20, String.valueOf(data.get(i).getCarparkNO()));//车场编号 CarparkNO
            item.put(ColumnName.c21, String.valueOf(data.get(i).getBigSmall()));//大小标识 BigSmall
            item.put(ColumnName.c22, CR.prepareDetectString(data.get(i).getFreeReason(), ""));//免费原因 FreeReason
            item.put(ColumnName.c23, CR.prepareDetectString(data.get(i).getInUser(), ""));//人场人员 InUser
            item.put(ColumnName.c24, CR.prepareDetectString(data.get(i).getOutUser(), ""));//出场人员 OutUser
            item.put(ColumnName.c25, CR.prepareDetectString(data.get(i).getInPic(), ""));//入场图片 InPic
            item.put(ColumnName.c26, CR.prepareDetectString(data.get(i).getOutPic(), ""));//出场图片 OutPic
            item.put(ColumnName.c27, CR.prepareDetectString(data.get(i).getDeptName(), ""));//部门名称 DeptName
            item.put(ColumnName.c28, "");//证件图片 ZJPic
            item.put(ColumnName.c29, CR.prepareDetectString(data.get(i).getOutOperatorCard(), ""));//出场操作编号 OutOperatorCard
            item.put(ColumnName.c31, CR.prepareDetectString(data.get(i).getInOperator(), ""));//入场操作员 InOperator
            item.put(ColumnName.c32, CR.prepareDetectString(data.get(i).getOutOperator(), ""));//出场操作员 OutOperator
            items.add(item);
        }
        fragmentDetailManager.setData(null, null, items, null);

    }

    private void updateCarInParkingDetail(List<GetCarInResp.DataBean> data)
    {
        ArrayList<HashMap<String, String>> items = new ArrayList<HashMap<String, String>>();
        if (data == null || data.size() <= 0)
        {
            fragmentDetailManager.cleanCarInPakingDetailData();
            return;
        }

        for (int i = 0; i < data.size(); i++)
        {
            HashMap<String, String> item = new HashMap<String, String>();
            item.put(ColumnName.c1, CR.prepareDetectString(data.get(i).getCPH(), ""));
            item.put(ColumnName.c2, CR.prepareDetectString(data.get(i).getChineseName(), ""));
            item.put(ColumnName.c3, CR.prepareDetectString(data.get(i).getInTime(), ""));
            item.put(ColumnName.c4, CR.prepareDetectString(data.get(i).getInGateName(), ""));
            item.put(ColumnName.c5, CR.prepareDetectString(data.get(i).getUserNO(), ""));
            item.put(ColumnName.c6, CR.prepareDetectString(data.get(i).getUserName(), ""));
            item.put(ColumnName.c7, String.valueOf(data.get(i).getBalance()));
            item.put(ColumnName.c8, CR.prepareDetectString(data.get(i).getCardNO(), ""));
            item.put(ColumnName.c9, String.valueOf(data.get(i).getCarparkNO()));
            item.put(ColumnName.c10, String.valueOf(data.get(i).getBigSmall()));
            item.put(ColumnName.c11, "");//免费原因 FreeReason
            item.put(ColumnName.c12, CR.prepareDetectString(data.get(i).getInPic(), ""));
            item.put(ColumnName.c13, CR.prepareDetectString(data.get(i).getDeptName(), ""));
            item.put(ColumnName.c14, ""); // ZJPic
            item.put(ColumnName.c15, CR.prepareDetectString(data.get(i).getInOperatorCard(), ""));
            item.put(ColumnName.c16, CR.prepareDetectString(data.get(i).getInOperator(), ""));
            items.add(item);
        }
        fragmentDetailManager.setData(items, null, null, null);
    }


    @Override
    protected void onDestroy()
    {
        L.e("onDestroy...................................");
        super.onDestroy();
        for (int i = 0; i < Model.iChannelCount; i++)
        {
            parkingMonitoringView.stopVideoByIndex(i); // 这里的控件出现泄漏，如果取消视频播放呢?
        }
        // 发送注销的命令
        LogOutReq logOutReq = new LogOutReq(Model.token);
        String resultUrl = GetServiceData.getResultUrl(METHOD_LOGOUT, logOutReq);
        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(LogOutResp.class, this, logOutReq, resultUrl, -1));
        mList.add(loadController);

        // 退出线程池
        executor.shutdown();
        tcpsdk.getInstance().cleanup();

        mHandler.removeCallbacksAndMessages(null); // 清除所有的handler消息和runnable等;
        for (LoadController controller : mList)
        {
            controller.cancel();
        }

        if (queueTask != null)
        {
            queueTask.end();
            try
            {
                queueTask.join();
                L.e("queueTask end.............................");
            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            }
        }

        delImageTaskThread.setEnd();
        downloadOffLineCardThread.endDownLoad();
        try
        {
            delImageTaskThread.join();
            L.e("delImageTaskThread.join().........................");
            downloadOffLineCardThread.join();
            L.e("downloadOffLineCardThread.join().........................");
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }

        ConcurrentQueueHelper.getInstance().destory();
//        application.closeActivity(); // 强制关闭
    }


    @Override
    public void onStart()
    {
        super.onStart();
    }

    @Override
    public void onStop()
    {
        super.onStop();
    }


    public void iFullLightMoreThan_0()
    {
        for (int x = 0; x < Model.iChannelCount; x++)
        {
            if (Model.Channels[x].iInOut == 0)
            {
                if (summary0.SurplusCarCount > 0)
                {
                    if (forbidIn[x] || bStopInInit[x] || bLoadFullCW[x])
                    {
                        CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_RELIEVEPARKINGLOTFULL, 1, x);
                        CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_RELIEVEPARKINGLOTFULL, 2, x);
                        CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_RELIEVEPARKINGLOTFULL, 3, x);
                        CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_RELIEVEPARKINGLOTFULL, 4, x);

//                        cmd.VoiceDisplay(VoiceType.RelieveMonthlyParkingFull, x);//释放满位信号
//
//                        cmd.VoiceDisplay(VoiceType.RelieveTemporaryParkingFull, x);//释放满位信号
//
//                        cmd.VoiceDisplay(VoiceType.RelieveStoredValueParkingFull, x);//释放满位信号
//
//                        // sender0.VoiceDisplay(VoiceType.RelieveMonthlyParkingFull, x);//释放满位信号
//
//                        cmd.VoiceDisplay(VoiceType.RelieveParkingFull, x);//释放满位信号

                        forbidIn[x] = false;
                        bStopInInit[x] = false;
                        bLoadFullCW[x] = false;
                    }

                }
                else
                {
                    if (forbidIn[x] == false || bLoadFullCW[x])
                    {
                        CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_RELIEVEPARKINGLOTFULL, Model.iFullLight, x);
                        forbidIn[x] = true;
                        bLoadFullCW[x] = false;
                    }

                }
            }

        }
    }

    /// 方便控制板显示传递数据
    private static class CtrlLedShowLoadBean
    {
        public boolean iCtrlShowInfo;
        public String CtrlShowInfoText;
        public boolean iCtrlShowRemainPos;
        public String CtrlShowRemainPosText;
    }

    /**
     * 统计车位信息
     */
    private int outCarCount;
    public Summary summary0 = new Summary();
    boolean bRStopIn = true;

    private void updateGetParkingInfo(GetParkingInfoResp.DataBean pi)
    {
        summary0.MthCount = pi.getMonthCarCountInPark();
        summary0.TmpCount = pi.getTempCarCountInPark();
        summary0.FreCount = pi.getFreeCarCountInPark();
        summary0.StrCount = pi.getPrepaidCarCountInPark();
        outCarCount = 0;

        if (Model.bPaiChe)
        {
            summary0.OutCount = outCarCount;
            fragmentChargeManager.setCarSpaceOutCountValue(String.valueOf(summary0.OutCount));//派出车总数
        }
        if (Model.iFreeCardNoInPlace == 1)
        {
            summary0.SurplusCarCount = (Model.iParkTotalSpaces - pi.getTotalCarCountInPark() + pi.getFreeCarCountInPark());////免费车不计入车位数 （iModifyCarPos没用到）
        }
        else
        {
            summary0.SurplusCarCount = Model.iParkTotalSpaces - pi.getTotalCarCountInPark();
        }

        if (Model.bTempCarPlace)
        {
            summary0.SurplusCarCount = Model.iTempCarPlaceNum - pi.getTempCarCountInPark();
            summary0.OutCount = Model.iMonthCarPlaceNum - pi.getMonthCarCountInPark();
            parkingMonitoringView.setSurplusCarCountHint("临时车位");
            fragmentChargeManager.setCarSpaceOutCountHintVisble("固定车位:");
            fragmentChargeManager.setCarSpaceOutCountValueVisble(String.valueOf(summary0.OutCount));
        }
        else if (Model.bMonthCarPlace)
        {
            summary0.SurplusCarCount = Model.iMonthCarPlaceNum - pi.getMonthCarCountInPark();
            summary0.OutCount = Model.iMonthCarPlaceNum - pi.getMonthCarCountInPark();
            parkingMonitoringView.setSurplusCarCountHint("固定车位");
            fragmentChargeManager.setCarSpaceOutCountHintVisble("临时车位:");
            fragmentChargeManager.setCarSpaceOutCountValueVisble(String.valueOf(summary0.OutCount));
        }
        else if (Model.bMoneyCarPlace)
        {
            summary0.SurplusCarCount = Model.iMoneyCarPlaceNum - pi.getPrepaidCarCountInPark();
            summary0.OutCount = Model.iMonthCarPlaceNum - pi.getMonthCarCountInPark();

            parkingMonitoringView.setSurplusCarCountHint("储值车位");
            fragmentChargeManager.setCarSpaceOutCountHintVisble("固定车位:");
            fragmentChargeManager.setCarSpaceOutCountValueVisble(String.valueOf(summary0.OutCount));
        }

        if (Model.iFullLight > 0)
        {
            iFullLightMoreThan_0();
        }
        else
        {
            if (bRStopIn)
            {

                for (int x = 0; x < Model.iChannelCount; x++)
                {
                    if (Model.Channels[x].iInOut == 0)
                    {
//                        cmd.VoiceDisplay(VoiceType.Relieve, x);
                        CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_RELIEVEPARKINGLOTFULL, 1, x);
                        CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_RELIEVEPARKINGLOTFULL, 2, x);
                        CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_RELIEVEPARKINGLOTFULL, 3, x);
                        CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_RELIEVEPARKINGLOTFULL, 5, x);
                    }
                }
                bRStopIn = false;
            }
        }

        if (Model.iSumMoneyHide == 1)
        {
            fragmentChargeManager.setChargeInfoAmountMoneyLabelVisble(View.INVISIBLE);
            fragmentChargeManager.setChargeInfoAmountMoneyVisble(View.INVISIBLE);
            fragmentChargeManager.setChargeInfoAmountMoneyUnitVisble(View.INVISIBLE);
        }
        else
        {
            fragmentChargeManager.setChargeInfoAmountMoneyLabelVisble(View.VISIBLE);
            fragmentChargeManager.setChargeInfoAmountMoneyVisble(View.VISIBLE);
            fragmentChargeManager.setChargeInfoAmountMoneyUnitVisble(View.VISIBLE);
            summary0.MoneyCount = pi.getTotalCharge();
        }

//        if (lostFlag == 0) // lostFlag 在线程来作标记
//        {
//            return;
//        }
        if (Model.iCtrlShowRemainPos == 1 || Model.iCtrlShowInfo == 1)
        {
            iCtrlLedDelay = iCtrlLedDelay - 1;
            iCtrlLedDelay = -1;
            String strLoad = "";
            String strShowInfo = "";
            if (Model.iCtrlShowInfo == 1)
            {
                strShowInfo = (String) CR.GetAppConfig(getApplicationContext(), "fbxx", "");
                if (strShowInfo == null)
                {
                    strShowInfo = "欢迎光临";
                }
                //strShowInfo = "欢迎光临";
            }
            if (Model.iCtrlShowRemainPos == 1)
            {
                if (!strLoad.equals(""))
                {
                    strLoad += "  ";
                }
                if (summary0.SurplusCarCount < 1)
                {
                    strLoad += "车位已满 谢谢！";
                }
                else
                {
                    strLoad += "剩余车位:" + summary0.SurplusCarCount;
                    //strLoad += "剩余车位:" + 995;
                }
            }

//            String strShowInfoZ = "";
//            byte[] array = null;
//            if (Model.iCtrlShowInfo == 1)
//            {
//                array = strShowInfo.getBytes();
//                //strShowInfoZ = string.Empty;
//                if (array != null)
//                {
//                    for (int i = 0; i < array.length; i++)
//                    {
////                        strShowInfoZ += ToStringX2(array[i]);
//                        strShowInfoZ += String.format("%02x", array[i]);
//                    }
//                }
//            }
//
//            byte[] array1 = strLoad.getBytes();
//            String str = "";
//            if (array1 != null)
//            {
//                for (int i = 0; i < array1.length; i++)
//                {
//                    str += String.format("%02x", array[i]);
//                }
//            }
//
//            if (Model.iCtrlShowInfo == 1)
//            {
//                str = "01" + strShowInfoZ + "02" + str;
//            }

            for (int x = 0; x < Model.iChannelCount; x++)
            {
                if (Model.Channels[x].iOnLine == 0)
                {
                    continue;
                }

                if (Model.Channels[x].iInOut == 0)
                {
//                    byte byteCmdX;
//                    int iMacNO = Model.Channels[x].iCtrlID;
//                    if (iMacNO > 127)
//                    {
//                        iMacNO = iMacNO - 127;
//                        byteCmdX = 0x45;
//                    }
//                    else
//                    {
//                        byteCmdX = 0x3D;
//                    }

                    if (Model.Channels[x].iXieYi == 1)
                    {
                        CtrlLedShowLoadBean ctrlLedShowLoadBean = new CtrlLedShowLoadBean();
                        ctrlLedShowLoadBean.iCtrlShowInfo = Model.iCtrlShowInfo == 1;
                        ctrlLedShowLoadBean.iCtrlShowRemainPos = Model.iCtrlShowRemainPos == 1;
                        ctrlLedShowLoadBean.CtrlShowInfoText = strShowInfo;
                        ctrlLedShowLoadBean.CtrlShowRemainPosText = strLoad;

                        CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_CtrlLedShowLoad, ctrlLedShowLoadBean, x);
//                        String rtnlStr = VsendBll.CtrlLedShow(Convert.ToByte(iMacNO), byteCmdX, 0x67, str, Model.Channels[x].iXieYi);
                    }
                }
                else if (Model.iCtrlShowInfo == 1 && Model.Channels[x].iInOut == 1)
                {
//                    byte byteCmdX;
//                    int iMacNO = Model.Channels[x].iCtrlID;
////                    SedBll VsendBll = new SedBll(Model.Channels[x].sIP, 1007, 1005);
//                    if (iMacNO > 127)
//                    {
//                        iMacNO = iMacNO - 127;
//                        byteCmdX = 0x45;
//                    }
//                    else
//                    {
//                        byteCmdX = 0x3D;
//                    }
                    if (Model.Channels[x].iXieYi == 1)
                    {
                        CtrlLedShowLoadBean ctrlLedShowLoadBean = new CtrlLedShowLoadBean();
                        ctrlLedShowLoadBean.iCtrlShowInfo = Model.iCtrlShowInfo == 1;
                        ctrlLedShowLoadBean.iCtrlShowRemainPos = false;
                        ctrlLedShowLoadBean.CtrlShowInfoText = strShowInfo;
                        ctrlLedShowLoadBean.CtrlShowRemainPosText = strLoad;

                        CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_CtrlLedShowLoad, ctrlLedShowLoadBean, x);
                    }
                }
            }

            ////月卡3 临时卡4 免费卡5 储值卡6 总车辆数7 收费总数8 开闸数9 免费金额10
            summary0.OpenCount = pi.getManualOpenCarCount();
            summary0.FreMoney = pi.getTotalDiscount();

            for (int x = 0; x < Model.iChannelCount; x++)
            {
                updateGetLedSettingResp(x);
            }
        }

        fragmentChargeManager.setChargeInfoMthCount(String.valueOf(summary0.MthCount));
        fragmentChargeManager.setChargeInfoTempCount(String.valueOf(summary0.TmpCount));
        fragmentChargeManager.setChargeInfoStoreCount(String.valueOf(summary0.StrCount));
        fragmentChargeManager.setChargeInfoFreeCount(String.valueOf(summary0.FreCount));
        fragmentChargeManager.setChargeInfoFreeMoney(String.format("%.2f", summary0.FreMoney));
        fragmentChargeManager.setChargeInfoAmountMoney(String.format("%.2f", summary0.MoneyCount));
        fragmentChargeManager.setChargeInfoManualCount(String.valueOf(summary0.OpenCount));
        fragmentChargeManager.setCarSpaceOutCountValue(String.valueOf(summary0.OpenCount));
        parkingMonitoringView.setSurplusCarCount(String.valueOf(summary0.SurplusCarCount));
    }

    private int lostFlag;

    private void dealGetLedSettingRespData(List<GetLedSettingResp.DataBean> dtS, int index)
    {
        if (dtS == null || dtS.size() == 0)
        {
            return;
        }

        for (GetLedSettingResp.DataBean dr : dtS)
        {
            String showWay = dr.getShowWay();
            String SendSum = "";
            String StrSum = "";
            boolean bMW = false;//2016-09-08 th
            if (showWay.contains("3"))//是否含有空车位
            {
                if (summary0.SurplusCarCount < 1)
                {
                    if (dr.getPattern().equals("2"))
                    {
                        StrSum = "0000";
                        bMW = false;
                    }
                    else
                    {
                        StrSum = "车位已满 谢谢";
                        bMW = true;
                    }
                }
                else
                {
                    bMW = false;
                    if (dr.getCPHEndStr().equals(""))
                    {
                        if (dr.getPattern().equals("2"))
                        {
                            StrSum = String.format("%04d", summary0.SurplusCarCount);
//                            StrSum = (Convert.ToInt32(summary0.SurplusCarCount)).ToString("0000");
                        }
                        else if (dr.getPattern().equals("8"))
                        {
//                            StrSum = "剩余车位:" + (Convert.ToInt32(summary0.SurplusCarCount)).ToString("000");
                            StrSum = "剩余车位:" + String.format("%03d", summary0.SurplusCarCount);
                        }
                        else
                        {
//                            StrSum = "空车位:" + (Convert.ToInt32(summary0.SurplusCarCount)).ToString("000");
                            StrSum = "空车位:" + String.format("%03d", summary0.SurplusCarCount);
                        }
                    }
                    else
                    {
                        StrSum = dr.getCPHEndStr() + String.format("%03d", summary0.SurplusCarCount);
//                        StrSum = dr.CPHEndStr + (Convert.ToInt32(summary0.SurplusCarCount)).ToString("000");
                    }
                }
            }

            if (StrSum.equals(""))
            {
                String Jstrs = "";

                if (bMW)
                {
                    Jstrs = "01" + dr.getSpeed() + "00" + dr.getColor() + dr.getSumTime() + CR.GetStrTo16(StrSum);//移动方式： 速度,单幅停留时间,颜色,总显示时间
                }
                else
                {
                    Jstrs = dr.getMove() + dr.getSpeed() + dr.getStopTime() + dr.getColor() + dr.getSumTime() + CR.GetStrTo16(StrSum);//移动方式： 速度,单幅停留时间,颜色,总显示时间
                }

                int sum = 0;

                byte[] array = CR.GetByteArray(Jstrs);
                for (int i = 0; i < array.length; i++)
                {
                    sum += array[i];
                }
                sum = sum % 256;
                //Thread.Sleep(300);
//                SendSum = "CC" + Convert.ToInt32(dr.SurplusID).ToString("X2") + "BB5154" + sum.ToString("X2") + Jstrs + "FF";
                SendSum = "CC" + CR.stringPadLeft(dr.getSurplusID(), 2, '0') + "BB5154" + String.format("%2x", sum) + Jstrs + "FF";
//
//                SedBll senbll = new SedBll(Model.Channels[x].sIP, 1007, 1005);
                if (Model.Channels[index].iXieYi == 1)
                {
                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_SurplusCtrlLedShow, SendSum, index);
                }
            }
        }
    }

    private void updateGetLedSettingResp(final int index)
    {
        GetXXXCommonReq req = new GetXXXCommonReq();
        req.setJsonSearchParam(JsonSearchParam.getWhenGetLedSetting(Model.Channels[index].iCtrlID, String.valueOf(Model.stationID)));
        req.setToken(Model.token);

        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_GETLEDSETTING, req); // 根据条件查询剩余车位屏信息
        LoadController controller = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetLedSettingResp.class, new GsonCallback.Listener()
                {
                    @Override
                    public void success(Object reqData, Object respData, String url, int paramInt)
                    {
                        GetLedSettingResp getLedSettingResp = (GetLedSettingResp) respData;
                        dealGetLedSettingRespData(getLedSettingResp.getData(), index);
                    }

                    @Override
                    public void error(Object data, String url, String errorString)
                    {
                        T.showShort(ParkingMonitoringActivity.this, "连接服务器失败");
                    }
                }, req, resultUrl, index));
        mList.add(controller);
    }


    /**
     * 从 Model rights中获取指定的权限
     *
     * @param title
     * @param itemName
     * @return
     */
    public List<GetRightsByGroupIDResp.DataBean> GetRightsByName(String title, String itemName)
    {
        if (Model.lstRights == null || Model.lstRights.size() == 0)
        {
            return null;
        }

        List<GetRightsByGroupIDResp.DataBean> temp = new ArrayList<GetRightsByGroupIDResp.DataBean>();
        for (GetRightsByGroupIDResp.DataBean val : Model.lstRights)
        {
            if (val.getFormName().equals(title) && val.getItemName().equals(itemName))
            {
                temp.add(val);
            }
        }
        return temp;
    }

    /// <summary>
    /// 卡片号码
    /// </summary>
    private String cardNO;

    /// <summary>
    /// 车道数索引
    /// </summary>
    private int modulus = 100;

    private int iIndex;

    /// <summary>
    /// 入出场标识(0表示入场，1表示出场, Flag)
    /// </summary>
    private int InOut;

    /// <summary>
    /// 压地感识别车牌
    /// </summary>
    private String sDzScan;

    /// <summary>
    /// 区别读卡或者识别（false读卡记录 true识别记录）
    /// </summary>
    private boolean bReadAuto = false;

    class QueueTask extends Thread
    {
        private boolean taskFlag;

        public QueueTask(boolean runningFlag)
        {
            taskFlag = runningFlag;
        }

        @Override
        public void run()
        {
            try
            {
                while (taskFlag)
                {
                    ModelNode modelNode = ConcurrentQueueHelper.getInstance().get();
                    if (modelNode != null)
                    {
                        L.i("###　接受到车牌数据 ###" + modelNode.toString() + ", modelNode.type.getValue():" + modelNode.type.getValue());
                        if (modelNode.type.getValue() >= 0 && modelNode.type.getValue() < 100)
                        {
                            L.i("###　接受到车牌数据 ###" + modelNode.toString());
                            boolean dzChePaiShiBieQ = DZChePaiShiBieQ(modelNode.getiDzIndex(), modelNode.getStrFile(), modelNode.getStrFileJpg(), modelNode.getStrCPH());
                            if (dzChePaiShiBieQ)// true 表示可以处理
                            {
                                strReadPicFile[modelNode.getiDzIndex()] = modelNode.getStrFile();
                                strReadPicFileJpg[modelNode.getiDzIndex()] = modelNode.getStrFileJpg();
                                String strCPH = modelNode.getStrCPH();
//                                modelNode.setStrCPH("");
//                                cardNO = modelNode.getStrCPH();
                                modulus = modelNode.getiDzIndex();
                                iIndex = modelNode.getiDzIndex();
                                InOut = Model.Channels[iIndex].iInOut;
                                sDzScan = "";
                                bReadAuto = true;

                                if ((modelNode.getStrCPH().contains("_无_") || modelNode.getStrCPH().equals("无车牌")))
                                {
                                    modelNode.type = QueueMessageTypeEnum.QUEUE_CAR_OUT_MANUAL_OPEN;
                                }
                                dealCarInAndOut(modelNode);
                            }
                            else// 不处理
                            {// false
//                                modelNode.type = QueueMessageTypeEnum.QUEUE_CAR_OUT_MANUAL_OPEN;
//                                if (System.IO.File.Exists(model.strFileJpg))
//                                {
//                                    System.IO.File.Delete(model.strFileJpg);
//                                }
//                                dealCarInAndOut(modelNode);
                            }

                            mHandler.postDelayed(new Runnable() // 延时的更新
                            {
                                @Override
                                public void run()
                                {
                                    RefreshInOut(); // 这个可以，即每一次进场出场都需要更新数据
                                }
                            }, 1000);
                        }
                        else
                        {
                            L.i("###　接受到队列数据 ###" + modelNode.toString());
                            dealUdpSendMessage(modelNode);
                        }
                    }
                    else// 和板子建立心跳
                    {
//                        if (Model.bIsKZB && Model.strKZJ.equals("1"))
//                        {
//                            if (ReadCardsRecord() == false)
//                            {
////                                return;
//                            }
//                        }
//                        else
//                        {
////                            return;
//                        }
                    }
                    Thread.sleep(200); // c# 用了300ms
                }
            }
            catch (Exception ex)
            {
                ex.printStackTrace();
                L.i("结束：" + ex.toString());
            }
        }

        public void end()
        {
            taskFlag = false;
        }
    }

    private int rowsCount = 0;

    //    读卡的记录
    public boolean ReadCardsRecord()
    {
        try
        {
            boolean Record = false;
            if (lstCDS == null || lstCDS.size() == 0)
            {
                return false;
            }

            for (int y = 0; y < lstCDS.size(); y++)
            {
                if (y != rowsCount)
                {

                }
                else
                {
                    final GetCheDaoSetResp.DataBean dataBean = lstCDS.get(y);
                    if (y + 1 == lstCDS.size())
                    {
                        rowsCount = 0;
                    }
                    else
                    {
                        rowsCount = y + 1;
                    }

                    for (int i = 0; i < Model.iChannelCount; i++)
                    {
                        if (dataBean.getCtrlNumber() == Model.Channels[i].iCtrlID && rowsCount != y)
                        {
                            modulus = i;
                            break;
                        }
                        else
                        {
                            if (Model.iChannelCount == 1 && dataBean.getCtrlNumber() == Model.Channels[i].iCtrlID)
                            {
                                modulus = 0;
                            }
                        }
                    }

                    if (dataBean.getOnLine() == 0)
                    {
                        return false;
                    }

                    if (dataBean.getXieYi() == 1)
                    {
                        cardNO = readRecordEx(dataBean.getIP(), dataBean.getCtrlNumber());
//                        L.e("cardNO:" + cardNO);
                    }

                    if (cardNO.equals("2"))
                    {
                        if (dataBean.getXieYi() == 1)
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    parkingMonitoringView.setOperatorHintInfo("控制机【" + dataBean.getIP() + "】忙");
                                }
                            });
                        }
                        else
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    parkingMonitoringView.setOperatorHintInfo("控制机【" + dataBean.getCtrlNumber() + "】忙");
                                }
                            });
                        }
                    }

                    if (cardNO.length() > 20)
                    {
                        if (cardNO.substring(0, 1).equals("E"))
                        {
                            List<String> lstData = new ArrayList<String>();
                            lstData.add(cardNO);
                            HttpPostRequest.requestAddOfflineInOut("AddOfflineInOut", dataBean.getCtrlNumber(), lstData);
                            return false;
                        }

                        bReadAuto = false;
                        Record = true;
                        break;
                    }
                    if (Model.Quit_Flag == false)
                    {
                        return false;
                    }
                }
            }
            return Record;
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            return false;
        }
    }

    private void dealUdpSendMessage(ModelNode modelNode)
    {
        synchronized (ParkingMonitoringActivity.class)
        {
            switch (modelNode.type)
            {
                case QUEUE_BEOVERDUE:
                case QUEUE_REPEATADMISSION:
                case QUEUE_NOTHISLANEPERMISSION:
                case QUEUE_PROHIBITCURRENT:
                {
                    int dzIndex = modelNode.getiDzIndex();
                    BaseApplication.getUdpSend().VoiceLoad(Model.Channels[dzIndex].sIP, Model.Channels[dzIndex].iCtrlID, (ConstantClass.VoiceEnum) modelNode.data);
                    break;
                }
                case QUEUE_OPENGATE:
                {
                    int dzIndex = modelNode.getiDzIndex();
                    L.i("Model.Channels[dzIndex].sIP:" + Model.Channels[dzIndex].sIP + ",Model.Channels[dzIndex].iCtrlID:" + Model.Channels[dzIndex].iCtrlID);
                    BaseApplication.getUdpSend().OpenGate(Model.Channels[dzIndex].sIP, Model.Channels[dzIndex].iCtrlID);//自动开闸
                    break;
                }
                case QUEUE_VOICEINYW:
                {
                    int dzIndex = modelNode.getiDzIndex();
                    BaseApplication.getUdpSend().VoiceInYW(Model.Channels[dzIndex].sIP, Model.Channels[dzIndex].iCtrlID, (VoiceInYWModel) modelNode.data);
                    break;
                }
                case QUEUE_CONFIRMCUTOFF:
                case QUEUE_BLACKLIST:
                case QUEUE_PERSONALFULL:
                case QUEUE_PROHIBITCUTOFF:
                case QUEUE_TEMPORARYCARNOTINSMALL:
                case queue_MthBeOverdueToTmpCharge:
                case QUEUE_TEMP_NOCUTOFF:
                case QUEUE_CENTERCHARGEBUTNOTEXIT:
                case QUEU_CENTERCHARGEOUTFREETIMEBUTNOTEXIT:
                case queue_SendCombinationVioce:
                {
                    int dzIndex = modelNode.getiDzIndex();
                    BaseApplication.getUdpSend().SendCombinationVioce(Model.Channels[dzIndex].sIP, Model.Channels[dzIndex].iCtrlID, (String) modelNode.data);
                    break;
                }
                case QUEUE_CARFULL:
                case QUEUE_CARFULLCONFIRMCUTOFF:
                {
                    int dzIndex = modelNode.getiDzIndex();
                    BaseApplication.getUdpSend().ParkinglotFull(Model.Channels[dzIndex].sIP, Model.Channels[dzIndex].iCtrlID, (Integer) modelNode.data);
                    break;
                }
                case QUEUE_BALANCENOTENOUGH:
                {
                    int dzIndex = modelNode.getiDzIndex();
                    BaseApplication.getUdpSend().NoMoneyInOut(Model.Channels[dzIndex].sIP, Model.Channels[dzIndex].iCtrlID);
                    break;
                }
                case QUEUE_CAROUT_SENDVOICE:
                case QUEUE_LSNOX2010ZNYKTOUTGATE:
                case QUEUE_CACLCHARGEAMOUNT:
                {
                    int dzIndex = modelNode.getiDzIndex();
                    BaseApplication.getUdpSend().LoadLsNoX2010znyktOutGate(Model.Channels[dzIndex].sIP, Model.Channels[dzIndex].iCtrlID, (LoadLsNoX2010znyktOutGateModel) modelNode.data);
                    break;
                }
                case QUEUE_TEMPOUTOPEN:
                {
                    int dzIndex = modelNode.getiDzIndex();
                    BaseApplication.getUdpSend().ShowLed55(Model.Channels[dzIndex].sIP, Model.Channels[dzIndex].iCtrlID);
                    break;
                }
                case QUEUE_LOADLSNOX2010ZNYKTINGATE:
                {
                    int dzIndex = modelNode.getiDzIndex();
                    BaseApplication.getUdpSend().LoadLsNoX2010znyktInGate(Model.Channels[dzIndex].sIP, Model.Channels[dzIndex].iCtrlID, (LoadLsNoX2010znyktInGateModel) modelNode.data);
                    break;
                }
                case queue_ShowLed:
                {
                    int dzIndex = modelNode.getiDzIndex();
                    BaseApplication.getUdpSend().ShowLed(Model.Channels[dzIndex].sIP, Model.Channels[dzIndex].iCtrlID, (Integer) modelNode.data);
                    break;
                }
                case queue_openGate_callback://
                {
                    int dzIndex = modelNode.getiDzIndex();
                    final String s = BaseApplication.getUdpSend().OpenGate(Model.Channels[dzIndex].sIP, Model.Channels[dzIndex].iCtrlID);//自动开闸
                    if (modelNode.data != null)
                    {
                        final OpenGateCallBack callBack = (OpenGateCallBack) modelNode.data;

                        mHandler.postDelayed(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                if (s.equals("0"))
                                {
                                    callBack.success(s);
                                }
                                else
                                {
                                    callBack.failed();
                                }
                            }
                        }, modelNode.dealyTime);
                    }
                    break;
                }
                case queue_DownLoadToTempCPH:
                {
                    int dzIndex = modelNode.getiDzIndex();
                    BaseApplication.getUdpSend().DownLoadToTempCPH(Model.Channels[dzIndex].sIP, Model.Channels[dzIndex].iCtrlID, (DownTempCPHModel) modelNode.data);
                    break;
                }
                case QUEUE_RELIEVEPARKINGLOTFULL:
                {
                    int dzIndex = modelNode.getiDzIndex();
                    BaseApplication.getUdpSend().RelieveParkinglotFull(Model.Channels[dzIndex].sIP, Model.Channels[dzIndex].iCtrlID, (Integer) modelNode.data);
                    break;
                }
                case QUEUE_CtrlLedShowLoad:
                {
                    CtrlLedShowLoadBean ledShowLoadBean = (CtrlLedShowLoadBean) modelNode.data;
                    int dzIndex = modelNode.getiDzIndex();
                    BaseApplication.getUdpSend().CtrlLedShowLoad(Model.Channels[dzIndex].sIP, Model.Channels[dzIndex].iCtrlID
                            , ledShowLoadBean.iCtrlShowInfo, ledShowLoadBean.iCtrlShowRemainPos, ledShowLoadBean.CtrlShowInfoText, ledShowLoadBean.CtrlShowRemainPosText);
                    break;
                }
                case QUEUE_SurplusCtrlLedShow:
                {
                    int dzIndex = modelNode.getiDzIndex();
                    BaseApplication.getUdpSend().SurplusCtrlLedShow(Model.Channels[dzIndex].sIP, Model.Channels[dzIndex].iCtrlID, (String) modelNode.data, false);
                    break;
                }
                default:
                    break;
            }
        }

    }

    /**
     * 车牌识别处理
     *
     * @param idzIint 车道索引号
     * @param strFile
     * @param strFileJpg
     * @param str1      车牌
     */
    private String strRemberCPH;
    private long timeCPH;
    private long ZdtStart;
    private int iRemberInOut;
    private String[] myCarNo = new String[11]; // 全局存储

    private boolean DZChePaiShiBieQ(final int idzIint, String strFile, String strFileJpg, String str1)
    {
        if (!strReadPicFileJpg[idzIint].equals(""))
            filesJpg = strReadPicFileJpg[idzIint];

        try
        {
            ZdtStart = System.currentTimeMillis();
            int iCountY = 0;
            if (TextUtils.isEmpty(strRemberCPH))
            {
                strRemberCPH = str1;
                timeCPH = System.currentTimeMillis();
                iRemberInOut = Model.Channels[idzIint].iInOut;
            }
            else
            {
                if (!TextUtils.isEmpty(str1) && str1.length() > 6 && strRemberCPH.length() > 6)
                {
                    for (int i = 0; i < 7; i++)
                    {
                        if (str1.substring(i, 1 + i).equals(strRemberCPH.substring(i, +i)))//判断两个车牌相同位数
                        {
                            iCountY++;
                        }
                    }
                }
            }

            if (iCountY > 3 && iRemberInOut != Model.Channels[idzIint].iInOut)
            {
                if (System.currentTimeMillis() < 1000 * Double.parseDouble(Model.iSameCphDelay) + timeCPH)
                {
//                    gsd.AddLog("在线监控" + ":DZChePaiShiBieQ", "车牌号:" + str1 + "在" + Model.iSameCphDelay.ToString() + "之内不处理4位以上相同车牌");
                    return false;
                }
                else
                {
                    strRemberCPH = str1;
                    timeCPH = System.currentTimeMillis();
                    iRemberInOut = Model.Channels[idzIint].iInOut;
                }
            }
            else
            {
                strRemberCPH = str1;
                timeCPH = System.currentTimeMillis();
                iRemberInOut = Model.Channels[idzIint].iInOut;
            }

            myCarNo[idzIint] = str1;

            L.e("str1:" + str1);
            if ((str1.contains("_无_") || str1.equals("无车牌"))) // 无牌车的处理
            {
                L.e("Model.iNoCPHAutoKZ:" + str1 + ",Model.Channels[idzIint].iInOut: " + Model.Channels[idzIint].iInOut);
                if (Model.iNoCPHAutoKZ == 1 && Model.Channels[idzIint].iInOut == 0)
                {
                    L.e("Model.iNoCPHAutoKZ:" + str1 + ",Model.Channels[idzIint].iInOut: " + Model.Channels[idzIint].iInOut);

                    SetCarInWithoutCPHReq setCarInWithoutCPHReq = new SetCarInWithoutCPHReq();
                    setCarInWithoutCPHReq.setToken(Model.token);
                    setCarInWithoutCPHReq.setCtrlNumber(Model.Channels[idzIint].iCtrlID);
                    setCarInWithoutCPHReq.setStationId(Model.stationID);

                    String resultUrl = GetServiceData.getResultUrl(METHOD_SETCARINWITHOUTCPH, setCarInWithoutCPHReq);
                    LoadController loadController = RequestManager
                            .getInstance()
                            .get(resultUrl, new GsonCallback<>(SetCarInWithoutCPHResp.class, new GsonCallback.Listener()
                            {
                                @Override
                                public void success(Object reqData, Object respData, String url, int paramInt)
                                {
                                    if (respData == null) return;
                                    SetCarInWithoutCPHResp withoutCPHResp = (SetCarInWithoutCPHResp) respData;
                                    RCodeEnum rCodeEnum = RCodeEnum.valueOf(Integer.parseInt(withoutCPHResp.getRcode()));
                                    final SetCarInWithoutCPHResp.DataBean dataBean = withoutCPHResp.getData();
                                    switch (rCodeEnum)
                                    {
                                        case SummaryCarFull:
                                        {
                                            parkingMonitoringView.setOperatorHintInfo("车位已满!");
                                            CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_CARFULL, 5, idzIint);
                                            break;
                                        }
                                        case OK:
                                            CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_OPENGATE, null, idzIint);
                                            CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_REPEATADMISSION, ConstantClass.VoiceEnum.WelCome, idzIint);
                                            parkingMonitoringView.setOperatorHintInfo("无牌车自动入场");
                                            break;
                                        default:
                                            MessageBox.show(ParkingMonitoringActivity.this, withoutCPHResp.getMsg());
                                            break;
                                    }

                                    // 对于图像来处理，进行上传 对于ImageSavePath(idzIint, 0);路径的构建交给了相应的界面即可
                                    ImageProcessing(filesJpg, dataBean.getImagePath(), idzIint, false, true, false);
                                }

                                @Override
                                public void error(Object data, String url, String errorString)
                                {

                                }
                            }, null, resultUrl, -1));
                    mList.add(loadController);
                    return false;
                }
                else
                {

                }
            }

            return true;
//            if (str1.equals(""))
//            {
//                myCarNo[idzIint] = "";
//
//                mHandler.post(new Runnable()
//                {
//                    @Override
//                    public void run()
//                    {
//                        parkingMonitoringView.setOperatorHintInfo("无车牌");
//                    }
//                });
//                return false;
//            }
//            else
//            {
//                return true;
//            }
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            final String message = ex.getMessage();
//            gsd.AddLog("在线监控", "DZChePaiShiBie" + ex.Message);
//            txbOperatorInfo.Text = ex.Message;
            mHandler.post(new Runnable()
            {
                @Override
                public void run()
                {
                    parkingMonitoringView.setOperatorHintInfo(message);
                }
            });
            return false;
        }
    }

    private void dealCarInAndOut(ModelNode modelNode)
    {
        switch (modelNode.type)
        {
            case QUEUE_CAR_IN_TYPE_AUTO: // 手动输入车牌
            {
                int getiDzIndex = modelNode.getiDzIndex();
                strReadPicFileJpg[getiDzIndex] = modelNode.getStrFileJpg();
                requestUrlUpdateUiWhenSetIn((SetCarInReq) modelNode.data, modelNode.getiDzIndex(), PlateColorEnum.Unknown);
                break;
            }
            case QUEUE_CAR_IN_TYPE_AUTO_NOPLATE:// 无牌车手动输入车牌
            {
                int getiDzIndex = modelNode.getiDzIndex();
                strReadPicFileJpg[getiDzIndex] = modelNode.getStrFileJpg();
                requestUrlRequestWhenNoPlateIn((SetCarInWithoutCPHReq) modelNode.data, modelNode.getiDzIndex());
                break;
            }
            case QUEUE_CAR_OUT_TYPE_AUTO: // 手动输入的车辆出场 对于无牌的手动出场，直接在无牌车中执行的;
            {
                int index = modelNode.getiDzIndex();
                strReadPicFileJpg[index] = modelNode.getStrFileJpg();
                L.e("QUEUE_CAR_OUT_TYPE_AUTO:" + strReadPicFileJpg[index]);
                requestUrlUpdateUIWhenSetCarOut((SetCarOutReq) modelNode.data, modelNode.getiDzIndex(), PlateColorEnum.Unknown);
                break;
            }
            case QUEUE_CAR_INOUT_TYPE_RECOGNITION: // 相机的主动识别的入场和出场
            {
                int index = modelNode.getiDzIndex();
                if (Model.Channels[index].iInOut == CAR_CHANNEL_IN)
                {
                    L.i("入场:" + Model.Channels[index].sInOutName);
                    strReadPicFileJpg[index] = modelNode.getStrFileJpg();//存到全局中了

                    SetCarInReq req = new SetCarInReq(); // 发送进场数据
                    req.setCPH(modelNode.getStrCPH());
                    req.setToken(Model.token);
                    req.setCtrlNumber(Model.Channels[index].iCtrlID);
                    req.setStationId(Model.stationID);
                    requestUrlUpdateUiWhenSetIn(req, index, PlateColorEnum.Unknown);
                }
                else if (Model.Channels[index].iInOut == CAR_CHANNEL_OUT)
                {
                    L.i("出场:" + Model.Channels[index].sInOutName);
                    strReadPicFileJpg[index] = modelNode.getStrFileJpg();//存到全局中了

                    SetCarOutReq req = new SetCarOutReq();
                    req.setCPH(modelNode.getStrCPH());
                    req.setToken(Model.token);
                    req.setCtrlNumber(Model.Channels[index].iCtrlID);
                    req.setStationId(Model.stationID);
                    requestUrlUpdateUIWhenSetCarOut(req, modelNode.getiDzIndex(), PlateColorEnum.Unknown);
                }
                break;
            }
            case QUEUE_CAR_OUT_MANUAL_OPEN://无牌车
            {
                L.e("手动触发");
                break;
            }
        }

    }

    /**
     * 请求服务器数据，然后更新ui界面
     */
    private void requestUrlUpdateUIWhenSetCarOut(final SetCarOutReq req, final int index, PlateColorEnum color)
    {
        req.setCPColor(color.getColorValue());
        String resultUrl = GetServiceData.getResultUrl(METHOD_SETCAROUT, req);
        LoadController controller = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(SetCarOutResp.class, this, req, resultUrl, index));
        mList.add(controller);
    }

    @Override
    protected void onRestart()
    {
        L.e("onRestart=======================");
        super.onRestart();
    }

    @NonNull
    private SetCarInReq initSetCarIn(String CPH, int ctrlNumber)
    {
        SetCarInReq setCarInReq = new SetCarInReq(); // 发送进场数据
        setCarInReq.setCPH(CPH);
        setCarInReq.setToken(Model.token);
        setCarInReq.setCtrlNumber(ctrlNumber);
        setCarInReq.setStationId(Model.stationID);
        return setCarInReq;
    }

    /**
     * 处理出场的返回值
     *
     * @param resp
     */
    public boolean dealSetCarOutResponse(final SetCarOutResp resp, String srcCPH, final int index, final PlateColorEnum color)
    {
        if (index < 0 || index > Model.iChannelCount - 1)
        {
            return false;
        }

        try
        {
            if (!CR.CheckUpCPH(srcCPH, false))
            {
                return false;
            }

            if (!strReadPicFileJpg[index].equals(""))
                filesJpg = strReadPicFileJpg[index];

            parkingMonitoringView.setCPHText(index, srcCPH);

            boolean isUpload = true;
            RCodeEnum rCodeEnum = RCodeEnum.valueOf(Integer.parseInt(resp.getRcode()));
            final SetCarOutResp.DataBean carOut = resp.getData();
            L.i(carOut.toString());

            switch (rCodeEnum)
            {
                case BlackList:
                {
                    String detectString = CR.prepareDetectString(carOut.getCPH(), srcCPH);
                    updateCarHintToFragment(MSG_CarHintInfoAfterResume
                            , detectString + ":" + CR.prepareDetectString(carOut.getBlackReason(), ""));
                    String chineseCPH = DeviceStringTool.GetChineseCPH(detectString) + "D2AF";
                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_BLACKLIST, chineseCPH, index);
                    return false;
                }
                case NoThisLanePermission:
                {
                    updateCarHintToFragment(MSG_CarHintInfoAfterResume, "在 " + carOut.getCtrlNumber() + " 号机上无权限！");
                    parkingMonitoringView.setOperatorHintInfo(carOut.getCtrlNumber() + " 号机上无权限!");
                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_NOTHISLANEPERMISSION, ConstantClass.VoiceEnum.Invalid, index);
                    return false;
                }
                case BeOverdue:
                {
                    parkingMonitoringView.setOperatorHintInfo("已过期，请到管理处延期!");
                    updateCarHintToFragment(MSG_CarHintInfoAfterResume, "已过期，请到管理处延期!");
                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_BEOVERDUE, ConstantClass.VoiceEnum.Overstayed, index);

                    AddOptLogReq addOptLogReq = CR.initAddOptLog("在线监控:FlowProcessing", "已过期，请联系管理处" + carOut.getCardNO());
                    String resultUrl = GetServiceData.getResultUrl(METHOD_ADDOPTLOG, CR.initAddOptLog("在线监控:FlowProcessing", "已过期，请联系管理处" + carOut.getCardNO()));
                    LoadController loadController = RequestManager
                            .getInstance()
                            .get(resultUrl, new GsonCallback<>(AddOptLogResp.class, this, addOptLogReq, resultUrl, index));
                    mList.add(loadController);
                    return false;
                }
                case BalanceNotEnough:
                {
                    updateCarHintToFragment(MSG_CarHintInfoAfterResume, "余额不足，请先充值!");
                    parkingMonitoringView.setOperatorHintInfo("余额不足，请先充值!");
                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_BALANCENOTENOUGH, null, index);
                    return false;
                }
                case NotFoundApproachRecord: // 没有发卡行记录，弹出入场的画面;
                {
                    L.i("data.getImagePath():" + carOut.getImagePath());
                    ShowImage(index, carOut.getImagePath());
                    ParkingTempGob_bigViewSub parkingTempGob_bigViewSub = new ParkingTempGob_bigViewSub(ParkingMonitoringActivity.this
                            , ParkingTempGob_bigView.E_VIEW_TYPE.E_VIEW_CHARGE_NOT_RECORD
                            , PlateColorEnum.Unknown
                            , index
                            , carOut
                            , filesJpg
                            , mHandler);
                    parkingTempGob_bigViewSub.setCallback(new RefreshParkingMonitorView());
                    parkingTempGob_bigViewSub.show();
                    return false;
                }
                case ProhibitCutOff:
                {
                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_PROHIBITCUTOFF, "ADD4", index);
                    return false;
                }
                case CenterChargeButNotExit:
                {
                    String strsLoad = "7A";
                    int iLenY = (strsLoad.length() / 2);
                    strsLoad += CR.stringPadLeft(String.valueOf(CR.YHXY(strsLoad)), 2, '0');
                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_CENTERCHARGEBUTNOTEXIT, strsLoad, index);// 发送组合语音
                    parkingMonitoringView.setOperatorHintInfo("未交费请到收费处交费");
                    updateCarHintToFragment(MSG_CarHintInfoAfterResume, "未交费请到收费处交费");
                    return false;
                }
                case CenterChargeOutFreeTimeButNotExit:
                {
                    String strsLoad = "7B";
                    int iLenY = (strsLoad.length() / 2);
                    strsLoad += CR.stringPadLeft(String.valueOf(CR.YHXY(strsLoad)), 2, '0');
                    CR.sendModeToQueue(QueueMessageTypeEnum.QUEU_CENTERCHARGEOUTFREETIMEBUTNOTEXIT, strsLoad, index);
//                UpdateTxbText(txbOperatorInfo, "已超时请回收费处补费");
                    updateCarHintToFragment(MSG_CarHintInfoAfterResume, "已超时请回收费处补费");
                    return false;
                }
                case MthFullToTmpCharge:
                case MthBeOverdueToTmpCharge:
                case OK: //继续进行处理
                {
                    break;
                }
                default:
                {
                    MessageBox.show(ParkingMonitoringActivity.this, resp.getMsg());
                    return false;
                }
            }

            String cardType = carOut.getCardType();
            if (cardType.length() > 3)
            {
                String strCardCW = CR.prepareDetectString(carOut.getCarPlace(), "");
                int openMode = Integer.parseInt(carOut.getOpenMode());
                if (openMode == OpenWayEnum.ConfirmCutOff.getValue())
                {
                    if (cardType.substring(0, 3).equals("Tmp")
                            || cardType.substring(0, 3).equals("Mtp"))//临时车和月临车，开闸确认弹出收费窗口
                    {
                        ShowImage(index, carOut.getImagePath());
                        isUpload = false;
                        ParkingTempGob_bigViewSub parkingTempGob_bigViewSub = new ParkingTempGob_bigViewSub(ParkingMonitoringActivity.this
                                , ParkingTempGob_bigView.E_VIEW_TYPE.E_VIEW_CHARGE_HAVA_RECORD
                                , PlateColorEnum.Unknown
                                , index
                                , carOut
                                , filesJpg
                                , mHandler);
                        parkingTempGob_bigViewSub.setCallback(new RefreshParkingMonitorView());
                        parkingTempGob_bigViewSub.show();
                    }
                    else if (cardType.substring(0, 3).equals("Mth")) // 固定车确认开闸
                    {
                        ShowImage(index, carOut.getImagePath());
                        isUpload = false;
                        CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_CONFIRMCUTOFF, "ABD3", index);

                        Map<String, Object> objectObjectTreeMap = new TreeMap<>();
                        objectObjectTreeMap.put("laneIndex", index);
                        objectObjectTreeMap.put("CardNO", carOut.getCardNO());
                        objectObjectTreeMap.put("CPH", carOut.getCPH());
                        objectObjectTreeMap.put("CardType", carOut.getCardType());
                        objectObjectTreeMap.put("InTime", carOut.getInTime());
                        objectObjectTreeMap.put("OutTime", carOut.getOutTime());
                        objectObjectTreeMap.put("InOutName", carOut.getInOutName());
                        objectObjectTreeMap.put("RemainingDays", carOut.getRemainingDays());
                        objectObjectTreeMap.put("RemainingPlaceCount", carOut.getRemainingPlaceCount());

                        ParkingMthCPHView parkingMthCPHView = new ParkingMthCPHView(ParkingMonitoringActivity.this, objectObjectTreeMap)
                        {
                            @Override
                            public void onCancelChargeClick()
                            {
                                requestCancelCharge(carOut);
                            }
                        };
                        parkingMthCPHView.show();
                    }
                }
                else
                {
                    if (cardType.substring(0, 3).equals("Mth")
                            || cardType.substring(0, 3).equals("Str")
                            || cardType.substring(0, 3).equals("Fre"))
                    {
                        if (strCardCW.equals(""))
                        {
                            strCardCW = "FFFF";
                        }
                        if (strCardCW.length() != 4)
                        {
                            String CarCW = strCardCW;
                            for (int i = 0; i < 4 - strCardCW.length(); i++)
                            {
                                CarCW = "0" + CarCW;
                            }
                            strCardCW = CarCW.substring(CarCW.length() - 4, CarCW.length());
                        }
                        CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_OPENGATE, null, index); // 开闸
                        CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_CAROUT_SENDVOICE, initOutGateModel(carOut, strCardCW, carOut.getRemainingDays(), (int) carOut.getBalance()), index);
                    }
                    else if (cardType.substring(0, 3).equals("Tmp")
                            || cardType.substring(0, 3).equals("Mtp"))
                    {
                        if (Model.iAutoKZ == 1 && carOut.getSFJE() == 0)
                        {
                            CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_OPENGATE, null, index); // 开闸
                            CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_TEMPOUTOPEN, null, index);
                        }
                        else
                        {
                            CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_OPENGATE, null, index);
                            CR.sendModeToQueue(QueueMessageTypeEnum.QUEUE_CAROUT_SENDVOICE, initOutGateModel(carOut, strCardCW, 0, 0), index);
                        }
                    }
                }
            }
            SurplusCPH(index, carOut.getCPH(), carOut.getCardType(), carOut.getRemainingPlaceCount(), (float) carOut.getBalance(), (float) carOut.getSFJE());

            if (Model.iPersonVideo == 1)
            {
                ImageProcessing(filesJpg, carOut.getImagePath(), index, true, isUpload, false);//上传图片到服务器
            }
            else
            {
                L.e("filesJpg:" + filesJpg);
                ImageProcessing(filesJpg, carOut.getImagePath(), index, true, isUpload, false);//出口
            }

            updateSetCarInByOut(carOut);
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            MessageBox.show(ParkingMonitoringActivity.this, ex.getMessage() + "\n", "dealSetCarOutResponse");
        }
        return true;
    }

    @NonNull
    private LoadLsNoX2010znyktOutGateModel initOutGateModel(SetCarOutResp.DataBean carOut, String strCardCW, int remainDays, int getBalance)
    {
        int[] diff = TimeConvertUtils.processTwo(CR.prepareDetectString(carOut.getInTime(), carOut.getOutTime()), carOut.getOutTime());
        LoadLsNoX2010znyktOutGateModel outGateModel = new LoadLsNoX2010znyktOutGateModel();
        outGateModel.strCPH = carOut.getCPH();
        outGateModel.CarTypeenum = CR.getCardTypeEnum(carOut.getCardType().substring(0, 3));
        outGateModel.CYkDay = remainDays;
        outGateModel.strCardCW = strCardCW;
        outGateModel.SFJE = getBalance;
        outGateModel.iIDNoticeDay = Model.iIDNoticeDay;
        outGateModel.CCzkMoney = (int) carOut.getSFJE();
//        L.e("carOut.getSFJE():" + carOut.getSFJE() + "outGateModel.CCzkMoney:" + outGateModel.CCzkMoney);
        outGateModel.iDay = diff[0];
        outGateModel.iHour = diff[1];
        outGateModel.iMinutes = diff[2];
        return outGateModel;
    }

    private void requestGetCarIn(String cph, String inName, String inOperator)//有变化；
    {
        GetCarInReq req = new GetCarInReq();
        req.setToken(Model.token);
        req.setOrderField(OrderField.getWhenGetCarIn("desc"));
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("CarparkNO", String.valueOf(Model.iParkingNo));

        if (!TextUtils.isEmpty(cph))
        {
            map.put("CPH", "%" + cph + "%");
        }
        if (!TextUtils.isEmpty(inName))
        {
            map.put("InGateName", "%" + inName + "%");
        }
        if (!TextUtils.isEmpty(inOperator))
        {
            map.put("InOperator", "%" + inOperator + "%");
        }
        req.setJsonSearchParam(JsonSearchParam.getWhenGetCarOutAndIn(map));
        L.e("req:" + req);
        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_GETCARIN, req);
        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetCarInResp.class, this, req, resultUrl, -1));
        mList.add(loadController);
    }

    /**
     * 4，获取 车场内车辆收费明细信息
     */
    private void requestGetCarOut(String cph, String outName, String outOpeator)
    {
        GetCarOutReq req = new GetCarOutReq();
        req.setToken(Model.token);
        req.setOrderField(OrderField.getWhenGetCarOut("desc"));
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("CarparkNO", String.valueOf(Model.iParkingNo));
        if (!TextUtils.isEmpty(cph))
        {
            map.put("CPH", "%" + cph + "%");
        }
        if (!TextUtils.isEmpty(outName))
        {
            map.put("OutGateName", "%" + outName + "%");
        }
        if (!TextUtils.isEmpty(cph))
        {
            map.put("OutOperator", "%" + outOpeator + "%");
        }

        req.setJsonSearchParam(JsonSearchParam.getWhenGetCarOutAndIn(map));
        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_GETCAROUT, req);

        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetCarOutResp.class, this, req, resultUrl, -1));
        mList.add(loadController);
    }

    /**
     * 5, 获取车场的车位信息
     */
    private void requestGetParkingInfo()
    {
        GetParkingInfoReq req = new GetParkingInfoReq();
        req.setToken(Model.token);
        req.setStationId(Model.stationID);
        req.setStartTime(TimeConvertUtils.longToString("yyyyMMdd000000", System.currentTimeMillis()));
        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_GETPARKINGINFO, req);
        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetParkingInfoResp.class, this, req, resultUrl, -1));
        mList.add(loadController);
    }

    /**
     * 7, 设置车辆入场操作
     *
     * @param setCarInReq
     * @return
     */
    private void requestUrlUpdateUiWhenSetIn(SetCarInReq setCarInReq, int index, PlateColorEnum color)
    {
        setCarInReq.setCPColor(color.getColorValue());
        String resultUrl = GetServiceData.getResultUrl(METHOD_SETCARIN, setCarInReq);
        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(SetCarInResp.class, this, setCarInReq, resultUrl, index));
        mList.add(loadController);
    }

    /**
     * 9, 设置无牌车车辆进场设置
     *
     * @param carInWithoutCPHReq
     * @return
     */
    @Nullable
    private void requestUrlRequestWhenNoPlateIn(SetCarInWithoutCPHReq carInWithoutCPHReq, int index)
    {
        String resultUrl = GetServiceData.getResultUrl(METHOD_SETCARINWITHOUTCPH, carInWithoutCPHReq);
        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(SetCarInWithoutCPHResp.class, this, carInWithoutCPHReq, resultUrl, index));
        mList.add(loadController);
    }

    private GetCarInReq initSelectComeCPH_Like(String cph)
    {
        GetCarInReq req = new GetCarInReq();
        req.setToken(Model.token);
        req.setJsonSearchParam(JsonSearchParam.getWhenSelectComeCPH_Like(cph.substring(1), String.valueOf(Model.iParkingNo)));
        req.setOrderField(OrderField.getSelectComeCPH_Like("desc"));
        return req;
    }


    private void requestCancelCharge(SetCarOutResp.DataBean data)
    {
        try
        {
            CancelChargeReq req = new CancelChargeReq();
            req.setToken(Model.token);
            req.setCardNO(data.getCardNO());
            req.setCardType(data.getCardType());
            req.setOutTime(TimeConvertUtils.longToString("yyyyMMddHHmmss", TimeConvertUtils.stringToLong(data.getOutTime())));

            String resultUrl = GetServiceData.getResultUrl(METHOD_CANCELCHARGE, req);
            LoadController loadController = RequestManager
                    .getInstance()
                    .get(resultUrl, new GsonCallback<>(CancelChargeResp.class, this, req, resultUrl, -1));
            mList.add(loadController);
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }

    }

    private void requestAddIDInfoFromBody()
    {
        // AddIDInfoFromBody 将结构体数据和图片以 json字符来进行传输
        CardIdInfo cardIdInfo = new CardIdInfo();
        cardIdInfo.setSAMID("0123456789");
        cardIdInfo.setName("小王");
        cardIdInfo.setSex("男");
        cardIdInfo.setNation("汉");
        cardIdInfo.setBirth("1990-10-01");
        cardIdInfo.setAddress("广东省深圳市清湖");
        cardIdInfo.setIDNumber("421088199010012888");
        cardIdInfo.setDepart("深圳公安");
        cardIdInfo.setValidityTime("2020-10-01");
        cardIdInfo.setFPLength(1024);
        cardIdInfo.setFPData(new byte[1024]);
        String cardPath = SDCardUtils.getDiskCacheDirPath(this, "/cardInfo.png");
        L.e("cardPath:" + cardPath);

        Bitmap bitmap = BitmapFactory.decodeFile(cardPath); // 从文件中读取的数据，是以文件的
        byte[] bytes = BitmapUtil.bitmapToByte(bitmap);
        cardIdInfo.setPhoto(bytes);
        cardIdInfo.setPhotoLength(bytes.length);

        String idInfoModel = JsonSearchParam.getInfoModel(cardIdInfo); // gson字符串

        GetXXXCommonReq getXXXCommonReq = new GetXXXCommonReq();
        getXXXCommonReq.setToken(Model.token);
        String resultUrl = GetServiceData.getResultUrl(METHOD_ADDIDINFOFROMBODY, getXXXCommonReq);
        L.e("resultUrl:" + resultUrl + ",length:" + bytes.length); // 采用这种方式来传递数据存在一些问题，即data的数据传递出去了吗?还是需要用自己的定义的post的方法来传递数据呢？

        //
        LoadController loadController = RequestManager
                .getInstance()
                .post(resultUrl, idInfoModel, new GsonCallback<>(GetCommonXXXResp.class, new GsonCallback.Listener()
                {
                    @Override
                    public void success(Object reqData, Object respData, String url, int paramInt)
                    {
                        L.e("success respData:" + respData);
                    }

                    @Override
                    public void error(Object data, String url, String errorString)
                    {
                        L.e("errorString:" + errorString);
                    }
                }, getXXXCommonReq, resultUrl, -1));
        mList.add(loadController);
    }

    private void requestAddIdInfoWithPhoto() // 测试可以通过的,即测试上传身份证信息
    {
// 测试的身份证数据信息 (含有身份证数据，和不含)
        CardIdInfo cardIdInfo = new CardIdInfo();
        cardIdInfo.setSAMID("0123456789");
        cardIdInfo.setName("小王");
        cardIdInfo.setSex("男");
        cardIdInfo.setNation("汉");
        cardIdInfo.setBirth("1990-10-01");
        cardIdInfo.setAddress("广东省深圳市清湖");
        cardIdInfo.setIDNumber("421088199010012888");
        cardIdInfo.setDepart("深圳公安");
        cardIdInfo.setValidityTime("2020-10-01");
        cardIdInfo.setFPLength(1024);
        cardIdInfo.setFPData(new byte[1024]);

        AddIDInfoReq addIDInfoReq = new AddIDInfoReq();
        addIDInfoReq.setToken(Model.token);
        // 将addIDInfoReq,转换成json字符串
        addIDInfoReq.setJsonModel(JsonSearchParam.getInfoModel(cardIdInfo));
        String resultUrl = GetServiceData.getResultUrl(METHOD_ADDIDINFOWITHPHOTO, addIDInfoReq);
        L.e("resultUrl:" + resultUrl);
        RequestMap params = new RequestMap();

        String cardPath = SDCardUtils.getDiskCacheDirPath(this, "/cardInfo.png");
        L.e("cardPath:" + cardPath);
        params.put("file", new File(cardPath));

        LoadController loadController = RequestManager
                .getInstance()
                .post(resultUrl, params, new GsonCallback<>(GetCommonXXXResp.class, new GsonCallback.Listener()
                {
                    @Override
                    public void success(Object reqData, Object respData, String url, int paramInt)
                    {
                        L.e("success respData:" + respData);
                    }

                    @Override
                    public void error(Object data, String url, String errorString)
                    {
                        L.e("errorString:" + errorString);
                    }
                }, addIDInfoReq, resultUrl, -1));
        mList.add(loadController);
    }


    private String filesJpg; //表示当前图片所有的路径

    private void ShowImage(int laneIndex, String networkPath)// networkPath没有用到
    {
        if (filesJpg == null)
        {
            return;
        }

        L.i("filesJpg:" + filesJpg + ",:networkPath" + networkPath);

        try
        {
            if (Model.Channels[laneIndex].iInOut == 0)
            {
                if (new File(filesJpg).exists())//入场,即是在fileJpg文件存在的情况下作的操作
                {
                    Bitmap bitmap = BitmapFactory.decodeFile(filesJpg);
                    if (Model.iPersonVideo == 1) // 人像抓拍
                    {
                    }
                    else
                    {
                        parkingMonitoringView.setInPicture(laneIndex, bitmap);
                    }
                }
                else
                {
                    L.e(networkPath + " 本地不存在");
                }
            }
            else
            {
                if (new File(filesJpg).exists())//出场
                {
                    Bitmap bitmap = BitmapFactory.decodeFile(filesJpg);
                    if (Model.iPersonVideo == 1) // 人像抓拍
                    {
                    }
                    else
                    {
                        parkingMonitoringView.setOutPicture(laneIndex, bitmap);
                    }
                }
                else
                {
                    L.e(networkPath + " 本地不存在");
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public class RefreshParkingMonitorView implements ParkingTempGob_bigViewSub.ICallBack
    {
        @Override
        public void updateAppearanceRecord(SetCarOutResp.DataBean appearanceModel, int laneIndex, String localImagePath)// 车辆开闸的时候触发
        {
            parkingMonitoringView.setCPHText(laneIndex, CR.prepareDetectString(appearanceModel.getCPH(), "")); // 设置视频显示下的车牌号
            fragmentChargeManager.setChargeInfoInTime(appearanceModel.getInTime());
            fragmentChargeManager.setChargeInfoOutTime(appearanceModel.getOutTime());
            fragmentChargeManager.setChargeInfoCarNO(appearanceModel.getCardNO());
            fragmentChargeManager.setChargeInfoCardType(CR.GetCardType(appearanceModel.getCardType(), 1));
            fragmentChargeManager.setChargeInfoPersonNO(appearanceModel.getUserNO());
            fragmentChargeManager.setChargeInfoDeptName(appearanceModel.getDeptName());
            fragmentChargeManager.setChargeInfoPersonName(appearanceModel.getUserName());
            fragmentChargeManager.setChargeInfoReminderValue(String.valueOf(appearanceModel.getBalance()));//剩余金额
            fragmentChargeManager.setChargeInfoPayMoney("0.00");//收费金额
            parkingMonitoringView.setChargeMoney("0.00");
            parkingMonitoringView.setSurplusCarCount(String.valueOf(appearanceModel.getRemainingPlaceCount()));

            if (null != localImagePath && localImagePath.length() > 0)
            {
                if (new File(localImagePath).exists())
                {
                    String fileName = moveFile(localImagePath, appearanceModel.getImagePath());
                    ImageProcessing(fileName, appearanceModel.getImagePath(), laneIndex, false, true, false);
                }
            }

            GetBinInOut();//更新界面数据
            requestGetParkingInfo(); //请求更新车场数据
        }

        @Override
        public void tempGob_big_Photo(String count)//点击照片抓拍时触发
        {//最后构建File路径
//            string Filebmps = "", PathStr = "";
//            DateTime MyCapDateTime;
//
//            if (Model.sImageSavePath.Substring(Model.sImageSavePath.Length - 1) != @"\") // @在前表示不要转义;
//            {
//                Model.sImageSavePath = Model.sImageSavePath + @"\";
//            }
//            MyCapDateTime = DateTime.Now;
//            PathStr = Model.sImageSavePath + MyCapDateTime.ToString("yyyyMMdd");
//            if (System.IO.Directory.Exists(PathStr) == false)
//            {
//                System.IO.Directory.CreateDirectory(PathStr);//创建路径
//            }
//            Filebmps = PathStr + @"\" + monitor.CardNo + MyCapDateTime.ToString("yyyyMMddHHmmss") + "证件" + ".bmp";
//            File = PathStr + @"\" + monitor.CardNo + MyCapDateTime.ToString("yyyyMMddHHmmss") + "证件" + ".jpg";
        }

        @Override
        public void binData(String CardType, double SFJE)//在改变车辆类型时，触发回调
        {
            if (CR.IsChineseCharacters(CardType))
            {
                fragmentChargeManager.setChargeInfoCardType(CardType);
            }
            else
                fragmentChargeManager.setChargeInfoCardType(CR.GetCardType(CardType, 1));
            fragmentChargeManager.setChargeInfoPayMoney(String.valueOf(SFJE));
        }
    }

    /**
     * 更新进出场数据更新
     */
    private void GetBinInOut()
    {
        final String searchCPHText = parkingMonitoringView.getSearchCPHText();
        final String inName = parkingMonitoringView.getInOutName(0);
        final String inOpeator = parkingMonitoringView.getInOutOperator(0);

        final String outName = parkingMonitoringView.getInOutName(1);
        final String outOpeator = parkingMonitoringView.getInOutOperator(1);


        L.e("searchCPHText:" + searchCPHText + ",inName:" + inName + ",inOpeator:" + inOpeator);
        L.e("searchCPHText:" + searchCPHText + ",outName:" + outName + "outOpeator:" + outOpeator);
        requestGetCarIn(searchCPHText, inName, inOpeator);
        requestGetCarOut(searchCPHText, outName, outOpeator);
    }

    private void requestUploadImage(String filesJpg, final int index)
    {
        UploadCaptureImageReq req = new UploadCaptureImageReq();
        req.setToken(Model.token);
        req.setStationId(String.valueOf(Model.stationID));
        req.setDate(TimeConvertUtils.longToString("yyyyMMdd", System.currentTimeMillis()));
        String resultUrl = GetServiceData.getResultUrl(METHOD_UPLOADCAPTUREIMAGE, req);
        RequestMap params = new RequestMap();
        params.put("file", new File(filesJpg));

        LoadController loadController = RequestManager
                .getInstance()
                .post(resultUrl, params, new GsonCallback<>(UploadCaptureImageResp2.class, new GsonCallback.Listener()
                {
                    @Override
                    public void success(Object reqData, Object respData, String url, int paramInt)
                    {
                        CR.printGsonResp(reqData, respData, url, paramInt);
                        if (Model.Channels[index].iInOut == CAR_CHANNEL_IN)
                        {
                            parkingMonitoringView.setOperatorHintInfo("入口图片上传成功!");
                        }
                        else if (Model.Channels[index].iInOut == CAR_CHANNEL_OUT)
                        {
                            parkingMonitoringView.setOperatorHintInfo("出口图片上传成功!");
                        }
                    }

                    @Override
                    public void error(Object data, String url, String errorString)
                    {
                        T.showShort(ParkingMonitoringActivity.this, "连接服务器失败");
                        if (Model.Channels[index].iInOut == CAR_CHANNEL_IN)
                        {
                            parkingMonitoringView.setOperatorHintInfo("入口图片上传失败!");
                        }
                        else if (Model.Channels[index].iInOut == CAR_CHANNEL_OUT)
                        {
                            parkingMonitoringView.setOperatorHintInfo("出口图片上传失败!");
                        }
                    }
                }, req, resultUrl, index));
        mList.add(loadController);
    }

    public String moveFile(String filesJpg, String networkImagePath)
    {
        String convertPath;
        if (networkImagePath != null)
        {
            convertPath = networkImagePath.replace("\\", "/");
        }
        else
        {
            convertPath = "";
        }

        CR.checkImagePath(ParkingMonitoringActivity.this);
        String fileName = Model.sImageSavePath + File.separator + convertPath; // 构建新路径
        String parentDir = fileName.substring(0, fileName.lastIndexOf("/"));

        File parentFile = new File(parentDir);
        if (!parentFile.exists())
        {
            parentFile.mkdirs();
        }

        File filesJpgContent = new File(filesJpg);
        //将filesJpg拷贝到fileName中即可
        FileUtil.fileChannelCopy(filesJpgContent, new File(fileName));
        try
        {
            FileUtil.deleteFile(filesJpgContent);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        return fileName;
    }


    private void ImageProcessing(
            String localImagePath // 本地存放路径
            , String networkImagePath    // 服务器请求数据返回的路径
            , int laneIndex
            , boolean isShowPicture
            , boolean isUpload // 上传
            , boolean isDown // 下载
    )
    {
        if (localImagePath == null)
        {
            return;
        }

        try
        {
            File file = new File(localImagePath);
            if (file.exists())//文件是否存在
            {
                if (isShowPicture)//且显示
                {
                    if (Model.Channels[laneIndex].iInOut == CAR_CHANNEL_IN)
                    {
                        parkingMonitoringView.setInPicture(laneIndex, BitmapFactory.decodeFile(localImagePath));
                        L.e("parkingMonitoringView.setInPicture(laneIndex, BitmapFactory.decodeFile(localImagePath));");
                    }
                    else
                    {
                        parkingMonitoringView.setOutPicture(laneIndex, BitmapFactory.decodeFile(localImagePath));
                    }

                    if (isUpload)//如果上传
                    {
                        localImagePath = moveFile(filesJpg, networkImagePath);
                    }
                }


                if (isUpload)// 上传图片
                {
                    requestUploadImage(localImagePath, laneIndex);
                }
            }
            else
            {
                if (isDown)//下载图片即可
                {
//                    requstUpdownImage();

//                    ImageInfo imageInfo = new ImageInfo();
//                    imageInfo.localPath = System.IO.Path.Combine(Model.sImageSavePath, networkImagePath);
//                    imageInfo.networkPath = networkImagePath;
//                    imageInfo.picShow = ptrShow;
//                    imageInfo.isEntrance = Model.Channels[laneIndex].iInOut > 0 ? false : true;
//                    Thread threadImageDown = new Thread(new ParameterizedThreadStart(ImageDown));
//                    threadImageDown.IsBackground = true;
//                    threadImageDown.Start(imageInfo);
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    //线程的回调
    private class ThreadCallback implements Callback
    {

        @Override
        public void onError(Thread thread, Throwable t)
        {
            L.e(String.format("线程%s运行出现异常，异常信息为：%s", thread, t.getMessage()));
        }

        @Override
        public void onCompleted(Thread thread)
        {
            L.e(String.format("线程%s运行完毕", thread));
        }

        @Override
        public void onStart(Thread thread)
        {

        }
    }

    public GetCardIssueReq initGetCardIssueReq(String cph)
    {
        GetCardIssueReq getCardIssueReq = new GetCardIssueReq(); // 请求发卡行信息
        getCardIssueReq.setToken(Model.token);
        getCardIssueReq.setJsonSearchParam(JsonSearchParam.getWhenGetCardIssue(cph.substring(1)));  // 过滤掉第一个省份简称
        getCardIssueReq.setOrderField(OrderField.getWhenGetCardIssue("asc"));
        return getCardIssueReq;
    }

    public String saveBitmapToFile(int index, String jpgFile)
    {
        parkingMonitoringView.saveImage(jpgFile, index);
        return jpgFile;
    }

    public void restartLoginUser()
    {
        LoginUserReq loginUserReq = new LoginUserReq(Model.sUserCard, Model.sUserPwd);
        String resultUrl = GetServiceData.getResultUrl(LoginActivity.METHOD_LOGINUSER, loginUserReq);
        LoadController loadController = RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(LoginUserResp.class, this, loginUserReq, resultUrl, -1));
        mList.add(loadController);
    }

    private String SendDownCmd(String IP, byte[] bData)
    {
        synchronized (ParkingMonitoringActivity.class)
        {
            return BaseApplication.getUdpSend().SendDownCmd(IP, bData);
        }
    }

    private String readRecordEx(String IP, int ctrlID)
    {
        synchronized (ParkingMonitoringActivity.class)
        {
            return BaseApplication.getUdpSend().ReadRecordEx(IP, ctrlID);
        }
    }

    private void setTime()
    {
        GetTimeModel getTimeModel = new GetTimeModel();
        synchronized (ParkingMonitoringActivity.class)
        {
            for (int y = 0; y < Model.iChannelCount; y++)
            {
                long currentTimeMillis = System.currentTimeMillis();
                getTimeModel.strTime = TimeConvertUtils.longToString(currentTimeMillis);
                getTimeModel.iWeek = TimeConvertUtils.getWeeks(currentTimeMillis);
                BaseApplication.getUdpSend().SetTime(Model.Channels[y].sIP, Model.Channels[y].iCtrlID, getTimeModel);
            }
        }
    }

    private String getTime()
    {
        GetTimeModel getTimeModel = new GetTimeModel();
        StringBuffer stringBuffer = new StringBuffer();
        synchronized (ParkingMonitoringActivity.class)
        {
            for (int y = 0; y < Model.iChannelCount; y++)
            {
                BaseApplication.getUdpSend().GetTime(Model.Channels[y].sIP, Model.Channels[y].iCtrlID, getTimeModel);

                stringBuffer.append("IP:" + Model.Channels[y].sIP + ",iCtrlID:" + Model.Channels[y].iCtrlID + getTimeModel.toString());
            }
        }
        return stringBuffer.toString();
    }
}
