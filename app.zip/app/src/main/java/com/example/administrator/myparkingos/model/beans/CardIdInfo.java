package com.example.administrator.myparkingos.model.beans;

import java.util.Arrays;

/**
 * Created by Administrator on 2017-06-20.
 */
public class CardIdInfo
{
    private long  ID; // Y
    private String  SAMID; // N 设备的SAMID信息
    private String  Name; // N 姓名
    private String  Sex; // N 性别
    private String  Nation; // N 民族
    private String  Birth; // N 出生日期
    private String  Address; // N 家庭住址
    private String  IDNumber; // Y 身份证号码
    private String  Depart; // N 签发机关
    private String  ValidityTime; // N 身份证有效期结束日
    private int  PhotoLength; // N 照片数据长度
    private byte[]  Photo; // N 照片
    private int  FPLength; // N 指纹数据长度
    private byte[]  FPData; // N 指纹数据

    public long getID()
    {
        return ID;
    }

    public void setID(long ID)
    {
        this.ID = ID;
    }

    public String getSAMID()
    {
        return SAMID;
    }

    public void setSAMID(String SAMID)
    {
        this.SAMID = SAMID;
    }

    public String getName()
    {
        return Name;
    }

    public void setName(String name)
    {
        Name = name;
    }

    public String getSex()
    {
        return Sex;
    }

    public void setSex(String sex)
    {
        Sex = sex;
    }

    public String getNation()
    {
        return Nation;
    }

    public void setNation(String nation)
    {
        Nation = nation;
    }

    public String getBirth()
    {
        return Birth;
    }

    public void setBirth(String birth)
    {
        Birth = birth;
    }

    public String getAddress()
    {
        return Address;
    }

    public void setAddress(String address)
    {
        Address = address;
    }

    public String getIDNumber()
    {
        return IDNumber;
    }

    public void setIDNumber(String IDNumber)
    {
        this.IDNumber = IDNumber;
    }

    public String getDepart()
    {
        return Depart;
    }

    public void setDepart(String depart)
    {
        Depart = depart;
    }

    public String getValidityTime()
    {
        return ValidityTime;
    }

    public void setValidityTime(String validityTime)
    {
        ValidityTime = validityTime;
    }

    public int getPhotoLength()
    {
        return PhotoLength;
    }

    public void setPhotoLength(int photoLength)
    {
        PhotoLength = photoLength;
    }

    public byte[] getPhoto()
    {
        return Photo;
    }

    public void setPhoto(byte[] photo)
    {
        Photo = photo;
    }

    public int getFPLength()
    {
        return FPLength;
    }

    public void setFPLength(int FPLength)
    {
        this.FPLength = FPLength;
    }

    public byte[] getFPData()
    {
        return FPData;
    }

    public void setFPData(byte[] FPData)
    {
        this.FPData = FPData;
    }

    @Override
    public String toString()
    {
        return "CardIdInfo{" +
                "ID=" + ID +
                ", SAMID='" + SAMID + '\'' +
                ", Name='" + Name + '\'' +
                ", Sex='" + Sex + '\'' +
                ", Nation='" + Nation + '\'' +
                ", Birth='" + Birth + '\'' +
                ", Address='" + Address + '\'' +
                ", IDNumber='" + IDNumber + '\'' +
                ", Depart='" + Depart + '\'' +
                ", ValidityTime='" + ValidityTime + '\'' +
                ", PhotoLength=" + PhotoLength +
                ", Photo=" + Arrays.toString(Photo) +
                ", FPLength=" + FPLength +
                ", FPData=" + Arrays.toString(FPData) +
                '}';
    }
}
