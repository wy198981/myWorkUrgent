package com.example.administrator.myparkingos.myUserControlLibrary.scrollerList;

import android.view.View;

/**
 * MyOnItemClickListener like OnCLickListener,but this listener is applied to form.
 * @version 1.0
 * @author �ף��أ�
 * @Time 2014-08-11
 * */
public interface MyOnItemClickListener {
	public void OnItemClickListener(View view, int line, int row, long id);
	public void OnItemLongClickListener(View view, int line, int row, long id);
}
