package com.example.administrator.myparkingos.constant;


/**
 * Created by Administrator on 2017-04-06.
 */
public class GlobalParams
{
    public static int CAR_CHANNEL_OUT = 1; // 表示车辆出口标记
    public static int CAR_CHANNEL_IN = 0; // 表示车辆入口标记

}
