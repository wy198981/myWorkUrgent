package com.example.administrator.myparkingos.model.requestInfo;

import com.example.administrator.myparkingos.model.responseInfo.GetCardIssueResp2;

import java.util.List;

/**
 * Created by Administrator on 2017-05-12.
 */
public class SaveUserAndCardIssueResp
{
    private String rcode; // Y 参考错误码列表
    private String msg; // Y 错误信息
    private List<GetCardIssueResp2.DataBean> data;

    public String getRcode()
    {
        return rcode;
    }

    public void setRcode(String rcode)
    {
        this.rcode = rcode;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg(String msg)
    {
        this.msg = msg;
    }

    public List<GetCardIssueResp2.DataBean> getData()
    {
        return data;
    }

    public void setData(List<GetCardIssueResp2.DataBean> data)
    {
        this.data = data;
    }

    @Override
    public String toString()
    {
        return "SaveUserAndCardIssueResp{" +
                "rcode='" + rcode + '\'' +
                ", msg='" + msg + '\'' +
                ", data=" + data +
                '}';
    }
}
