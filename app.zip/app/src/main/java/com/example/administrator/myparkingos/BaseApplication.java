package com.example.administrator.myparkingos;

import android.app.Application;

import com.android.volley.utils.BuildConfig;
import com.example.administrator.myparkingos.ui.onlineMonitorPage.ParkingMonitoringActivity;
import com.example.administrator.myparkingos.util.CrashHandler;
import com.example.administrator.myparkingos.util.L;
import com.example.sfmudpsdk_android.UDPSendbll;
import com.jude.http.RequestManager;

/**
 * Created by Administrator on 2017-04-17.
 */
public class BaseApplication extends Application
{
    private BaseApplication sInstance;
    private LoginActivity loginActivity;
    private ParkingMonitoringActivity parkingMonitoringActivity;
    private static UDPSendbll udpSendbll;

    @Override
    public void onCreate()
    {
        super.onCreate();
//        CrashHandler crashHandler = CrashHandler.getInstance();
//        crashHandler.init(getApplicationContext());
        sInstance = this;

//        OkGoUtil.INSTATNCE.init(this);

        RequestManager.getInstance().init(this);
        RequestManager.getInstance().setRetryTimes(1);
        RequestManager.getInstance().setTimeOut(3000);
        RequestManager.getInstance().setDebugMode(BuildConfig.DEBUG, " net ");

        udpSendbll = new UDPSendbll(0);
        udpSendbll.SetTimeOut(1000);
    }

    public void setLoginActivity(LoginActivity loginActivity)
    {
        this.loginActivity = loginActivity;
    }

    public void setParkingMonitoringActivity(ParkingMonitoringActivity parkingMonitoringActivity)
    {
        this.parkingMonitoringActivity = parkingMonitoringActivity;
    }

    static int count = 0;

    // 需要作同步处理
    public static UDPSendbll getUdpSend()
    {
        return udpSendbll;
    }

    public void closeActivity()
    {
        if (loginActivity != null)
        {
            loginActivity.finish();
        }
        if (parkingMonitoringActivity != null)
        {
            parkingMonitoringActivity.finish();
        }
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(0);
    }
}
