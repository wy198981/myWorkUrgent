package com.example.administrator.myparkingos.ui.onlineMonitorPage;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.myUserControlLibrary.niceSpinner.NiceSpinner;

/**
 * Created by Administrator on 2017-02-16.
 * 【在线监控】 --> 左侧【开闸】按钮 -->> 【电脑开闸】
 */
public class ParkingOpenActivity extends AppCompatActivity implements View.OnClickListener
{
    private EditText txtCardNO;
    private NiceSpinner cmbCarNumber;
    private Spinner cmbCardType;
    private NiceSpinner cmbKZ;
    private Button btnOK;
    private Button btnCancel;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.opendoor_activity);

        initView();

        Window window = getWindow();
        WindowManager m = getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = window.getAttributes(); // 获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 1 / 3); // 改变的是dialog框在屏幕中的位置而不是大小
        p.width = (int) (d.getWidth() * 1 / 2.5); // 宽度设置为屏幕的0.65
        window.setAttributes(p);

//        window.setBackgroundDrawableResource(R.drawable.parkdowncard_background);
        setTitle(getResources().getString(R.string.computeOpenDoor));
    }

    private void initView()
    {

        txtCardNO = (EditText) findViewById(R.id.txtCardNO);
        txtCardNO.setOnClickListener(this);
        cmbCarNumber = (NiceSpinner) findViewById(R.id.cmbCarNumber);
        cmbCarNumber.setOnClickListener(this);
        cmbCardType = (Spinner) findViewById(R.id.cmbCardType);
        cmbCardType.setOnClickListener(this);
        cmbKZ = (NiceSpinner) findViewById(R.id.cmbKZ);
        cmbKZ.setOnClickListener(this);
        btnOK = (Button) findViewById(R.id.btnOK);
        btnOK.setOnClickListener(this);
        btnCancel = (Button) findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(this);
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.btnOK:

                break;
            case R.id.btnCancel:

                break;
        }
    }
}
