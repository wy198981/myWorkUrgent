package com.example.administrator.myparkingos.ui.onlineMonitorPage;

import android.app.Activity;

/**
 * Created by Administrator on 2017-02-16.
 * 【点击车内明细，弹出界面】
 */
public class ParkingUpdateCPHView
{

}
