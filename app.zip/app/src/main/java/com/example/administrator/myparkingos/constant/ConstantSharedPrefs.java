package com.example.administrator.myparkingos.constant;

/**
 * Created by Administrator on 2017-02-22.
 */
public class ConstantSharedPrefs
{

    public static final String FileAppSetting = "AppSetting";
    public static final String ParkingCommunicationConfig = "ParkingCommunicationConfig";
    public static final String ServiceIP = "ServiceIP";
    public static final String ServicePort = "ServicePort";
    public static final String StationID = "StationID";
    public static final String UserCode = "UserCode";
    public static final String LoginDate = "LoginDate";
}
