package com.example.administrator.myparkingos.model.requestInfo;

/**
 * Created by Administrator on 2017-05-02.
 */
public class GetStationSetAndOperatorsWithoutLoginReq
{
    private String CallBack; // N	是否使用JSONP方式。关于JSONP方式请参考Javascript跨域访问一节。

    public String getCallBack()
    {
        return CallBack;
    }

    public void setCallBack(String callBack)
    {
        CallBack = callBack;
    }

    @Override
    public String toString()
    {
        return "GetStationSetAndOperatorsWithoutLoginReq{" +
                "CallBack='" + CallBack + '\'' +
                '}';
    }
}
