package com.example.administrator.myparkingos.model.responseInfo;


import java.util.List;

/**
 * Created by Administrator on 2017-05-11.
 */
public class GetIssueFormDataResp
{
    private String rcode; // Y 参考错误码列表
    private String msg; // Y 错误信息
    private DataBean data; // N

    @Override
    public String toString()
    {
        return "GetIssueFormDataResp{" +
                "rcode='" + rcode + '\'' +
                ", msg='" + msg + '\'' +
                ", data=" + data +
                '}';
    }

    public String getRcode()
    {
        return rcode;
    }

    public void setRcode(String rcode)
    {
        this.rcode = rcode;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg(String msg)
    {
        this.msg = msg;
    }

    public DataBean getData()
    {
        return data;
    }

    public void setData(DataBean data)
    {
        this.data = data;
    }

    public static class DataBean
    {
        private List<GetParkJHSetResp.DataBean> Device; // Y   参考机号表数据结构
        private List<GetUserInfoResp.DataBean> UserInfo; // Y   参考人员表数据结构
        private List<GetCardIssueResp2.DataBean> CardIssue; // Y   参考发行表数据结构
        private List<GetCardTypeDefResp.DataBean> CardTypeDef; // Y   参考卡类型定义表数据结构
        private String AutoUserNO; // Y   自动生成的用户编号
        private String AutoCardNO; // Y   自动生成的车辆编号

        @Override
        public String toString()
        {
            return "DataBean{" +
                    "Device=" + Device +
                    ", UserInfo=" + UserInfo +
                    ", CardIssue=" + CardIssue +
                    ", CardTypeDef=" + CardTypeDef +
                    ", AutoUserNO='" + AutoUserNO + '\'' +
                    ", AutoCardNO='" + AutoCardNO + '\'' +
                    '}';
        }

        public List<GetParkJHSetResp.DataBean> getDevice()
        {
            return Device;
        }

        public void setDevice(List<GetParkJHSetResp.DataBean> device)
        {
            Device = device;
        }

        public List<GetUserInfoResp.DataBean> getUserInfo()
        {
            return UserInfo;
        }

        public void setUserInfo(List<GetUserInfoResp.DataBean> userInfo)
        {
            UserInfo = userInfo;
        }

        public List<GetCardIssueResp2.DataBean> getCardIssue()
        {
            return CardIssue;
        }

        public void setCardIssue(List<GetCardIssueResp2.DataBean> cardIssue)
        {
            CardIssue = cardIssue;
        }

        public List<GetCardTypeDefResp.DataBean> getCardTypeDef()
        {
            return CardTypeDef;
        }

        public void setCardTypeDef(List<GetCardTypeDefResp.DataBean> cardTypeDef)
        {
            CardTypeDef = cardTypeDef;
        }

        public String getAutoUserNO()
        {
            return AutoUserNO;
        }

        public void setAutoUserNO(String autoUserNO)
        {
            AutoUserNO = autoUserNO;
        }

        public String getAutoCardNO()
        {
            return AutoCardNO;
        }

        public void setAutoCardNO(String autoCardNO)
        {
            AutoCardNO = autoCardNO;
        }
    }
}
