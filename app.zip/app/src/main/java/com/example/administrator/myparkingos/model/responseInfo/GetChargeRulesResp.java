package com.example.administrator.myparkingos.model.responseInfo;

import java.util.List;

/**
 * Created by Administrator on 2017-06-30.
 */
public class GetChargeRulesResp
{
    private String rcode;  // 参考错误码列表
    private String msg;  //错误信息
    private int PageIndex;  //当前页码。仅当查询时指定了分页参数才有此值。
    private int PageSize;  // 分页大小。仅当查询时指定了分页参数才有此值。
    private int TotalRows;  //总行数。仅当查询时指定了分页参数才有此值。
    //Data  参考说明中的描述    如果没有指定ExportFields参数则为数据Model数组，否则为下载导出文件的完整URL

    private List<DataBean> data;

    @Override
    public String toString()
    {
        return "GetChargeRulesResp{" +
                "rcode='" + rcode + '\'' +
                ", msg='" + msg + '\'' +
                ", PageIndex=" + PageIndex +
                ", PageSize=" + PageSize +
                ", TotalRows=" + TotalRows +
                ", data=" + data +
                '}';
    }

    public String getRcode()
    {
        return rcode;
    }

    public void setRcode(String rcode)
    {
        this.rcode = rcode;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg(String msg)
    {
        this.msg = msg;
    }

    public int getPageIndex()
    {
        return PageIndex;
    }

    public void setPageIndex(int pageIndex)
    {
        PageIndex = pageIndex;
    }

    public int getPageSize()
    {
        return PageSize;
    }

    public void setPageSize(int pageSize)
    {
        PageSize = pageSize;
    }

    public int getTotalRows()
    {
        return TotalRows;
    }

    public void setTotalRows(int totalRows)
    {
        TotalRows = totalRows;
    }

    public List<DataBean> getData()
    {
        return data;
    }

    public void setData(List<DataBean> data)
    {
        this.data = data;
    }

    public static class DataBean
    {
        private long ID; // Y 自增长唯一标识
        private int ParkID; // Y 车场编号。同一种卡不同车场可设置不同的收费率。
        private String CardType; // Y 实际卡类型标识。如TmpA、TmpB。该字段的值应从卡类型定义Model的Identifying字段中选取。
        private int FreeMinute; // Y 如果CardType为临时卡(Tmp开头)，则此字段表示免费分钟，停车时间不超过此值时不计费；
        private int TopSF; // Y 如果CardType为月租卡(Mth开头)，则此字段表示每次交费应交多少个月的费用；
        private int Hours; // Y 每日最高收费金额。
        private double JE; // Y 参考收费模式说明。
        private boolean Enabled; // N 如果CardType为临时卡(Tmp开头)，参考收费模式说明；
        private String Remarks; // N 如果CardType为月租卡(Mth开头)，则此字段表示每次交费应交多少金额；
        private String ChineseName; // N 参考卡类型定义Model的同名字段

        @Override
        public String toString()
        {
            return "DataBean{" +
                    "ID=" + ID +
                    ", ParkID=" + ParkID +
                    ", CardType='" + CardType + '\'' +
                    ", FreeMinute=" + FreeMinute +
                    ", TopSF=" + TopSF +
                    ", Hours=" + Hours +
                    ", JE=" + JE +
                    ", Enabled=" + Enabled +
                    ", Remarks='" + Remarks + '\'' +
                    ", ChineseName='" + ChineseName + '\'' +
                    '}';
        }

        public long getID()
        {
            return ID;
        }

        public void setID(long ID)
        {
            this.ID = ID;
        }

        public int getParkID()
        {
            return ParkID;
        }

        public void setParkID(int parkID)
        {
            ParkID = parkID;
        }

        public String getCardType()
        {
            return CardType;
        }

        public void setCardType(String cardType)
        {
            CardType = cardType;
        }

        public int getFreeMinute()
        {
            return FreeMinute;
        }

        public void setFreeMinute(int freeMinute)
        {
            FreeMinute = freeMinute;
        }

        public int getTopSF()
        {
            return TopSF;
        }

        public void setTopSF(int topSF)
        {
            TopSF = topSF;
        }

        public int getHours()
        {
            return Hours;
        }

        public void setHours(int hours)
        {
            Hours = hours;
        }

        public double getJE()
        {
            return JE;
        }

        public void setJE(double JE)
        {
            this.JE = JE;
        }

        public boolean isEnabled()
        {
            return Enabled;
        }

        public void setEnabled(boolean enabled)
        {
            Enabled = enabled;
        }

        public String getRemarks()
        {
            return Remarks;
        }

        public void setRemarks(String remarks)
        {
            Remarks = remarks;
        }

        public String getChineseName()
        {
            return ChineseName;
        }

        public void setChineseName(String chineseName)
        {
            ChineseName = chineseName;
        }
    }
}
