package com.example.administrator.myparkingos.ui;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.model.responseInfo.GetCarInReportResp;
import com.example.administrator.myparkingos.model.responseInfo.GetQueryResp;
import com.example.administrator.myparkingos.model.responseInfo.GetQuerySchemeResp;
import com.example.administrator.myparkingos.util.L;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2017-07-06.
 */
public class FragmentChargeRecordManager
{
    private FragmentManager mFragmentManager;

    private Fragment currentChargeFragment = new Fragment();
    private List<Fragment> fragmentsList = new ArrayList<>();
    public static final String CURRENT_FRAGMENT = "STATE_FRAGMENT_SHOW_CHARGE";
    private int currentIndex = 0;

    private final String CHAGEMANAGERNAME = "ChargeRecordManagerName";
    public FragmentChargeRecordManager(FragmentManager fragmentManager)
    {
        mFragmentManager = fragmentManager;
    }

    public String createTagName(int index)
    {
        return new StringBuffer(CHAGEMANAGERNAME).append(index).toString();
    }

    public void init(@Nullable Bundle savedInstanceState)
    {
        if (savedInstanceState != null)
        { // “内存重启”时调用

            //获取“内存重启”时保存的索引下标
            currentIndex = savedInstanceState.getInt(CURRENT_FRAGMENT, 0);
//            L.e("currentIndex.............." + currentIndex);

            Fragment fragmentByTag0 = mFragmentManager.findFragmentByTag(createTagName(0));
            if (fragmentByTag0 == null)
            {
                Log.i("wyDebug", "fragmentByTag0 == null");
                fragmentByTag0 = new CarChargeSelectFragment();
            }

            Fragment fragmentByTag1 = mFragmentManager.findFragmentByTag(createTagName(1));
            if (fragmentByTag1 == null)
            {
                Log.i("wyDebug", "fragmentByTag1 == null");
                fragmentByTag1 = new CarChargeResultFragment();
            }
            fragmentsList.add(fragmentByTag0);
            fragmentsList.add(fragmentByTag1);
            loadFragment();
        }
        else
        {
            L.e("fragmentsList.size:" + fragmentsList.size());
            //正常启动时调用
            fragmentsList.add(new CarChargeSelectFragment());// 0
            fragmentsList.add(new CarChargeResultFragment());// 1
//            showFragment(currentIndex);
            loadFragment();
        }
    }

    /**
     * 使用show() hide()切换页面
     * 显示fragment
     */
    public void showFragment(int index)
    {

        FragmentTransaction transaction = mFragmentManager.beginTransaction();
        currentIndex = index;

        transaction
                .hide(currentChargeFragment)
                .show(fragmentsList.get(currentIndex));

        currentChargeFragment = fragmentsList.get(currentIndex);
        transaction.commit();
    }

    public void loadFragment()
    {
        FragmentTransaction mBeginTreansaction = mFragmentManager.beginTransaction();
        for (int i = 0; i < fragmentsList.size(); i++)
        {
            if (fragmentsList.get(i).isAdded())
            {
            }
            else
            {
                mBeginTreansaction.add(R.id.flCharge_Content, fragmentsList.get(i), createTagName(i));
            }
            mBeginTreansaction.hide(fragmentsList.get(i));
        }

        if (currentIndex >=0 && currentIndex < fragmentsList.size())
        {
            mBeginTreansaction.show(fragmentsList.get(currentIndex));
        }

        currentChargeFragment = fragmentsList.get(currentIndex);
        mBeginTreansaction.commitAllowingStateLoss();
    }

    public void setStartTime(String text)
    {
        CarChargeSelectFragment carChargeSelectFragment = (CarChargeSelectFragment) fragmentsList.get(0);
        carChargeSelectFragment.setStartTime(text);
    }

    public void setEndTime(String text)
    {
        CarChargeSelectFragment carChargeSelectFragment = (CarChargeSelectFragment) fragmentsList.get(0);
        carChargeSelectFragment.setEndTime(text);
    }

    public void setSelectGridData(List<GetQueryResp.DataBean> dataList)
    {
        CarChargeSelectFragment carChargeSelectFragment = (CarChargeSelectFragment) fragmentsList.get(0);
        carChargeSelectFragment.setGridData(dataList);
    }

    public void setResultCountInfo(GetCarInReportResp.DataBean inReportResp)
    {
        CarChargeResultFragment carChargeResultFragment = (CarChargeResultFragment) fragmentsList.get(1);
        carChargeResultFragment.setShowContent(inReportResp);
    }

    public void setSelectPlan(Map<String, List<GetQuerySchemeResp.DataBean>> selectPlan)
    {
        CarChargeSelectFragment carChargeSelectFragment = (CarChargeSelectFragment) fragmentsList.get(0);
        carChargeSelectFragment.setPlan(selectPlan);
    }

}
