package com.example.administrator.myparkingos.model.responseInfo;

/**
 * Created by Administrator on 2017-05-08.
 */
public class LogOutResp
{
    private String rcode; // rcode 参考错误码列表
    private String msg; // msg 错误信息
    private Object data; // data

    public String getRcode()
    {
        return rcode;
    }

    public void setRcode(String rcode)
    {
        this.rcode = rcode;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg(String msg)
    {
        this.msg = msg;
    }

    public Object getData()
    {
        return data;
    }

    public void setData(Object data)
    {
        this.data = data;
    }

    @Override
    public String toString()
    {
        return "LogOutResp{" +
                "rcode='" + rcode + '\'' +
                ", msg='" + msg + '\'' +
                ", data=" + data +
                '}';
    }
}
