package com.example.administrator.myparkingos.ui.onlineMonitorPage;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.administrator.mydistributedparkingos.R;

import java.util.Calendar;

/**
 * Created by Administrator on 2017-02-16.
 * 【在线监控】 -->> 【黑名单登记】
 */
public class FormAddBlackListActivity extends AppCompatActivity
{


    private Spinner spinProvince;
    private EditText etInputCarPlate;
    private TextView tvStartTime;
    private TextView tvEndTime;
    private EditText etReson;
    private Button btnAdd;
    private Button btnQuery;
    private Button btnDelete;
    private Button btnDeleteAll;
    private Button btnQuit;
    private ListView listView;
    private int mYear;
    private int mMonth;
    private int mDay;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.form_addblacklist);
    }



}
