package com.example.administrator.myparkingos.ui.onlineMonitorPage;

import android.app.Activity;
import android.app.Dialog;
import android.text.TextUtils;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.constant.CR;
import com.example.administrator.myparkingos.constant.ConstantSharedPrefs;
import com.example.administrator.myparkingos.constant.JsonSearchParam;
import com.example.administrator.myparkingos.constant.OrderField;
import com.example.administrator.myparkingos.constant.RCodeEnum;
import com.example.administrator.myparkingos.model.GetServiceData;
import com.example.administrator.myparkingos.model.beans.Model;
import com.example.administrator.myparkingos.model.requestInfo.GetWorkHandoverPrintReq;
import com.example.administrator.myparkingos.model.requestInfo.GetXXXCommonReq;
import com.example.administrator.myparkingos.model.requestInfo.SetWorkHandoverReq;
import com.example.administrator.myparkingos.model.responseInfo.GetBillPrintSetResp;
import com.example.administrator.myparkingos.model.responseInfo.GetBlacklistResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCommonXXXResp;
import com.example.administrator.myparkingos.model.responseInfo.GetOperatorsResp;
import com.example.administrator.myparkingos.model.responseInfo.GetWorkHandoverPrintResp;
import com.example.administrator.myparkingos.model.responseInfo.SetWorkHandoverResp;
import com.example.administrator.myparkingos.myUserControlLibrary.MessageBox;
import com.example.administrator.myparkingos.myUserControlLibrary.niceSpinner.NiceSpinner;
import com.example.administrator.myparkingos.myUserControlLibrary.radioBtn.FlowRadioGroup;
import com.example.administrator.myparkingos.myUserControlLibrary.spinnerList.SpinerPopWindow;
import com.example.administrator.myparkingos.util.L;
import com.example.administrator.myparkingos.util.SPUtils;
import com.example.administrator.myparkingos.util.TimeConvertUtils;
import com.example.administrator.myparkingos.volleyUtil.callback.GsonCallback;
import com.jude.http.RequestListener;
import com.jude.http.RequestManager;

import java.sql.Time;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017-03-13.
 */
public class ParkingChangeView implements View.OnClickListener, GsonCallback.Listener
{
    private Dialog dialog;
    private FlowRadioGroup rgSelectProvince;
    private Button btnCarInputOk;
    private Button btnCarIntCancel;
    private Button btnNoPlateCancel;
    private Button btnLogin;
    private Button btnGiveUp;
    private Button btnPrint;


    private final String METHOD_GETOPERATORS = "GetOperators";
    private NiceSpinner cmbUserNO;
    private EditText txtPassWord;
    private ArrayList userNoList;
    private TextView lblUserNo;
    private Activity mActivity;

    public ParkingChangeView(Activity activity)
    {
        mActivity = activity;
        dialog = new Dialog(mActivity); // @android:style/Theme.Dialog
        dialog.setContentView(R.layout.parking_changeshift);
        dialog.setCanceledOnTouchOutside(true);

        Window window = dialog.getWindow();
        WindowManager m = mActivity.getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = window.getAttributes(); // 获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 1 / 3); // 改变的是dialog框在屏幕中的位置而不是大小
        p.width = (int) (d.getWidth() * 1 / 3); // 宽度设置为屏幕的0.65
        window.setAttributes(p);

        initView();
//        dialog.getWindow().setBackgroundDrawableResource(R.drawable.parkdowncard_background);
        dialog.setTitle(mActivity.getResources().getString(R.string.parkMontior_shiftLog));
    }

    private void initView()
    {
        btnLogin = (Button) dialog.findViewById(R.id.btnLogin);
        btnGiveUp = (Button) dialog.findViewById(R.id.btnGiveUp);
        btnPrint = (Button) dialog.findViewById(R.id.btnPrint);

        cmbUserNO = (NiceSpinner) dialog.findViewById(R.id.cmbUserNO);
        txtPassWord = (EditText) dialog.findViewById(R.id.txtPassWord);

        lblUserNo = (TextView) dialog.findViewById(R.id.lblUserNo);

        btnLogin.setOnClickListener(this);
        btnGiveUp.setOnClickListener(this);
        btnPrint.setOnClickListener(this);

        cmbUserNO.setSpinnerListener(new NiceSpinner.SpinnerListener()
        {
            @Override
            public void OnSpinnerItemClick(int pos)
            {
                lblUserNo.setText(getUserNo(cmbUserNO.getCurrentText()));
            }
        });
        userNoList = new ArrayList();
        cmbUserNO.refreshData(userNoList, 0);
    }

    private String getUserNo(String userName)
    {
        if (mOperatorsList == null)
        {
            return "";
        }

        for (GetOperatorsResp.DataBean item : mOperatorsList)
        {
            if (item.getUserName().equals(userName))
            {
                return item.getUserNO();
            }
        }
        return "";
    }

    private GetOperatorsResp.DataBean findOperator(String userName)
    {
        if (mOperatorsList == null)
        {
            return null;
        }

        for (GetOperatorsResp.DataBean item : mOperatorsList)
        {
            if (item.getUserName().equals(userName))
            {
                return item;
            }
        }
        return null;
    }

    private List<GetOperatorsResp.DataBean> mOperatorsList;

    private void setCmbUserNo(List<GetOperatorsResp.DataBean> dataBean)
    {
        if (dataBean.size() == 0)
        {
            setUserHintInfo("");
            L.e("dataBean.size() == 0");
        }
        else
        {
            mOperatorsList = dataBean;
            for (GetOperatorsResp.DataBean item : dataBean)
            {
                userNoList.add(item.getUserName());
            }
            cmbUserNO.refreshData(userNoList, 0);

            setUserHintInfo(mOperatorsList.get(0).getUserNO());
        }

    }

    private void setUserHintInfo(String text)
    {
        lblUserNo.setText(text);
    }

    public void show()
    {
        if (dialog != null)
        {
            prepareInitView();//根据服务器情况的数据
            txtPassWord.setText("");//直接设置
            dialog.show();
        }
    }

    /**
     * 每次显示更新操作姓名的列表数据
     */
    private void prepareInitView()
    {
        GetXXXCommonReq getXXXCommonReq = new GetXXXCommonReq();
        getXXXCommonReq.setToken(Model.token);
        getXXXCommonReq.setJsonSearchParam(JsonSearchParam.getByUserNo(Model.sUserCard, true));
        getXXXCommonReq.setOrderField(OrderField.getOperators("desc"));

        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_GETOPERATORS, getXXXCommonReq);
        RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetOperatorsResp.class, this, getXXXCommonReq, resultUrl, -1));
    }

    public void dismiss()
    {
        if (dialog != null && dialog.isShowing())
        {
            dialog.dismiss();
        }
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.btnLogin:
                onBtnLogin();
                break;
            case R.id.btnGiveUp:
                onBtnGiveUp();
                break;
            case R.id.btnPrint:
                onBtnPrint();
                break;
        }
    }

    private void onBtnPrint()
    {
        if (TextUtils.isEmpty(lblUserNo.getText().toString().trim()))
        {
            MessageBox.show(mActivity, "请选择操作员编号");
            return;
        }

        GetWorkHandoverPrintReq getWorkHandoverPrintReq = new GetWorkHandoverPrintReq();
        getWorkHandoverPrintReq.setToken(Model.token);
        getWorkHandoverPrintReq.setStationId(Model.stationID);

        String resultUrl = GetServiceData.getInstance().getResultUrl("GetWorkHandoverPrint", getWorkHandoverPrintReq);
        RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetWorkHandoverPrintResp.class, this, getWorkHandoverPrintReq, resultUrl, -1));
    }

    private void onBtnGiveUp()
    {
        dismiss();
    }

    /**
     * 点击登录按钮
     */
    private void onBtnLogin()
    {
        if (!cmbUserNO.getCurrentText().trim().equals(Model.sUserCard))
        {
            if (Model.sUserCard.equals("888888")
                    || Model.sUserName.equals("管理员")
                    || lblUserNo.getText().toString().trim().equals("888888"))
            {
                MessageBox.show(mActivity, "【管理员】不能换班登录！");
                return;
            }

            if (mOperatorsList.size() > 0) //
            {
                GetOperatorsResp.DataBean operator = findOperator(cmbUserNO.getCurrentText());
                if (operator != null && operator.getCardNO().length() > 0)
                {
                    String userMd5 = CR.UserMd5(txtPassWord.getText().toString().trim());
                    requstSetWorkHandover(operator, operator.getCardNO(), userMd5);
                }
            }
        }
        else
        {
            updateStatus("相同操作编号不用换班");
        }

        txtPassWord.setText("");
//        lblUserName.Content = "";//没有显示
        dismiss();
    }

    private void requstSetWorkHandover(GetOperatorsResp.DataBean operator, String cardNO, String password)
    {
        SetWorkHandoverReq setWorkHandoverReq = new SetWorkHandoverReq();
        setWorkHandoverReq.setToken(Model.token);
        setWorkHandoverReq.setStationId(Model.stationID);
        setWorkHandoverReq.setPassword(password);
        setWorkHandoverReq.setTakeOverOperatorNo(cardNO);

        String resultUrl = GetServiceData.getInstance().getResultUrl("SetWorkHandover", setWorkHandoverReq);
        RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(SetWorkHandoverResp.class, this, operator, resultUrl, -1));
    }

    @Override
    public void success(Object reqData, Object respData, String url, int paramInt)
    {
        CR.printGsonResp(reqData, respData, url, paramInt);
        if (respData instanceof GetOperatorsResp)
        {
            GetOperatorsResp operatorsResp = (GetOperatorsResp) respData;
            if (Integer.parseInt(operatorsResp.getRcode()) != RCodeEnum.OK.getValue())
            {
                L.e(operatorsResp.getMsg());
            }
            else
            {
                if (operatorsResp.getData() == null)
                {
                    L.e("operatorsResp.getData() == null");
                    return;
                }

                setCmbUserNo(operatorsResp.getData());
            }
        }
        else if (respData instanceof SetWorkHandoverResp)
        {
            SetWorkHandoverResp setWorkHandoverResp = (SetWorkHandoverResp) respData;
            if (Integer.parseInt(setWorkHandoverResp.getRcode()) != RCodeEnum.OK.getValue())
            {
                L.e(setWorkHandoverResp.getMsg());
            }
            else
            {
                if (setWorkHandoverResp.getData() != null && setWorkHandoverResp.getData().getModel() != null)
                {
                    dealWorkHandoverResp(setWorkHandoverResp.getData().getModel(), (GetOperatorsResp.DataBean) reqData, setWorkHandoverResp.getData().getToken());
                    updateStatus("增加一条新换班纪录");
                }
                else
                {
                    updateStatus("增加一条新换班纪录");
                }
            }
        }
        else if (respData instanceof GetWorkHandoverPrintResp)
        {
            GetWorkHandoverPrintResp getWorkHandoverPrintResp = (GetWorkHandoverPrintResp) respData;
            if (Integer.parseInt(getWorkHandoverPrintResp.getRcode()) != RCodeEnum.OK.getValue())
            {
                L.e(getWorkHandoverPrintResp.getMsg());
            }
            else
            {
                SetWorkHandoverResp.Handover handover = getWorkHandoverPrintResp.getData();
                handover.setTakeOverOperatorName(cmbUserNO.getCurrentText());
                handover.setTakeOverOperatorNO(lblUserNo.getText().toString().trim()); // lblUserNo 没有显示

                L.e("handover:" + handover.toString()); // 显示的报表的数据
            }
        }
        else if (respData instanceof GetBillPrintSetResp)
        {
            GetBillPrintSetResp getBillPrintSetResp = (GetBillPrintSetResp) respData;
            if (Integer.parseInt(getBillPrintSetResp.getRcode()) != RCodeEnum.OK.getValue())
            {
                L.e(getBillPrintSetResp.getMsg());
            }
            else
            {
//                停车卡初次发行收费票据"));
            }
        }
    }

    protected void updateStatus(String record)
    {

    }

    private void dealWorkHandoverResp(SetWorkHandoverResp.Handover model, GetOperatorsResp.DataBean reqData, String token)
    {
        try
        {
            Model.sUserCard = TextUtils.isEmpty(model.getTakeOverOperatorNO()) ? reqData.getCardNO() : model.getTakeOverOperatorNO();
            Model.sUserName = TextUtils.isEmpty(model.getTakeOverOperatorName()) ? reqData.getUserName() : model.getTakeOverOperatorName();
            Model.dLoginTime = TimeConvertUtils.stringToLong(model.getThisTakeOverTime());
            Model.token = token;

            if (Model.bOnlyLocation)
            {
                AutoPrint(model);//打印相关的
            }

            SPUtils.put(ConstantSharedPrefs.FileAppSetting, mActivity.getApplicationContext(),
                    ConstantSharedPrefs.UserCode, String.valueOf(Model.sUserCard));

            SPUtils.put(ConstantSharedPrefs.FileAppSetting, mActivity.getApplicationContext(),
                    ConstantSharedPrefs.LoginDate, String.valueOf(Model.dLoginTime));
        }
        catch (ParseException e)
        {
            e.printStackTrace();
        }

    }

    private void AutoPrint(SetWorkHandoverResp.Handover model)
    {
        if (model == null)  return;

        GetXXXCommonReq getXXXCommonReq = new GetXXXCommonReq();
        getXXXCommonReq.setToken(Model.token);
        String resultUrl = GetServiceData.getInstance().getResultUrl("tBillPrintSet", getXXXCommonReq);
        RequestManager
                .getInstance()
                .get(resultUrl, new GsonCallback<>(GetBillPrintSetResp.class, this, getXXXCommonReq, resultUrl, -1));
    }


    @Override
    public void error(Object data, String url, String errorString)
    {
        L.e("服务器连接失败");
    }
}
