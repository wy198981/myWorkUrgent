package com.example.administrator.myparkingos.constant;

import android.content.Context;
import android.text.TextUtils;

import com.example.administrator.myparkingos.common.utils.MD5Util;
import com.example.administrator.myparkingos.model.beans.Model;
import com.example.administrator.myparkingos.model.beans.ModelNode;
import com.example.administrator.myparkingos.model.requestInfo.AddOptLog;
import com.example.administrator.myparkingos.model.requestInfo.AddOptLogReq;
import com.example.administrator.myparkingos.model.responseInfo.GetAutoTempDownLoadResp;
import com.example.administrator.myparkingos.model.responseInfo.GetCardTypeDefResp;
import com.example.administrator.myparkingos.model.responseInfo.GetRightsByGroupIDResp;
import com.example.administrator.myparkingos.util.ConcurrentQueueHelper;
import com.example.administrator.myparkingos.util.L;
import com.example.administrator.myparkingos.util.RegexUtil;
import com.example.administrator.myparkingos.util.SDCardUtils;
import com.example.administrator.myparkingos.util.SPUtils;
import com.example.administrator.myparkingos.util.TimeConvertUtils;
import com.example.sfmudpsdk_android.ConstantClass;
import com.google.gson.Gson;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Administrator on 2017-04-12.
 */
public class CR
{
    // 存放的通用的库，作一些临时处理;
    private static Map<String, String> dicCardType = new LinkedHashMap<String, String>();
    private static Map<String, String> dicCardTypeValue = new LinkedHashMap<String, String>();
    /// <summary>
    /// 更新卡片种类
    /// </summary>
    /// <param name="dt"></param>

    public static void BinDic(List<GetCardTypeDefResp.DataBean> lstCTD)
    {
        if (lstCTD == null)
        {
            return;
        }
        if (dicCardType != null)
        {
            dicCardType.clear();
            dicCardType = null;
        }

        if (dicCardTypeValue != null)
        {
            dicCardTypeValue.clear();
            dicCardTypeValue = null;
        }

        dicCardType = new LinkedHashMap<String, String>();
        dicCardTypeValue = new LinkedHashMap<String, String>();

        for (int i = 0; i < lstCTD.size(); i++)
        {
            dicCardType.put(lstCTD.get(i).getIdentifying(), lstCTD.get(i).getCardType());
            dicCardTypeValue.put(lstCTD.get(i).getCardType(), lstCTD.get(i).getIdentifying());
        }
    }

    /**
     * flag = 0, 即(临时车,TemA)
     * flag = 1, 即(TemA, 临时车)
     *
     * @param type
     * @param Flag
     * @return
     */
    public static String GetCardType(String type, int Flag)
    {
        String strRet = "无效卡";
        if (Flag == 0)
        {
            for (String m : dicCardTypeValue.keySet())
            {
                if (m.equals(type))
                {
                    strRet = dicCardTypeValue.get(m);
                }
            }
        }
        else if (Flag == 1)
        {
            for (String m : dicCardType.keySet())
            {
                if (m.equals(type))
                {
                    strRet = dicCardType.get(m);
                }
            }
        }
        return strRet;
    }

    public static Object GetAppConfig(Context context, String key, Object defaultValue)
    {
        return SPUtils.get(ConstantSharedPrefs.FileAppSetting, context, key, defaultValue);
    }

    public static void UpdateAppConfig(Context context, String key, Object value)
    {
        SPUtils.put(ConstantSharedPrefs.FileAppSetting, context, key, value);
    }

    public static String stringPadLeft(String source, int totalWidth, char paddingChar)
    {
        if (totalWidth < 0)
        {
            throw new ArrayIndexOutOfBoundsException("totalWidth < 0");
        }

        if (source.length() > totalWidth)
        {
            return source;
        }
        else if (source.length() == totalWidth)
        {
            return new String(source);
        }
        else
        {
            StringBuffer stringBuffer = new StringBuffer(); // 12  6 '0'
            for (int i = 0; i < totalWidth - source.length(); i++)
            {
                stringBuffer.append(paddingChar);
            }
            return stringBuffer.append(source).toString();
        }
    }


    /**
     * 检测合法车牌
     *
     * @param strCPH
     * @return
     */
    public static boolean CheckUpCPH(String strCPH, boolean isJunC)
    {
        if (null == strCPH || (strCPH.length() != 7 && strCPH.length() != 8))
        {
            return false;
        }
        else if (strCPH.length() == 8)
        {
            String head = strCPH.substring(2, 1 + 2);
            String end = strCPH.substring(strCPH.length() - 1, strCPH.length());
            if (!strCPH.substring(0, 2).toUpperCase().equals("WJ") && !head.equals("F") && !head.equals("D") && !end.equals("F") && !end.equals("D"))
            {
                return false;
            }
            else
            {
                String cphHead = "京津冀晋蒙辽吉黑沪苏浙皖闽赣鲁豫鄂湘粤桂琼渝川贵云藏陕甘青宁新港澳台警军空海北沈兰济南广成临";
                if (strCPH.substring(0, 2).toUpperCase().equals("WJ"))
                {
                    if (RegexUtil.IsLetterOrFigureNotIO(strCPH.substring(3)))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else if (!strCPH.substring(0, 2).toUpperCase().equals("WJ") && cphHead.contains(strCPH.substring(0, 1)))
                {
                    if (RegexUtil.IsLetterOrFigureNotIO(strCPH.substring(1)))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
        }
        else
        {
            if (isJunC)
            {
                return true;
            }
            else
            {
                String cphHead = "京津冀晋蒙辽吉黑沪苏浙皖闽赣鲁豫鄂湘粤桂琼渝川贵云藏陕甘青宁新港澳台警军空海北沈兰济南广成临";
                if (cphHead.contains(strCPH.substring(0, 1 + 0)))
                {
//                if (RegexUtil.IsLetterNotIO(strCPH.substring(1, 1 + 1)))
                    {
                        if (RegexUtil.IsLetterOrFigureNotIO(strCPH.substring(2, 4 + 2)))
                        {
                            String strCphHead = "港澳警学领ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjklmnpqrstuvwxyz0123456789";
                            if (strCphHead.contains(strCPH.substring(6, 1 + 6)))
                            {
                                return true;
                            }
                            else
                            {
                                return false;
                            }
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
                else
                {
                    return false;
                }
            }
        }
    }

    /// <summary>
    /// 判断字符串是否为中文字符
    /// </summary>
    /// <param name="s"></param>
    /// <returns></returns>
    public static boolean IsChineseCharacters(String str)
    {
        Matcher matcher = Pattern.compile("^[\u4E00-\u9FA5]+$").matcher(str);
        return matcher.matches();
    }

    public static AddOptLogReq initAddOptLog(String menu, String content)
    {
        AddOptLogReq req = new AddOptLogReq();
        req.setToken(Model.token);
        req.setJsonModel(getAddOptLogText(menu, content));
        return req;
    }

    private static Gson mGson = new Gson();

    private static String getAddOptLogText(String menu, String content)
    {
        AddOptLog opt = new AddOptLog();
        opt.setOptNO(Model.sUserCard);
        opt.setUserName(Model.sUserName);
        opt.setOptMenu(menu);
        opt.setOptContent(content);
        opt.setOptTime(TimeConvertUtils.longToString(System.currentTimeMillis()));
        opt.setStationID(Model.stationID);

        try
        {
            return URLEncoder.encode(mGson.toJson(opt), "UTF-8");
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 字符串转换为16进制
     *
     * @param str
     * @return
     */
    public static String GetStrTo16(String str)
    {
        StringBuffer stringBuffer = new StringBuffer();
        if (!"".equals(str))
        {
//            byte[] array = System.Text.Encoding.Default.GetBytes(str);
            byte[] array = str.getBytes(); // 使用的编码方式?
            // TODO 可能出现问题
            if (array != null)
            {
                for (int i = 0; i < array.length; i++)
                {
                    stringBuffer.append(String.format("%x", array[i]));// 将b转换成十六进制的字符串
//                    strSum += array[i].ToString("X2");
                }
            }
        }
        return stringBuffer.toString();
    }

    /**
     * 字符串转换为Byte数组
     *
     * @param str
     * @return
     */
    public static byte[] GetByteArray(String str)
    {
        String[] HexStr = GetStringArray(str);
        byte[] Hexbyte = new byte[HexStr.length];
        for (int j = 0; j < HexStr.length; j++)
        {
//            Hexbyte[j] = Convert.ToByte(HexStr[j], 16);
            Hexbyte[j] = Byte.parseByte(HexStr[j], 16);
        }

        return Hexbyte;
    }

    /**
     * 字符串转换为字符串数组
     * 如12345678,每取两位转换为12 34 56 78的四个数组
     *
     * @param str
     * @return
     */
    public static String[] GetStringArray(String str) // 如果不是偶数位呢? 还是需要测试
    {
        String[] HexStr = new String[str.length() / 2];

        for (int i = 0; i < str.length() / 2; i++)
        {
            HexStr[i] = str.substring(i * 2, i * 2 + 2);
        }
        return HexStr;
    }

    /// <summary>
    ///异或效验
    /// </summary>
    /// <param name="strList"></param>
    /// <returns></returns>
    public static byte YHXY(String str)
    {
        String[] strList = GetStringArray(str);
        byte[] Hexbyte = new byte[strList.length];
        byte check = 0;

        //2015-08-15
        if (strList.length == 1)
        {
//            return Convert.ToByte(strList[0], 16);
            return Byte.parseByte(strList[0], 16);
        }

        check = (byte) (Byte.parseByte(strList[0], 16) ^ Byte.parseByte(strList[1], 16));
//        check = (byte)(Convert.ToByte(strList[0], 16) ^ Convert.ToByte(strList[1], 16));
        for (int i = 2; i < strList.length; i++)
        {
            check = (byte) (check ^ Byte.parseByte(strList[i], 16));
        }
//        String CheckSumHex = Convert.ToString(check, 16); // check转换16
        String CheckSumHex = String.format("%x", check);
        if (CheckSumHex.length() == 1)
        {
            CheckSumHex = "0" + CheckSumHex;
        }
        return Byte.parseByte(CheckSumHex.toUpperCase(), 16);

//        return Convert.ToByte(CheckSumHex.ToUpper(), 16);
    }

    public static ConstantClass.CarType getCardTypeEnum(String cardTypeStr)
    {
        if (cardTypeStr.equals("Mth"))
        {
            return ConstantClass.CarType.Month;
        }
        else if (cardTypeStr.equals("Tmp"))
        {
            return ConstantClass.CarType.Temp;
        }
        else if (cardTypeStr.equals("Fre"))
        {
            return ConstantClass.CarType.Free;
        }
        else if (cardTypeStr.equals("Str"))
        {
            return ConstantClass.CarType.Store;
        }
        else if (cardTypeStr.equals("Mtp"))
        {
            return ConstantClass.CarType.MonthTemp;
        }
        else
        {
            L.e("getCardTypeEnum(String cardTypeStr) 出现错误:" + cardTypeStr);
            return ConstantClass.CarType.Temp;
        }
    }

    /**
     * 预先检测字符串
     *
     * @return
     */
    public static String prepareDetectString(String srcStr, String defaultStr)
    {
        if (TextUtils.isEmpty(srcStr))
        {
            return defaultStr;
        }
        return srcStr;
    }


    public static void sendModeToQueue(QueueMessageTypeEnum type, Object data, int index, int delayTime)
    {
        ModelNode modelNode = new ModelNode();
        modelNode.data = data;
        modelNode.type = type;
        modelNode.dealyTime = delayTime;
        modelNode.setiDzIndex(index);
        ConcurrentQueueHelper.getInstance().put(modelNode);
    }

    public static void sendModeToQueue(QueueMessageTypeEnum type, Object data, int index)
    {
        ModelNode modelNode = new ModelNode();
        modelNode.data = data;
        modelNode.type = type;
        modelNode.setiDzIndex(index);
        ConcurrentQueueHelper.getInstance().put(modelNode);
    }

    public static void sendModeToQueue(QueueMessageTypeEnum type, String cph, Object data, int index, String fileName)
    {
        ModelNode modelNode = new ModelNode();
        modelNode.data = data;
        modelNode.type = type;
        modelNode.setsDzScan("");
        modelNode.setiDzIndex(index);
        modelNode.setStrFileJpg(fileName);
        modelNode.setStrCPH(cph);
        ConcurrentQueueHelper.getInstance().put(modelNode);
    }

    /// <summary>
    /// 金额转为大写金额
    /// </summary>
    /// <param name="LowerMoney"></param>
    /// <returns></returns>
    public static String MoneyToChinese(String LowerMoney)
    {
        String functionReturnValue = null;
        boolean IsNegative = false; // 是否是负数
        if (LowerMoney.trim().substring(0, 1) == "-")
        {
            // 是负数则先转为正数
//            LowerMoney = LowerMoney.trim().Remove(0, 1);
            LowerMoney = LowerMoney.trim().substring(1);
            IsNegative = true;
        }
        String strLower = null;
        String strUpart = null;
        String strUpper = null;
        int iTemp = 0;
        // 保留两位小数 123.489→123.49　　123.4→123.4
        LowerMoney = String.format("%.2f", Double.parseDouble(LowerMoney));
        if (LowerMoney.indexOf(".") > 0)
        {
            if (LowerMoney.indexOf(".") == LowerMoney.length() - 2)
            {
                LowerMoney = LowerMoney + "0";
            }
        }
        else
        {
            LowerMoney = LowerMoney + ".00";
        }
        strLower = LowerMoney;
        iTemp = 1;
        strUpper = "";
        while (iTemp <= strLower.length())
        {
            switch (strLower.substring(strLower.length() - iTemp, strLower.length() - iTemp + 1))
            {
                case ".":
                    strUpart = "元";
                    break;
                case "0":
                    strUpart = "零";
                    break;
                case "1":
                    strUpart = "壹";
                    break;
                case "2":
                    strUpart = "贰";
                    break;
                case "3":
                    strUpart = "叁";
                    break;
                case "4":
                    strUpart = "肆";
                    break;
                case "5":
                    strUpart = "伍";
                    break;
                case "6":
                    strUpart = "陆";
                    break;
                case "7":
                    strUpart = "柒";
                    break;
                case "8":
                    strUpart = "捌";
                    break;
                case "9":
                    strUpart = "玖";
                    break;
            }

            switch (iTemp)
            {
                case 1:
                    strUpart = strUpart + "分";
                    break;
                case 2:
                    strUpart = strUpart + "角";
                    break;
                case 3:
                    strUpart = strUpart + "";
                    break;
                case 4:
                    strUpart = strUpart + "";
                    break;
                case 5:
                    strUpart = strUpart + "拾";
                    break;
                case 6:
                    strUpart = strUpart + "佰";
                    break;
                case 7:
                    strUpart = strUpart + "仟";
                    break;
                case 8:
                    strUpart = strUpart + "万";
                    break;
                case 9:
                    strUpart = strUpart + "拾";
                    break;
                case 10:
                    strUpart = strUpart + "佰";
                    break;
                case 11:
                    strUpart = strUpart + "仟";
                    break;
                case 12:
                    strUpart = strUpart + "亿";
                    break;
                case 13:
                    strUpart = strUpart + "拾";
                    break;
                case 14:
                    strUpart = strUpart + "佰";
                    break;
                case 15:
                    strUpart = strUpart + "仟";
                    break;
                case 16:
                    strUpart = strUpart + "万";
                    break;
                default:
                    strUpart = strUpart + "";
                    break;
            }

            strUpper = strUpart + strUpper;
            iTemp = iTemp + 1;
        }

        strUpper = strUpper.replace("零拾", "零");
        strUpper = strUpper.replace("零佰", "零");
        strUpper = strUpper.replace("零仟", "零");
        strUpper = strUpper.replace("零零零", "零");
        strUpper = strUpper.replace("零零", "零");
        strUpper = strUpper.replace("零角零分", "整");
        strUpper = strUpper.replace("零分", "整");
        strUpper = strUpper.replace("零角", "零");
        strUpper = strUpper.replace("零亿零万零元", "亿元");
        strUpper = strUpper.replace("亿零万零元", "亿元");
        strUpper = strUpper.replace("零亿零万", "亿");
        strUpper = strUpper.replace("零万零元", "万元");
        strUpper = strUpper.replace("零亿", "亿");
        strUpper = strUpper.replace("零万", "万");
        strUpper = strUpper.replace("零元", "元");
        strUpper = strUpper.replace("零零", "零");
        //strUpper = strUpper.Replace("零元", "元");
        // 对壹圆以下的金额的处理
        if (strUpper.substring(0, 1).equals("元"))
        {
            strUpper = strUpper.substring(1, strUpper.length());
        }
        if (strUpper.substring(0, 1).equals("零"))
        {
            strUpper = strUpper.substring(1, strUpper.length());
        }
        if (strUpper.substring(0, 1).equals("角"))
        {
            strUpper = strUpper.substring(1, strUpper.length());
        }
        if (strUpper.substring(0, 1).equals("分"))
        {
            strUpper = strUpper.substring(1, strUpper.length());
        }
        if (strUpper.substring(0, 1).equals("整"))
        {
            strUpper = "零元整";
        }
        functionReturnValue = strUpper;

        if (IsNegative == true)
        {
            return "负" + functionReturnValue;
        }
        else
        {
            return functionReturnValue;
        }
    }

    public static String GetChineseMoney(String strMoney)
    {
        String strRst = "";

        for (int i = 0; i < strMoney.length(); i++)
        {
            String strW = strMoney.substring(i, 1 + i);
            switch (strW)
            {
                case "零":
                    strRst += "00";
                    break;
                case "壹":
                    strRst += "01";
                    break;
                case "贰":
                    strRst += "02";
                    break;
                case "叁":
                    strRst += "03";
                    break;
                case "肆":
                    strRst += "04";
                    break;
                case "伍":
                    strRst += "05";
                    break;
                case "陆":
                    strRst += "06";
                    break;
                case "柒":
                    strRst += "07";
                    break;
                case "捌":
                    strRst += "08";
                    break;
                case "玖":
                    strRst += "09";
                    break;
                case "拾":
                    strRst += "0A";
                    break;
                case "佰":
                    strRst += "0B";
                    break;
                case "仟":
                    strRst += "0C";
                    break;
                case "万":
                    strRst += "0D";
                    break;
                case "分":
                    strRst += "8A";
                    break;
                case "角":
                    strRst += "64";
                    break;
                case "元":
                    strRst += "63";
                    break;
            }
        }

        return strRst;
    }


    /**
     * 创建临时的文件存储的位置
     *
     * @param context
     * @return
     */
    public static String createTempImageSavePath(Context context, int inOut)// /mnt/internal_sd/Android/data/com.example.administrator.mydistributedparkingos/20170506/xxx.jpg
    {
        checkImagePath(context);

//        L.e("Model.sImageSavePath" + Model.sImageSavePath); // /mnt/internal_sd/Android/data/com.example.administrator.mydistributedparkingos/cache/

        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append(Model.sImageSavePath)
                .append(TimeConvertUtils.longToString("yyyyMMdd", System.currentTimeMillis()));

        String dirName = stringBuffer.toString();
        File file = new File(dirName);
        if (!file.exists())
        {
            file.mkdirs();
        }

        String newFileName = dirName + File.separator + UUID.randomUUID().toString() + TimeConvertUtils.longToString("yyyyMMddHHmmss", System.currentTimeMillis());
        if (inOut == 0)
        {
            newFileName += "in" + ".jpg";
        }
        else
        {
            newFileName += "out" + ".jpg";
        }

        return newFileName;
    }

    public static void checkImagePath(Context context)
    {
        String diskCacheDirPath = SDCardUtils.getDiskCacheDirPath(context, "");
        if (Model.sImageSavePath == null || !Model.sImageSavePath.contains(diskCacheDirPath))
        {
            Model.sImageSavePath = diskCacheDirPath + File.separator;
        }
    }

    public static void printGsonResp(Object reqData, Object respData, String url, int paramInt)
    {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("Sucess###")
                .append("URL[").append(url).append("],")
                .append("reqData[").append(reqData.toString()).append("],")
                .append("mIntParam[").append(paramInt).append("],")
                .append("respData[").append(respData.toString()).append("]");
        L.e(stringBuffer.toString());
    }

    public static GetRightsByGroupIDResp.DataBean getRightsByName(String fromName, String itemName)
    {
        if (Model.lstRights == null)
        {
            return null;
        }


        for (GetRightsByGroupIDResp.DataBean right : Model.lstRights)
        {
            if (right.getFormName().equals(fromName)
                    && right.getItemName().equals(itemName))
            {
                return right;
            }
        }
        return null;
    }

    /**
     * 脱机车牌识别下载
     *
     * @param strCPH
     * @return
     */
    public static String GetCPHtoCardNO(String strCPH)
    {
        String strSum = "";

        if (strCPH.length() > 6)
        {
            String strCardE = "";
            String CPH = strCPH.substring(strCPH.length() - 5, strCPH.length());
            for (int i = 0; i < CPH.length(); i++)
            {
                String str1 = CPH.substring(i, i + 1);
                String str = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ港澳台警领学";
                int iTmp = 0;
                for (int Ii = 0; Ii < str.length(); Ii++)
                {
                    if (str.substring(Ii, Ii + 1).equals(str1))
                    {
                        iTmp = Ii;
                        break;
                    }
                }

                String padLeft = CR.stringPadLeft(Integer.toBinaryString(iTmp), 6, '0');
//                strCardE += Convert.ToString(iTmp, 2).PadLeft(6, '0');
                strCardE += padLeft;
            }
            strCardE = CR.stringPadLeft(strCardE, 32, '0');
//            strCardE = strCardE.PadLeft(32, '0');

            for (int y = 0; y < strCardE.length() / 4; y++)
            {
                String substring = strCardE.substring(y * 4, y * 4 + 4);
                int parseInt = Integer.parseInt(substring, 2);

                String toHexString = Integer.toHexString(parseInt);
                strSum += toHexString;
//                strSum += string.Format("{0:x}", Convert.ToInt32(strCardE.Substring(y * 4, 4), 2)); // 表示以16显示字符串
            }
            strSum = strSum.toUpperCase();
        }
        return strSum.toLowerCase();
    }

    public static String GetDownLoadToTempCPH(GetAutoTempDownLoadResp.DataBean tempDownLoad)
    {
        String sendData = "";
        String CarNO = GetCPHtoCardNO(tempDownLoad.getCPH());
        String StatType = "E8";
        String CarNumber = CarNO;
        String strInTime = tempDownLoad.getInTime(); // 直接以HHmmss显示
        int[] arrayDate = TimeConvertUtils.getArrayDate(strInTime);
        strInTime = String.format("%20d%20d%20d", arrayDate[3], arrayDate[4], arrayDate[5]);
        L.e("strInTime:" + strInTime);
//        String strInTime = dr.InTime.ToString("HHmmss");
//        String strDateTime = tempDownLoad.getInTime().ToShortDateString().Replace("-", "").Substring(2, 6); // #  2013-07-26 ->20130726
        String strDateTime = String.format("%20d%20d%20d", arrayDate[0] % 100, arrayDate[1], arrayDate[2]);//130726
        L.e("strDateTime:" + strDateTime);
        String strDateTime1 = strInTime;

//        CarNumber = CarNumber.PadLeft(8, '0');
        CarNumber = CR.stringPadLeft(CarNumber, 8, '0');

        //2015-11-07 TH
        String strCPH = strPlateZIPNew(tempDownLoad.getCPH(), true);
        if (strCPH.length() == 12)
        {
            CarNumber = strCPH.substring(0, 6) + CarNumber;
        }
        else
        {
//            CarNumber = CarNumber.PadLeft(14, '0');
            CarNumber = CR.stringPadLeft(CarNumber, 14, '0');
        }
        sendData = StatType + CarNumber + strDateTime + strDateTime1 + "0000";

        return sendData;
    }

    public static String strPlateZIPNew(String strPlate, boolean bZIP)
    {
        int Ii, jj;
        int iTmp = 0;
        byte[] byte7 = new byte[7];
        boolean[] bit48 = new boolean[48];
        String[] strTmp7 = new String[7];
        byte[] byteMode = new byte[12];
        byte[] byteBitMode = new byte[8];
        byteBitMode = Model.byteBitMode;

        String strPlateZIP = "";

        if (strPlate.length() == 8 && strPlate.substring(0, 2).equals("WJ"))
        {
            strPlate = "武" + strPlate.substring(2);
        }

        String strTmpX = "京津冀晋蒙辽吉黑沪苏浙皖闽赣鲁豫鄂湘粤桂琼渝川贵云藏陕甘青宁新港澳台警军空海北沈兰济南广成甲乙丙午未申庚巳辛壬临武使ABCDEFGHIJKLMNOPQRSTUVWXYZ";//武 WJ川12345
        String strTmpX1 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ京津冀晋蒙辽吉黑沪苏浙皖闽赣鲁豫鄂湘粤桂琼渝川贵云藏陕甘青宁新港澳台警使武领学";

        if (strPlate.length() != 7 || strPlate.equals("0000000") || strPlate.equals("6666666") || strPlate.equals("8888888"))
        {
            return "";
        }

        for (Ii = 0; Ii < strTmpX.length(); Ii++)
        {
            if (strTmpX.substring(Ii, 1 + Ii).equals(strPlate.substring(0, 1)))
            {
                iTmp = Ii;
                break;
            }
        }

        String str2Sum = "";
//        String str2SumFrist = Convert.ToString(iTmp, 2);
        String str2SumFrist = Integer.toBinaryString(iTmp);
//        str2Sum = Convert.ToString(iTmp, 2).PadLeft(6, '0');
        str2Sum = CR.stringPadLeft(Integer.toBinaryString(iTmp), 6, '0');

        if (str2Sum.length() > 6)
        {
            str2Sum = str2Sum.substring(str2Sum.length() - 6, str2Sum.length());
        }
        else
        {
//            str2Sum = str2Sum.PadLeft(6, '0');
            str2Sum = CR.stringPadLeft(str2Sum, 6, '0');
        }

        for (jj = 1; jj < 7; jj++)
        {
            for (Ii = 0; Ii < strTmpX1.length(); Ii++)
            {
                if (strTmpX1.substring(Ii, Ii + 1).equals(strPlate.substring(jj, jj + 1)))
                {
//                    String str2TO = Convert.ToString(Ii, 2);
                    String str2TO = Integer.toBinaryString(Ii);
                    if (str2TO.length() > 6)
                    {
                        str2Sum = str2Sum + str2TO.substring(str2TO.length() - 6, str2TO.length());
                    }
                    else
                    {
                        str2Sum = str2Sum + CR.stringPadLeft(str2TO, 6, '0');
                    }

                    if (jj == 1 && str2TO.length() > 6 && str2TO.substring(0, 1).equals("1"))
                    {
                        str2Sum = "10" + str2Sum;
                    }
                    if (str2Sum.length() == 42 && str2TO.length() > 6 && str2TO.substring(0, 1).equals("1"))
                    {
                        str2Sum = "1" + str2Sum;
                    }
                    else if (str2Sum.length() == 44 && str2TO.length() > 6 && str2TO.substring(0, 1).equals("1"))
                    {
                        str2Sum = str2Sum.substring(0, 1) + "1" + str2Sum.substring(2);
                    }
                    break;
                }
            }
        }
//        str2Sum = str2Sum.PadLeft(44, '0');
        str2Sum = CR.stringPadLeft(str2Sum, 44, '0');
        if (str2SumFrist.length() > 6)
        {
            str2Sum = "1" + str2Sum;
        }
        str2Sum = CR.stringPadLeft(str2Sum, 48, '0');
        ;


        for (jj = 0; jj < 12; jj++)
        {
            String substring = str2Sum.substring(4 * jj, 4 * jj + 4);
            int parseInt = Integer.parseInt(substring, 2);
            strPlateZIP = strPlateZIP + Integer.toHexString(parseInt).toUpperCase();
//            strPlateZIP = strPlateZIP + string.Format("{0:x}", Convert.ToInt32(str2Sum.Substring(4 * jj, 4), 2)).ToUpper();
        }
        return strPlateZIP;
    }

    /**
     * //字符串MD5加密 不可逆 用于密码
     * @param str1
     * @return
     */
    public static String UserMd5(String str1)
    {
        // 1,获取md5加密之后的字节数组
        byte[] bytes = MD5Util.md5(str1);
        StringBuffer pwd = new StringBuffer();

        // 2，转换成String
        for (int i = 0; i < bytes.length; i++)
        {
            // 将得到的字符串使用十六进制类型格式。格式后的字符是小写的字母，如果使用大写（X）则格式后的字符是大写字符
//            pwd = pwd + s[i].ToString("x2");
            pwd.append(String.format("%02x", bytes[i]));
        }
        return pwd.toString();
    }
}