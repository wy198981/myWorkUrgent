package com.example.administrator.myparkingos.constant;

/**
 * Created by Administrator on 2017-03-03.
 */
public class NetworkConfig
{
    public static final String ServerIP = "192.168.2.158";
    public static final String ServerPort = "9000";
}
