package com.example.administrator.myparkingos.ui.onlineMonitorPage;

/**
 * Created by Administrator on 2017-02-16.
 * 【车辆收费时】-->> 人员图片预览
 */
public class FormCamPoto
{
}
