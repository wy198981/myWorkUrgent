package com.example.administrator.myparkingos.ui.carParkSettingPager;

/**
 * Created by Administrator on 2017-02-16.
 * 【车场设置】 -->>>【下载管理】 -- >>【车牌号码下载查询】
 */
public class SelectDown
{
}
