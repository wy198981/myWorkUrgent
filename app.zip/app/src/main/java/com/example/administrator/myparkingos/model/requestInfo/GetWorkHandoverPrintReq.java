package com.example.administrator.myparkingos.model.requestInfo;

/**
 * Created by Administrator on 2017-07-05.
 */
public class GetWorkHandoverPrintReq
{
    private String token;//    	Y	用户登录时候获取的token值
    private Integer StationId;//		Y	工作站编号
    private String CallBack;//		N	是否使用JSONP方式。关于JSONP方式请参考Javascript跨域访问一节。

    @Override
    public String toString()
    {
        return "GetWorkHandoverPrintReq{" +
                "token='" + token + '\'' +
                ", StationId=" + StationId +
                ", CallBack='" + CallBack + '\'' +
                '}';
    }

    public String getToken()
    {
        return token;
    }

    public void setToken(String token)
    {
        this.token = token;
    }

    public Integer getStationId()
    {
        return StationId;
    }

    public void setStationId(Integer stationId)
    {
        StationId = stationId;
    }

    public String getCallBack()
    {
        return CallBack;
    }

    public void setCallBack(String callBack)
    {
        CallBack = callBack;
    }
}
