package com.example.administrator.myparkingos.common.data.cipher;

/**
 * @author MaTianyu
 * @date 14-7-31
 */
public abstract class Cipher implements Encrypt,Decrypt{

}
