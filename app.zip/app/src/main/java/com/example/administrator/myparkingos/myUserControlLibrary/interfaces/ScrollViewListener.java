package com.example.administrator.myparkingos.myUserControlLibrary.interfaces;

import android.view.View;

/**
 * Created by zhangcheng on 16/2/29.
 */
public interface ScrollViewListener {
    void onScrollChanged(View scrollView, int x, int y, int oldx, int oldy);
}
