package com.example.administrator.myparkingos.ui.onlineMonitorPage.report;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.ui.adapter.CommonAdapter;
import com.example.administrator.myparkingos.ui.adapter.ViewHolder;
import com.example.administrator.myparkingos.util.L;
import com.example.administrator.myparkingos.util.T;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017-02-16.
 * 【在线监控】 -->> 【期限查询】
 * 固定车期限查询 -> 导出Excel
 */
public class ExportExcelView implements View.OnClickListener
{
    private final Activity mActivity;
    private final Dialog dialog;
    private ListView lstData;
    private ListView lstSelectData;
    private Button btnRight;
    private Button btnAllRight;
    private Button btnLeft;
    private Button btnAllLeft;
    private Button btnUp;
    private Button btnDown;
    private Button btnExport;
    private Button btnCancel;
    private ListDataAdapter listDataAdapter;
    private ListSelectDataAdapter listSelectDataAdapter;

    private int lstDataIndex = -1;
    private int lstDataSelectIndex = -1;

    public ExportExcelView(Activity activity)
    {
        this.mActivity = activity;

        dialog = new Dialog(activity); // @android:style/Theme.Dialog
        dialog.setContentView(R.layout.exportexcel_activity);
        dialog.setCanceledOnTouchOutside(true);

        Window window = dialog.getWindow();
        WindowManager m = activity.getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = window.getAttributes(); // 获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 1 / 2.5); // 改变的是dialog框在屏幕中的位置而不是大小
        p.width = (int) (d.getWidth() * 1 / 2.5); // 宽度设置为屏幕的0.65
        window.setAttributes(p);

        dialog.getWindow().setBackgroundDrawableResource(R.drawable.parkdowncard_background);
        dialog.setTitle(activity.getResources().getString(R.string.carDealLineExportExcel));

        intView();
    }

    private void intView()
    {
        lstData = (ListView) dialog.findViewById(R.id.lstData);
        lstSelectData = (ListView) dialog.findViewById(R.id.lstSelectData);

        btnRight = (Button) dialog.findViewById(R.id.btnRight);
        btnAllRight = (Button) dialog.findViewById(R.id.btnAllRight);
        btnLeft = (Button) dialog.findViewById(R.id.btnLeft);
        btnAllLeft = (Button) dialog.findViewById(R.id.btnAllLeft);
        btnUp = (Button) dialog.findViewById(R.id.btnUp);
        btnDown = (Button) dialog.findViewById(R.id.btnDown);
        btnExport = (Button) dialog.findViewById(R.id.btnExport);
        btnCancel = (Button) dialog.findViewById(R.id.btnCancel);

        btnRight.setOnClickListener(this);
        btnAllRight.setOnClickListener(this);
        btnLeft.setOnClickListener(this);
        btnAllLeft.setOnClickListener(this);
        btnUp.setOnClickListener(this);
        btnDown.setOnClickListener(this);
        btnExport.setOnClickListener(this);
        btnCancel.setOnClickListener(this);

        intListView();
    }

    private List<String> listDataList;
    private List<String> listSelectDataList;

    private void intListView()
    {
        listDataList = new ArrayList<>();
        initLstData();

        listSelectDataList = new ArrayList<>();
        listDataAdapter = new ListDataAdapter(mActivity, listDataList, R.layout.listdata_item);
        lstData.setAdapter(listDataAdapter);
        lstData.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                lstDataIndex = position;
            }
        });

        listSelectDataAdapter = new ListSelectDataAdapter(mActivity, listSelectDataList, R.layout.listdata_item);
        lstSelectData.setAdapter(listSelectDataAdapter);
        lstSelectData.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                lstDataSelectIndex = position;
            }
        });
    }

    private void initLstData()
    {
        listDataList.add(mActivity.getResources().getString(R.string.dealLineQuery_plateNo));
        listDataList.add(mActivity.getResources().getString(R.string.dealLineQuery_carNO));
        listDataList.add(mActivity.getResources().getString(R.string.dealLineQuery_carType));
        listDataList.add(mActivity.getResources().getString(R.string.dealLineQuery_parkingValidStartTime));
        listDataList.add(mActivity.getResources().getString(R.string.dealLineQuery_parkingValidEndTime));
        listDataList.add(mActivity.getResources().getString(R.string.dealLineQuery_reminderDays));
        listDataList.add(mActivity.getResources().getString(R.string.dealLineQuery_personName));
        listDataList.add(mActivity.getResources().getString(R.string.dealLineQuery_personNo));
        listDataList.add(mActivity.getResources().getString(R.string.dealLineQuery_deptName));
        listDataList.add(mActivity.getResources().getString(R.string.dealLineQuery_telephone));
    }

    public void show()
    {
        if (dialog != null)
        {
            dialog.show();
        }
    }

    public void dismiss()
    {
        if (dialog != null && dialog.isShowing())
        {
            dialog.dismiss();
        }
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.btnRight:
                moveR();
                break;
            case R.id.btnAllRight:
                moveAllR();
                break;
            case R.id.btnLeft:
                moveL();
                break;
            case R.id.btnAllLeft:
                moveAllL();
                break;
            case R.id.btnUp://向上移动数据
                moveUp();
                break;
            case R.id.btnDown:
                moveDown();
                break;
            case R.id.btnExport:
                T.showShort(mActivity, "有待后续实现");
                break;
            case R.id.btnCancel:
                dismiss();
                break;
            default:
                break;
        }
    }

    private void moveAllL()
    {
        move(listSelectDataList, listSelectDataAdapter, listDataList, listDataAdapter, -2);
    }

    private void moveL()
    {
        move(listSelectDataList, listSelectDataAdapter, listDataList, listDataAdapter, lstDataSelectIndex);
    }

    private void moveAllR()
    {
        move(listDataList, listDataAdapter, listSelectDataList, listSelectDataAdapter, -2);
    }

    private void moveR()
    {
        move(listDataList, listDataAdapter, listSelectDataList, listSelectDataAdapter, lstDataIndex);
    }

    private void moveDown()
    {
        if (lstDataSelectIndex == listSelectDataList.size() - 1)
        {
            T.showShort(mActivity, "到尾了不能移动数据");
            return;
        }
        String down = listSelectDataList.get(lstDataSelectIndex);
        listSelectDataList.remove(lstDataSelectIndex);
        listSelectDataList.add(lstDataSelectIndex + 1, down);
        listSelectDataAdapter.notifyDataSetChanged();
    }

    private void moveUp()
    {
        if (!checkIsValid(listSelectDataList, lstDataSelectIndex))
        {
            return;
        }

        if (lstDataSelectIndex == 0)
        {
            T.showShort(mActivity, "到头了不能移动数据");
            return;
        }

        String up = listSelectDataList.get(lstDataSelectIndex);
        listSelectDataList.remove(lstDataSelectIndex);
        listSelectDataList.add(lstDataSelectIndex - 1, up);
        listSelectDataAdapter.notifyDataSetChanged();
    }


    private boolean checkIsValid(List<String> leftList, int index)
    {
        if (leftList.size() == 0)
        {
            return false;
        }

        // 2, index判断
        if ((index < 0) || index > leftList.size())
        {
            return false;
        }

        return true;
    }

    /**
     * index = -2,表示移动所有数据
     *
     * @param leftList
     * @param rightList
     * @param index
     */
    private void move(List<String> leftList, CommonAdapter leftAdapter, List<String> rightList, CommonAdapter rightAdapter, int index)
    {
        if (leftList.size() == 0)
        {
            return;
        }

        // 2, index判断
        if ((index < 0 && index != -2) || index > leftList.size())
        {
            return;
        }

        //3, 移动数据
        if (index != -2)
        {
            String s = leftList.get(index);
            leftList.remove(index);
            leftAdapter.notifyDataSetChanged();

            rightList.add(s);
            rightAdapter.notifyDataSetChanged();
        }
        else
        {
            rightList.addAll(leftList);
            rightAdapter.notifyDataSetChanged();

            leftList.clear();
            leftAdapter.notifyDataSetChanged();
        }

    }

    public class ListDataAdapter extends CommonAdapter<String>
    {
        public ListDataAdapter(Context context, List<String> datas, int layoutId)
        {
            super(context, datas, layoutId);
        }

        @Override
        public void convert(ViewHolder viewHolder, String s, int position)
        {
            TextView tvItem = (TextView) viewHolder.getView(R.id.tvItem);
            tvItem.setText(s);
        }
    }

    public class ListSelectDataAdapter extends CommonAdapter<String>
    {
        public ListSelectDataAdapter(Context context, List<String> datas, int layoutId)
        {
            super(context, datas, layoutId);
        }

        @Override
        public void convert(ViewHolder viewHolder, String s, int position)
        {
            TextView tvItem = (TextView) viewHolder.getView(R.id.tvItem);
            tvItem.setText(s);
        }
    }
}
