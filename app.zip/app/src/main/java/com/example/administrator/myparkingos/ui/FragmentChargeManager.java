package com.example.administrator.myparkingos.ui;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.util.L;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017-03-07.
 */
public class FragmentChargeManager
{
    private FragmentManager mFragmentManager;

    private Fragment currentChargeFragment = new Fragment();
    private List<Fragment> fragmentsList = new ArrayList<>();
    public static final String CURRENT_FRAGMENT = "STATE_FRAGMENT_SHOW_CHARGE";
    private int currentIndex = 0;

    private final String CHAGEMANAGERNAME = "ChargeManagerName";
    public FragmentChargeManager(FragmentManager fragmentManager)
    {
        mFragmentManager = fragmentManager;
    }

    public String createTagName(int index)
    {
        return new StringBuffer(CHAGEMANAGERNAME).append(index).toString();
    }

    public void init(@Nullable Bundle savedInstanceState)
    {
        if (savedInstanceState != null)
        { // “内存重启”时调用

            //获取“内存重启”时保存的索引下标
            currentIndex = savedInstanceState.getInt(CURRENT_FRAGMENT, 0);
            L.e("currentIndex.............." + currentIndex);

            Fragment fragmentByTag0 = mFragmentManager.findFragmentByTag(createTagName(0));
            if (fragmentByTag0 == null)
            {
                Log.i("wyDebug", "fragmentByTag0 == null");
                fragmentByTag0 = new ChargeInfoFragment();
            }

            Fragment fragmentByTag1 = mFragmentManager.findFragmentByTag(createTagName(1));
            if (fragmentByTag1 == null)
            {
                Log.i("wyDebug", "fragmentByTag1 == null");
                fragmentByTag1 = new ChargeSpaceFragment();
            }

            Fragment fragmentByTag2 = mFragmentManager.findFragmentByTag(createTagName(2));
            if (fragmentByTag2 == null)
            {
                Log.i("wyDebug", "fragmentByTag2 == null");
                fragmentByTag2 = new ChargePromptFragment();
            }

            fragmentsList.add(fragmentByTag0);
            fragmentsList.add(fragmentByTag1);
            fragmentsList.add(fragmentByTag2);
            loadFragment();
        }
        else
        {
            L.e("fragmentsList.size:" + fragmentsList.size());
            //正常启动时调用
            fragmentsList.add(new ChargeInfoFragment());// 0
            fragmentsList.add(new ChargeSpaceFragment());// 1
            fragmentsList.add(new ChargePromptFragment()); //2
//            showFragment(currentIndex);
            loadFragment();
        }
    }

    /**
     * 使用show() hide()切换页面
     * 显示fragment
     */
    public void showFragment(int index)
    {

        FragmentTransaction transaction = mFragmentManager.beginTransaction();
        currentIndex = index;

        transaction
                .hide(currentChargeFragment)
                .show(fragmentsList.get(currentIndex));

        currentChargeFragment = fragmentsList.get(currentIndex);
        transaction.commit();
    }

    public void loadFragment()
    {
        FragmentTransaction mBeginTreansaction = mFragmentManager.beginTransaction();
        for (int i = 0; i < fragmentsList.size(); i++)
        {
            if (fragmentsList.get(i).isAdded())
            {

            }
            else
            {
                mBeginTreansaction.add(R.id.flchargeSpaceContainer, fragmentsList.get(i), createTagName(i));
            }
            mBeginTreansaction.hide(fragmentsList.get(i));
        }

        if (currentIndex >=0 && currentIndex < fragmentsList.size())
        {
            mBeginTreansaction.show(fragmentsList.get(currentIndex));
        }

        currentChargeFragment = fragmentsList.get(currentIndex);
        mBeginTreansaction.commitAllowingStateLoss();
    }


    /**
     * 设置界面的数据
     *
     * @param chargeInfo
     * @param chargeSpace
     */
    public void setData(ArrayList<String> chargeInfo, ArrayList<String> chargeSpace)
    {
        if (chargeInfo != null && chargeInfo.size() > 0)
        {
            ChargeInfoFragment fragment = (ChargeInfoFragment) fragmentsList.get(0);
            fragment.setData(chargeInfo);
        }

        if (chargeSpace != null && chargeSpace.size() > 0)
        {
            ChargeSpaceFragment fragment = (ChargeSpaceFragment) fragmentsList.get(1);
            fragment.setData(chargeSpace);
        }
    }

    public int getCurrentIndex()
    {
        return currentIndex;
    }

    public void setTextData(String txt)
    {
        ChargePromptFragment chargePromptFragment = (ChargePromptFragment) fragmentsList.get(2);
        chargePromptFragment.setViewPrompt(txt);
    }

    public void setCarSpaceOutCountHintVisble(String text)
    {
        if (text == null) return;
        ChargeSpaceFragment fragment = (ChargeSpaceFragment) fragmentsList.get(1);
        fragment.setOutCountHintTextAndVisble(text);
    }

    public void setCarSpaceOutCountValueVisble(String text)
    {
        if (text == null) return;
        ChargeSpaceFragment fragment = (ChargeSpaceFragment) fragmentsList.get(1);
        fragment.setOutCountTextAndVisble(text);
    }

    public void setCarSpaceOutCountHint(String text)
    {
        if (text == null) return;
        ChargeSpaceFragment fragment = (ChargeSpaceFragment) fragmentsList.get(1);
        fragment.setOutCountHintText(text);
    }

    public void setCarSpaceOutCountValue(String text)
    {
        if (text == null) return;
        ChargeSpaceFragment fragment = (ChargeSpaceFragment) fragmentsList.get(1);
        fragment.setOutCountText(text);
    }

    public void setChargeInfoManualCount(String count)
    {
        ChargeSpaceFragment fragment = (ChargeSpaceFragment) fragmentsList.get(1);
        fragment.setManualNum(count);
    }

    public void setChargeInfoMthCount(String count)
    {
        ChargeSpaceFragment fragment = (ChargeSpaceFragment) fragmentsList.get(1);
        fragment.setMthCount(count);
    }

    public void setChargeInfoTempCount(String count)
    {
        ChargeSpaceFragment fragment = (ChargeSpaceFragment) fragmentsList.get(1);
        fragment.setTmpCount(count);
    }

    public void setChargeInfoStoreCount(String count)
    {
        ChargeSpaceFragment fragment = (ChargeSpaceFragment) fragmentsList.get(1);
        fragment.setStoreCarNum(count);
    }

    public void setChargeInfoFreeCount(String count)
    {
        ChargeSpaceFragment fragment = (ChargeSpaceFragment) fragmentsList.get(1);
        fragment.setFreeCount(count);
    }

    public void setChargeInfoPersonNO(String personNO)
    {
        ChargeInfoFragment fragment = (ChargeInfoFragment) fragmentsList.get(0);
        fragment.setPersonNO(personNO);
    }

    public void setChargeInfoPersonName(String personName)
    {
        ChargeInfoFragment fragment = (ChargeInfoFragment) fragmentsList.get(0);
        fragment.setPersonName(personName);
    }

    public void setChargeInfoCarNO(String carNO)
    {
        ChargeInfoFragment fragment = (ChargeInfoFragment) fragmentsList.get(0);
        fragment.setCarNO(carNO);
    }

    public void setChargeInfoDeptName(String DeptName)
    {
        ChargeInfoFragment fragment = (ChargeInfoFragment) fragmentsList.get(0);
        fragment.setDeptName(DeptName);
    }

    public void setChargeInfoCardType(String text)
    {
        ChargeInfoFragment fragment = (ChargeInfoFragment) fragmentsList.get(0);
        fragment.setCarType(text);
    }

    public void setChargeInfoFreeMoney(String money)
    {
        ChargeInfoFragment fragment = (ChargeInfoFragment) fragmentsList.get(0);
        fragment.setFreeMoney(money);
    }

    public void setChargeInfoInTime(String inTime)
    {
        ChargeInfoFragment fragment = (ChargeInfoFragment) fragmentsList.get(0);
        fragment.setInTime(inTime);
    }

    public void setChargeInfoOutTime(String OutTime)
    {
        ChargeInfoFragment fragment = (ChargeInfoFragment) fragmentsList.get(0);
        fragment.setOutTime(OutTime);
    }

    public void setChargeInfoPayMoney(String text)
    {
        ChargeInfoFragment fragment = (ChargeInfoFragment) fragmentsList.get(0);
        fragment.setPayMoney(text);
    }

    public void setChargeInfoAmountMoney(String money)
    {
        ChargeInfoFragment fragment = (ChargeInfoFragment) fragmentsList.get(0);
        fragment.setAmountMoney(money);
    }

    public void setChargeInfoValidMoneyValue(String text)
    {
        ChargeInfoFragment fragment = (ChargeInfoFragment) fragmentsList.get(0);
        fragment.setRemainerMoneyLabel(text);
    }

    public void setChargeInfoValidMoneyVisiable(int type)
    {
        ChargeInfoFragment fragment = (ChargeInfoFragment) fragmentsList.get(0);
        fragment.setRemainerMoneyLabelVisiable(type);
    }

    public void setChargeInfoReminderValue(String text)
    {
        ChargeInfoFragment fragment = (ChargeInfoFragment) fragmentsList.get(0);
        fragment.setRemainerMoneyValue(text);
    }

    public void setChargeInfoReminderValueVisiable(int type)
    {
        ChargeInfoFragment fragment = (ChargeInfoFragment) fragmentsList.get(0);
        fragment.setRemainerMoneyValueVisiable(type);
    }

    public void setChargeInfoReminderHint(String text)
    {
        ChargeInfoFragment fragment = (ChargeInfoFragment) fragmentsList.get(0);
        fragment.setRemainerMoneyLabel(text);
    }

    public void setChargeInfoReminderLabelVisible(int type)
    {
        ChargeInfoFragment fragment = (ChargeInfoFragment) fragmentsList.get(0);
        fragment.setRemainerMoneyLabelVisiable(type);
    }

    public void settChargeInfoReminderUnitVisble(int type)
    {
        ChargeInfoFragment fragment = (ChargeInfoFragment) fragmentsList.get(0);
        fragment.setRemainerMoneyUnitVisble(type);
    }


    public void setChargeInfoAmountMoneyVisble(int type)
    {
        ChargeInfoFragment fragment = (ChargeInfoFragment) fragmentsList.get(0);
        fragment.setAmountMoneyVisible(type);
    }

    public void setChargeInfoAmountMoneyLabelVisble(int type)
    {
        ChargeInfoFragment fragment = (ChargeInfoFragment) fragmentsList.get(0);
        fragment.setAmountMoneyLableVisible(type);
    }

    public void setChargeInfoAmountMoneyUnitVisble(int type)
    {
        ChargeInfoFragment fragment = (ChargeInfoFragment) fragmentsList.get(0);
        fragment.setAmountMoneyUnitVisible(type);
    }
}


