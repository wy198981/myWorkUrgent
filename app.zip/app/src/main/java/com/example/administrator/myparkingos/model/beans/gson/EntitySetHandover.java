package com.example.administrator.myparkingos.model.beans.gson;

/**
 * Created by Administrator on 2017-03-14.
 */
public class EntitySetHandover
{

    /**
     * rcode : 200
     * msg : OK
     * data : 13
     */

    private int data;
    public int getData()
    {
        return data;
    }

    public void setData(int data)
    {
        this.data = data;
    }
}
