package com.example.administrator.myparkingos.ui.onlineMonitorPage;

import android.app.Activity;
import android.app.Dialog;
import android.text.TextUtils;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.example.administrator.mydistributedparkingos.R;
import com.example.administrator.myparkingos.common.assist.Base64;
import com.example.administrator.myparkingos.constant.CR;
import com.example.administrator.myparkingos.constant.JsonSearchParam;
import com.example.administrator.myparkingos.constant.RCodeEnum;
import com.example.administrator.myparkingos.model.GetServiceData;
import com.example.administrator.myparkingos.model.beans.Model;
import com.example.administrator.myparkingos.model.requestInfo.GetXXXCommonReq;
import com.example.administrator.myparkingos.model.requestInfo.UpdateCarPhotoReq;
import com.example.administrator.myparkingos.model.requestInfo.UpdateUserPhotoReq;
import com.example.administrator.myparkingos.model.responseInfo.GetCommonXXXResp;
import com.example.administrator.myparkingos.model.responseInfo.GetDepartmentResp;
import com.example.administrator.myparkingos.model.responseInfo.GetOperatorsResp;
import com.example.administrator.myparkingos.model.responseInfo.GetRightGroupsResp;
import com.example.administrator.myparkingos.model.responseInfo.GetUserInfoResp;
import com.example.administrator.myparkingos.myUserControlLibrary.DateTimePicker;
import com.example.administrator.myparkingos.myUserControlLibrary.MessageBox;
import com.example.administrator.myparkingos.myUserControlLibrary.niceSpinner.NiceSpinner;
import com.example.administrator.myparkingos.util.L;
import com.example.administrator.myparkingos.util.TimeConvertUtils;
import com.example.administrator.myparkingos.volleyUtil.callback.GsonCallback;
import com.google.gson.Gson;
import com.jude.http.RequestListener;
import com.jude.http.RequestManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by Administrator on 2017-02-16.
 * 【在线监控】 -->> 【车牌登记】 -->> 【添加人事信息】
 */
public class FormPersonnelAddView implements View.OnClickListener, GsonCallback.Listener
{
    private final Activity mActivity;
    private final Dialog dialog;
    private EditText txtUserNO;
    private EditText txtUserName;
    private DateTimePicker dpBirthDate;
    private DateTimePicker dpWorkDate;
    private RadioButton rbtMan;
    private RadioButton rbtWoman;
    private RadioButton rbtMarried;
    private RadioButton personnelAddUnMarried;
    private NiceSpinner cmbDeptName;
    private NiceSpinner cmbJob;
    private EditText txtIDCard;
    private EditText txtCarPosCount;
    private EditText txtTelephone;
    private EditText txtPhone;
    private EditText txtCredentials;
    private EditText txtNativePlace;
    private EditText txtHomeAddress;
    private Button btnSave;
    private Button btnUpdate;
    private Button btnCarPic;
    private Button btnPeoplePic;
    private Button btVedio;
    private Button btnColose;

    private Gson mGson = new Gson();
    public static final String METHOD_GETDEPARTMENT = "GetDepartment";
    private RadioGroup rgSex;
    private RadioGroup rgMarray;

    /// <summary>
    /// 人员图片
    /// </summary>
    byte[] PersonPhoto = null;
    /// <summary>
    /// 车图片
    /// </summary>
    byte[] CarPhoto = null;

    public FormPersonnelAddView(Activity activity)
    {
        mActivity = activity;
        dialog = new Dialog(activity); // @android:style/Theme.Dialog
        dialog.setContentView(R.layout.personneladd_activity);
        dialog.setCanceledOnTouchOutside(true);

        Window window = dialog.getWindow();
        WindowManager m = activity.getWindowManager();
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = window.getAttributes(); // 获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 1 / 2); // 改变的是dialog框在屏幕中的位置而不是大小
        p.width = (int) (d.getWidth() * 1 / 2); // 宽度设置为屏幕的0.65
        window.setAttributes(p);
        dialog.getWindow().setBackgroundDrawableResource(R.drawable.parkdowncard_background);
        dialog.setTitle(activity.getResources().getString(R.string.personnelAddTitle));
        initView();
        initSpinner();

    }

    private List<String> deptNameList;

    private String[] jobList;

    /**
     * 初始化下拉选择框
     */
    private void initSpinner()
    {
        //显示部分名称
        deptNameList = new ArrayList<String>();
        cmbDeptName.setSpinnerListener(new NiceSpinner.SpinnerListener()
        {
            @Override
            public void OnSpinnerItemClick(int pos)
            {

            }
        });
        cmbDeptName.refreshData(deptNameList, 0);

        // 显示现任职位列表信息
        jobList = mActivity.getResources().getStringArray(R.array.jobType);
        cmbJob.setSpinnerListener(new NiceSpinner.SpinnerListener()
        {
            @Override
            public void OnSpinnerItemClick(int pos)
            {

            }
        });
        cmbJob.refreshData(Arrays.asList(jobList), 0, true);
    }


    private void initView()
    {
        txtUserNO = (EditText) dialog.findViewById(R.id.txtUserNO);
        txtUserName = (EditText) dialog.findViewById(R.id.txtUserName);
        dpBirthDate = (DateTimePicker) dialog.findViewById(R.id.dpBirthDate);
        dpWorkDate = (DateTimePicker) dialog.findViewById(R.id.dpWorkDate);
        rbtMan = (RadioButton) dialog.findViewById(R.id.rbtMan);
        rbtWoman = (RadioButton) dialog.findViewById(R.id.rbtWoman);
        rbtMarried = (RadioButton) dialog.findViewById(R.id.rbtMarried);
        personnelAddUnMarried = (RadioButton) dialog.findViewById(R.id.personnelAddUnMarried);
        cmbDeptName = (NiceSpinner) dialog.findViewById(R.id.cmbDeptName);
        cmbJob = (NiceSpinner) dialog.findViewById(R.id.cmbJob);
        txtIDCard = (EditText) dialog.findViewById(R.id.txtIDCard);
        txtCarPosCount = (EditText) dialog.findViewById(R.id.txtCarPosCount);
        txtTelephone = (EditText) dialog.findViewById(R.id.txtTelephone);
        txtPhone = (EditText) dialog.findViewById(R.id.txtPhone);
        txtCredentials = (EditText) dialog.findViewById(R.id.txtCredentials);
        txtNativePlace = (EditText) dialog.findViewById(R.id.txtNativePlace);
        txtHomeAddress = (EditText) dialog.findViewById(R.id.txtHomeAddress);
        btnSave = (Button) dialog.findViewById(R.id.btnSave);
        btnUpdate = (Button) dialog.findViewById(R.id.btnUpdate);
        btnCarPic = (Button) dialog.findViewById(R.id.btnCarPic);
        btnPeoplePic = (Button) dialog.findViewById(R.id.btnPeoplePic);
        btVedio = (Button) dialog.findViewById(R.id.btVedio);
        btnColose = (Button) dialog.findViewById(R.id.btnColose);

        rgSex = (RadioGroup) dialog.findViewById(R.id.rgSex);
        rgMarray = (RadioGroup) dialog.findViewById(R.id.rgMarray);

        btnSave.setOnClickListener(this);
        btnUpdate.setOnClickListener(this);
        btnCarPic.setOnClickListener(this);
        btnPeoplePic.setOnClickListener(this);
        btVedio.setOnClickListener(this);
        btnColose.setOnClickListener(this);
    }

    private boolean isManSex()
    {
        for (int i = 0; i < rgSex.getChildCount(); i++)
        {
            RadioButton childAt = (RadioButton) rgSex.getChildAt(i);
            if (childAt.isChecked() && i == 0)
            {
                return true;
            }
        }

        return false;
    }

    private boolean isWomanSex()
    {
        for (int i = 0; i < rgSex.getChildCount(); i++)
        {
            RadioButton childAt = (RadioButton) rgSex.getChildAt(i);
            if (childAt.isChecked() && i == 1)
            {
                return true;
            }
        }

        return false;
    }

    private boolean isMarray()
    {
        for (int i = 0; i < rgMarray.getChildCount(); i++)
        {
            RadioButton childAt = (RadioButton) rgMarray.getChildAt(i);
            if (childAt.isChecked() && i == 0)
            {
                return true;
            }
        }

        return false;
    }

    private boolean isUnMarray()
    {
        for (int i = 0; i < rgMarray.getChildCount(); i++)
        {
            RadioButton childAt = (RadioButton) rgMarray.getChildAt(i);
            if (childAt.isChecked() && i == 1)
            {
                return true;
            }
        }

        return false;
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.btnSave:
                btnOnSave();
                dismiss();
                break;
            case R.id.btnUpdate:
                break;
            case R.id.btnCarPic://车辆图片 从文件中获取图片 没有实现
                btnCarPic_Click();
                break;
            case R.id.btnPeoplePic:// 人员图片 从文件中获取图片 没有实现
                btnPeoplePic_Click();
                break;
            case R.id.btVedio:
                btVedio_Click(); // 利用外接的相机头进行拍照获取图片即可 没有实现
                break;
            case R.id.btnColose:
                dismiss();
                break;
        }
    }

    private void btVedio_Click()
    {

    }

    private void btnPeoplePic_Click()
    {

    }

    private void btnCarPic_Click()
    {

    }


    private void btnOnSave()
    {
        try
        {
            String strUserNO = txtUserNO.getText().toString().trim();
            String strUserName = txtUserName.getText().toString().trim();
            String strDept = cmbDeptName.getCurrentText();

//            if (cmbCPH.Text != "") // cmdCPH 没有显示
//            {
//                if (!CR.CheckUpCPH(cmbCPH.Text))
//                {
//                    MessageBox.Show("车牌号不规范!请重新输入！\n\n【" + cmbCPH.Text + "】会引起车牌数据显示错误", "提示", MessageBoxButton.OK, MessageBoxImage.Information);
//                    return;
//                }
//            }
            GetUserInfoResp.DataBean userInfo = getUserInfo();
            if (TextUtils.isEmpty(userInfo.getUserNO())) // 5
            {
                MessageBox.show(mActivity, "编号不能为空!");
                return;
            }
            else
            {
                requestExistByUserNo(userInfo);
            }

            if (TextUtils.isEmpty(Model.sUserName)) // 4
            {
                MessageBox.show(mActivity, "用户名不能为空!");
                return;
            }

            updateUserInfo(userInfo);

            CPHDJfxPersonnelDataHandler(strUserNO, strUserName, strDept);
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            MessageBox.show(mActivity, ex.getMessage());
        }
    }

    protected void CPHDJfxPersonnelDataHandler(String strUserNO, String strUserName, String strDept)
    {

    }

    private void requestExistByUserNo(final GetUserInfoResp.DataBean userInfo)
    {
        GetXXXCommonReq getXXXCommonReq = new GetXXXCommonReq();
        getXXXCommonReq.setToken(Model.token);
        getXXXCommonReq.setJsonSearchParam(JsonSearchParam.getByUserNo(userInfo.getUserNO()));

        final String resultUrl = GetServiceData.getResultUrl("GetUserInfo", getXXXCommonReq);
        RequestManager.getInstance().get(resultUrl, new RequestListener()
        {
            @Override
            public void onRequest()
            {
            }

            @Override
            public void onSuccess(String s)
            {
                GetUserInfoResp getUserInfoResp = mGson.fromJson(s, GetUserInfoResp.class);
                if (Integer.parseInt(getUserInfoResp.getRcode()) != RCodeEnum.OK.getValue())
                {
                    L.e(resultUrl + getUserInfoResp.getMsg());
                }
                else
                {
                    if (getUserInfoResp.getData() == null || getUserInfoResp.getData().size() == 0)
                    {//等待处理
                        updateUserInfo(userInfo);
                    }
                    else// 返回出去
                    {
                        MessageBox.show(mActivity, "编号已存在!");
                    }
                }
            }

            @Override
            public void onError(String s)
            {
            }
        });
    }

    private void updateUserInfo(final GetUserInfoResp.DataBean userInfo)
    {
        GetXXXCommonReq getXXXCommonReq = new GetXXXCommonReq();
        getXXXCommonReq.setToken(Model.token);
        getXXXCommonReq.setJsonModel(JsonSearchParam.getInfoModel(userInfo));
        final String resultUrl = GetServiceData.getResultUrl("AddUserInfo", getXXXCommonReq);
        RequestManager.getInstance().get(resultUrl, new RequestListener()
        {
            @Override
            public void onRequest()
            {
            }

            @Override
            public void onSuccess(String s)
            {
                GetCommonXXXResp commonXXXResp = mGson.fromJson(s, GetCommonXXXResp.class);
                if (Integer.parseInt(commonXXXResp.getRcode()) != RCodeEnum.OK.getValue())
                {
                    L.e(resultUrl + commonXXXResp.getMsg());
                }
                else
                {
                    if (commonXXXResp.getData() > 0)
                    {
                        if (PersonPhoto != null)//上传人员图像
                        {
                            requestPersonPhoto(userInfo.getUserNO(), PersonPhoto);
                        }

                        if (CarPhoto != null) // cph != "" 上传车辆照片 这里带有图片
                        {
                            requestCarPhoto(userInfo.getUserNO(), "", PersonPhoto);
                        }

                        requstAddOperators(userInfo);
                    }
                    else
                    {
                    }
                }
            }

            @Override
            public void onError(String s)
            {
            }
        });
    }

    private void requestPersonPhoto(String userNo, byte[] bytes)
    {
        UpdateUserPhotoReq updateUserPhotoReq = new UpdateUserPhotoReq();
        updateUserPhotoReq.setToken(Model.token);
        updateUserPhotoReq.setUserNo(userNo);
        updateUserPhotoReq.setPhoto(Base64.encodeToString(bytes, Base64.DEFAULT));

        String resultUrl = GetServiceData.getResultUrl("UpdateUserPhoto", updateUserPhotoReq);
        RequestManager.getInstance().get(resultUrl, new GsonCallback<>(GetCommonXXXResp.class, this, updateUserPhotoReq, resultUrl, -1));
    }

    private void requestCarPhoto(String userNo, String cph, byte[] bytes)
    {
        UpdateCarPhotoReq carPhotoReq = new UpdateCarPhotoReq();
        carPhotoReq.setToken(Model.token);
        carPhotoReq.setCardNo(userNo); // cardNO <--> userNO
        carPhotoReq.setCPH(cph);
        carPhotoReq.setPhoto(Base64.encodeToString(bytes, Base64.DEFAULT));

        String resultUrl = GetServiceData.getResultUrl("UpdateCarPhoto", carPhotoReq);
        RequestManager.getInstance().get(resultUrl, new GsonCallback<>(GetCommonXXXResp.class, this, carPhotoReq, resultUrl, -1));
    }

    private void requstAddOperators(GetUserInfoResp.DataBean userInfo)
    {
        if ((
                userInfo.getJob().equals("操作员")
                        || userInfo.getJob().equals("财务")
        )
                && (Integer.parseInt(userInfo.getUserNO()) <= 80099 && Integer.parseInt(userInfo.getUserNO()) > 80001))
        {
            GetOperatorsResp.DataBean dataBean = new GetOperatorsResp.DataBean();
            dataBean.setCardNO(userInfo.getUserNO());
            dataBean.setCardType(userInfo.getJob()); // carType <--> job
            dataBean.setUserNO(userInfo.getUserNO());
            dataBean.setDeptName(userInfo.getDeptName());
            dataBean.setUserName(userInfo.getUserName());
            dataBean.setPwd(CR.UserMd5(""));
            dataBean.setCardState(0);

            if (userInfo.getJob().equals("操作员"))
            {
                requestGetRightGroupID("收费员组", dataBean);
            }
            else if (userInfo.getJob().equals("财务"))
            {
                requestGetRightGroupID("财务组", dataBean);
            }
        }
    }

    private void requestGetRightGroupID(String groupName, GetOperatorsResp.DataBean operators)
    {
        GetXXXCommonReq getXXXCommonReq = new GetXXXCommonReq();
        getXXXCommonReq.setToken(Model.token);
        getXXXCommonReq.setJsonSearchParam(JsonSearchParam.getRightGroup(groupName));

        final String resultUrl = GetServiceData.getResultUrl("GetRightGroups", getXXXCommonReq);
        RequestManager
                .getInstance().get(resultUrl, new GsonCallback<>(GetRightGroupsResp.class, this, operators, resultUrl, -1));
    }

    private long getDeptNameId(String deptName)
    {
        if (localDepartList == null || localDepartList.size() == 0)
        {
            return -1;
        }

        for (GetDepartmentResp.DataBean item : localDepartList)
        {
            if (item.getDeptName().equals(deptName))
            {
                return item.getID();
            }
        }
        return -1;
    }


    /**
     * 获取界面上的UserInfo信息
     *
     * @return
     */
    private GetUserInfoResp.DataBean getUserInfo()
    {
        GetUserInfoResp.DataBean dataBean = new GetUserInfoResp.DataBean();
        dataBean.setUserNO(txtUserNO.getText().toString().trim());
        dataBean.setUserName(txtUserName.getText().toString().trim());
        if (isManSex())
        {
            dataBean.setSex("男");
        }
        else
        {
            dataBean.setSex("女");
        }

        dataBean.setHomeAddress(txtHomeAddress.getText().toString().trim());
        String currentText = cmbDeptName.getCurrentText();
        if (!TextUtils.isEmpty(currentText))
        {
            long deptNameId = getDeptNameId(currentText);
            if (deptNameId > 0)
            {
                dataBean.setDeptId(deptNameId);
            }
        }
        dataBean.setDeptName(cmbDeptName.getCurrentText());
        dataBean.setJob(cmbJob.getCurrentText());
        dataBean.setWorkTime(TimeConvertUtils.toLongDateString(dpWorkDate.getDateTime()));
        dataBean.setBirthDate(TimeConvertUtils.toLongDateString(dpBirthDate.getDateTime()));
        dataBean.setIDCard(txtIDCard.getText().toString().trim());

        if (isMarray())
        {
            dataBean.setMaritalStatus("已婚");
        }
        else
        {
            dataBean.setMaritalStatus("未婚");
        }

        dataBean.setTelNumber(txtTelephone.getText().toString().trim());
        dataBean.setMobNumber(txtPhone.getText().toString().trim());
        dataBean.setNativePlace(txtNativePlace.getText().toString().trim());

        dataBean.setSkill(txtCredentials.getText().toString().trim());
        String trim = txtNativePlace.getText().toString().trim();
        if (TextUtils.isEmpty(trim))
        {
            dataBean.setCarPlaceNo(1);
        }
        else
        {
            dataBean.setCarPlaceNo(Integer.parseInt(trim));
        }
        return dataBean;
    }

    private void prepareInitData()
    {
        GetXXXCommonReq getXXXCommonReq = new GetXXXCommonReq();
        getXXXCommonReq.setToken(Model.token);

        String resultUrl = GetServiceData.getInstance().getResultUrl(METHOD_GETDEPARTMENT, getXXXCommonReq);
        RequestManager
                .getInstance().get(resultUrl, new GsonCallback<>(GetDepartmentResp.class, this, getXXXCommonReq, resultUrl, -1));
    }

    /**
     * 显示数据
     */
    public void show()
    {
        if (dialog != null && dialog.isShowing() == false)
        {
            prepareInitData();
            dialog.show();
        }
    }

    /**
     * 隐藏
     */
    public void dismiss()
    {
        if (dialog != null && dialog.isShowing())
        {
            dialog.dismiss();
        }
    }

    @Override
    public void success(Object reqData, Object respData, String url, int paramInt)
    {
        if (respData instanceof GetDepartmentResp)
        {
            GetDepartmentResp departmentResp = (GetDepartmentResp) respData;
            if (Integer.parseInt(departmentResp.getRcode()) != RCodeEnum.OK.getValue())
            {
                L.e(departmentResp.getMsg());
            }
            else
            {
                if (departmentResp.getData() == null || departmentResp.getData().size() == 0)
                {
                    L.e("departmentResp.getData() == null || departmentResp.getData().size() == 0");
                    return;
                }

                updateDeptName(departmentResp.getData());
            }
        }
        else if (respData instanceof GetRightGroupsResp)
        {
            GetRightGroupsResp rightGroupsResp = (GetRightGroupsResp) respData;
            if (Integer.parseInt(rightGroupsResp.getRcode()) != RCodeEnum.OK.getValue())
            {
                L.e(rightGroupsResp.getMsg());
            }
            else
            {
                GetOperatorsResp.DataBean data = (GetOperatorsResp.DataBean) reqData;
                if (rightGroupsResp.getData() == null || rightGroupsResp.getData().size() == 0)
                {
                    L.e("departmentResp.getData() == null || departmentResp.getData().size() == 0");
                    data.setUserLevel(0);
                }
                else
                {
                    data.setUserLevel((int) (rightGroupsResp.getData().get(0).getID()));
                }
                requestAddOperators(data);
            }
        }
        else if (respData instanceof GetCommonXXXResp)
        {
            GetCommonXXXResp commonXXXResp = (GetCommonXXXResp) respData;
            if (Integer.parseInt(commonXXXResp.getRcode()) != RCodeEnum.OK.getValue())
            {
                L.e(commonXXXResp.getMsg());
            }
            else
            {
                L.e(url + " 请求服务成功");
            }
        }
    }

    private void requestAddOperators(GetOperatorsResp.DataBean operators)
    {
        GetXXXCommonReq getXXXCommonReq = new GetXXXCommonReq();
        getXXXCommonReq.setToken(Model.token);
        getXXXCommonReq.setJsonModel(JsonSearchParam.getInfoModel(operators));

        final String resultUrl = GetServiceData.getInstance().getResultUrl("AddOperators", getXXXCommonReq);
        RequestManager
                .getInstance().get(resultUrl, new RequestListener()
        {
            @Override
            public void onRequest()
            {
            }

            @Override
            public void onSuccess(String s)
            {
                GetCommonXXXResp getCommonXXXResp = mGson.fromJson(s, GetCommonXXXResp.class);
                if (Integer.parseInt(getCommonXXXResp.getRcode()) != RCodeEnum.OK.getValue())
                {
                    L.e(getCommonXXXResp.getMsg());
                }
                else
                {
                    L.e(resultUrl + " 成功 " + getCommonXXXResp.toString());
                    MessageBox.show(mActivity, "添加成功!");
                }
            }

            @Override
            public void onError(String s)
            {

            }
        });
    }

    private List<GetDepartmentResp.DataBean> localDepartList;

    private void updateDeptName(List<GetDepartmentResp.DataBean> data)
    {
        localDepartList = data;
        ArrayList<String> strings = new ArrayList<>();
        for (GetDepartmentResp.DataBean item : data)
        {
            strings.add(item.getDeptName());
        }
        cmbDeptName.refreshData(strings, 0);
    }

    @Override
    public void error(Object data, String url, String errorString)
    {
        L.e("服务器连接失败");
    }
}
