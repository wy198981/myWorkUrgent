package com.example.administrator.myparkingos.model.requestInfo;

/**
 * Created by Administrator on 2017-06-20.
 */
public class AddIDInfoReq
{
    private String token; // 用户登录时候获取的token值
    private String jsonModel; // JSON格式的数据Model。
    private String CallBack; // 是否使用JSONP方式。关于JSONP方式请参考Javascript跨域访问一节。

    public String getToken()
    {
        return token;
    }

    public void setToken(String token)
    {
        this.token = token;
    }

    public String getJsonModel()
    {
        return jsonModel;
    }

    public void setJsonModel(String jsonModel)
    {
        this.jsonModel = jsonModel;
    }

    public String getCallBack()
    {
        return CallBack;
    }

    public void setCallBack(String callBack)
    {
        CallBack = callBack;
    }

    @Override
    public String toString()
    {
        return "AddIDInfoReq{" +
                "token='" + token + '\'' +
                ", jsonModel='" + jsonModel + '\'' +
                ", CallBack='" + CallBack + '\'' +
                '}';
    }
}
