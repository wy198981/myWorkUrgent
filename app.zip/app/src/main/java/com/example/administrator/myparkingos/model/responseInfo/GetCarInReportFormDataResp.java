package com.example.administrator.myparkingos.model.responseInfo;

import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2017-07-06.
 */
public class GetCarInReportFormDataResp
{
    private String rcode;//		Y	参考错误码列表
    private String msg;//   	Y	错误信息
    private BeanData data;//	N	结构参考下面的说明。

    @Override
    public String toString()
    {
        return "GetCarInReportFormDataResp{" +
                "rcode='" + rcode + '\'' +
                ", msg='" + msg + '\'' +
                ", data=" + data +
                '}';
    }

    public String getRcode()
    {
        return rcode;
    }

    public void setRcode(String rcode)
    {
        this.rcode = rcode;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg(String msg)
    {
        this.msg = msg;
    }

    public BeanData getData()
    {
        return data;
    }

    public void setData(BeanData data)
    {
        this.data = data;
    }

    public static class BeanData
    {
        private String StartTime; // Y 服务器当前日期
        private String EndTime; // Y 服务器当前日期
        private List<GetQueryResp.DataBean> Fields; // Y 报表查询条件列表。结构参考报表查询条件数据结构
        private Map<String, List<GetQuerySchemeResp.DataBean>> SavedPlans; // Y 已保存的查询方案组成的键值对对象。键为方案名称；值为查询方案记录组成的数组，数组元素结构参考报表查询方案数据结构。
        private List<OperatorSymbol> Operators; // Y 比较关系组成的键值对对象数组。数组元素的结构参考下面的说明。

        @Override
        public String toString()
        {
            return "BeanData{" +
                    "StartTime='" + StartTime + '\'' +
                    ", EndTime='" + EndTime + '\'' +
                    ", Fields=" + Fields +
                    ", SavedPlans=" + SavedPlans +
                    ", Operators=" + Operators +
                    '}';
        }

        public String getStartTime()
        {
            return StartTime;
        }

        public void setStartTime(String startTime)
        {
            StartTime = startTime;
        }

        public String getEndTime()
        {
            return EndTime;
        }

        public void setEndTime(String endTime)
        {
            EndTime = endTime;
        }
        public List<GetQueryResp.DataBean> getFields()
        {
            return Fields;
        }

        public void setFields(List<GetQueryResp.DataBean> fields)
        {
            Fields = fields;
        }

        public Map<String, List<GetQuerySchemeResp.DataBean>> getSavedPlans()
        {
            return SavedPlans;
        }

        public void setSavedPlans(Map<String, List<GetQuerySchemeResp.DataBean>> savedPlans)
        {
            SavedPlans = savedPlans;
        }

        public List<OperatorSymbol> getOperators()
        {
            return Operators;
        }

        public void setOperators(List<OperatorSymbol> operators)
        {
            Operators = operators;
        }
    }

    public static class OperatorSymbol
    {
        private int Key;// Y	操作符代号
        private String Value;// Y	操作符描述

        @Override
        public String toString()
        {
            return "Operators{" +
                    "Key=" + Key +
                    ", Value='" + Value + '\'' +
                    '}';
        }

        public int getKey()
        {
            return Key;
        }

        public void setKey(int key)
        {
            Key = key;
        }

        public String getValue()
        {
            return Value;
        }

        public void setValue(String value)
        {
            Value = value;
        }
    }
}
