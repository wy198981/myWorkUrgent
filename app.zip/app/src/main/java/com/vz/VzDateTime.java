package com.vz;

public class VzDateTime {
	public short nYear;	/**<年*/
	public short nMonth;	/**<月*/
	public short nMDay;	/**<日*/
	public short nHour;	/**<时*/
	public short nMin;		/**<分*/
	public short nSec;		/**<秒*/
}
