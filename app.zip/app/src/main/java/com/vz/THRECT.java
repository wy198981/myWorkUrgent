package com.vz;

public class THRECT {
	  public int left;	/**<左*/
	   public  int top;	/**<上*/
	   public int right;	/**<右*/
	   public int bottom;	/**<下*/

	@Override
	public String toString()
	{
		return "THRECT{" +
				"left=" + left +
				", top=" + top +
				", right=" + right +
				", bottom=" + bottom +
				'}';
	}
}
