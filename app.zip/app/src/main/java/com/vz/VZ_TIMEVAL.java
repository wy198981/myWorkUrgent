package com.vz;

public class VZ_TIMEVAL {
	  public int uTVSec;
	  public int uTVUSec;

	@Override
	public String toString()
	{
		return "VZ_TIMEVAL{" +
				"uTVSec=" + uTVSec +
				", uTVUSec=" + uTVUSec +
				'}';
	}
}
